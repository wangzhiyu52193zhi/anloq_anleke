package com.anloq.adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.anloq.activity.EditAuthActivity;
import com.anloq.anleke.R;
import com.anloq.model.AuthManagerBean;
import com.anloq.ui.GlideCircleTransform;
import com.anloq.utils.TimeUtil;
import com.bumptech.glide.Glide;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/4/27 :)
 * Function:授权管理列表数据的适配器
 */

public class AuthManagerAdapter extends BaseAdapter {

    private int room_id;
    private int keyid;
    private int relation;
    private int zoneid;
    private Context mContext;
    private List<AuthManagerBean.ObjectBean> authBeanList;

    public AuthManagerAdapter(Context mContext, List<AuthManagerBean.ObjectBean> authBeanList, int keyid, int zoneid, int relation, int room_id) {
        this.mContext = mContext;
        this.authBeanList = authBeanList;
        this.keyid = keyid;
        this.zoneid = zoneid;
        this.relation = relation;
        this.room_id = room_id;
    }

    @Override
    public int getCount() {
        return authBeanList.size();
    }

    @Override
    public Object getItem(int position) {
        return authBeanList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_auth_manager, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final AuthManagerBean.ObjectBean objectBean = authBeanList.get(position);
        if (!"".equals(objectBean.getHeadpic()) && objectBean.getHeadpic() != null) {
            Glide.with(mContext).load(objectBean.getHeadpic())
                    .transform(new GlideCircleTransform(mContext)).into(holder.ivIcon);
        }
        holder.tvName.setText(objectBean.getUser_name());
        switch (objectBean.getUser_type()) {
            case 2:
                holder.tvIdentify.setText("家人");
                break;
            case 3:
                holder.tvIdentify.setText("租客");
                break;
            case 4:
                holder.tvIdentify.setText("访客");
                break;
        }
        holder.tvIndate.setText(objectBean.getAuth_start_date().substring(0, 10) + " - " +
                objectBean.getAuth_end_date().substring(0, 10));
        holder.tvBinding.setText("未绑定任何设备");
        holder.ivState.setVisibility(objectBean.isIs_freeze() ? View.VISIBLE : View.GONE);
        boolean isInvalidDate = TimeUtil.checkIsInvalidDate(objectBean.getAuth_start_date(), objectBean.getAuth_end_date());
        holder.ivOutDate.setVisibility(isInvalidDate ? View.VISIBLE : View.GONE);
        holder.llAuthItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, EditAuthActivity.class);
                int user_id = objectBean.getUser_id();
                int resident_id = objectBean.getResident_id();
                int auth_key_id = objectBean.getAuth_key_id();
                int master_resident_id = objectBean.getMaster_resident_id();
                String user_phone = objectBean.getUser_phone();
                String auth_start_date = objectBean.getAuth_start_date();
                String auth_end_date = objectBean.getAuth_end_date();
                int user_type = objectBean.getUser_type();
                intent.putExtra("user_id", user_id);
                intent.putExtra("resident_id", resident_id);
                intent.putExtra("auth_key_id", auth_key_id);
                intent.putExtra("master_resident_id", master_resident_id);
                intent.putExtra("user_phone", user_phone);
                intent.putExtra("auth_start_date", auth_start_date);
                intent.putExtra("auth_end_date", auth_end_date);
                intent.putExtra("user_type", user_type);
                intent.putExtra("zoneid", zoneid);
                intent.putExtra("keyid", keyid);
                intent.putExtra("roomid", room_id);
                Log.e("TAG", "zoneid===" + zoneid + ",keyid===" + keyid);
                intent.putExtra("relation", relation);
                mContext.startActivity(intent);
            }
        });

        return convertView;
    }

    static class ViewHolder {
        @BindView(R.id.ivIcon)
        ImageView ivIcon;
        @BindView(R.id.tvName)
        TextView tvName;
        @BindView(R.id.tvIdentify)
        TextView tvIdentify;
        @BindView(R.id.tvIndate)
        TextView tvIndate;
        @BindView(R.id.tvBinding)
        TextView tvBinding;
        @BindView(R.id.ivState)
        ImageView ivState;
        @BindView(R.id.ivOutDate)
        ImageView ivOutDate;
        @BindView(R.id.ivWatch)
        ImageView ivWatch;
        @BindView(R.id.ivBand)
        ImageView ivBand;
        @BindView(R.id.llAuthItem)
        LinearLayout llAuthItem;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
