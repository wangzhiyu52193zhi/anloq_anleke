package com.anloq.runnable;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.model.BtDeviceBean;
import com.anloq.model.EventBusMsg;
import com.anloq.model.VkeyBean;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;
import org.litepal.crud.DataSupport;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import okhttp3.Call;
import okhttp3.MediaType;

/**
 * Created by xpf on 2018/1/29 :)
 * Function:使用MAC匹配设备实现在线开锁
 */

public class MatchDeviceRunnable implements Runnable {

    private String mKeyId;
    private Context mContext;
    private int mUnitId = -1;
    private int mDeviceId = -1;
    private boolean isHavingMac = false;
    private HashSet<String> macSet; // 扫描到的mac地址集合
    private static final String TAG = MatchDeviceRunnable.class.getSimpleName();

    /**
     * constructor
     *
     * @param context
     * @param keyId
     * @param macSet
     */
    public MatchDeviceRunnable(Context context, String keyId, HashSet<String> macSet) {
        this.mKeyId = keyId;
        this.macSet = macSet;
        this.mContext = context;
    }

    public void setMacSet(HashSet<String> macSet) {
        this.macSet = macSet;
    }

    public void setKeyId(String mKeyId) {
        this.mKeyId = mKeyId;
    }

    public void setContext(Context mContext) {
        this.mContext = mContext;
    }

    @Override
    public void run() {
        startMatchMac();
    }

    /**
     * 开始匹配mac地址进行在线开锁
     */
    private void startMatchMac() {
        if (macSet.size() > 0) {
            for (String mac : macSet) {
                // 1.取出对应的keyid的mac地址列表
                List<VkeyBean> macList = DataSupport.where("key_id = ?", mKeyId).find(VkeyBean.class);
                if (macList.size() > 0) {
                    List<String> mBtMacList = macList.get(macList.size() - 1).getBt_device_mac();
                    // 2.判断扫描到的mac是否存在于keyid的mac地址列表
                    if (mBtMacList != null && mBtMacList.size() > 0) {
                        for (int i = 0; i < mBtMacList.size(); i++) {
                            if (mac.equals(mBtMacList.get(i))) {
                                isHavingMac = true;
                                break; // 一旦找到匹配的mac就跳出循环
                            }
                        }
                    }

                    if (isHavingMac) {
                        // 查询数据库表，mac地址
                        List<BtDeviceBean> keyList = DataSupport.where("mac_attr = ?", mac).find(BtDeviceBean.class);
                        if (keyList.size() > 0) {
                            BtDeviceBean btDeviceBean = keyList.get(keyList.size() - 1);
                            mUnitId = btDeviceBean.getUnit_id();
                            mDeviceId = btDeviceBean.getDeviceid();
                            break; // 一旦取到mUnitId和mDeviceId就跳出循环
                        }
                    }
                } else {
                    com.orhanobut.logger.Logger.t(TAG).e("Not find mac address match with keyid!");
                }
            }

            checkValueAndUnlock();

        } else {
            showNotFindDevice();
        }
    }

    /**
     * 校验值的合法性并开锁
     */
    private void checkValueAndUnlock() {
        if (mDeviceId != -1 && mUnitId != -1) {
            unLock(mDeviceId, mUnitId);
            resetValue();
        } else {
            showNotFindDevice();
        }
    }

    /**
     * 重置为初始值
     */
    private void resetValue() {
        mUnitId = -1;
        mDeviceId = -1;
        isHavingMac = false;
        if (macSet != null && macSet.size() > 0) {
            macSet.clear();
        }
    }

    /**
     * 弹出没有找到门禁设备吐司
     */
    private void showNotFindDevice() {
        ((Activity) mContext).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ToastUtil.show(mContext.getString(R.string.unlock_fail));
                // 处理没有发现设备时的动画显示
                EventBus.getDefault().post(new EventBusMsg("unlockresult", ""));
            }
        });
    }

    /**
     * 直接远程开锁
     *
     * @param deviceId
     * @param unitId
     */
    private void unLock(int deviceId, int unitId) {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String account = SpUtil.getInstance().getString("account", "");

        String url = Constants.UNLOCKINCALLING + uid + Constants.TOKEN + token;
        Log.e(TAG, "UnlockInCalling_url===" + url);

        HashMap<String, Object> map = new HashMap<>();
        map.put("eqt_id", deviceId);
        map.put("unit_id", unitId);
        map.put("command", 1);
        map.put("phone", account);
        String content = new Gson().toJson(map);
        Logger.t(TAG).json(content);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        ToastUtil.show(mContext.getString(R.string.net_error));
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                    }
                });
    }
}
