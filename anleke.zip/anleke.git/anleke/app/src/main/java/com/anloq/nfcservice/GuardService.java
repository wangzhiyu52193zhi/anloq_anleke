package com.anloq.nfcservice;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import app.project.IMyAidlInterface;

/**
 * Created by Steven on 2017/8/9.
 * 守护进程
 */

public class GuardService extends Service {
    MyConn conn;
    MyBinder binder;

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        conn = new MyConn();
        binder = new MyBinder();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //Toast.makeText(this, " 远程服务started", Toast.LENGTH_SHORT).show();
        this.bindService(new Intent(this, HuaweiService.class), conn, Context.BIND_IMPORTANT);
        return START_STICKY;
    }

    class MyBinder extends IMyAidlInterface.Stub {
        @Override
        public String getServiceName() throws RemoteException {
            return GuardService.class.getSimpleName();
        }
    }

    class MyConn implements ServiceConnection {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            // Toast.makeText(GuardService.this, "本地服务killed", Toast.LENGTH_SHORT).show();
            //开启本地服务
            GuardService.this.startService(new Intent(GuardService.this, HuaweiService.class));
            //绑定本地服务
            GuardService.this.bindService(new Intent(GuardService.this, HuaweiService.class), conn, Context.BIND_IMPORTANT);
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("GuardService", "onDestroy: "+"GuardService进程被杀死！" );
        //开启本地服务
        GuardService.this.startService(new Intent(GuardService.this, HuaweiService.class));
        //绑定本地服务
        GuardService.this.bindService(new Intent(GuardService.this, HuaweiService.class), conn, Context.BIND_IMPORTANT);
    }
}
