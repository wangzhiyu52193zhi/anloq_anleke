package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/3/27 :)
 * Function:城区数据
 */

public class CityBean {

    /**
     * name : cites
     * object : [{"city_id":1,"city_name":"朝阳区"},{"city_id":392,"city_name":"海淀区"},{"city_id":393,"city_name":"东城区"},{"city_id":394,"city_name":"西城区"},{"city_id":395,"city_name":"丰台区"},{"city_id":396,"city_name":"石景山区"},{"city_id":397,"city_name":"通州区"},{"city_id":398,"city_name":"昌平区"},{"city_id":399,"city_name":"顺义区"},{"city_id":400,"city_name":"怀柔区"},{"city_id":401,"city_name":"密云区"},{"city_id":402,"city_name":"延庆区"},{"city_id":403,"city_name":"平谷区"},{"city_id":404,"city_name":"大兴区"},{"city_id":405,"city_name":"门头沟区"},{"city_id":406,"city_name":"房山区"}]
     * code : 200
     */

    private String name;
    private int code;
    private List<ObjectBean> object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<ObjectBean> getObject() {
        return object;
    }

    public void setObject(List<ObjectBean> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * city_id : 1
         * city_name : 朝阳区
         */

        private int city_id;
        private String city_name;

        public int getCity_id() {
            return city_id;
        }

        public void setCity_id(int city_id) {
            this.city_id = city_id;
        }

        public String getCity_name() {
            return city_name;
        }

        public void setCity_name(String city_name) {
            this.city_name = city_name;
        }
    }
}
