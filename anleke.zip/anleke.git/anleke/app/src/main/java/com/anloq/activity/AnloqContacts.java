package com.anloq.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.anloq.adapter.AnloqContactAdapter;
import com.anloq.anleke.R;
import com.anloq.model.AnloqContactBean;
import com.anloq.utils.MessageProvider;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

// 安络联系人
public class AnloqContacts extends Activity {

    private static final String TAG = AnloqContacts.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.listView)
    ListView listView;
    @BindView(R.id.tvNoData)
    TextView tvNoData;
    private Context mContext;
    private AnloqContactAdapter adapter;
    private List<AnloqContactBean> allAnloqContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anloq_contacts);
        ButterKnife.bind(this);
        mContext = this;
        tvTitle.setText(R.string.anloq_contact);
        intContactData();
        initListener();
    }

    private void initListener() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String phone = allAnloqContacts.get(position).getPhone();
                Intent intent = getIntent();
                Bundle data = new Bundle();
                data.putString("phone", phone);
                intent.putExtras(data);
                AnloqContacts.this.setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

    private void intContactData() {
        allAnloqContacts = MessageProvider.getInstance().getAllAnloqContacts();
        if (allAnloqContacts != null && allAnloqContacts.size() > 0) {
            tvNoData.setVisibility(View.GONE);
            adapter = new AnloqContactAdapter(mContext, allAnloqContacts);
            listView.setAdapter(adapter);
        } else {
            tvNoData.setVisibility(View.VISIBLE);
        }
    }

    @OnClick(R.id.ivBack)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
        }
    }
}
