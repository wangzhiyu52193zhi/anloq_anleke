package com.anloq.model;

/**
 * Created by xpf on 2017/4/11 :)
 * Function:开锁结果的Bean
 */

public class UnlockResult {

    /**
     * name : popmsg
     * object : {"title":"远程开门","content":"门禁已经打开！","command":0}
     */

    private String name;
    private ObjectBean object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * title : 远程开门
         * content : 门禁已经打开！
         * command : 0
         */

        private String title;
        private String content;
        private int command;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getCommand() {
            return command;
        }

        public void setCommand(int command) {
            this.command = command;
        }
    }
}
