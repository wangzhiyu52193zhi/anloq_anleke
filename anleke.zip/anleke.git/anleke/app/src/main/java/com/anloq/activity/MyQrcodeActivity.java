package com.anloq.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.anleke.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

// 我的二维码
public class MyQrcodeActivity extends Activity {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.ivQrcode)
    ImageView ivQrcode;
    @BindView(R.id.tvSave)
    TextView tvSave;
    @BindView(R.id.tvWechat)
    TextView tvWechat;
    @BindView(R.id.tvQQ)
    TextView tvQQ;
    @BindView(R.id.tvFriends)
    TextView tvFriends;
    @BindView(R.id.tvWeibo)
    TextView tvWeibo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_qrcode);
        ButterKnife.bind(this);
        tvTitle.setText(R.string.my_qrcode);
    }

    @OnClick({R.id.ivBack, R.id.tvSave, R.id.tvWechat, R.id.tvQQ, R.id.tvFriends, R.id.tvWeibo})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.tvSave: // 保存到相册
                break;
            case R.id.tvWechat:
                break;
            case R.id.tvQQ:
                break;
            case R.id.tvFriends:
                break;
            case R.id.tvWeibo:
                break;
        }
    }
}
