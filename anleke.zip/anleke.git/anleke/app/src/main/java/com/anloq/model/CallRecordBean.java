package com.anloq.model;

/**
 * Created by xpf on 2017/4/19 :)
 * Function:通话记录的Bean类
 */

public class CallRecordBean {

    private String callTime;
    private String eqtName;
    private String currentTime;

    public CallRecordBean() {
    }

    public CallRecordBean(String callTime, String eqtName, String currentTime) {
        this.callTime = callTime;
        this.eqtName = eqtName;
        this.currentTime = currentTime;
    }

    public String getCallTime() {
        return callTime;
    }

    public void setCallTime(String callTime) {
        this.callTime = callTime;
    }

    public String getEqtName() {
        return eqtName;
    }

    public void setEqtName(String eqtName) {
        this.eqtName = eqtName;
    }

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    @Override
    public String toString() {
        return "CallRecordBean{" +
                "callTime='" + callTime + '\'' +
                ", eqtName='" + eqtName + '\'' +
                ", currentTime='" + currentTime + '\'' +
                '}';
    }
}
