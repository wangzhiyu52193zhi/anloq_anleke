package com.anloq.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupWindow;

import com.anloq.anleke.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

/**
 * Created by xpf on 2018/1/29 :)
 * Function:自定义开锁动画的Loading视图
 */

public class UnlockLoading {

    private Context mContext;
    private PopupWindow popupWindow;

    public UnlockLoading(Context context) {
        this.mContext = context;
    }

    /**
     * 显示开锁加载视图
     */
    public void show() {
        View popupView = View.inflate(mContext, R.layout.unlock_popupwindow, null);
        popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT);

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                dismiss();
            }
        });

        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setFocusable(true);
        ImageView ivUnlocking = (ImageView) popupView.findViewById(R.id.ivUnlocking);
        Glide.with(mContext).load(R.drawable.unlocking)
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(ivUnlocking);

        dismiss();

        if (popupWindow != null) {
            popupWindow.showAtLocation(((Activity) mContext).findViewById(R.id.activity_main),
                    Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        }
    }

    /**
     * 隐藏加载视图
     */
    public void dismiss() {
        if (popupWindow != null && popupWindow.isShowing()) {
            popupWindow.dismiss();
        }
    }

    /**
     * 是否正在显示
     *
     * @return
     */
    public boolean isShowing() {
        return popupWindow != null && popupWindow.isShowing();
    }
}
