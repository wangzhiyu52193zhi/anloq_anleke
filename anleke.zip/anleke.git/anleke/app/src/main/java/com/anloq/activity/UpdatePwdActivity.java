package com.anloq.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.utils.MD5Utils;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.MediaType;

// 修改密码页面
public class UpdatePwdActivity extends Activity {

    private static final String TAG = UpdatePwdActivity.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvUpdate)
    TextView tvUpdate;
    @BindView(R.id.etOldPwd)
    EditText etOldPwd;
    @BindView(R.id.etNewPwd1)
    EditText etNewPwd1;
    @BindView(R.id.etNewPwd2)
    EditText etNewPwd2;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_password);
        ButterKnife.bind(this);
        tvTitle.setText(getString(R.string.update_pwd));
    }

    @OnClick({R.id.ivBack, R.id.tvUpdate})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.tvUpdate:
                updatePwd();
                break;
        }
    }

    private void updatePwd() {
        String old_pwd = etOldPwd.getText().toString().trim();
        String pwd1 = etNewPwd1.getText().toString().trim();
        String pwd2 = etNewPwd2.getText().toString().trim();
        if (old_pwd.equals("")) {
            ToastUtil.show(getString(R.string.current_password_empty));
        } else {
            if (pwd1.equals(pwd2)) {
                if (pwd1.length() < 6) {
                    ToastUtil.show(getString(R.string.password_less_six));
                } else if (pwd1.length() > 18) {
                    ToastUtil.show(getString(R.string.password_more_eighteen));
                } else {
                    getDataFromNet();
                }
            } else {
                ToastUtil.show(getString(R.string.twice_not_same));
            }
        }
    }

    private void getDataFromNet() {
        String oldpwd = etOldPwd.getText().toString().trim();
        String newpwd = etNewPwd1.getText().toString().trim();
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.CHANGEPWD + uid + Constants.TOKEN + token;
        Logger.t(TAG).i(TAG, "CHANGEPWD_url===" + url);

        String md5OldPwd = MD5Utils.MD5(oldpwd);
        String md5NewPwd = MD5Utils.MD5(newpwd);

        HashMap map = new HashMap();
        map.put("oldpwd", md5OldPwd);
        map.put("newpwd", md5NewPwd);
        String content = new Gson().toJson(map);
        Logger.t(TAG).i(TAG, content);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e(TAG, "修改密码联网失败===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).i(TAG, "修改密码联网成功===" + response);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        String code = RequestUtil.getCode(UpdatePwdActivity.this, json);
        if ("200".equals(code)) {
            ToastUtil.show(getString(R.string.password_update_success));
            SpUtil.getInstance().save("password", ""); // 将原来保存的密码清空
            startActivity(new Intent(UpdatePwdActivity.this, GuideActivity.class));
            finish();
        }
    }
}
