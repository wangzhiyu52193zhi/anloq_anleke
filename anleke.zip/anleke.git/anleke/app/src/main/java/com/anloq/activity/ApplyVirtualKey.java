package com.anloq.activity;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.anloq.adapter.BuildingListAdapter;
import com.anloq.adapter.CityBeanAdapter;
import com.anloq.adapter.RoomListAdapter;
import com.anloq.adapter.SelectZoneAdapter;
import com.anloq.adapter.UnitListAdapter;
import com.anloq.adapter.ZoneBeanAdapter;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.BrightnessManager;
import com.anloq.manager.DBManager;
import com.anloq.model.ApplyKeyBean;
import com.anloq.model.BuildingBean;
import com.anloq.model.CityBean;
import com.anloq.model.ProvinceBean;
import com.anloq.model.RoomBean;
import com.anloq.model.UnitBean;
import com.anloq.model.ZoneBean;
import com.anloq.utils.InitUtil;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.MediaType;

// 申请虚拟钥匙页面
public class ApplyVirtualKey extends Activity {

    private static final String TAG = ApplyVirtualKey.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.rlSelectGarden)
    RelativeLayout rlSelectGarden;
    @BindView(R.id.rlSelectRoomNum)
    RelativeLayout rlSelectRoomNum;
    @BindView(R.id.rlSelectShip)
    RelativeLayout rlSelectShip;
    @BindView(R.id.llApplyName)
    LinearLayout llApplyName;
    @BindView(R.id.llLayout)
    LinearLayout llLayout;
    @BindView(R.id.llApplyResult)
    LinearLayout llApplyResult;
    @BindView(R.id.llOwner)
    LinearLayout llOwner;
    @BindView(R.id.llOwnerIc)
    LinearLayout llOwnerIc;
    @BindView(R.id.llOtherPhone)
    LinearLayout llOtherPhone;
    @BindView(R.id.llOwnerPhone)
    LinearLayout llOwnerPhone;
    @BindView(R.id.etOwnerName)
    EditText etOwnerName;
    @BindView(R.id.etApplyName)
    EditText etApplyName;
    @BindView(R.id.etOwnerIcNum)
    EditText etOwnerIcNum;
    @BindView(R.id.tvOwnerPhone)
    TextView tvOwnerPhone;
    @BindView(R.id.tvOtherPhone)
    TextView tvOtherPhone;
    @BindView(R.id.btnCommit)
    TextView btnCommit;
    @BindView(R.id.btnCancel)
    TextView btnCancel;
    @BindView(R.id.tvRelation)
    TextView tvRelation;
    @BindView(R.id.tvAllArea)
    TextView tvAllArea;
    @BindView(R.id.tvDetailRoom)
    TextView tvDetailRoom;
    @BindView(R.id.tvPhone)
    TextView tvPhone;
    @BindView(R.id.tvWuyePhone)
    TextView tvWuyePhone;
    @BindView(R.id.tvBackHome)
    TextView tvBackHome;
    @BindView(R.id.tvWuyeText)
    TextView tvWuyeText;
    @BindView(R.id.tvYezhuText)
    TextView tvYezhuText;
    @BindView(R.id.llWuye)
    LinearLayout llWuye;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

    private PopupWindow popupWindow, popupRoomNum, popupShip;
    private View popupView, popupRoomView, popupShipView;
    private TranslateAnimation animation;
    private ListView lvProvince, lvDistrict, lvCity, lvZone;
    private TextView tvProvince, tvCity, tvArea;
    private TextView tvConfirm, tvClose, tvBuilding, tvUnit, tvRoom;
    private ListView lvBuilding, lvUnit, lvRoom;
    private SelectZoneAdapter selectZoneAdapter;
    private Context mContext;
    private List<ProvinceBean.ObjectBean> cityBean;
    private int provinceId, districtId;
    private String token = "";
    private int uid = -1;
    private String currentProvince = "", currentCity = "", currentZone = "";
    private String detailRoom = "";
    private String[] mBuildingData, mUnitData, mRoomData;
    private String currentZoneName, mCurrentBuilding = "", mCurrentUnit = "", mCurrentRoom = "";
    private int currentZoneId = -1, currentBuildingId = -1, currentUnitId = -1, currentRoomId = -1;
    private int currentItemIndex = -1; // 当前Item的Index
    private List<CityBean.ObjectBean> districList;
    private List<ZoneBean.ObjectBean> zoneList;
    private List<BuildingBean.ObjectBean> buildingList;
    private List<UnitBean.ObjectBean> unitList;
    private List<RoomBean.ObjectBean> roomList;
    private boolean hasKey;
    private int relation = -1; // 与业主的关系:1-业主，2-家人，3-租客，4-访客
    private BuildingListAdapter buildingListAdapter;
    private UnitListAdapter unitListAdapter;
    private RoomListAdapter roomListAdapter;
    private String phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_virtural_key);
        ButterKnife.bind(this);
        mContext = this;
        tvTitle.setText(R.string.applying_vkey);
        uid = SpUtil.getInstance().getInt("uid", -1);
        token = SpUtil.getInstance().getString("token", "");
        phone = SpUtil.getInstance().getString("account", "");
        tvOwnerPhone.setText(phone);
        tvOtherPhone.setText(phone);
    }

    @OnClick({R.id.ivBack, R.id.rlSelectGarden, R.id.rlSelectRoomNum, R.id.btnCommit,
            R.id.btnCancel, R.id.rlSelectShip, R.id.tvBackHome})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.rlSelectGarden:
                selectProvince();
                BrightnessManager.lightoff(mContext);
                break;
            case R.id.rlSelectRoomNum:
                if ("".equals(currentProvince) || "".equals(currentCity) || "".equals(currentZone)) {
                    Toast.makeText(ApplyVirtualKey.this, R.string.please_select_zone, Toast.LENGTH_SHORT).show();
                } else {
                    selectRoomNum();
                    BrightnessManager.lightoff(mContext);
                }
                break;
            case R.id.btnCommit:
                commitApply(); // 申请
                break;
            case R.id.btnCancel:
                finish();
                break;
            case R.id.rlSelectShip:
                selectShip();
                BrightnessManager.lightoff(mContext);
                break;
            case R.id.tvBackHome:
                // 判断卡片是否更新过
                if (!SpUtil.getInstance().getBoolean("alreadyupdatedcards", false)) {
                    SpUtil.getInstance().save("addupdate", true);
                }
                finish();
                break;
        }
    }

    /**
     * 选择关系
     */
    private void selectShip() {
        if (popupShip == null) {
            popupShipView = View.inflate(this, R.layout.item_relation, null);
            popupShip = new PopupWindow(popupShipView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);

            popupShip.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(mContext);
                }
            });

            popupShip.setBackgroundDrawable(new BitmapDrawable());
            popupShip.setFocusable(true);
            popupShip.setOutsideTouchable(true);
            animation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0, Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 1, Animation.RELATIVE_TO_PARENT, 0);
            animation.setInterpolator(new AccelerateInterpolator());
            animation.setDuration(200);

            popupShipView.findViewById(R.id.tvFamily).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tvRelation.setText(R.string.family);
                    relation = 2;
                    popupShip.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            popupShipView.findViewById(R.id.tvRenter).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tvRelation.setText(R.string.renter);
                    relation = 3;
                    popupShip.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            popupShipView.findViewById(R.id.tvVisitor).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tvRelation.setText(R.string.visiter);
                    relation = 4;
                    popupShip.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
        }

        if (popupShip.isShowing()) {
            popupShip.dismiss();
            BrightnessManager.lighton(mContext);
        }
        popupShip.showAtLocation(ApplyVirtualKey.this.findViewById(R.id.activity_apply_virtural_key),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        popupShipView.startAnimation(animation);
    }

    /**
     * 申请钥匙
     */
    private void commitApply() {
        if ("".equals(mCurrentBuilding) || "".equals(mCurrentUnit) || "".equals(mCurrentRoom)) {
            Toast.makeText(ApplyVirtualKey.this, R.string.please_select_room, Toast.LENGTH_SHORT).show();
            return;
        }
        String name;
        String ic = "";
        Log.e(TAG, "hasKey===" + hasKey);

        if (hasKey) { // 有业主
            name = etApplyName.getText().toString().trim();

        } else { // 无业主
            relation = 1;
            name = etOwnerName.getText().toString().trim();
            ic = etOwnerIcNum.getText().toString().trim();
        }

        if (relation == -1) {
            ToastUtil.show(getString(R.string.please_relation));
            return;
        }
        if (hasKey) {
            if ("".equals(name)) {
                ToastUtil.show(getString(R.string.master_room_name));
                return;
            }
        }
//        else {
//            if ("".equals(ic)) {
//                ToastUtil.show(getString(R.string.ic_num_not_empty));
//                return;
//            } else {
//                // 校验15位身份证号或者18位后缀带X身份证号
//                if (!Validator.isICard(ic.toUpperCase())) {
//                    ToastUtil.show(getString(R.string.ic_card_num_invalid));
//                    return;
//                }
//            }
//        }

        /**
         * 判断申请的钥匙是否已经拥有
         */
        boolean hasKey = DBManager.getInstance().isHasKey(currentRoomId);
        if (!hasKey) {
            sendApplyRequest(name, ic);
        }
    }

    private void sendApplyRequest(String name, String ic) {
        String url = Constants.APPLYKEY + uid + Constants.TOKEN + token;
        Log.e(TAG, "APPLYKEY_url===" + url);
        Log.e(TAG, "currentZoneId===" + currentZoneId + ",currentRoomId===" + currentRoomId);

        HashMap map = new HashMap();
        map.put("province_name", currentProvince);
        map.put("city_name", currentCity);
        map.put("zone_id", currentZoneId);
        map.put("zone_name", currentZoneName);
        map.put("building_id", currentBuildingId);
        map.put("building_name", mCurrentBuilding);
        map.put("unit_id", currentUnitId);
        map.put("unit_name", mCurrentUnit);
        map.put("room_id", currentRoomId);
        map.put("room_name", mCurrentRoom);
        map.put("relation", relation);
        map.put("name", name);
        map.put("phone", phone);
        if (!this.hasKey) {
            map.put("id_num", ic);
        }
        String content = new Gson().toJson(map);
        Log.e(TAG, "content===" + content);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e(TAG, "申请钥匙结果返回失败===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "申请钥匙结果返回成功===" + response);
                        parseResult(response);
                    }
                });
    }

    /**
     * 解析申请钥匙的返回信息
     */
    private void parseResult(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            Toast.makeText(ApplyVirtualKey.this, R.string.commit_success, Toast.LENGTH_SHORT).show();
            ApplyKeyBean applyKeyBean = new Gson().fromJson(json, ApplyKeyBean.class);
            String room_admin_name = applyKeyBean.getObject().getRoom_admin_name();
            String room_admin_tel = applyKeyBean.getObject().getRoom_admin_tel();
            int room_admin_type = applyKeyBean.getObject().getRoom_admin_type();
            Log.e(TAG, "业主：" + room_admin_name + ",联系电话：" + room_admin_tel + "住户类型：" + room_admin_type);
            llLayout.setVisibility(View.GONE);
            llApplyResult.setVisibility(View.VISIBLE);
            if (hasKey) {
                tvYezhuText.setVisibility(View.VISIBLE);
                tvWuyeText.setVisibility(View.GONE);
                llWuye.setVisibility(View.GONE);
            } else {
                tvYezhuText.setVisibility(View.GONE);
                tvWuyeText.setVisibility(View.VISIBLE);
                if (!TextUtils.isEmpty(room_admin_tel)) {
                    llWuye.setVisibility(View.VISIBLE);
                    tvPhone.setText(room_admin_tel);
                }
            }
        } else {
            ToastUtil.show(getString(R.string.application_fail));
        }
    }

    /**
     * 选择楼栋单元房间号
     */
    private void selectRoomNum() {
        popupRoomView = View.inflate(this, R.layout.item_select_room, null);
        popupRoomNum = new PopupWindow(popupRoomView, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        popupRoomNum.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                BrightnessManager.lighton(mContext);
            }
        });

        popupRoomNum.setBackgroundDrawable(new BitmapDrawable());
        popupRoomNum.setFocusable(true);
        popupRoomNum.setOutsideTouchable(true);
        animation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0, Animation.RELATIVE_TO_PARENT, 0,
                Animation.RELATIVE_TO_PARENT, 1, Animation.RELATIVE_TO_PARENT, 0);
        animation.setInterpolator(new AccelerateInterpolator());
        animation.setDuration(200);

        tvClose = (TextView) popupRoomView.findViewById(R.id.tvClose);
        tvConfirm = (TextView) popupRoomView.findViewById(R.id.tvConfirm);
        tvBuilding = (TextView) popupRoomView.findViewById(R.id.tvBuilding);
        tvUnit = (TextView) popupRoomView.findViewById(R.id.tvUnit);
        tvRoom = (TextView) popupRoomView.findViewById(R.id.tvRoom);
        lvBuilding = (ListView) popupRoomView.findViewById(R.id.lvBuilding);
        lvUnit = (ListView) popupRoomView.findViewById(R.id.lvUnit);
        lvRoom = (ListView) popupRoomView.findViewById(R.id.lvRoom);

        tvClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupRoomNum.dismiss();
                BrightnessManager.lighton(mContext);
            }
        });
        tvConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("".equals(mCurrentBuilding)) {
                    Toast.makeText(ApplyVirtualKey.this, R.string.select_building_name, Toast.LENGTH_SHORT).show();
                } else {
                    if ("".equals(mCurrentUnit)) {
                        Toast.makeText(ApplyVirtualKey.this, R.string.please_select_unit, Toast.LENGTH_SHORT).show();
                    } else {
                        if ("".equals(mCurrentRoom)) {
                            Toast.makeText(ApplyVirtualKey.this, R.string.please_room, Toast.LENGTH_SHORT).show();
                        } else {
                            tvDetailRoom.setText(detailRoom);
                            popupRoomNum.dismiss();
                            judgeIsHasKey();
                            BrightnessManager.lighton(mContext);
                        }
                    }
                }
            }
        });
        getBuildingData();

        if (popupRoomNum.isShowing()) {
            popupRoomNum.dismiss();
            BrightnessManager.lighton(mContext);
        }
        popupRoomNum.showAtLocation(ApplyVirtualKey.this.findViewById(R.id.activity_apply_virtural_key),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        popupRoomView.startAnimation(animation);
    }

    /**
     * 判断是否已经有业主
     */
    private void judgeIsHasKey() {
        if (roomList != null && roomList.size() > 0) {
            hasKey = roomList.get(currentItemIndex).isHas_key();
            if (hasKey) { // 有业主
                llOwner.setVisibility(View.GONE);
                llOwnerPhone.setVisibility(View.GONE);
                llOwnerIc.setVisibility(View.GONE);
                rlSelectShip.setVisibility(View.VISIBLE);
                llApplyName.setVisibility(View.VISIBLE);
                llOtherPhone.setVisibility(View.VISIBLE);

            } else { // 无业主
                llOwner.setVisibility(View.VISIBLE);
                llOwnerPhone.setVisibility(View.VISIBLE);
                llOwnerIc.setVisibility(View.VISIBLE);
                rlSelectShip.setVisibility(View.GONE);
                llApplyName.setVisibility(View.GONE);
                llOtherPhone.setVisibility(View.GONE);
            }
        }
    }

    /**
     * 获得楼栋数据
     */
    private void getBuildingData() {
        if (currentZoneId != -1) {
            String url = Constants.SELECTBUILDING + uid + Constants.TOKEN + token + Constants.ZONEID + currentZoneId;
            Log.e(TAG, "SELECTBUILDING_url===" + url);
            OkHttpUtils
                    .get()
                    .url(url)
                    .build()
                    .execute(new StringCallback() {
                        @Override
                        public void onError(Call call, Exception e, int id) {

                        }

                        @Override
                        public void onResponse(String response, int id) {
                            Log.e(TAG, "Building_Result===" + response);
                            parseBuildingJson(response);
                        }
                    });
        }
    }

    /**
     * 解析楼栋数据
     */
    private void parseBuildingJson(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            BuildingBean buildingBean = new Gson().fromJson(json, BuildingBean.class);
            buildingList = buildingBean.getObject();
            if (buildingList != null && buildingList.size() > 0) {
                mBuildingData = InitUtil.initBuildingData(buildingList);
                currentBuildingId = buildingList.get(0).getBuilding_id();
                Log.e(TAG, "mCurrentBuilding===" + mCurrentBuilding);
                buildingListAdapter = new BuildingListAdapter(mContext, buildingList);
                lvBuilding.setAdapter(buildingListAdapter);
                lvBuilding.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        mCurrentBuilding = buildingList.get(position).getBuilding_name();
                        Log.e(TAG, "mCurrentBuilding===" + mCurrentBuilding);
                        currentBuildingId = buildingList.get(position).getBuilding_id();
                        tvBuilding.setText(mCurrentBuilding);
                        mCurrentUnit = "";
                        tvUnit.setText(mCurrentUnit);
                        mCurrentRoom = "";
                        tvRoom.setText(mCurrentRoom);
                        detailRoom = "";
                        detailRoom += mCurrentBuilding;
                        updateUnit();
                    }
                });
                updateUnit();
            } else {
                ToastUtil.show(getString(R.string.not_get_more));
            }
        }
    }

    /**
     * 选择省份直辖市
     */
    private void selectProvince() {
        if (popupWindow == null) {
            popupView = View.inflate(this, R.layout.item_select_province, null);
            popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);

            popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(mContext);
                }
            });

            popupWindow.setTouchable(true);
            popupWindow.setFocusable(true);
            popupWindow.setBackgroundDrawable(new BitmapDrawable());
            popupWindow.setOutsideTouchable(true);

            animation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0, Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 1, Animation.RELATIVE_TO_PARENT, 0);
            animation.setInterpolator(new AccelerateInterpolator());
            animation.setDuration(200);

            popupView.findViewById(R.id.ivClose).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });

            tvProvince = (TextView) popupView.findViewById(R.id.tvProvince);
            tvCity = (TextView) popupView.findViewById(R.id.tvCity);
            tvArea = (TextView) popupView.findViewById(R.id.tvArea);
            lvProvince = (ListView) popupView.findViewById(R.id.lvProvince);
            lvDistrict = (ListView) popupView.findViewById(R.id.lvDistrict);
            lvCity = (ListView) popupView.findViewById(R.id.lvCity);
            lvZone = (ListView) popupView.findViewById(R.id.lvZone);
            setListener();
            getProvinceData();
        }

        if (popupWindow.isShowing()) {
            popupWindow.dismiss();
            BrightnessManager.lighton(mContext);
        }
        popupWindow.showAtLocation(ApplyVirtualKey.this.findViewById(R.id.activity_apply_virtural_key),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        popupView.startAnimation(animation);
    }

    private void setListener() {
        /**
         * 点击选择省份直辖市
         */
        lvProvince.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                provinceId = cityBean.get(position).getProvince_id();
                currentProvince = cityBean.get(position).getProvince_name();
                tvProvince.setText(currentProvince);
                getDistrictData();
            }
        });

        lvDistrict.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                districtId = districList.get(position).getCity_id();
                currentCity = districList.get(position).getCity_name();
                tvCity.setText(currentCity);
                getZoneData();
            }
        });

        lvCity.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });

        lvZone.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                currentZone = zoneList.get(position).getZone_name();
                currentZoneId = zoneList.get(position).getZone_id();
                currentZoneName = zoneList.get(position).getZone_name();
                tvArea.setText(currentZone);
                tvAllArea.setText(currentProvince + currentCity + currentZone);
                popupWindow.dismiss();
                popupWindow = null;
                tvDetailRoom.setText(R.string.please_select_room_and_building);
                BrightnessManager.lighton(mContext);
            }
        });
    }

    private void getZoneData() {
        String url = Constants.SELECTZONE + uid + Constants.TOKEN + token + Constants.PROVINCEID
                + provinceId + Constants.CITYID + districtId;
        Log.e(TAG, "SELECTZONE_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        parseZone(response);
                        Log.e(TAG, "SELECTZONE_Result===" + response);
                    }
                });
    }

    /**
     * 解析小区数据
     */
    private void parseZone(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            ZoneBean zoneBean = new Gson().fromJson(json, ZoneBean.class);
            zoneList = zoneBean.getObject();
            if (zoneList != null && zoneList.size() > 0) {
                ZoneBeanAdapter zoneBeanAdapter = new ZoneBeanAdapter(mContext, zoneList);
                lvZone.setAdapter(zoneBeanAdapter);
            } else {
                ToastUtil.show(getString(R.string.not_get_zone_more));
            }
        }
    }

    /**
     * 获取城市数据
     */
    private void getDistrictData() {
        String url = Constants.SELECTCITY + uid + Constants.TOKEN + token + Constants.PROVINCEID + provinceId;
        Log.e(TAG, "SELECTCITY_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        parseDistrict(response);
                        Log.e(TAG, "Result===" + response);
                    }
                });
    }

    /**
     * 解析地区数据
     */
    private void parseDistrict(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            CityBean cityBean = new Gson().fromJson(json, CityBean.class);
            districList = cityBean.getObject();
            if (districList != null && districList.size() > 0) {
                CityBeanAdapter cityBeanAdapter = new CityBeanAdapter(mContext, districList);
                lvDistrict.setAdapter(cityBeanAdapter);
            } else {
                ToastUtil.show(getString(R.string.not_get_city_more));
            }
        }
    }

    /**
     * 获取省市数据
     */
    private void getProvinceData() {
        String url = Constants.SELECTPROVINCE + uid + Constants.TOKEN + token;
        Log.e(TAG, "SELECTPROVINCE_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "SELECTPROVINCE_Result===" + response);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            ProvinceBean provinceBean = new Gson().fromJson(json, ProvinceBean.class);
            cityBean = provinceBean.getObject();
            if (cityBean != null && cityBean.size() > 0) {
                selectZoneAdapter = new SelectZoneAdapter(mContext, cityBean);
                lvProvince.setAdapter(selectZoneAdapter);
            } else {
                ToastUtil.show(getString(R.string.not_get_city_more));
            }
        }
    }

    /**
     * 更新单元对应的房间
     */
    private void updateRoom() {
        String url = Constants.SELECTROOM + uid + Constants.TOKEN + token + Constants.ZONEID
                + currentZoneId + Constants.UNITID + currentUnitId;
        Log.e(TAG, "SELECTROOM_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        parseRoomJson(response);
                        Log.e(TAG, "SELECTROOM_Result===" + response);
                    }
                });
    }

    /**
     * 解析房间数据
     */
    private void parseRoomJson(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            if (roomListAdapter != null) {
                if (roomList != null) {
                    roomList.clear();
                }
                roomListAdapter.notifyDataSetChanged();
            }
            RoomBean roomBean = new Gson().fromJson(json, RoomBean.class);
            roomList = roomBean.getObject();
            if (roomList != null && roomList.size() > 0) {
                mRoomData = InitUtil.initRoomData(roomList);
                currentRoomId = roomList.get(0).getRoom_id();
                //mCurrentRoom = roomList.get(0).getRoom_name();
                roomListAdapter = new RoomListAdapter(mContext, roomList);
                lvRoom.setAdapter(roomListAdapter);
                lvRoom.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        currentItemIndex = position;
                        mCurrentRoom = roomList.get(position).getRoom_name();
                        currentRoomId = roomList.get(position).getRoom_id();
                        tvRoom.setText(mCurrentRoom);
                        detailRoom = "";
                        detailRoom = mCurrentBuilding;
                        detailRoom += mCurrentUnit;
                        detailRoom += mCurrentRoom;
                    }
                });
            } else {
                ToastUtil.show(getString(R.string.not_get_room));
            }
        }
    }

    /**
     * 更新楼栋对应的单元
     */
    private void updateUnit() {
        if (currentBuildingId != -1) {
            String url = Constants.SELECTUNIT + uid + Constants.TOKEN + token + Constants.ZONEID
                    + currentZoneId + Constants.BUILDINGID + currentBuildingId;
            Log.e(TAG, "SELECTUNIT_url===" + url);
            OkHttpUtils
                    .get()
                    .url(url)
                    .build()
                    .execute(new StringCallback() {
                        @Override
                        public void onError(Call call, Exception e, int id) {

                        }

                        @Override
                        public void onResponse(String response, int id) {
                            Log.e(TAG, "SELECTUNIT_Result===" + response);
                            parseUnitJson(response);
                        }
                    });
        }
    }

    /**
     * 解析单元数据
     */
    private void parseUnitJson(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            if (unitListAdapter != null) {
                if (unitList != null) {
                    unitList.clear();
                }
                unitListAdapter.notifyDataSetChanged();
            }
            if (roomListAdapter != null) {
                if (roomList != null) {
                    roomList.clear();
                }
                roomListAdapter.notifyDataSetChanged();
            }
            UnitBean unitBean = new Gson().fromJson(json, UnitBean.class);
            unitList = unitBean.getObject();
            if (unitList != null && unitList.size() > 0) {
                mUnitData = InitUtil.initUnitData(unitList);
                currentUnitId = unitList.get(0).getUnit_id();
                //mCurrentUnit = unitList.get(0).getUnit_name();
                unitListAdapter = new UnitListAdapter(mContext, unitList);
                lvUnit.setAdapter(unitListAdapter);
                lvUnit.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        mCurrentUnit = unitList.get(position).getUnit_name();
                        currentUnitId = unitList.get(position).getUnit_id();
                        tvUnit.setText(mCurrentUnit);
                        mCurrentRoom = "";
                        tvRoom.setText(mCurrentRoom);
                        detailRoom = "";
                        detailRoom += mCurrentBuilding;
                        Log.e(TAG, "unitList_mCurrentBuilding===" + mCurrentBuilding);
                        detailRoom += mCurrentUnit;
                        updateRoom();
                    }
                });
                updateRoom();
            } else {
                ToastUtil.show(getString(R.string.not_get_unit_more));
            }
        }
    }

}
