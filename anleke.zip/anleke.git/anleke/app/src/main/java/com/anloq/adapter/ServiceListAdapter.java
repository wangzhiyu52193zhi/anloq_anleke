package com.anloq.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.model.ServiceDataBean;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/4/19 :)
 * Function:服务数据列表的适配器
 */

public class ServiceListAdapter extends BaseAdapter {

    private Context mContext;
    private List<ServiceDataBean.ObjectBean> serviceList;

    public ServiceListAdapter(Context mContext, List<ServiceDataBean.ObjectBean> serviceList) {
        this.mContext = mContext;
        this.serviceList = serviceList;
    }

    @Override
    public int getCount() {
        return serviceList.size();
    }

    @Override
    public Object getItem(int position) {
        return serviceList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_service, null);
            ButterKnife.bind(convertView);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        ServiceDataBean.ObjectBean objectBean = serviceList.get(position);
        holder.tvName.setText(objectBean.getService_name());
        holder.tvPhone.setText(objectBean.getTel());
        return convertView;
    }

    static class ViewHolder {
        @BindView(R.id.ivIcon)
        ImageView ivIcon;
        @BindView(R.id.tvName)
        TextView tvName;
        @BindView(R.id.tvPhone)
        TextView tvPhone;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
