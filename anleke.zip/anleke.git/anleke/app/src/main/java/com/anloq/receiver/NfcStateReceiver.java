package com.anloq.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.util.Log;

import com.anloq.activity.MainActivity;
import com.anloq.model.EventBusMsg;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by xpf on 2017/6/3 :)
 * Function:NFC状态的接收器
 */

public class NfcStateReceiver extends BroadcastReceiver {

    private static final String TAG = NfcStateReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        int state = intent.getIntExtra(NfcAdapter.ACTION_ADAPTER_STATE_CHANGED,
                NfcAdapter.STATE_ON);
        switch (state) {
            case NfcAdapter.STATE_OFF:
                Log.e(TAG, "STATE_OFF NFC关闭");
                sendState("nfc_close");
                break;
            case NfcAdapter.STATE_TURNING_OFF:
                Log.e(TAG, "STATE_TURNING_OFF NFC正在关闭");
                break;
            case NfcAdapter.STATE_ON:
                Log.e(TAG, "STATE_ON NFC开启");
                sendState("nfc_open");
                break;
            case NfcAdapter.STATE_TURNING_ON:
                Log.e(TAG, "STATE_TURNING_ON NFC正在开启");
                break;
        }
    }

    /**
     * 发送状态到通知页面
     * @param state
     */
    private void sendState(String state) {
        if (MainActivity.isVisible) {
            EventBus.getDefault().post(new EventBusMsg(state, ""));
        }
    }
}
