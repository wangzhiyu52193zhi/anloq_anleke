package com.anloq.model;

import com.anloq.utils.TimeUtil;

/**
 * Created by xpf on 2017/4/14 :)
 * Function:收到顶部弹窗消息(例如远程开门后收到消息的Bean)
 */

public class PopMessageBean {

    /**
     * name : popmsg
     * object : {"title":"远程开门","content":"已开门","command":1}
     * time : 2017-05-24T14:49:34.045Z
     */

    private String name;
    private ObjectBean object;
    private String time;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public String getTime() {
        return TimeUtil.getTime(time);
    }

    public void setTime(String time) {
        this.time = time;
    }

    public static class ObjectBean {
        /**
         * title : 远程开门
         * content : 已开门
         * command : 1
         */

        private String title;
        private String content;
        private int command;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getCommand() {
            return command;
        }

        public void setCommand(int command) {
            this.command = command;
        }
    }
}
