package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/2/27:)
 * Function:登录成功返回数据的Bean类
 */

public class LoginBean {

    /**
     * code : 200
     * name : token
     * object : {"bind_hardware":false,"call_answer":true,"headpic":"","ice_servers":["stun:118.190.98.108","turn:118.190.98.108:3478?transport=udp","turn:118.190.98.108:3478?transport=tcp","stun:139.129.242.78","turn:139.129.242.78:3478?transport=udp","turn:139.129.242.78:3478?transport=tcp"],"language":1,"mqtt_server":"tcp://emqdev.anloq.com:1883","nickname":"17600733534","no_distrub":3,"password":"e10adc3949ba59abbe56e057f20f883e","ring":1,"ring_shake":true,"shake_enable":true,"socket_cluster":"http://139.129.242.78:8000/socketcluster/","sound_enable":true,"token":"CjIAFBQHPDwJPB4CKAoHPAAARh4DMh4EUDwBWigFAB4JRh4BHlAJAAAAAAE=","uid":100027}
     */

    private int code;
    private String name;
    private ObjectBean object;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * bind_hardware : false
         * call_answer : true
         * headpic :
         * ice_servers : ["stun:118.190.98.108","turn:118.190.98.108:3478?transport=udp","turn:118.190.98.108:3478?transport=tcp","stun:139.129.242.78","turn:139.129.242.78:3478?transport=udp","turn:139.129.242.78:3478?transport=tcp"]
         * language : 1
         * mqtt_server : tcp://emqdev.anloq.com:1883
         * nickname : 17600733534
         * no_distrub : 3
         * password : e10adc3949ba59abbe56e057f20f883e
         * ring : 1
         * ring_shake : true
         * shake_enable : true
         * socket_cluster : http://139.129.242.78:8000/socketcluster/
         * sound_enable : true
         * token : CjIAFBQHPDwJPB4CKAoHPAAARh4DMh4EUDwBWigFAB4JRh4BHlAJAAAAAAE=
         * uid : 100027
         */

        private boolean bind_hardware;
        private boolean call_answer;
        private String headpic;
        private int language;
        private String mqtt_server;
        private String nickname;
        private int no_distrub;
        private String password;
        private int ring;
        private boolean ring_shake;
        private boolean shake_enable;
        private String socket_cluster;
        private boolean sound_enable;
        private String token;
        private int uid;
        private List<String> ice_servers;
        private boolean account_visible;

        public boolean isAccount_visible() {
            return account_visible;
        }

        public void setAccount_visible(boolean account_visible) {
            this.account_visible = account_visible;
        }

        public boolean isBind_hardware() {
            return bind_hardware;
        }

        public void setBind_hardware(boolean bind_hardware) {
            this.bind_hardware = bind_hardware;
        }

        public boolean isCall_answer() {
            return call_answer;
        }

        public void setCall_answer(boolean call_answer) {
            this.call_answer = call_answer;
        }

        public String getHeadpic() {
            return headpic;
        }

        public void setHeadpic(String headpic) {
            this.headpic = headpic;
        }

        public int getLanguage() {
            return language;
        }

        public void setLanguage(int language) {
            this.language = language;
        }

        public String getMqtt_server() {
            return mqtt_server;
        }

        public void setMqtt_server(String mqtt_server) {
            this.mqtt_server = mqtt_server;
        }

        public String getNickname() {
            return nickname;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public int getNo_distrub() {
            return no_distrub;
        }

        public void setNo_distrub(int no_distrub) {
            this.no_distrub = no_distrub;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public int getRing() {
            return ring;
        }

        public void setRing(int ring) {
            this.ring = ring;
        }

        public boolean isRing_shake() {
            return ring_shake;
        }

        public void setRing_shake(boolean ring_shake) {
            this.ring_shake = ring_shake;
        }

        public boolean isShake_enable() {
            return shake_enable;
        }

        public void setShake_enable(boolean shake_enable) {
            this.shake_enable = shake_enable;
        }

        public String getSocket_cluster() {
            return socket_cluster;
        }

        public void setSocket_cluster(String socket_cluster) {
            this.socket_cluster = socket_cluster;
        }

        public boolean isSound_enable() {
            return sound_enable;
        }

        public void setSound_enable(boolean sound_enable) {
            this.sound_enable = sound_enable;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public List<String> getIce_servers() {
            return ice_servers;
        }

        public void setIce_servers(List<String> ice_servers) {
            this.ice_servers = ice_servers;
        }
    }
}
