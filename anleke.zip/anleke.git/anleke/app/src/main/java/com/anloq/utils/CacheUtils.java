package com.anloq.utils;

import android.os.Environment;

import com.orhanobut.logger.Logger;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * Created by xpf on 2017/05/20 :)
 * 缓存工具类(按不同账户分类别存储)
 */
public class CacheUtils {

    private static final String TAG = CacheUtils.class.getSimpleName();

    /**
     * 缓存文本数据
     */
    public static void putString(String key, String values) {

        String account = SpUtil.getInstance().getString("account", "");
        Logger.t(TAG).i("缓存消息6.account===" + account + ",key===" + key);

        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            // sdcard可用-用文件缓存
            // key-->MD5加密-->xxxxx(文件的名称)
            try {
                File file = null;
                String fileName = MD5Utils.MD5(account + key);
                if ("json_message".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/messages/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/messages/" + fileName);
                } else if ("json_call_record".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/callrecord/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/callrecord/" + fileName);
                } else if ("json_unlock_record".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/unlockrecord/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/unlockrecord/" + fileName);
                } else if ("json_anloq_contacts".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/anloqcontacts/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/anloqcontacts/" + fileName);
                } else if ("json_anloq_message_type_number".equals(key)) {
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/anloqmessagetype/" + fileName);
                }
                File parent = file.getParentFile();// mnt/sdcard/anloq/localfiles/messages/

                if (!parent.exists()) {
                    parent.mkdirs();// 创建多层目录
                }
                if (!file.exists()) {
                    file.createNewFile(); // 文件不存在就创建文件
                }
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(values.getBytes());
                fos.flush();
                fos.close();
                // 缓存消息7.缓存完成ok
                Logger.t(TAG).i("缓存消息完成ok~");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            if (!"".equals(account)) {
                SpUtil.getInstance().save(account + key, values);
            }
        }
    }

    /**
     * 获取缓存文本信息
     */
    public static String getString(String key) {

        String account = SpUtil.getInstance().getString("account", "");
        String result = "";// 默认返回空字符串

        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            // 读取sdcard的文件
            try {
                File file = null;
                String fileName = MD5Utils.MD5(account + key);
                if ("json_message".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/messages/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/messages/" + fileName);
                } else if ("json_call_record".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/callrecord/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/callrecord/" + fileName);
                } else if ("json_unlock_record".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/unlockrecord/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/unlockrecord/" + fileName);
                } else if ("json_anloq_contacts".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/anloqcontacts/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/anloqcontacts/" + fileName);
                } else if ("json_anloq_message_type_number".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/anloqcontacts/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/anloqmessagetype/" + fileName);
                }

                if (file.exists()) {
                    FileInputStream fis = new FileInputStream(file);
                    byte[] buffer = new byte[1024];
                    int length;
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    while ((length = fis.read(buffer)) != -1) {
                        stream.write(buffer, 0, length);
                    }
                    result = stream.toString();
                    fis.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            result = SpUtil.getInstance().getString(account + key, "");
        }

        return result;
    }

    /**
     * 删除缓存文本信息
     */
    public static boolean deleteString(String key) {
        String account = SpUtil.getInstance().getString("account", "");

        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            // 读取sdcard的文件
            try {
                File file = null;
                String fileName = MD5Utils.MD5(account + key);
                if ("json_message".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/messages/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/messages/" + fileName);
                } else if ("json_call_record".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/callrecord/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/callrecord/" + fileName);
                } else if ("json_unlock_record".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/unlockrecord/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/unlockrecord/" + fileName);
                } else if ("json_anloq_contacts".equals(key)) {
                    // mnt/sdcard/anloq/localfiles/anloqcontacts/ + fileName
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/anloqcontacts/" + fileName);
                }

                if (file.exists() && file.isFile()) {
                    return file.delete();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            SpUtil.getInstance().save(account + key, "");
            return true;
        }
        return false;
    }

    /**
     * 删除缓存的文件
     *
     * @param deleteFile
     */
    public static void delete(final File deleteFile) {
        new Thread() {
            public void run() {
                File file = deleteFile;
                if (file == null) {
                    file = new File(Environment.getExternalStorageDirectory() + "/Anloq/localfiles/");
                }
                if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                    if (file.isFile()) {
                        file.delete();
                        return;
                    }
                    if (file.isDirectory()) {
                        File[] childFiles = file.listFiles();
                        if (childFiles == null || childFiles.length == 0) {
                            file.delete();
                            return;
                        }
                        for (int i = 0; i < childFiles.length; i++) {
                            delete(childFiles[i]);
                        }
                        file.delete();
                    }
                }
            }
        }.start();
    }

}
