package com.anloq.model;

/**
 * Created by xpf on 2017/5/18 :)
 * Function:意见反馈选择小区的Bean
 */

public class OpinionZoneBean {

    private int zone_id;
    private String zone_name;

    public OpinionZoneBean() {
    }

    public OpinionZoneBean(int zone_id, String zone_name) {
        this.zone_id = zone_id;
        this.zone_name = zone_name;
    }

    public int getZone_id() {
        return zone_id;
    }

    public void setZone_id(int zone_id) {
        this.zone_id = zone_id;
    }

    public String getZone_name() {
        return zone_name;
    }

    public void setZone_name(String zone_name) {
        this.zone_name = zone_name;
    }

    @Override
    public String toString() {
        return "OpinionZoneBean{" +
                "zone_id=" + zone_id +
                ", zone_name='" + zone_name + '\'' +
                '}';
    }
}
