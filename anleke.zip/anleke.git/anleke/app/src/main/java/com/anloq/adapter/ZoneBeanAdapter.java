package com.anloq.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.model.ZoneBean;

import java.util.List;

/**
 * Created by xpf on 2017/3/27 :)
 * Function:小区数据的适配器
 */

public class ZoneBeanAdapter extends BaseAdapter {

    private Context mContext;
    private List<ZoneBean.ObjectBean> zoneList;

    public ZoneBeanAdapter(Context mContext, List<ZoneBean.ObjectBean> zoneList) {
        this.mContext = mContext;
        this.zoneList = zoneList;
    }

    @Override
    public int getCount() {
        return zoneList.size();
    }

    @Override
    public Object getItem(int position) {
        return zoneList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        viewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_zone, null);
            holder = new viewHolder();
            holder.tv = (TextView) convertView.findViewById(R.id.tv);
            convertView.setTag(holder);
        } else {
            holder = (viewHolder) convertView.getTag();
        }

        ZoneBean.ObjectBean objectBean = zoneList.get(position);
        holder.tv.setText(objectBean.getZone_name());
        return convertView;
    }

    static class viewHolder {
        TextView tv;
    }
}
