package com.anloq.activity;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.ProfileManager;
import com.anloq.model.ProfileBean;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

import static com.anloq.MyApplication.mContext;

/**
 * Created by Steven on 2017/7/14.
 * 铃声设置
 */

public class RingSelectActivity extends Activity {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.rlRing1)
    RelativeLayout rlRing1;
    @BindView(R.id.rlRing2)
    RelativeLayout rlRing2;
    @BindView(R.id.rlRing3)
    RelativeLayout rlRing3;
    @BindView(R.id.rlRing4)
    RelativeLayout rlRing4;
    @BindView(R.id.rlRing5)
    RelativeLayout rlRing5;
    @BindView(R.id.ivRing1)
    ImageView ivRing1;
    @BindView(R.id.ivRing2)
    ImageView ivRing2;
    @BindView(R.id.ivRing3)
    ImageView ivRing3;
    @BindView(R.id.ivRing4)
    ImageView ivRing4;
    @BindView(R.id.ivRing5)
    ImageView ivRing5;
    private MediaPlayer mediaPlayer1 = null;
    private List<ImageView> mImageView;
    private int ringIndex;
    private int defaultRing;
    private static final String TAG = RingSelectActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ring_select);
        ButterKnife.bind(this);
        tvTitle.setText(R.string.ring_pager);
        initViewList();
        initToggle();
    }

    private void initToggle() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.GETPROFILE + uid + Constants.TOKEN + token;
        Logger.t(TAG).i("GETPROFILE_url===" + url);

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e(e.toString());
                        setErrorSetting();
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        ProfileBean profileBean = new Gson().fromJson(json, ProfileBean.class);
        if (profileBean != null) {
            ProfileBean.ObjectBean object = profileBean.getObject();
            if (object != null) {
                ringIndex = object.getRing();
                defaultRing = ringIndex;
                setCheckedState(ringIndex - 1);
                ringSetting(ringIndex);
            }
        }
    }

    private void setErrorSetting() {
        ringIndex = SpUtil.getInstance().getInt("ring_state", -1);
        if (ringIndex == -1) {
            ringIndex = 0;
            SpUtil.getInstance().save("ring_state", 0);
        }
        setCheckedState(ringIndex);
    }

    private void initViewList() {
        mImageView = new ArrayList<>();
        mImageView.add(ivRing1);
        mImageView.add(ivRing2);
        mImageView.add(ivRing3);
        mImageView.add(ivRing4);
        mImageView.add(ivRing5);
    }

    private void setCheckedState(int ring_state) {
        for (int i = 0; i < mImageView.size(); i++) {
            mImageView.get(i).setVisibility(i == ring_state ? View.VISIBLE : View.GONE);
        }
    }

    //调用铃声
    private void startRinging(int ringID) {
        if (mediaPlayer1 != null) {
            stopRinging();//停止铃声播放
        }
        //下面是调用振动的三行代码/之后调用的是铃声
        mediaPlayer1 = MediaPlayer.create(this, ringID);
        mediaPlayer1.setLooping(true);
        try {
            mediaPlayer1.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mediaPlayer1.start();
    }

    //铃声关闭
    private void stopRinging() {
        mediaPlayer1.stop();//暂停
        mediaPlayer1.release();//释放掉资源
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mediaPlayer1 != null) {
            mediaPlayer1.stop();//暂停
            mediaPlayer1.release();//释放掉资源
            mediaPlayer1 = null;
        }
    }

    @OnClick({R.id.ivBack, R.id.rlRing1, R.id.rlRing2, R.id.rlRing3, R.id.rlRing4, R.id.rlRing5})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                if (defaultRing != ringIndex) {
                    SpUtil.getInstance().save("ring_state", ringIndex);
                    ringSetting(ringIndex + 1);
                }
                ToastUtil.show("铃声设置成功！");
                finish();
                break;
            case R.id.rlRing1:
                ringIndex = 0;
                setCheckedState(ringIndex);
                startRinging(R.raw.calling1);
                break;
            case R.id.rlRing2:
                ringIndex = 1;
                setCheckedState(ringIndex);
                startRinging(R.raw.calling2);
                break;
            case R.id.rlRing3:
                ringIndex = 2;
                setCheckedState(ringIndex);
                startRinging(R.raw.calling3);
                break;
            case R.id.rlRing4:
                ringIndex = 3;
                setCheckedState(ringIndex);
                startRinging(R.raw.calling4);
                break;
            case R.id.rlRing5:
                ringIndex = 4;
                setCheckedState(ringIndex);
                startRinging(R.raw.calling5);
                break;
        }
    }

    /**
     * 上传用户铃声设置
     */
    private void ringSetting(int index) {
        HashMap map = new HashMap();
        map.put("ring", index);
        ProfileManager.update(map, new ProfileManager.OnProfileUpdateListener() {
            @Override
            public void onUpdate(String result) {
                String code = RequestUtil.getCode(mContext, result);
                if ("200".equals(code)) {
                    Logger.i("铃声设置成功！");
                }
            }
        });
    }
}
