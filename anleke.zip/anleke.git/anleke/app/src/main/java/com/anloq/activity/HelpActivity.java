package com.anloq.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.model.HelpPageBean;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

// 帮助页面
public class HelpActivity extends Activity {

    private static final String TAG = HelpActivity.class.getSimpleName();
    private String rlDoWhat_url = "";
    private String rlApplyKey_url = "";
    private String rlApplyMostKey_url = "";
    private String rlBleUnlock_url = "";
    private String rlNfcUnlock_url = "";
    private String rlShareKey_url = "";
    private String rlManagerAuth_url = "";
    private String rlRemoteUnlock_url = "";
    private String rlLead_url="";
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.rlGuidePager)
    RelativeLayout rlGuidePager;
    @BindView(R.id.rlDoWhat)
    RelativeLayout rlDoWhat;
    @BindView(R.id.rlApplyKey)
    RelativeLayout rlApplyKey;
    @BindView(R.id.rlBleUnlock)
    RelativeLayout rlBleUnlock;
    @BindView(R.id.rlNfcUnlock)
    RelativeLayout rlNfcUnlock;
    @BindView(R.id.rlShareKey)
    RelativeLayout rlShareKey;
    @BindView(R.id.rlManagerAuth)
    RelativeLayout rlManagerAuth;
    @BindView(R.id.rlRemoteUnlock)
    RelativeLayout rlRemoteUnlock;
    @BindView(R.id.rlApplyMostKey)
    RelativeLayout rlApplyMostKey;
    @BindView(R.id.rlLead)
    RelativeLayout rlLead;
    private Intent it = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        it = new Intent(HelpActivity.this, HelpPageActivity.class);
        ButterKnife.bind(this);
        tvTitle.setText(R.string.functions_introduce);
        getKeyBagData();//获取数据信息
    }

    /**
     * 获取新手引导页连接信息
     */
    private void getKeyBagData() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.GUIDEANSWER + uid + Constants.TOKEN + token;// + Constants.STARTTIME + lasttime;
        Log.e(TAG, "KEYPACKAGE_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e(TAG, "网络访问错误！");
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "返回链接信息: "+response );
                        Log.e(TAG, "KEYPACKAGE_Result===" + response);
                        HashMap<String, Object> map = new Gson().fromJson(response, new TypeToken<HashMap<String, Object>>() {
                        }.getType());
                        Log.e(TAG, "code==" + map.get("code") + "");
                        if (map.size() >= 3) {
                            doResult(response);
                        } else {
                            Log.e(TAG, "返回链接为空！");
                        }
                    }
                });
    }

    @OnClick({R.id.ivBack, R.id.rlGuidePager, R.id.rlDoWhat, R.id.rlApplyKey, R.id.rlBleUnlock,
            R.id.rlNfcUnlock, R.id.rlShareKey, R.id.rlManagerAuth, R.id.rlRemoteUnlock, R.id.rlApplyMostKey,R.id.rlLead})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.rlGuidePager:
                SpUtil.getInstance().save("helpguide", true);
                startActivity(new Intent(HelpActivity.this, GuideActivity.class));
                break;
            case R.id.rlDoWhat:
                //安络克能做什么
                it.putExtra("url", rlDoWhat_url);
                it.putExtra("flag", 1);
                startActivity(it);
                break;
            case R.id.rlApplyKey:
                //如何申请钥匙
                it.putExtra("url", rlApplyKey_url);
                it.putExtra("flag", 2);
                startActivity(it);
                break;
            case R.id.rlApplyMostKey:
                //如何申请多个钥匙包
                it.putExtra("url", rlApplyMostKey_url);
                it.putExtra("flag", 3);
                startActivity(it);
                break;
            case R.id.rlBleUnlock:
                //如何使用蓝牙开锁
                it.putExtra("url", rlBleUnlock_url);
                it.putExtra("flag", 4);
                startActivity(it);
                break;
            case R.id.rlNfcUnlock:
                //如何使用NFC开锁
                it.putExtra("url", rlNfcUnlock_url);
                it.putExtra("flag", 5);
                startActivity(it);
                break;
            case R.id.rlShareKey:
                //如何授权
                it.putExtra("url", rlShareKey_url);
                it.putExtra("flag", 6);
                startActivity(it);
                break;
            case R.id.rlManagerAuth:
                //更改记录
                it.putExtra("url", rlManagerAuth_url);
                it.putExtra("flag", 7);
                startActivity(it);
                break;
            case R.id.rlRemoteUnlock:
                //远程开锁
                it.putExtra("url", rlRemoteUnlock_url);
                it.putExtra("flag", 8);
                startActivity(it);
                break;
            case R.id.rlLead:
                //加入白名单
                it.putExtra("url",rlLead_url);
                it.putExtra("flag",10);
                startActivity(it);
                break;
        }
    }

    //解析结果
    private void doResult(String response) {
        HelpPageBean hp = new Gson().fromJson(response, HelpPageBean.class);
        if (hp.getObject().getData().size() == 9) {
            rlDoWhat_url = hp.getObject().getData().get(0);
            rlApplyKey_url = hp.getObject().getData().get(1);
            rlApplyMostKey_url = hp.getObject().getData().get(2);
            rlBleUnlock_url = hp.getObject().getData().get(3);
            rlNfcUnlock_url = hp.getObject().getData().get(7);
            rlShareKey_url = hp.getObject().getData().get(4);
            rlManagerAuth_url = hp.getObject().getData().get(5);
            rlRemoteUnlock_url = hp.getObject().getData().get(6);
            rlLead_url=hp.getObject().getData().get(8);
            Log.e("tag", "rlDoWhat_url==" + hp.getObject().getData().get(0) + "rlApplyKey_url==" + hp.getObject().getData().get(1));
        }
    }
}
