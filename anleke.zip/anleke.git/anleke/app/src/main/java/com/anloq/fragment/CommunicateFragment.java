package com.anloq.fragment;

import android.util.Log;
import android.view.View;

import com.anloq.adapter.MyFragmentPagerAdapter;
import com.anloq.anleke.R;
import com.anloq.base.BaseFragment;
import com.anloq.model.EventBusMsg;
import com.anloq.ui.MyViewPager;
import com.flyco.tablayout.SlidingTabLayout;
import com.flyco.tablayout.listener.OnTabSelectListener;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/3/22:)
 * Function:联络页面的Fragment
 */
public class CommunicateFragment extends BaseFragment {

    private static final String TAG = CommunicateFragment.class.getSimpleName();
    @BindView(R.id.mTabLayout)
    SlidingTabLayout mTabLayout;
    @BindView(R.id.mViewPager)
    MyViewPager mViewPager;
    private List<BaseFragment> mFragments;
    //private String[] mTitles = new String[4];
    private String[] mTitles = new String[3];
    private int currentPos = 0;

    public int getCurrentPos() {
        return currentPos;
    }

    @Override
    public View initView() {
        View view = View.inflate(mContext, R.layout.fragment_communicate, null);
        ButterKnife.bind(this, view);
        Log.e(TAG, "联络页面的视图初始化了");
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        Log.e(TAG, "联络页面的数据初始化了");
        mTitles[0] = getResources().getString(R.string.call_record);
        mTitles[1] = getResources().getString(R.string.contacts);
        mTitles[2] = getResources().getString(R.string.services);
        //mTitles[3] = getResources().getString(R.string.dial_number);
        mViewPager.setNoScroll(true);
        initFragment();
        initListener();
    }

    private void initFragment() {
        mFragments = new ArrayList<>();
        mFragments.add(new CallRecFragment());
        mFragments.add(new ContactsFragment());
        mFragments.add(new ServiceFragment());
        //mFragments.add(new DialFragment());
        if (mFragments != null && mFragments.size() > 0) {
            // 设置ViewPager的适配器
            mViewPager.setAdapter(new MyFragmentPagerAdapter(getFragmentManager(), mFragments, mTitles));
            mTabLayout.setViewPager(mViewPager); // 将slidingTabLayout和ViewPager绑定！
        }
        mViewPager.setCurrentItem(0); // 默认在第一页
    }

    private void initListener() {
        // 设置Tab指示器选择的监听
        mTabLayout.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                mViewPager.setCurrentItem(position);
                currentPos = position;
                EventBusMsg msg;
                //if (position == 3) {
                if (position == 2) {
                    msg = new EventBusMsg("cardisshow", "0");
                } else {
                    msg = new EventBusMsg("cardisshow", "1");
                }
                EventBus.getDefault().post(msg);
            }

            @Override
            public void onTabReselect(int position) {

            }
        });
    }

}
