package com.anloq.activity;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.anloq.adapter.MyViewPagerAdapter;
import com.anloq.anleke.R;
import com.anloq.anleke.ble.BleGattAttributes;
import com.anloq.anleke.ble.BleService;
import com.anloq.api.Constants;
import com.anloq.base.BaseFragment;
import com.anloq.fragment.AnjuFragment;
import com.anloq.fragment.ApplyKeyFragment;
import com.anloq.fragment.CardFragment;
import com.anloq.fragment.CommunicateFragment;
import com.anloq.fragment.MeFragment;
import com.anloq.manager.BrightnessManager;
import com.anloq.manager.DBManager;
import com.anloq.model.CheckZoneBean;
import com.anloq.model.EventBusMsg;
import com.anloq.model.VKeysPkgBean;
import com.anloq.model.VkeyBean;
import com.anloq.nfcservice.EmqttService;
import com.anloq.nfcservice.NFCEmuService;
import com.anloq.receiver.NetStateReceiverUtil;
import com.anloq.runnable.MatchDeviceRunnable;
import com.anloq.ui.NoScrollViewPager;
import com.anloq.ui.NotifcationView;
import com.anloq.ui.UnlockLoading;
import com.anloq.utils.CheckNetStateUtils;
import com.anloq.utils.ConvertUtil;
import com.anloq.utils.DensityUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.anloq.utils.VKeyUtil;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.orhanobut.logger.Logger;
import com.umeng.analytics.MobclickAgent;
import com.umeng.socialize.UMShareAPI;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.Call;
import pub.devrel.easypermissions.EasyPermissions;
import pub.devrel.easypermissions.PermissionRequest;

import static com.anloq.anleke.ble.BleService.ACTION_DATA_AVAILABLE;
import static com.anloq.anleke.ble.BleService.ACTION_GATT_CONNECTED;
import static com.anloq.anleke.ble.BleService.ACTION_GATT_DISCONNECTED;
import static com.anloq.anleke.ble.BleService.ACTION_GATT_SERVICES_NO_DISCOVERED;
import static com.anloq.anleke.ble.BleService.ACTION_WRITE_SUCCESSFUL;

// 主页面
public class MainActivity extends FragmentActivity implements EasyPermissions.PermissionCallbacks {
    private final static String TAG = MainActivity.class.getSimpleName();
    @BindView(R.id.rbAnju)
    RadioButton rbAnju;
    @BindView(R.id.rbContact)
    RadioButton rbContact;
    @BindView(R.id.rbMe)
    RadioButton rbMe;
    @BindView(R.id.rgMain)
    RadioGroup rgMain;
    @BindView(R.id.flContainer)
    FrameLayout flContainer;
    @BindView(R.id.cardViewPager)
    NoScrollViewPager cardViewPager;
    @BindView(R.id.llPointGroup)
    LinearLayout llPointGroup;
    @BindView(R.id.ivRedPoint)
    ImageView ivRedPoint;
    @BindView(R.id.rlPoints)
    RelativeLayout rlPoints;

    private Context mContext;
    private List<BaseFragment> fragments;
    private List<BaseFragment> cardFragments = null;
    private int currentPosition = 0; // 默认为位置为0
    private Fragment tempFragment; // 用于存储临时的Fragment
    private CommunicateFragment communicateFragment;
    private static final int MESSAGE_BACK = 1;
    private static final int DISMISS = 3;
    private List<VKeysPkgBean.ObjectBean> vkeyList;
    private String key_id; // 全局开锁keyId
    public static String currentKeyId = "", currentZoneId = "";
    private List<String> allKeyId;
    private List<String> allRoomId;
    private List<String> allZoneId;
    private boolean cardIsShowing = false; // 卡片是否正在显示
    private boolean firstShowing = false; // 是否是第一次需要移动卡片
    private boolean isRemoteUnlock = true; // 是否是远程开锁，否则为蓝牙开锁
    public static boolean isVisible = false;
    private boolean isFlag = true;
    private int newHandsView = -1;
    private int leftMarg; // 两点间的间距
    private PopupWindow popupWindow;
    private View popupView;
    private HashSet<String> macSet; // 扫描到的mac地址集合
    private MatchDeviceRunnable matchDeviceRunnable;
    private boolean isFindEsp32Device = false;// 是否发现ESP32设备
    private UnlockLoading mUnlockLoading; // 开锁动画的加载视图
    private NetStateReceiverUtil netStateReceiverUtil;

    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_BACK:
                    isFlag = true; // 在2s时,恢复isFlag的变量值
                    break;
                case 2:
                    verticalRun(false);
                    break;
                case DISMISS:
                    dismissUnlockLoading();
                    if (!isRemoteUnlock) {
                        ToastUtil.show(getString(R.string.bt_connect_fail));
                        Log.e(TAG, "蓝牙连接失败");
                        mBleService.resetService();
                    }
                    break;
                case 4:
                    if (newHandsView != -1) {
                        showNewHandsView();
                        BrightnessManager.lightoff(mContext);
                    }
                    break;
                case 5:
                    Log.e(TAG, getString(R.string.not_find_devices));
                    ToastUtil.show(getString(R.string.device_not_find));
                    scanLeDevice(false);
                    mBleService.resetService();
                    dismissUnlockLoading();
                    break;
                case 6:
                    requestNewHandGuideMsg();
                    break;
            }
        }
    };

    /**
     * 请求发送新手引导消息
     */
    private void requestNewHandGuideMsg() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.SENDGUIDEMSG + uid + Constants.TOKEN + token;
        Log.e(TAG, "SENDGUIDEMSG_url===" + url);

        OkHttpUtils
                .postString()
                .url(url)
                .content(new Gson().toJson(null))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "SENDGUIDEMSG_Result===" + response);
                    }
                });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (WebRtcActivity.isLaunch && !WebRtcActivity.isHome) {
            startActivity(new Intent(MainActivity.this, WebRtcActivity.class));
        }
    }

    /**
     * 显示新手引导视图
     */
    private void showNewHandsView() {
        switch (newHandsView) {
            case 1:
                popupView = View.inflate(this, R.layout.activity_new_hand, null);
                popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.WRAP_CONTENT);
                break;
            case 2:
                popupView = View.inflate(this, R.layout.activity_press_card_guide, null);
                popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.WRAP_CONTENT);
                break;
            case 3:
                popupView = View.inflate(this, R.layout.activity_up_card_guide, null);
                popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT);
                break;
        }

        if (popupWindow == null) {
            return;
        }

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                BrightnessManager.lighton(mContext);
            }
        });

        popupWindow.setTouchable(true);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setOutsideTouchable(true);

        popupView.findViewById(R.id.activity_new_hand).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                BrightnessManager.lighton(mContext);
            }
        });

        if (popupWindow.isShowing()) {
            popupWindow.dismiss();
            BrightnessManager.lighton(mContext);
        }
        popupWindow.showAtLocation(MainActivity.this.findViewById(R.id.activity_main),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        mContext = this;
        boolean registered = EventBus.getDefault().isRegistered(this);
        if (!registered) {
            EventBus.getDefault().register(this);
        }
        initFragment();
        initListener();
        rgMain.check(R.id.rbAnju); // 默认选中“安居”
        getKeyBagData();
        isCheckSupport();
        // 当有钥匙包时再开始消息服务
        //startService(new Intent(MainActivity.this, ObserverService.class));
        boolean netState = SpUtil.getInstance().getBoolean("netstate", true);
        if (netState) {
            startService(new Intent(MainActivity.this, EmqttService.class));
        }
        startService(new Intent(MainActivity.this, NFCEmuService.class));
        macSet = new HashSet<>();
        netStateReceiverUtil = new NetStateReceiverUtil(this);
        netStateReceiverUtil.register();
    }

    /**
     * 获取钥匙包数据
     */
    private void getKeyBagData() {
        //String lasttime = SpUtil.getInstance().getString("lasttime", "");
        String lasttime = "";
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.KEYPACKAGE + uid + Constants.TOKEN + token;// + Constants.STARTTIME + lasttime;
        Logger.t(TAG).i("KEYPACKAGE_url===" + url);

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        String vkeyjson = SpUtil.getInstance().getString("vkeyjson", "");
                        if (!"".equals(vkeyjson)) {
                            parseJson(vkeyjson);
                        }
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        DataSupport.deleteAll(VkeyBean.class);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        VKeysPkgBean vKeysPkgBean = null;
        try {
            vKeysPkgBean = new Gson().fromJson(json, VKeysPkgBean.class);
        } catch (JsonSyntaxException e) {
            e.printStackTrace();
        }
        vkeyList = new ArrayList<>();
        allKeyId = new ArrayList<>();
        allRoomId = new ArrayList<>();
        allZoneId = new ArrayList<>();
        if (vKeysPkgBean != null) {
            SpUtil.getInstance().save("vkeyjson", json);
            String time = vKeysPkgBean.getTime();
            SpUtil.getInstance().save("lasttime", time);
            List<List<VKeysPkgBean.ObjectBean>> zoneVkeyList = vKeysPkgBean.getObject();
            if (zoneVkeyList != null && zoneVkeyList.size() > 0) {
                for (int i = 0; i < zoneVkeyList.size(); i++) {
                    List<VKeysPkgBean.ObjectBean> vkeyPkgFilter = new ArrayList<VKeysPkgBean.ObjectBean>();
                    List<VKeysPkgBean.ObjectBean> vkeyPkg = zoneVkeyList.get(i);
                    for (int j = 0; j < vkeyPkg.size(); j++) {
                        if (!vkeyPkg.get(j).getKey_info().isIs_deleted()) {
                            vkeyPkgFilter.add(vkeyPkg.get(j));
                        }
                    }
                    vkeyList.addAll(vkeyPkgFilter);
                }
            }
            if (vkeyList != null && vkeyList.size() > 0) {
                for (int i = 0; i < vkeyList.size(); i++) {
                    int key_id = vkeyList.get(i).getKey_info().getKey_id();
                    int room_id = vkeyList.get(i).getRoom_info().getRoom_id();
                    int zone_id = vkeyList.get(i).getRoom_info().getZone_id();
                    allKeyId.add("" + key_id);
                    allRoomId.add("" + room_id);
                    allZoneId.add("" + zone_id);
                    /**
                     * 保存到数据库！！！不在Card页面保存（防止ViewPager只初始化2页）！！！
                     */
                    DBManager.getInstance().saveVkeyList(vkeyList.get(i));
                }
            }
            if (allKeyId != null && allKeyId.size() > 0) {
                String currentkeyid = allKeyId.get(0);
                SpUtil.getInstance().save("currentkeyid", currentkeyid);
            }
            if (allRoomId != null && allRoomId.size() > 0) {
                String roomid = allRoomId.get(0);
                SpUtil.getInstance().save("roomid", roomid);
            }
            if (allZoneId != null && allZoneId.size() > 0) {
                SpUtil.getInstance().save("zoneid", allZoneId.get(0));
                for (int i = 0; i < allZoneId.size(); i++) {
                    // 发送ZoneId去订阅小区消息 -> EmqttService
                    EventBus.getDefault().post(new CheckZoneBean(allZoneId.get(i), true));
                }
            }
            initCardsFragment();
            initPoints();
        }
    }

    /**
     * 初始化指示点阵
     */
    private void initPoints() {
        // 先移除之前的点防止重复添加
        if (llPointGroup.getChildCount() > 0) {
            llPointGroup.removeAllViews();
        }
        int widthDpi = DensityUtil.dp2px(this, 4);
        for (int i = 0; i < cardFragments.size(); i++) {
            ImageView point = new ImageView(this);
            point.setImageResource(R.drawable.gray_point);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(widthDpi, widthDpi);
            if (i != 0) {
                params.leftMargin = widthDpi; //设置间距
            }
            point.setLayoutParams(params);
            llPointGroup.addView(point);
        }
        ivRedPoint.getViewTreeObserver().addOnGlobalLayoutListener(new MyOnGlobalLayoutListener());
        cardViewPager.addOnPageChangeListener(new MyOnPageChangeListener());
    }

    class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            // 坐标 = 起始位置 + 红点移动的距离
            float leftMargin = (position + positionOffset) * leftMarg;
            RelativeLayout.LayoutParams paramgs = (RelativeLayout.LayoutParams) ivRedPoint.getLayoutParams();
            // 距离左边的距离
            paramgs.leftMargin = (int) leftMargin;
            ivRedPoint.setLayoutParams(paramgs);
        }

        @Override
        public void onPageSelected(int position) {

        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    }

    class MyOnGlobalLayoutListener implements ViewTreeObserver.OnGlobalLayoutListener {

        @Override
        public void onGlobalLayout() {
            ivRedPoint.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            // 间距 = 第一个点距离左边距离 - 第0个点距离左边距离
            if (llPointGroup.getChildCount() >= 2) { // @防止空指针异常！！！
                leftMarg = llPointGroup.getChildAt(1).getLeft() - llPointGroup.getChildAt(0).getLeft();
            }
        }
    }

    /**
     * 设置卡片是否需要上下滑动
     *
     * @param isShow
     */
    public void verticalRun(boolean isShow) {
        // 根据手机密度精确计算卡片的高度
        int cardHeight = DensityUtil.getDelta(this);
        int delta = cardViewPager.getHeight() - cardHeight;
        ValueAnimator animator;
        if (!isShow) {
            animator = ValueAnimator.ofFloat(0, delta);
            rlPoints.setVisibility(View.VISIBLE);
        } else {
            animator = ValueAnimator.ofFloat(0, 0);
            rlPoints.setVisibility(View.GONE);
        }
        animator.setInterpolator(new AccelerateInterpolator());
        animator.setTarget(cardViewPager);
        animator.setDuration(300).start();
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                cardViewPager.setTranslationY((Float) animation.getAnimatedValue());
            }
        });
        cardIsShowing = isShow;
        flContainer.setVisibility(isShow ? View.GONE : View.VISIBLE);
        if (isShow) {
            boolean isfirstup = SpUtil.getInstance().getBoolean("isfirstup", false);
            if (isfirstup && vkeyList != null && vkeyList.size() > 0) {
                newHandsView = 3;
                handler.sendEmptyMessageDelayed(4, 500);
                SpUtil.getInstance().save("isfirstup", false);
            }
        }
    }

    private void initFragment() {
        fragments = new ArrayList<>();
        fragments.add(new AnjuFragment());
        communicateFragment = new CommunicateFragment();
        fragments.add(communicateFragment);
        fragments.add(new MeFragment());
    }

    private void initCardsFragment() {
        if (cardFragments == null) {
            cardFragments = new ArrayList<>();
        }
        for (int i = 0; i < vkeyList.size(); i++) {
            if (vkeyList.get(i).getKey_info().getKey_status() != 3) {
                CardFragment cardFragment = new CardFragment();
                cardFragment.setObjectBean(vkeyList.get(i));
                cardFragments.add(cardFragment);
            }
        }
        cardFragments.add(new ApplyKeyFragment());

        if (cardFragments != null && cardFragments.size() > 0) {
            MyViewPagerAdapter pagerAdapter = new MyViewPagerAdapter(getSupportFragmentManager(), cardFragments);
            cardViewPager.setAdapter(pagerAdapter);
        }

        cardViewPager.setCurrentItem(0, false); // 默认在第一页
        if (allKeyId != null && allKeyId.size() > 0) {
            currentKeyId = allKeyId.get(0);
        }
        if (vkeyList != null && vkeyList.size() > 0) {
            saveFirstKey(0);
        } else {
            SpUtil.getInstance().save("roomid", "");
        }
        cardViewPager.setOnShowListener(new NoScrollViewPager.onShowListener() {
            @Override
            public void isShow(boolean isShow) {
                verticalRun(isShow);
                // TODO 卡片展开后屏蔽滑动
                // cardViewPager.setNoScroll(isShow);
            }
        });

        cardViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                saveCurrentKeyState(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        if (vkeyList != null && vkeyList.size() > 0) {
            if (SpUtil.getInstance().getBoolean("nokey", false)) {
                newHandsView = 2;
                handler.sendEmptyMessageDelayed(4, 3000);
                SpUtil.getInstance().save("nokey", false);
            }
        }
    }

    /**
     * 保存当前钥匙的信息
     */
    private void saveCurrentKeyState(final int position) {
        new Thread() {
            public void run() {
                if (position < allKeyId.size()) {
                    Logger.t(TAG).i("allKeyId.size()===" + allKeyId.size() + ",position===" + position);
                    if (vkeyList != null && vkeyList.size() > 0) {
                        saveFirstKey(position);
                    }
                    if (allZoneId != null && allZoneId.size() > 0) {
                        currentZoneId = allZoneId.get(position);
                        SpUtil.getInstance().save("zoneid", currentZoneId);
                    }
                    if (allKeyId != null && allKeyId.size() > 0) {
                        currentKeyId = allKeyId.get(position);
                        SpUtil.getInstance().save("currentkeyid", currentKeyId);
                    }
                }
                EventBus.getDefault().post(new EventBusMsg("updateopendoor", currentKeyId));
                EventBus.getDefault().post(new EventBusMsg("updateservicenumber", currentZoneId));
            }
        }.start();
    }

    private void saveFirstKey(int position) {
        CardFragment baseFragment = (CardFragment) cardFragments.get(position);
        String device_key_sr = baseFragment.getDevice_key_sr();
        String first_key = baseFragment.getFirst_key();
        Logger.t(TAG).i("device_key_sr===" + device_key_sr + ",first_key===" + first_key);
        SpUtil.getInstance().save("device_key_sr", device_key_sr);
        SpUtil.getInstance().save("first_key", first_key);
        SpUtil.getInstance().save("key_id", baseFragment.getKey_id());
        SpUtil.getInstance().save("roomid", "" + baseFragment.getVKeysObjectBean().getRoom_info().getRoom_id());
    }

    private void initListener() {
        rgMain.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbAnju:
                        cardViewPager.setVisibility(View.VISIBLE);
                        if (cardIsShowing) {
                            flContainer.setVisibility(View.GONE);
                            rlPoints.setVisibility(View.GONE);
                        } else {
                            rlPoints.setVisibility(View.VISIBLE);
                        }
                        currentPosition = 0;
                        break;
                    case R.id.rbContact:
                        cardViewPager.setVisibility(View.VISIBLE);
                        if (cardIsShowing) {
                            flContainer.setVisibility(View.GONE);
                            rlPoints.setVisibility(View.GONE);
                        }
                        currentPosition = 1;
                        int currentPos = communicateFragment.getCurrentPos();
                        if (currentPos == 3) {
                            cardViewPager.setVisibility(View.GONE);
                            rlPoints.setVisibility(View.GONE);
                        } else {
                            cardViewPager.setVisibility(View.VISIBLE);
                            rlPoints.setVisibility(View.VISIBLE);
                        }
                        break;
                    case R.id.rbMe:
                        rlPoints.setVisibility(View.GONE);
                        cardViewPager.setVisibility(View.GONE);
                        flContainer.setVisibility(View.VISIBLE);
                        currentPosition = 2;
                        break;
                }
                BaseFragment fragment = getFragmentByPosition(currentPosition);
                switchFragment(tempFragment, fragment);
            }
        });
    }

    private void switchFragment(Fragment fromFragment, Fragment toFragment) {
        if (tempFragment != toFragment) {
            tempFragment = toFragment;
            if (toFragment != null) {
                FragmentTransaction transaction = this.getSupportFragmentManager()
                        .beginTransaction(); // 开启事务
                // 判断要显示的Fragment是否已经被添加
                if (!toFragment.isAdded()) {
                    if (fromFragment != null) {
                        transaction.hide(fromFragment); // 隐藏当前的
                    }
                    transaction.add(R.id.flContainer, toFragment).commit(); // 添加新的
                } else {
                    if (fromFragment != null) {
                        transaction.hide(fromFragment);
                    }
                    transaction.show(toFragment).commit();
                }
            }
        }
    }

    private BaseFragment getFragmentByPosition(int position) {
        if (fragments != null && fragments.size() > 0) {
            return fragments.get(position);
        }
        return null;
    }

    private String[] location = {Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION};

    /**
     * 处理6.0动态权限
     */
    private void mayRequestLocation() {
        EasyPermissions.requestPermissions(
                new PermissionRequest.Builder(this, 520, location)
                        .setRationale("need permissions")
                        .setPositiveButtonText("confirm")
                        .setNegativeButtonText("reject")
                        .build());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Forward results to EasyPermissions
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        if (requestCode == 520) {
            verifyVirtualKey();
        }
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        Toast.makeText(this, "you reject permission!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && isFlag) {
            isFlag = false;
            ToastUtil.show(getString(R.string.press_keyback_again));
            handler.sendEmptyMessageDelayed(MESSAGE_BACK, 2000);
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        EventBus.getDefault().unregister(this);
        if (mServiceConnected) {
            mServiceConnected = false;
            unbindService(mServiceConnection); // 解绑服务
            mServiceConnection = null;
        }
        unregisterReceiver(mGattUpdateReceiver); // 解注册广播
        if (netStateReceiverUtil != null) {
            netStateReceiverUtil.unregister();
        }
    }

//////////////////////////BLE UNLOCK START//////////////////////////////

    private BleService mBleService; // ble服务
    private boolean mServiceConnected = false; // 是否已经连接
    private BluetoothAdapter mBluetoothAdapter; // 蓝牙适配器
    private static final int REQUEST_ENABLE_BT = 1; // 请求码
    private boolean mScanning; // 记录是否正在扫描
    private long recvBytes = 0; // 接收的字节数
    private long sendBytes; // 发送字节数
    private int sendIndex = 0;
    private int sendData1Len = 0;
    private int sendData2Len = 0;
    private byte[] sendData1;
    private int secondDataLen;
    private byte[] sendData2;
    private String mFirst_Key = null;
    private List<String> mBtMacList = null;
    private String mBtMac = "";
    private String mDevice_Key_Sr = null;
    private byte[] mVkeyData = null;
    private boolean isHead = false; // 是否已经收到头
    private boolean mbOnUnlockState = false;
    private int firstDataLen = -1; // 数据长度
    private int serviceCode = 0; // 业务代码
    private int currentPos = 0; // 当前数据存储到的位置
    private String watingCode = ""; // 等待码
    private byte[] byteBuffer3 = new byte[1024];
    private byte[] byteService = new byte[1024];

    /**
     * 服务状态改变时的回调
     */
    private ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBleService = ((BleService.LocalBinder) service).getService();
            if (!mBleService.initialize()) {
                Logger.t(TAG).e("初始化蓝牙设备失败！");
                finish();
            }
            mServiceConnected = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBleService = null;
            mServiceConnected = false;
        }
    };

    /**
     * 通过服务处理各种事件
     * ACTION_GATT_CONNECTED: 连接到GATT服务.
     * ACTION_GATT_DISCONNECTED: 从GATT服务断开.
     * ACTION_GATT_SERVICES_DISCOVERED: GATT服务被发现.
     * ACTION_DATA_AVAILABLE: 从设备接收数据.
     * This can be a result of read or notification operations.
     */
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {

        /**
         * 当收到广播时的回调
         * @param context
         * @param intent
         */
        @Override
        public void onReceive(Context context, final Intent intent) {
            String action = intent.getAction();

            if (ACTION_GATT_CONNECTED.equals(action)) {
                Logger.t(TAG).i("ACTION_GATT_CONNECTED");

            } else if (ACTION_GATT_DISCONNECTED.equals(action)) {
                Logger.t(TAG).e("ACTION_GATT_DISCONNECTED");
//                if (llUnlocking.getVisibility() == View.VISIBLE) {
//                    llUnlocking.setVisibility(View.GONE);
//                }
                dismissUnlockLoading();

            } else if (BleService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                Logger.t(TAG).i("ACTION_GATT_SERVICES_DISCOVERED");
                sendBtDataPkg();

            } else if (ACTION_GATT_SERVICES_NO_DISCOVERED.equals(action)) {
                Logger.t(TAG).e("ACTION_GATT_SERVICES_NO_DISCOVERED");

            } else if (ACTION_DATA_AVAILABLE.equals(action)) {
                Logger.t(TAG).i("ACTION_DATA_AVAILABLE");
                parseData(intent.getByteArrayExtra(BleService.EXTRA_DATA));

            } else if (ACTION_WRITE_SUCCESSFUL.equals(action)) {
                Logger.t(TAG).i("ACTION_WRITE_SUCCESSFUL");

                if (sendData1Len > 0) {
                    onSendBtnClicked(); // 写入数据成功后,判断是否还有数据再写入第二包数据
                } else {
                    byteService = new byte[1024];
                }

                if (secondDataLen != 793) { // 如果发送了140字节就变为等待状态
                    recvBytes = 0;
                    isHead = false;
                }

                if (secondDataLen > 0) {
                    onSendBtnClicked2(); // 写入数据成功后再写入第二包数据
                } else {
                    recvBytes = 0;
                    isHead = false;
                    byteService = new byte[1024];
                }
            }
        }
    };

    /**
     * 判断手机是否支持ble等准备工作
     */
    private void isCheckSupport() {
        // 判断手机是否支持ble
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            ToastUtil.show(getString(R.string.ble_not_support));
            Logger.t(TAG).e("BLE不支持");
        }
        // 初始化蓝牙适配器,通过蓝牙管理器获取蓝牙适配器对象
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        // 检查手机是否支持蓝牙
        if (mBluetoothAdapter == null) {
            ToastUtil.show("Bluetooth not supported.");
            Logger.t(TAG).e("Bluetooth not supported.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
        // 用于选择是否开启手机蓝牙
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_OK) {
            ToastUtil.show("蓝牙已打开");
//            if (llUnlocking.getVisibility() == View.VISIBLE) {
//                llUnlocking.setVisibility(View.GONE);
//            }
            mayRequestLocation();
        }
    }

    /**
     * 根据enable的值是否要扫描le设备
     */
    private boolean scanLeDevice(final boolean enable) {
        UUID[] serviceUuids = new UUID[1];
        serviceUuids[0] = UUID.fromString(BleGattAttributes.BLE_SPP_Service);
        if (enable) {
            mScanning = true;
            mBluetoothAdapter.startLeScan(serviceUuids, mLeScanCallback);
        } else {
            mScanning = false;
            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }
        return mScanning;
    }

    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
                    Logger.t(TAG).i("onLeScan device:" + device.getAddress() + ",rssi:" + rssi);
                    macSet.add(device.getAddress().toLowerCase());
                }
            };

    @Override
    protected void onResume() {
        super.onResume();
        NotifcationView.cancelNotice();
        MobclickAgent.onResume(this);
        // 将已经更新状态置为false
        SpUtil.getInstance().save("alreadyupdatedcards", false);
        boolean addupdate = SpUtil.getInstance().getBoolean("addupdate", false);
        if (addupdate) {
            cardFragments.clear(); // 先清空卡片
            getKeyBagData();
            SpUtil.getInstance().save("addupdate", false);
        }
        isVisible = true;
        if (!firstShowing) {
            handler.sendEmptyMessageDelayed(2, 1000);
            firstShowing = true;
        }
        Intent gattServiceIntent = new Intent(this, BleService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        if (SpUtil.getInstance().getBoolean("isregister", false)) {
            newHandsView = 1;
            handler.sendEmptyMessageDelayed(4, 5000);
            handler.sendEmptyMessageDelayed(6, 5000);
            SpUtil.getInstance().save("isregister", false);
        }

        // 判断用户是否按了Home键
        boolean iscaller = SpUtil.getInstance().getBoolean("iscaller", false);
        boolean presshome = SpUtil.getInstance().getBoolean("presshome", false);
        Logger.t(TAG).i("iscaller===" + iscaller);
        if (iscaller || presshome) {
            startActivity(new Intent(MainActivity.this, WebRtcActivity.class));
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        isVisible = false;
        MobclickAgent.onPause(this);
    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_GATT_CONNECTED);
        intentFilter.addAction(ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BleService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(ACTION_DATA_AVAILABLE);
        intentFilter.addAction(ACTION_WRITE_SUCCESSFUL);
        intentFilter.addAction(ACTION_GATT_SERVICES_NO_DISCOVERED);
        return intentFilter;
    }

    /**
     * 获取发送缓存字节数
     */
    private void getSendBuf1() {
        // 重新初始化
        isHead = false;
        recvBytes = 0;
        firstDataLen = -1;
        serviceCode = -1;
        byteService = new byte[1024];
        byteBuffer3 = new byte[1024];
        currentPos = 0;
        sendData1Len = 0;

        sendIndex = 0;
        sendData1 = new byte[16];
        sendData1[0] = 0x55;
        sendData1[1] = (byte) 0xAA;
        sendData1[2] = 0x00;
        sendData1[3] = 0x00;
        sendData1[4] = 0x0B;

        // 业务7.获取userId
        Logger.t(TAG).i("业务7.获取mKey_id===" + key_id);
        // 获取16进制字符串
        long lkey = 10000000000L + Integer.parseInt(key_id);
        String lstrkey = "" + lkey;
        String hexString = ConvertUtil.ByteArrayToHexString(lstrkey.getBytes());
        // 将16进制字符串转换为16进制数组
        byte[] hexBytes = lstrkey.getBytes();//ConvertUtil.HexStringToByteArray(hexString);
        Logger.t(TAG).i("hexUserId===" + hexString + ",hexBytesLength===" + hexBytes.length);
        System.arraycopy(hexBytes, 0, sendData1, 5, hexBytes.length);
        // 要发送数据的长度
        firstDataLen = sendData1.length;
        sendData1Len = sendData1.length;
    }

    /**
     * 获取发送缓存字节数
     */
    private void getSendBuf2() {
        sendData2 = new byte[mVkeyData.length + 5];
        sendData2[0] = 0x55;
        sendData2[1] = (byte) 0xAA;
        sendData2[2] = 0x02;
        sendData2[3] = 0x03;
        sendData2[4] = 0x14;
        // 获取16进制字符串
        String hexString = ConvertUtil.ByteArrayToHexString(mVkeyData);
        // 将16进制字符串转换为16进制数组
        byte[] hexBytes = mVkeyData;//ConvertUtil.HexStringToByteArray(hexString);
        Logger.t(TAG).i("vKey===" + hexString + ",vKeyLength===" + hexBytes.length);
        System.arraycopy(hexBytes, 0, sendData2, 5, hexBytes.length);
        // 要发送数据的长度
        secondDataLen = sendData2.length;
        sendData2Len = sendData2.length;
        Logger.t(TAG).i("secondDataLen===" + secondDataLen);
    }

    /**
     * 开锁按钮的点击事件
     */
    private void onSendBtnClicked() {
        if (firstDataLen > 20) { // 如果大于20字节就分包
            sendBytes += 20;
            byte[] buf = new byte[20]; // 缓存
            for (int i = 0; i < 20; i++) {
                buf[i] = sendData1[sendIndex + i];
            }
            sendIndex += 20;
            if (!mBleService.writeData(mBtMac, buf)) {
                mbOnUnlockState = false;
                mBleService.resetService();
                return;
            }
            sendData1Len -= 20; // 每发完20byte后就减掉20
        } else {
            if (firstDataLen == -1) {
                Logger.t(TAG).e("firstDataLen == -1");
                return;
            }
            byte[] buf = new byte[firstDataLen];
            for (int i = 0; i < firstDataLen; i++) {
                buf[i] = sendData1[sendIndex + i];
            }
            if (mBleService == null) {
                Logger.t(TAG).e("mBleService == null");
                return;
            }

            if (!mBleService.writeData(mBtMac, buf)) {
                mbOnUnlockState = false;
                mBleService.resetService();
                return;
            } else {
                // @写入第一组数据成功后将连接状态置为false
                mbOnUnlockState = true;
            }
            sendData1Len = 0;
            sendIndex = 0;
            Logger.t(TAG).i("用户标识发送完成");
        }
    }

    /**
     * 继续写入第二包数据20B一包
     */
    private void onSendBtnClicked2() {
        if (secondDataLen > 20) { // 如果大于20字节就分包
            sendBytes += 20;
            byte[] buf = new byte[20]; // 缓存

            for (int i = 0; i < 20; i++) {
                buf[i] = sendData2[sendIndex + i];
            }
            sendIndex += 20;
            if (mBleService == null) {
                Logger.t(TAG).e("mBleService == null");
                return;
            }
            if (!mBleService.writeData(mBtMac, buf)) {
                mbOnUnlockState = false;
                mBleService.resetService();
                return;
            }
            secondDataLen -= 20; // 每发完20byte后就减掉20
        } else {
            byte[] buf = new byte[secondDataLen];
            for (int i = 0; i < secondDataLen; i++) {
                buf[i] = sendData2[sendIndex + i];
            }
            if (!mBleService.writeData(mBtMac, buf)) {
                mbOnUnlockState = false;
                mBleService.resetService();
                return;
            }
            secondDataLen = 0;
            sendIndex = 0;
        }
        Log.e(TAG, "第二组数据发送完成");
    }


    /**
     * 解析收到的数据
     */
    private void parseData(byte[] buf) {
        try {
            recvBytes += buf.length;
            Logger.t(TAG).i("currentPos===" + currentPos);
            System.arraycopy(buf, 0, byteBuffer3, currentPos, buf.length);
            currentPos += buf.length;
            Logger.t(TAG).i("buf===" + ConvertUtil.ByteArrayToHexString(buf));
            if (recvBytes > 5 && !isHead) { // 收到的字节大于5先取出长度和业务代码
                byte[] bLenth = new byte[2];
                try {
                    System.arraycopy(buf, 3, bLenth, 0, 2);
                } catch (Exception e) {
                    e.printStackTrace();
                    // 处理异常情况
                    dismissUnlockLoading();
                    mBleService.resetService();
                }
                serviceCode = (short) (0xff & buf[2]); // 取出业务代码
                watingCode = ConvertUtil.ByteArrayToHexString(buf).substring(0, 12);
                Logger.t(TAG).i("watingCode===" + watingCode);
                firstDataLen = (short) ((0xff & bLenth[1]) | (0xff00 & (bLenth[0] << 8))) + 5; // 取出数据长度
                // 业务代码0表示第一次发送过来的数据，业务代码2表示第二次发送过来的数据
                // 业务代码1表示第一次发给对方的数据，业务代码3表示第二次发给对方的数据
                Logger.t(TAG).i("业务代码===" + serviceCode + ",数据总长度===" + firstDataLen);
                isHead = true;
            }

            Log.e(TAG, "firstDataLen===" + firstDataLen + ",recvBytes===" + recvBytes);
            if (firstDataLen == recvBytes) {
                System.arraycopy(byteBuffer3, 5, byteService, 0, firstDataLen - 5);
                if (serviceCode == 1) {        // 业务代码1
                    sendVkey(byteService);
                } else if (serviceCode == 3) { // 业务代码2
                    showResult(watingCode);
                }
                isHead = false;
                recvBytes = 0;
                firstDataLen = -1;
                serviceCode = -1;
                byteService = new byte[1024];
                byteBuffer3 = new byte[1024];
                currentPos = 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            // 处理异常情况
            dismissUnlockLoading();
            mBleService.resetService();
        }
    }

    /**
     * 显示开锁结果
     */
    private void showResult(String bytes) {
        dismissUnlockLoading();
        handler.removeMessages(DISMISS);
        String result = bytes.substring(11, 12);
        Logger.t(TAG).i("showResult result===" + result);
        switch (result) {
            case "0":
                Log.e(TAG, "开锁失败");
                ToastUtil.show(getString(R.string.open_door_fail));
                break;
            case "1":
                Log.e(TAG, "开锁成功");
                ToastUtil.show(getString(R.string.open_door_success));
                break;
        }
        if (mBleService != null) {
            mBleService.resetService();
        }
        mbOnUnlockState = false; // @将连接状态置为false
    }

    private void sendVkey(byte[] mCert) {
        // 此处应指明用户用的哪个钥匙去开门即key_id = xxx
        if (mFirst_Key == null || mDevice_Key_Sr == null) {
            Log.e(TAG, "mFirst_Key||mDevice_Key_Sr==null");
            return;
        }
        mFirst_Key = new String(Base64.decode(mFirst_Key, Base64.DEFAULT));
        Logger.t(TAG).i("mFirst_Key==" + mFirst_Key.length() + ",mDevice_Key_Sr===" + mDevice_Key_Sr.length());
        Logger.t(TAG).i("mFirst_Key==" + mFirst_Key + ",mDevice_Key_Sr===" + mDevice_Key_Sr);
        //mFirst_Key = "3D428950-A474-F5DD-D674-25B03014739B20170311-11:00:122";
        //mDevice_Key_Sr = "SpjyZio6UtF1GO9cyyCvYoWYT5XQ7+9B+xSZTKtODuU1l9XdBOiMJtATQR/mfrl1mean5ZBfFw5zahKQRdeeyd9isNIrmA2rczpUyXS9bIKYuVyge2mIOWqhqXXistHnScmp0Ii2FT9z+vrRSpcddsnmMUMYb/Ws6NfZdg7SB8mAIE6mq3qTvBPU3VWghNpLdtk++mWhJx45MX8Vowxw1MKubNV5sEsRb3/sgQJQUaXycJMcQbx5Gs+7j9XLTgTGGa1byF9r78TlZs7oouXhqAXR1wvJjJp7SDk8uoza300UCpiqwrHxSonF4E+VM03Tqzu2TEkVcH4Q+7F4ZfeWYC8Ye4/ZWL2T1JNTVRDe4aF8AvG6oSfkf95uBztPVJctfGA6GUo2GWf0UbuQeFKa9cxlDmRkMTXfaPbQEc5JBpdpvmkZBdLBrmWhMF+jwcdbfnZ5DoKdMtfzU3+bezoR14CX/nIhL1lad2Pt8TyRBAzxjj/6RDIAQfeAPWpUeZf3Js31vSqyEqxG/PhKFo0ff5Vp1Tq1dT6DolGs4BxNhc1SLQ1jIojatlbMY0ddUjZJgZCVagpiHMMgFSwVIj1N0LLWUwnFCwu3WZXn8AGeGQ1pjQe75d31kyv8jUvAYWaCSl1STgXlqe+xI3nI5LMzxF+CDJrcGcgizihM2ZPaeoZwTwfOUcBOd1gJKkG0tz9C2OlBYROuA2vRCpHKD0bEOZLC+BwLeo9nnHSC1v0/bgy492dl7tFLfdSbL6AQGYc06pEeVQuCeEZsKO0Em3z5C3NtTNz2t9UcwN0FwDqVajltqJKAYHPxbGAKb0j0uUEo7WHnUsRY30tCFkLWxiqFhy/18m584QwxkILJjzKMsYEVxa7KrTwfgqY69nMDqrFelkzRpEF7Z1F34fPhob3LalIBod82y7I7RZRVU2b94pVa9bBN7aKuwvHf0IwHkkDA";
        byte[] dksr = Base64.decode(mDevice_Key_Sr, Base64.DEFAULT);
        Logger.t(TAG).i("mFirst_Key===" + mFirst_Key);
        mVkeyData = new VKeyUtil().vkeyCommandPack(mCert, dksr, mFirst_Key.getBytes(), 1);
        getSendBuf2();
        onSendBtnClicked2();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBusMsg event) {
        Logger.t(TAG).i("onEventMainThread收到了消息：" + event.toString());
        switch (event.getType()) {
            case "unlock":
                key_id = event.getContent();
                openDoorWithBle();
                break;
            case "updatecards":
                Log.e(TAG, "updatecards...");
                SpUtil.getInstance().save("alreadyupdatedcards", true);
                cardFragments.clear(); // 先清空卡片
                getKeyBagData();
                break;
            case "cardisshow":
                String content = event.getContent();
                if ("0".equals(content)) {
                    cardViewPager.setVisibility(View.GONE);
                } else if ("1".equals(content)) {
                    cardViewPager.setVisibility(View.VISIBLE);
                }
                break;
            case "unlockresult":
                // 开锁成功后隐藏动画
                dismissUnlockLoading();
                break;
            default:
                break;
        }
    }

    /**
     * 使用ble开门
     */
    private void openDoorWithBle() {
        // 业务2.收到开锁指令和key_id
        Logger.t(TAG).i("业务2.收到开锁指令和key_id=" + key_id);
        int cardState = DBManager.getInstance().getCardState(Integer.parseInt(key_id));
        // 业务3.根据key_id判断卡片当前状态
        Logger.t(TAG).i("业务3.根据key_id判断卡片当前状态cardState" + cardState);
        if (2 == cardState) {
            boolean invalidKey = DBManager.getInstance().isInvalidKey(Integer.parseInt(key_id));
            // 业务4.根据key_id判断卡片是否有在效期内
            Logger.t(TAG).i("业务4.根据key_id判断卡片是否有在效期内" + !invalidKey);
            if (invalidKey) {
                ToastUtil.show(getString(R.string.vkey_outdate));
            } else {
                // 业务5.判断蓝牙是否打开
                if (mBluetoothAdapter.isEnabled()) {
                    Logger.t(TAG).i("业务5.蓝牙已经打开~");
                    mayRequestLocation(); // 处理动态权限
                } else {
                    Logger.t(TAG).i("业务5.蓝牙没有打开！");
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                }
            }
        } else if (1 == cardState) {
            ToastUtil.show(getString(R.string.card_is_applying));
        } else if (3 == cardState) {
            ToastUtil.show(getString(R.string.vkey_rejected));
        }
    }

    /**
     * 显示开锁加载动画
     */
    private void showUnlockLoading() {
        if (mUnlockLoading == null) {
            mUnlockLoading = new UnlockLoading(mContext);
        }
        mUnlockLoading.show();
    }

    /**
     * 取消开锁加载动画
     */
    private void dismissUnlockLoading() {
        if (mUnlockLoading != null) {
            mUnlockLoading.dismiss();
        }
    }

    /**
     * 校验虚拟钥匙
     */
    private void verifyVirtualKey() {
        // 显示开锁动画
        showUnlockLoading();
        // 处理10s还没有完成开锁时的动画
        handler.sendEmptyMessageDelayed(DISMISS, 10000);

        // 如果有网进行，在线开锁
        if (CheckNetStateUtils.isEnable()) {
            isRemoteUnlock = true;
            scanBleDevice();
        } else { // 走蓝牙开锁
            isRemoteUnlock = false;
            // 业务6.开始发送数据...
            Logger.t(TAG).i("业务6.开始发送数据...");
            List<VkeyBean> keyList = DataSupport.where("key_id = ?", key_id).find(VkeyBean.class);
            for (int i = 0; i < keyList.size(); i++) {
                mFirst_Key = keyList.get(i).getFirst_key();
                mDevice_Key_Sr = keyList.get(i).getDevice_key_sr();
                mBtMacList = keyList.get(i).getBt_device_mac();
            }
            if (mBtMacList != null && mBtMacList.size() > 0) {
                for (int i = 0; i < mBtMacList.size(); i++) {
                    mBtMac = mBtMacList.get(i);
                    Logger.t(TAG).i("mBtMac===" + mBtMac);
                    // TODO: 2017/11/8 适配ESP32蓝牙开锁
                    //if (mBtMac.startsWith("24:0a")) {
                    //    scanBleEsp32();
                    //} else {
                    BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(mBtMac.toUpperCase());
                    mBleService.connect(device);
                    //}
                }
            }
        }
    }

    /**
     * 扫描ble设备列表1秒，并开始进行在线匹配开锁
     */
    private void scanBleDevice() {
        if (macSet.size() > 0) {
            macSet.clear();
        }
        scanLeDevice(true); // 去扫描设备
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                scanLeDevice(false); // 去扫描设备
                startMatchMac();
            }
        }, 1000);
    }

    /**
     * 扫描ble Esp32设备列表1秒，并开始进行蓝牙开锁
     */
    private void scanBleEsp32() {
        macSet.clear();
        scanLeDevice(true); // 去扫描设备
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                scanLeDevice(false); // 去扫描设备
                openDoorWithEsp32();
            }
        }, 1000);
    }

    /**
     * ESP32设备开锁
     */
    private void openDoorWithEsp32() {
        if (macSet.size() > 0) {
            for (String mac : macSet) {
                // 2.判断扫描到的mac是否存在于"24:0a"开头的mac
                if (mac.startsWith("24:0a")) {
                    isFindEsp32Device = true;
                    BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(mac.toUpperCase());
                    mBleService.connect(device);
                } else {
                    isFindEsp32Device = false;
                }
            }

            if (!isFindEsp32Device) {
                showNotFindDevice();
            }

        } else {
            showNotFindDevice();
        }
    }

    private void showNotFindDevice() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ToastUtil.show(getString(R.string.unlock_fail));
            }
        });
    }

    /**
     * 发送蓝牙数据包
     */
    private void sendBtDataPkg() {
        getSendBuf1();
        onSendBtnClicked();
    }

    /**
     * 开始匹配mac地址进行在线开锁
     */
    private void startMatchMac() {
        if (matchDeviceRunnable == null) {
            matchDeviceRunnable = new MatchDeviceRunnable(mContext, key_id, macSet);
        } else {
            matchDeviceRunnable.setKeyId(key_id);
            matchDeviceRunnable.setMacSet(macSet);
            matchDeviceRunnable.setContext(mContext);
        }
        new Thread(matchDeviceRunnable).start();
    }

}