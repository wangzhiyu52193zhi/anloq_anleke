package com.anloq.activity;

import android.app.Activity;
import android.net.http.SslError;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.anleke.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Steven on 2017/6/24.
 */

public class HelpPageActivity extends Activity {
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.help_webView)
    WebView help_webView;
    private String url = "";
    private int flag = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_answer);
        ButterKnife.bind(this);
        url = getIntent().getStringExtra("url");
        flag = getIntent().getIntExtra("flag", -1);
        Log.e("HelpPageActivity", "url==" + url + ",flag==" + flag);
        initWebviewPager();
    }

    // 初始化数据
    private void initWebviewPager() {
        if (!url.equals("")) {
            WebSettings settings = help_webView.getSettings();
            settings.setUseWideViewPort(true);   // 设置支持双击页面变大
            settings.setLoadWithOverviewMode(true);
            settings.setPluginState(WebSettings.PluginState.ON);
            // 设置优先使用网络缓存
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
            settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
            settings.setJavaScriptEnabled(true); // 设置使用javaScript
            // 关键的部分就是在这里设置Client
            help_webView.setWebChromeClient(new WebChromeClient());
            help_webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    view.loadUrl(url);
                    // 返回值为true的时候表示使用webview打开,为false表示使用系统的浏览器或者使用第三方的浏览器打开
                    return true;
                }

                @Override
                public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                    //super.onReceivedSslError(view, handler, error);
                    handler.proceed();
                }
            });

            switch (flag) {

                case 1: // 安络克能做什么
                    tvTitle.setText(R.string.do_what);
                    break;
                case 2: // 如何申请钥匙
                    tvTitle.setText(R.string.apply_vkey);
                    break;
                case 3: // 如何申请多个钥匙包
                    tvTitle.setText(R.string.apply_more_vkey);
                    break;
                case 4: // 如何使用蓝牙开锁
                    tvTitle.setText(R.string.ble_open_door);
                    break;
                case 5: // 如何使用NFC开锁
                    tvTitle.setText(R.string.nfc_open_door);
                    break;
                case 6: // 如何授权
                    tvTitle.setText(R.string.auth_key);
                    break;
                case 7: // 更改记录
                    tvTitle.setText(R.string.record_);
                    break;
                case 8: // 远程开锁
                    tvTitle.setText(R.string.remote_open_door);
                    break;
                case 9: // 安络技术
                    tvTitle.setText(R.string.anloq_technolegy);
                    break;
                case 10: // 安络技术
                    tvTitle.setText(R.string.join_white_list);
                    break;
                default:
                    break;
            }
            Log.e("TAG", "initWebviewPager: "+flag+"++++"+url);
            help_webView.loadUrl(url);
        }
    }

    @OnClick({R.id.ivBack})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        help_webView.destroy();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
