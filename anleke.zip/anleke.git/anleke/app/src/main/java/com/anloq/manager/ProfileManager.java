package com.anloq.manager;

import com.anloq.api.Constants;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;

import okhttp3.Call;
import okhttp3.MediaType;

/**
 * Created by xpf on 2017/8/9 :)
 * Function:个人信息修改的管理类
 */

public class ProfileManager {

    private static final String TAG = ProfileManager.class.getSimpleName();

    /**
     * 修改信息
     */
    public static void update(HashMap map, final OnProfileUpdateListener onProfileUpdateListener) {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String content = new Gson().toJson(map);
        Logger.t(TAG).json(content);
        String url = Constants.CHANGEPROFILE + uid + Constants.TOKEN + token;
        Logger.t(TAG).i("CHANGEPROFILE_url===" + url);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e(e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        if (onProfileUpdateListener != null) {
                            onProfileUpdateListener.onUpdate(response);
                        }
                    }
                });
    }

    public interface OnProfileUpdateListener {
        void onUpdate(String result);
    }
}
