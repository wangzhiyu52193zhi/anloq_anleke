package com.anloq.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.BrightnessManager;
import com.anloq.manager.DBManager;
import com.anloq.model.EventBusMsg;
import com.anloq.model.VkeyBean;
import com.anloq.ui.CardView;
import com.anloq.ui.GlideRoundTransform;
import com.anloq.utils.MessageProvider;
import com.anloq.utils.SpUtil;
import com.anloq.utils.TimeUtil;
import com.anloq.utils.ToastUtil;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;
import org.wangchenlong.datescroller.widget.DateScrollerDialog;
import org.wangchenlong.datescroller.widget.data.Type;
import org.wangchenlong.datescroller.widget.listener.OnDateSetListener;

import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.MediaType;
import pub.devrel.easypermissions.EasyPermissions;
import pub.devrel.easypermissions.PermissionRequest;

// 授权钥匙详情页面
public class NormalAuthActivity extends FragmentActivity implements EasyPermissions.PermissionCallbacks {
    private static final String TAG = NormalAuthActivity.class.getSimpleName();
    public static final int PICK_CONTACT = 1;
    public static final int ANLOQCONTACT = 2;
    @BindView(R.id.tvCover)
    TextView tvCover;
    @BindView(R.id.ivNfc)
    ImageView ivNfc;
    @BindView(R.id.ivBle)
    ImageView ivBle;
    @BindView(R.id.tvZone)
    TextView tvZone;
    @BindView(R.id.tvBuilding)
    TextView tvBuilding;
    @BindView(R.id.tvUnit)
    TextView tvUnit;
    @BindView(R.id.tvRoom)
    TextView tvRoom;
    @BindView(R.id.tvStartDate)
    TextView tvStartDate;
    @BindView(R.id.tvEndDate)
    TextView tvEndDate;
    @BindView(R.id.llInDate)
    LinearLayout llInDate;
    @BindView(R.id.tvApply)
    TextView tvApply;
    @BindView(R.id.rlCard)
    RelativeLayout rlCard;
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.ivCard)
    ImageView ivCard;
    @BindView(R.id.etPhone)
    TextView etPhone;
    @BindView(R.id.tvName)
    TextView tvName;
    @BindView(R.id.tvStartTime)
    TextView tvStartTime;
    @BindView(R.id.llStartTime)
    LinearLayout llStartTime;
    @BindView(R.id.tvEndTime)
    TextView tvEndTime;
    @BindView(R.id.llEndTime)
    LinearLayout llEndTime;
    @BindView(R.id.tvShip)
    TextView tvShip;
    @BindView(R.id.llShip)
    LinearLayout llShip;
    @BindView(R.id.llName)
    LinearLayout llName;
    @BindView(R.id.btnAuth)
    TextView btnAuth;
    @BindView(R.id.btnReject)
    TextView btnReject;
    @BindView(R.id.ivContact)
    ImageView ivContact;

    private Context mContext;
    private int cursor_position = 0;
    private String userName = "";// 手机联系人的姓名
    private long mLastTime = System.currentTimeMillis(); // 上次设置的时间
    private boolean isStartTime = true;
    private int currentState = -1;
    private int authState = 1;
    private int RejectState = 2;

    private PopupWindow popupShip, popupWindow;
    private View popupShipView, popupView;
    private TranslateAnimation animation;
    private int uid = -1;
    private String token = "";
    private boolean isMainToAuth = false;  // 是否是主动授权
    private boolean isCountsAuth = false; // 是否是按次授权(否则为按时间授权)
    private String user_name; // 主动授权时不用填
    private String user_phone = ""; // 被授权者电话，要真实有效，在安络平台上注册过
    private int ship = -1;
    private int auth_count = -1; // 授权次数
    private int auth_cmd = -1; // 1-授权通过，2-驳回
    private int auth_type = 1; // 授权类型：1-按时间授权，2-按次授权
    private String zonename;
    private int buildingid;
    private String buildingname;
    private int unitid;
    private String unitname;
    private int roomid;
    private int user_id;
    private int resident_id;
    private int master_resident_id;
    private String image_url = "";

    private boolean isFreeze;
    private int mPosition;// 当前被动授权消息点进来的位置
    private int key_status; //"key_status": 1, //钥匙状态 1-待审核，2-已通过，3-已驳回
    private String room_admin_name, unit_name, building_name, zone_name,
            province_name, city_name, auth_start_date, auth_end_date, room_name;
    private int keyid, zoneid, expire_type, city_id, room_id, unit_id, building_id,
            province_id, zone_id, relation;
    private boolean isrequestauth;
    private long dateScrollMin; // 时间滚轴最小值
    private long dateScrollMax; // 时间滚轴最大值

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth_key);
        ButterKnife.bind(this);
        mContext = this;
        hideSoftKeyBoard();
        tvTitle.setText(R.string.normal_auth);
        parseAuthType();
        initCardInformation();
        dateScrollMin = TimeUtil.parseDate(auth_start_date);
        dateScrollMax = TimeUtil.parseDate(auth_end_date);
        tvStartTime.setText(R.string.select_please);
        tvEndTime.setText(R.string.select_please);
        auth_start_date = "";
        auth_end_date = "";
    }

    /**
     * 隐藏软键盘
     */
    private void hideSoftKeyBoard() {
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    /**
     * 解析授权类型(主动or被动)
     */
    private void parseAuthType() {
        isrequestauth = SpUtil.getInstance().getBoolean("isrequestauth", false);
        if (isrequestauth) {
            judgeIsRequestAuth();
            btnReject.setText(R.string.reject_btn);
            Log.e(TAG, "当前是被动授权");
        } else {
            llName.setVisibility(View.GONE);
            isMainToAuth = true;
            Intent intent = getIntent();
            zoneid = intent.getIntExtra("zoneid", -1);
            zonename = intent.getStringExtra("zonename");
            buildingid = intent.getIntExtra("buildingid", -1);
            buildingname = intent.getStringExtra("buildingname");
            unitid = intent.getIntExtra("unitid", -1);
            unitname = intent.getStringExtra("unitname");
            roomid = intent.getIntExtra("roomid", -1);
            keyid = intent.getIntExtra("key_id", -1);
            room_name = intent.getStringExtra("roomname");
            relation = intent.getIntExtra("relation", -1);
        }
    }

    /**
     * 初始化卡片信息
     */
    private void initCardInformation() {
        VkeyBean object = null;
        if (!isrequestauth) {
            object = DBManager.getInstance().getVKeyByKeyId(keyid);
        } else {
            object = DBManager.getInstance().getVKeyByRoomId(roomid);
            SpUtil.getInstance().save("isrequestauth", false); // 重置授权类型
        }
        if (object != null) {
            keyid = object.getKey_id();
            expire_type = object.getExpire_type();
            auth_start_date = object.getAuth_start_date();
            auth_end_date = object.getAuth_end_date();
            auth_count = object.getAuth_count();
            key_status = object.getKey_status();
            isFreeze = object.is_freeze();
            image_url = object.getImage_url();
            zone_name = object.getZone_name();
            province_name = object.getProvince_name();
            city_name = object.getCity_name();
            building_name = object.getBuilding_name();
            unit_name = object.getUnit_name();
            city_id = object.getCity_id();
            room_id = object.getRoom_id();
            room_name = object.getRoom_name();
            unit_id = object.getUnit_id();
            building_id = object.getBuilding_id();
            province_id = object.getProvince_id();
            room_admin_name = object.getRoom_admin_name();
            zone_id = object.getZone_id();

            if (!"".equals(image_url)) {
                Glide.with(mContext).load(image_url)
                        .transform(new GlideRoundTransform(mContext)).into(ivCard);
            }

            tvZone.setText(zone_name);
            tvBuilding.setText(building_name);
            tvUnit.setText(unit_name);
            tvRoom.setText("(" + room_name + "室)");
            if (auth_start_date != null && !"".equals(auth_start_date)) {
                tvStartDate.setText(auth_start_date.substring(0, 13).replace("T", " ") + "时");
            }
            if (auth_end_date != null && !"".equals(auth_end_date)) {
                tvEndDate.setText(auth_end_date.substring(0, 13).replace("T", " ") + "时");
            }

            if (!isFreeze) {
                // 判断卡片是否过期
                boolean invalidDate = TimeUtil.checkIsInvalidDate(auth_start_date, auth_end_date);
                if (!invalidDate) {
                    CardView.setColor(mContext, zoneid, tvCover, ivCard);
                } else {
                    llInDate.setVisibility(View.GONE);
                    tvApply.setVisibility(View.VISIBLE);
                    tvApply.setText(R.string.card_invalid);
                    tvCover.setBackground(getResources().getDrawable(R.drawable.card_gray_shape));
                }
            } else {
                llInDate.setVisibility(View.GONE);
                tvApply.setVisibility(View.VISIBLE);
                tvApply.setText(R.string.pause_auth);
            }
        }
        switch (ship) {
            case 2:
                tvShip.setText(R.string.family);
                break;
            case 3:
                tvShip.setText(R.string.renter);
                break;
            case 4:
                tvShip.setText(R.string.visiter);
                break;
        }
    }

    /**
     * 判断如果是被动授权就获取数据
     */
    private void judgeIsRequestAuth() {
        Intent intent = getIntent();
        mPosition = intent.getIntExtra("position", -1);
        user_phone = intent.getStringExtra("user_phone");
        user_name = intent.getStringExtra("user_name");
        auth_start_date = intent.getStringExtra("auth_start_date");
        auth_end_date = intent.getStringExtra("auth_end_date");
        ship = intent.getIntExtra("ship", -1);
        zoneid = intent.getIntExtra("zoneid", -1);
        zonename = intent.getStringExtra("zonename");
        buildingid = intent.getIntExtra("buildingid", -1);
        buildingname = intent.getStringExtra("buildingname");
        unitid = intent.getIntExtra("unitid", -1);
        unitname = intent.getStringExtra("unitname");
        roomid = intent.getIntExtra("roomid", -1);
        room_name = intent.getStringExtra("roomname");
        user_id = intent.getIntExtra("user_id", -1);
        resident_id = intent.getIntExtra("resident_id", -1);
        master_resident_id = intent.getIntExtra("master_resident_id", -1);
        etPhone.setText(user_phone);
        tvName.setText(user_name);
        if (auth_start_date != null && auth_end_date != null) {
            tvStartTime.setText(auth_start_date.substring(0, 16).replace("T", " "));
            tvEndTime.setText(auth_end_date.substring(0, 16).replace("T", " "));
        }
    }

    @OnClick({R.id.ivBack, R.id.llStartTime, R.id.llEndTime,
            R.id.llShip, R.id.btnAuth, R.id.btnReject, R.id.ivContact})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.llStartTime:
                isStartTime = true;
                showDate(view);
                break;
            case R.id.llEndTime:
                isStartTime = false;
                showDate(view);
                break;
            case R.id.llShip:
                selectShip();
                BrightnessManager.lightoff(mContext);
                break;
            case R.id.btnAuth:
                currentState = authState;
                auth_cmd = 1;
                toAuth();
                break;
            case R.id.btnReject:
                if (isrequestauth) {
                    currentState = RejectState;
                    auth_cmd = 2;
                    reqestResult();
                } else {
                    finish();
                }
                break;
            case R.id.ivContact:
                selectContact();
                BrightnessManager.lightoff(mContext);
                break;
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if (isShouldHideKeyboard(v, ev)) {
                hideKeyboard(v.getWindowToken());
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    /**
     * 根据EditText所在坐标和用户点击的坐标相对比，
     * 来判断是否隐藏键盘，因为当用户点击EditText时则不能隐藏
     */
    private boolean isShouldHideKeyboard(View v, MotionEvent event) {
        if (v != null && (v instanceof EditText)) {
            int[] l = {0, 0};
            v.getLocationInWindow(l);
            int left = l[0],
                    top = l[1],
                    bottom = top + v.getHeight(),
                    right = left + v.getWidth();
            if (event.getX() > left && event.getX() < right
                    && event.getY() > top && event.getY() < bottom) {
                // 点击EditText的事件，忽略它。
                return false;
            } else {
                return true;
            }
        }
        // 如果焦点不是EditText则忽略，这个发生在视图刚绘制完，第一个焦点不在EditText上，和用户用轨迹球选择其他的焦点
        return false;
    }

    /**
     * 获取InputMethodManager，隐藏软键盘
     */
    private void hideKeyboard(IBinder token) {
        if (token != null) {
            InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            im.hideSoftInputFromWindow(token, InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    private void selectContact() {
        if (popupWindow == null) {
            popupView = View.inflate(this, R.layout.item_select_contact, null);
            popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);

            popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(mContext);
                }
            });

            popupWindow.setBackgroundDrawable(new BitmapDrawable());
            popupWindow.setFocusable(true);
            popupWindow.setOutsideTouchable(true);
            animation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0, Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 1, Animation.RELATIVE_TO_PARENT, 0);
            animation.setInterpolator(new AccelerateInterpolator());
            animation.setDuration(200);

            popupView.findViewById(R.id.tvPhoneContact).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Intent contact = new Intent(Intent.ACTION_PICK,
//                            ContactsContract.Contacts.CONTENT_URI);
//                    startActivityForResult(contact, PICK_CONTACT);
                    popupWindow.dismiss();
                    BrightnessManager.lighton(mContext);
                    requestPermission();
                }
            });
            popupView.findViewById(R.id.tvAnloqContact).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(NormalAuthActivity.this, AnloqContacts.class);
                    startActivityForResult(intent, ANLOQCONTACT);
                    popupWindow.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
        }

        if (popupWindow.isShowing()) {
            popupWindow.dismiss();
            BrightnessManager.lighton(mContext);
        }

        // 设置popupWindow的显示位置，此处是在手机屏幕底部且水平居中的位置
        popupWindow.showAtLocation(NormalAuthActivity.this.findViewById(R.id.activity_auth_key),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        popupView.startAnimation(animation);
    }

    @Override
    public void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);

        switch (reqCode) {
            case PICK_CONTACT:
                if (resultCode == Activity.RESULT_OK) {
                    Uri contactData = data.getData();
                    Cursor c = getContentResolver().query(contactData, null, null, null, null);

                    if (c.moveToFirst()) {
                        String id = c.getString(c.getColumnIndex(ContactsContract.Contacts._ID));
                        Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + id, null, null);
                        etPhone.setText("");
                        if (phones.moveToFirst()) {
                            String phoneNumber = phones.getString(phones.getColumnIndex(
                                    ContactsContract.CommonDataKinds.Phone.NUMBER));
                            // 获得DATA表中的名字
                            userName = phones.getString(phones.getColumnIndex(
                                    ContactsContract.Contacts.DISPLAY_NAME));
                            Log.e("TAG", "userName===" + userName);
                            if (!phoneNumber.equals("")) {
                                Log.e("Error: ", "No Error");
                                etPhone.setText(phoneNumber);
                                user_phone = phoneNumber.replace(" ", "");
                                cursor_position = phoneNumber.length();
                            } else {
                                Log.e(TAG, "请输入手机号");
                            }
                        }
                        phones.close();
                    }
                }
                break;
            case ANLOQCONTACT:
                if (resultCode == Activity.RESULT_OK) {
                    String phone = data.getStringExtra("phone");
                    etPhone.setText(phone);
                }
                break;
        }
    }

    /**
     * 立即授权
     */
    private void toAuth() {
        user_phone = etPhone.getText().toString().trim().replace(" ", "");
        if (user_phone.length() < 11) {
            ToastUtil.show(getString(R.string.please_input_correct_phone));
            return;
        }
        if ("".equals(auth_start_date) || "".equals(auth_end_date) || ship == -1) {
            ToastUtil.show(getString(R.string.you_has_blank_column));
            return;
        }
        if (TimeUtil.parseIsSameHour(auth_start_date, auth_end_date)) {
            ToastUtil.show(getString(R.string.valid_time_toast));
            return;
        }
        reqestResult();
    }

    private void reqestResult() {
        uid = SpUtil.getInstance().getInt("uid", -1);
        token = SpUtil.getInstance().getString("token", "");
        String url = Constants.AUTHKEY + uid + Constants.TOKEN + token;
        Log.e(TAG, "AUTHKEY_url===" + url);

        HashMap<String, Object> map = new HashMap<>();
        map.put("zone_id", zoneid);
        map.put("zone_name", zonename);
        map.put("building_id", buildingid);
        map.put("building_name", buildingname);
        map.put("unit_id", unitid);
        map.put("unit_name", unitname);
        map.put("room_id", roomid);
        map.put("room_name", room_name);
        map.put("user_type", ship);
        map.put("user_phone", user_phone);
        map.put("auth_type", auth_type);
        map.put("auth_cmd", auth_cmd); // 1-授权通过，2-驳回

        if (!isMainToAuth) {
            map.put("user_id", user_id);
            map.put("user_name", user_name);
            map.put("resident_id", resident_id);
            map.put("master_resident_id", master_resident_id);
        }

        if (isCountsAuth) {
            map.put("auth_count", auth_count);
        } else {
            map.put("key_start_date", auth_start_date);
            map.put("key_end_date", auth_end_date);
        }

        String content = new Gson().toJson(map);
        Log.e(TAG, "content===" + content);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e(TAG, "授权结果联网失败===" + e.toString());
                        showException(e);
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "授权结果联网成功===" + response);
                        parseResult(response);
                    }
                });
    }

    private void showException(Exception e) {
        ToastUtil.show(getString(R.string.auth_disconnect_net) + e.toString());
        finish();
    }

    private void parseResult(String json) {
        JSONObject jsonObject = null;
        String code = "";
        try {
            jsonObject = new JSONObject(json);
            code = jsonObject.getString("code");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if ("200".equals(code)) {
            if (currentState == authState) {
                ToastUtil.show(getString(R.string.auth_success));
                if (isrequestauth) {
                    // 如果是被动授权，处理完之后删除该条消息。
                    EventBus.getDefault().post(new EventBusMsg("deleteauthmsg", "" + mPosition));
                }
            } else if (currentState == RejectState) {
                ToastUtil.show(getString(R.string.reject_success));
                if (isrequestauth) {
                    SpUtil.getInstance().save("reject_auth_success" + mPosition, true);
                    EventBus.getDefault().post(new EventBusMsg("setrejectread", "" + mPosition));
                }
            }
            currentState = -1;
            // 添加到安络联系人
            MessageProvider.getInstance().addToAnloqContact(userName, user_phone);
        } else if ("1004".equals(code)) {
            ToastUtil.show(getString(R.string.this_account_registed));
        } else if ("1016".equals(code)) {
            ToastUtil.show(getString(R.string.no_power));
        }
        finish();
    }

    /**
     * 显示日期(配置最大、最小时间伐值)
     */
    public void showDate(View view) {
        DateScrollerDialog dialog = new DateScrollerDialog.Builder()
                .setType(Type.YEAR_MONTH_DAY_HOUR)
                .setTitleStringId(getString(R.string.please_select_date))
                .setMinMilliseconds(dateScrollMin)
                .setMaxMilliseconds(dateScrollMax)
                .setCurMilliseconds(mLastTime)
                .setCallback(mOnDateSetListener)
                .build();

        if (dialog != null) {
            if (!dialog.isAdded()) {
                dialog.show(getSupportFragmentManager(), "year_month_day");
            }
        }
    }

    // 数据的回调
    private OnDateSetListener mOnDateSetListener = new OnDateSetListener() {
        @Override
        public void onDateSet(DateScrollerDialog timePickerView, long milliseconds) {
            mLastTime = milliseconds;
            String text = TimeUtil.getAuthTime(milliseconds);
            if (isStartTime) {
                auth_start_date = text;
                tvStartTime.setText(text.substring(0, 16).replace("T", " "));
            } else {
                auth_end_date = text;
                tvEndTime.setText(text.substring(0, 16).replace("T", " "));
            }
        }
    };

    /**
     * 选择关系
     */
    private void selectShip() {
        if (popupShip == null) {
            popupShipView = View.inflate(this, R.layout.item_relation, null);
            // 参数2,3：指明popupwindow的宽度和高度
            popupShip = new PopupWindow(popupShipView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
            popupShip.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(mContext);
                }
            });

            // 设置背景图片， 必须设置，不然动画没作用
            popupShip.setBackgroundDrawable(new BitmapDrawable());
            popupShip.setFocusable(true);
            // 设置点击popupwindow外屏幕其它地方消失
            popupShip.setOutsideTouchable(true);
            // 平移动画相对于手机屏幕的底部开始，X轴不变，Y轴从1变0
            animation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0, Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 1, Animation.RELATIVE_TO_PARENT, 0);
            animation.setInterpolator(new AccelerateInterpolator());
            animation.setDuration(200);
            TextView tvFamily = (TextView) popupShipView.findViewById(R.id.tvFamily);
            tvFamily.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tvShip.setText(R.string.family);
                    ship = 2;
                    popupShip.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            TextView tvRenter = (TextView) popupShipView.findViewById(R.id.tvRenter);
            tvRenter.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tvShip.setText(R.string.renter);
                    ship = 3;
                    popupShip.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            TextView tvVisitor = (TextView) popupShipView.findViewById(R.id.tvVisitor);
            tvVisitor.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tvShip.setText(R.string.visiter);
                    ship = 4;
                    popupShip.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            switch (relation) {
                case 2:
                    tvFamily.setVisibility(View.GONE);
                    break;
                case 3:
                    tvFamily.setVisibility(View.GONE);
                    tvRenter.setVisibility(View.GONE);
                    break;
            }
        }
        if (popupShip.isShowing()) {
            popupShip.dismiss();
            BrightnessManager.lighton(mContext);
        }
        // 设置popupWindow的显示位置，此处是在手机屏幕底部且水平居中的位置
        popupShip.showAtLocation(NormalAuthActivity.this.findViewById(R.id.activity_auth_key),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        popupShipView.startAnimation(animation);
    }

    private String[] read_contacts = {Manifest.permission.READ_CONTACTS};

    private void requestPermission() {
        EasyPermissions.requestPermissions(
                new PermissionRequest.Builder(this, 520, read_contacts)
                        .setRationale("need permissions")
                        .setPositiveButtonText("confirm")
                        .setNegativeButtonText("reject")
                        .build());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Forward results to EasyPermissions
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        switch (requestCode) {
            case 520:
                Intent contact = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(contact, PICK_CONTACT);
                break;
        }
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        ToastUtil.show("you reject permission!");
    }

}
