package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/4/19 :)
 * Function:服务页面数据的Bean
 */

public class ServiceDataBean {

    /**
     * name : servicetels
     * object : [{"service_id":10,"service_name":"张三","service_type":2,"tel":"13800138000"},{"service_id":11,"service_name":"李四","service_type":3,"tel":"13500135000"},{"service_id":12,"service_name":"赵六","service_type":1,"tel":"10086"}]
     * code : 200
     */

    private String name;
    private int code;
    private List<ObjectBean> object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<ObjectBean> getObject() {
        return object;
    }

    public void setObject(List<ObjectBean> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * service_id : 10
         * service_name : 张三
         * service_type : 2
         * tel : 13800138000
         */

        private int service_id;
        private String service_name;
        private int service_type;
        private String tel;

        public int getService_id() {
            return service_id;
        }

        public void setService_id(int service_id) {
            this.service_id = service_id;
        }

        public String getService_name() {
            return service_name;
        }

        public void setService_name(String service_name) {
            this.service_name = service_name;
        }

        public int getService_type() {
            return service_type;
        }

        public void setService_type(int service_type) {
            this.service_type = service_type;
        }

        public String getTel() {
            return tel;
        }

        public void setTel(String tel) {
            this.tel = tel;
        }
    }
}
