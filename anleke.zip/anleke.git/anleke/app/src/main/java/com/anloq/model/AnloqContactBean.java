package com.anloq.model;

/**
 * Created by xpf on 2017/5/23 :)
 * Function:安络联系人的Bean
 */

public class AnloqContactBean {

    private String name;
    private String phone;
    private String headpic;

    public AnloqContactBean() {
    }

    public AnloqContactBean(String name, String phone, String headpic) {
        this.name = name;
        this.phone = phone;
        this.headpic = headpic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getHeadpic() {
        return headpic;
    }

    public void setHeadpic(String headpic) {
        this.headpic = headpic;
    }

    @Override
    public String toString() {
        return "AnloqContactBean{" +
                "name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", headpic='" + headpic + '\'' +
                '}';
    }
}
