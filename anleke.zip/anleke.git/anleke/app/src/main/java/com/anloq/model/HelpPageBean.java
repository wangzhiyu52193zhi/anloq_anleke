package com.anloq.model;


/**
 * Created by Steven on 2017/6/24.
 * 解析url
 */

public class HelpPageBean {
    private String name = "";
    private UrlBean object = null;
    private Integer code = -1;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getName() {
        return name;

    }

    public void setName(String name) {
        this.name = name;
    }

    public UrlBean getObject() {
        return object;
    }

    public void setObject(UrlBean object) {
        this.object = object;
    }


}
