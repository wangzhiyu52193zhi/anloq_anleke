package com.anloq.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.model.OpinionZoneBean;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/5/18 :)
 * Function:意见反馈选择小区的适配器
 */

public class OpinionZoneAdapter extends BaseAdapter {

    private Context mContext;
    private List<OpinionZoneBean> allZones;

    public OpinionZoneAdapter(Context mContext, List<OpinionZoneBean> allZones) {
        this.mContext = mContext;
        this.allZones = allZones;
    }

    @Override
    public int getCount() {
        return allZones.size();
    }

    @Override
    public Object getItem(int position) {
        return allZones.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_zone, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        OpinionZoneBean bean = allZones.get(position);
        holder.tv.setText(bean.getZone_name());
        return convertView;
    }

    static class ViewHolder {
        @BindView(R.id.tv)
        TextView tv;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
