package com.anloq.model;

import com.anloq.utils.TimeUtil;

/**
 * Created by xpf on 2017/4/20 :)
 * Function:钥匙审核通过消息的Bean
 */

public class KeyPassMsgBean {

    /**
     * name : keypassmsg
     * object : {"title":"授权通知","content":"您申请的\"301\"房屋的虚拟钥匙已申请成功！","command":0}
     */

    private String name;
    private ObjectBean object;
    private String time;

    public String getTime() {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//        java.text.DateFormat sdfout = new java.text.SimpleDateFormat("MM/dd HH:MM");
//        Date date = new Date();
//        if(time != null){
//
//            try {
//                date = sdf.parse(time);
//            } catch (ParseException e) {
//                e.printStackTrace();
//            }
//        }
        return TimeUtil.getTime(time);
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * title : 授权通知
         * content : 您申请的"301"房屋的虚拟钥匙已申请成功！
         * command : 0
         */

        private String title;
        private String content;
        private int command;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getCommand() {
            return command;
        }

        public void setCommand(int command) {
            this.command = command;
        }
    }
}
