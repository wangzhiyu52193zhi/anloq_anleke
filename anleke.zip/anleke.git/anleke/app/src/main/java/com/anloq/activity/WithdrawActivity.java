package com.anloq.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.alipay.sdk.app.AuthTask;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.BrightnessManager;
import com.anloq.model.AccountOverviewBean;
import com.anloq.pay.AuthResult;
import com.anloq.pay.OrderInfoUtil;
import com.anloq.pay.PayKeys;
import com.anloq.pay.PayResult;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

import static android.content.ContentValues.TAG;
import static com.anloq.pay.PayKeys.APPID;
import static com.anloq.pay.PayKeys.PID;
import static com.anloq.pay.PayKeys.TARGET_ID;

// 提现页面
public class WithdrawActivity extends Activity {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.ivDetail)
    ImageView ivDetail;
    @BindView(R.id.llAvailable)
    LinearLayout llAvailable;
    @BindView(R.id.etMoney)
    EditText etMoney;
    @BindView(R.id.rbAlipay)
    RadioButton rbAlipay;
    @BindView(R.id.rbWeChatPay)
    RadioButton rbWeChatPay;
    @BindView(R.id.rgPayType)
    RadioGroup rgPayType;
    @BindView(R.id.tvWithdraw)
    TextView tvWithdraw;
    @BindView(R.id.tvBalance)
    TextView tvBalance;
    private EditText etPayPwd;
    private int withdrawType = -1;
    private String balance;

    private PopupWindow popupWindow;
    private View popupView;

    private static final int SDK_PAY_FLAG = 1;
    private static final int SDK_AUTH_FLAG = 2;

    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @SuppressWarnings("unused")
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SDK_PAY_FLAG: {
                    @SuppressWarnings("unchecked")
                    PayResult payResult = new PayResult((Map<String, String>) msg.obj);
                    /**
                     对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
                     */
                    String resultInfo = payResult.getResult();// 同步返回需要验证的信息
                    String resultStatus = payResult.getResultStatus();
                    // 判断resultStatus 为9000则代表支付成功
                    if (TextUtils.equals(resultStatus, "9000")) {
                        // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                        Toast.makeText(WithdrawActivity.this, "支付成功", Toast.LENGTH_SHORT).show();
                    } else {
                        // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                        Toast.makeText(WithdrawActivity.this, "支付失败", Toast.LENGTH_SHORT).show();
                    }
                    break;
                }
                case SDK_AUTH_FLAG: {
                    @SuppressWarnings("unchecked")
                    AuthResult authResult = new AuthResult((Map<String, String>) msg.obj, true);
                    String resultStatus = authResult.getResultStatus();

                    // 判断resultStatus 为“9000”且result_code
                    // 为“200”则代表授权成功，具体状态码代表含义可参考授权接口文档
                    if (TextUtils.equals(resultStatus, "9000") && TextUtils.equals(authResult.getResultCode(), "200")) {
                        // 获取alipay_open_id，调支付时作为参数extern_token 的value
                        // 传入，则支付账户为该授权账户
                        Toast.makeText(WithdrawActivity.this,
                                "授权成功\n" + String.format("authCode:%s", authResult.getAuthCode()), Toast.LENGTH_SHORT)
                                .show();
                    } else {
                        // 其他状态值则为授权失败
                        Toast.makeText(WithdrawActivity.this,
                                "授权失败" + String.format("authCode:%s", authResult.getAuthCode()), Toast.LENGTH_SHORT).show();
                    }
                    break;
                }
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdraw);
        ButterKnife.bind(this);
        tvTitle.setText("提现");
        initListener();
        getMyProfitInfo();
    }

    private void getMyProfitInfo() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.ACCOUNTOVERVIEW + uid + Constants.TOKEN + token;
        Logger.t(TAG).i("AccountOverview_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseProfit(response);
                    }
                });
    }

    private void parseProfit(String json) {
        AccountOverviewBean overviewBean = new Gson().fromJson(json, AccountOverviewBean.class);
        AccountOverviewBean.ObjectBean object = overviewBean.getObject();
        balance = object.getBalance();
        tvBalance.setText(balance);
    }

    private void initListener() {
        rgPayType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbAlipay:
                        withdrawType = 1;
                        break;
                    case R.id.rbWeChatPay:
                        withdrawType = 2;
                        break;
                }
            }
        });
        etMoney.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tvWithdraw.setEnabled(true);
//                String string = etMoney.getText().toString();
//                if ((Integer.parseInt("".equals(string) ? "0" : string) >= 100) &&
//                        (Double.parseDouble(balance) >= 100)) {
//                    tvWithdraw.setEnabled(true);
//                } else {
//                    tvWithdraw.setEnabled(false);
//                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @OnClick({R.id.ivBack, R.id.ivDetail, R.id.tvWithdraw})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.ivDetail:
                startActivity(new Intent(WithdrawActivity.this, AvailableDetail.class));
                break;
            case R.id.tvWithdraw:
//                withdraw();
                showPayPwdDialog();
//                withdrawDialog();
                BrightnessManager.lightoff(WithdrawActivity.this);
                break;
        }
    }

    /**
     * 提现
     */
    private void withdraw() {
        if (Double.parseDouble(balance) < 100) {
            ToastUtil.show("提现金额不足100元不能提现！");
            return;
        }
        // TODO: 2017/11/1 判断提现金额大于等于100且可提现的金额大于等于100
        String money = etMoney.getText().toString();
        if (Double.parseDouble(money) <= 0) {
            ToastUtil.show("提现金额不能小于0元！");
            return;
        }

        switch (withdrawType) {
            case 1: // 支付宝
                aliPay();
                break;
            case 2: // 微信
                weChatPay();
                break;
        }
    }

    private void aliPay() {
        // 判断是否绑定了支付宝
        //authV2();
    }

    private void weChatPay() {
        // 判断是否绑定了微信
    }

    /**
     * 支付宝账户授权业务
     */
    public void authV2() {
        if (TextUtils.isEmpty(PayKeys.PID) || TextUtils.isEmpty(PayKeys.APPID)
                || (TextUtils.isEmpty(PayKeys.RSA2_PRIVATE) && TextUtils.isEmpty(PayKeys.RSA_PRIVATE))
                || TextUtils.isEmpty(PayKeys.TARGET_ID)) {
            new AlertDialog.Builder(WithdrawActivity.this).setTitle("警告").setMessage("需要配置PARTNER |APP_ID| RSA_PRIVATE| TARGET_ID")
                    .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialoginterface, int i) {
                        }
                    }).show();
            return;
        }

        /**
         * 这里只是为了方便直接向商户展示支付宝的整个支付流程；所以Demo中加签过程直接放在客户端完成；
         * 真实App里，privateKey等数据严禁放在客户端，加签过程务必要放在服务端完成；
         * 防止商户私密数据泄露，造成不必要的资金损失，及面临各种安全风险；
         *
         * authInfo的获取必须来自服务端；
         */
        boolean rsa2 = (PayKeys.RSA2_PRIVATE.length() > 0);
        Map<String, String> authInfoMap = OrderInfoUtil.buildAuthInfoMap(PID, APPID, TARGET_ID, rsa2);
        String info = OrderInfoUtil.buildOrderParam(authInfoMap);

        String privateKey = rsa2 ? PayKeys.RSA2_PRIVATE : PayKeys.RSA_PRIVATE;
        String sign = OrderInfoUtil.getSign(authInfoMap, privateKey, rsa2);
        final String authInfo = info + "&" + sign;
        Runnable authRunnable = new Runnable() {

            @Override
            public void run() {
                // 构造AuthTask 对象
                AuthTask authTask = new AuthTask(WithdrawActivity.this);
                // 调用授权接口，获取授权结果
                Map<String, String> result = authTask.authV2(authInfo, true);

                Message msg = new Message();
                msg.what = SDK_AUTH_FLAG;
                msg.obj = result;
                mHandler.sendMessage(msg);
            }
        };

        // 必须异步调用
        Thread authThread = new Thread(authRunnable);
        authThread.start();
    }

    private void showPayPwdDialog() {
        if (popupWindow == null) {
            popupView = View.inflate(WithdrawActivity.this, R.layout.popupwindow_pay_pwd, null);
            popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT);
            popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(WithdrawActivity.this);
                    etPayPwd.setText("");
                }
            });
            popupWindow.setBackgroundDrawable(new BitmapDrawable());
            popupWindow.setFocusable(true);
            popupWindow.setOutsideTouchable(true);

            ToggleButton togglePwd = (ToggleButton) popupView.findViewById(R.id.togglePwd);
            etPayPwd = (EditText) popupView.findViewById(R.id.etPayPwd);
            togglePwd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        //如果选中，显示密码
                        etPayPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    } else {
                        //否则隐藏密码
                        etPayPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    }
                }
            });

            popupView.findViewById(R.id.tvCancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                    BrightnessManager.lighton(WithdrawActivity.this);
                }
            });

            popupView.findViewById(R.id.tvConfirm).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String payPwd = etPayPwd.getText().toString();
                    popupWindow.dismiss();
                    BrightnessManager.lighton(WithdrawActivity.this);
                }
            });
        }

        if (popupWindow.isShowing()) {
            popupWindow.dismiss();
            BrightnessManager.lighton(WithdrawActivity.this);
        }
        popupWindow.showAtLocation(WithdrawActivity.this.findViewById(R.id.activity_withdraw),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
    }

    /**
     * 提现申请成功
     */
    private void withdrawDialog() {
        if (popupWindow == null) {
            popupView = View.inflate(WithdrawActivity.this, R.layout.popupwindow_withdraw, null);
            popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT);
            popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(WithdrawActivity.this);
                }
            });
            popupWindow.setBackgroundDrawable(new BitmapDrawable());
            popupWindow.setFocusable(true);
            popupWindow.setOutsideTouchable(true);

            popupView.findViewById(R.id.tvIKnow).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                    BrightnessManager.lighton(WithdrawActivity.this);
                }
            });
        }

        if (popupWindow.isShowing()) {
            popupWindow.dismiss();
            BrightnessManager.lighton(WithdrawActivity.this);
        }
        popupWindow.showAtLocation(WithdrawActivity.this.findViewById(R.id.activity_withdraw),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
    }
}
