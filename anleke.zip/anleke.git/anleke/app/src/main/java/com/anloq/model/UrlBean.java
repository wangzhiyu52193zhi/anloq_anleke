package com.anloq.model;

import java.util.List;

/**
 * Created by Steven on 2017/6/24.
 *
 */

public class UrlBean {
    private List<String> data=null;

    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }
}
