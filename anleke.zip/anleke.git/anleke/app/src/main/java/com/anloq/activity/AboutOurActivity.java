package com.anloq.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.utils.AppInfo;
import com.anloq.utils.ToastUtil;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import pub.devrel.easypermissions.EasyPermissions;
import pub.devrel.easypermissions.PermissionRequest;

// 关于我们
public class AboutOurActivity extends Activity implements EasyPermissions.PermissionCallbacks {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvUrl)
    TextView tvUrl;
    @BindView(R.id.tvUpdate)
    TextView tvUpdate;
    @BindView(R.id.tvVersionNum)
    TextView tvVersionNum;
    @BindView(R.id.tvUserRule)
    TextView tvUserRule;
    @BindView(R.id.tvUseRule)
    TextView tvUseRule;
    @BindView(R.id.tvPrivateRule)
    TextView tvPrivateRule;
    @BindView(R.id.tvSinaWeibo)
    TextView tvSinaWeibo;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.tvToCall)
    TextView tvToCall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_our);
        ButterKnife.bind(this);
        initData();
    }

    private void initData() {
        tvTitle.setText(R.string.about_our);
        tvVersionNum.setText(AppInfo.getVersionName());
        tvUrl.setText(Html.fromHtml(getResources().getString(R.string.www_anloq_com)));
        tvToCall.setText(Html.fromHtml(getResources().getString(R.string.cooperation_call)));
    }

    @OnClick({R.id.ivBack, R.id.tvUrl, R.id.tvUpdate, R.id.tvUserRule,
            R.id.tvUseRule, R.id.tvPrivateRule, R.id.tvSinaWeibo, R.id.tvToCall})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.tvUrl:
                // 跳转到系统浏览器
                String url = "https://www.anloq.com";
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                break;
            case R.id.tvUpdate: // 检查更新
                break;
            case R.id.tvUserRule:
                startActivity(new Intent(AboutOurActivity.this, AnloqRuleDetail.class));
                break;
            case R.id.tvUseRule:
                startActivity(new Intent(AboutOurActivity.this, AnloqRuleDetail.class));
                break;
            case R.id.tvPrivateRule:
                startActivity(new Intent(AboutOurActivity.this, AnloqRuleDetail.class));
                break;
            case R.id.tvSinaWeibo:
                loadUrl("http://weibo.com/anloq");
                break;
            case R.id.tvToCall:
                requestCameraPermission();
                break;
        }
    }

    /**
     * 呼叫招商合作电话
     */
    @SuppressLint("MissingPermission")
    private void toCall() {
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:4001769588"));
        startActivity(intent);
    }

    private void loadUrl(String url) {
        Intent intent = new Intent(AboutOurActivity.this, HelpPageActivity.class);
        intent.putExtra("url", url);
        intent.putExtra("flag", 9);
        startActivity(intent);
    }

    private String[] call_phone = {Manifest.permission.CALL_PHONE};

    private void requestCameraPermission() {
        EasyPermissions.requestPermissions(
                new PermissionRequest.Builder(this, 520, call_phone)
                        .setRationale("need permissions")
                        .setPositiveButtonText("confirm")
                        .setNegativeButtonText("reject")
                        .build());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Forward results to EasyPermissions
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        if (requestCode == 520) {
            toCall();
        }
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        ToastUtil.show("you reject permission!");
    }
}
