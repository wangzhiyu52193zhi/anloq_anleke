package com.anloq.manager;

import android.telephony.TelephonyManager;

import com.anloq.MyApplication;

import static android.content.Context.TELEPHONY_SERVICE;

/**
 * Created by xpf on 2017/5/19 :)
 * Function:设备信息的管理者
 */

public class DeviceInfoManager {

    /**
     * 获取设备Imei
     */
    public static String getImei() {
        TelephonyManager tm = (android.telephony.TelephonyManager) MyApplication.getContext()
                .getSystemService(TELEPHONY_SERVICE);
        return tm.getDeviceId() == null ? tm.getDeviceId() : tm.getDeviceId();
    }

    /**
     * 获取设备Imsi
     */
    public static String getImsi() {
        TelephonyManager tm = (android.telephony.TelephonyManager) MyApplication.getContext()
                .getSystemService(TELEPHONY_SERVICE);
        return tm.getSubscriberId() == null ? tm.getDeviceSoftwareVersion() : tm.getSubscriberId();
    }

    /**
     * 获取手机设备的类型
     * @return 2代表华为    3代表小米   0代表其他
     */
    public static int getDeviceType() {
        int type = 0;
        String factoryName = android.os.Build.MANUFACTURER;
        String lowerCase = factoryName.toLowerCase();
        if (lowerCase.contains("huawei")) {
            type = 2;
        } else if (lowerCase.contains("xiaomi")) {
            type = 3;
        } else {
            type = 0;
        }
        return type;
    }
}
