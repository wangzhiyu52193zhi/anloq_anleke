package com.anloq.model;

/**
 * Created by xpf on 2017/8/15 :)
 * Function:MQTT消息照片的Bean
 */

public class CallingImageBean {

    /**
     * name : getcallimg
     * object : {"image_id":"897845057082757120","unit_id":"100012"}
     * time : 2017-08-16T15:38:37.421Z
     */

    private String name;
    private ObjectBean object;
    private String time;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public static class ObjectBean {
        /**
         * image_id : 897845057082757120
         * unit_id : 100012
         */

        private String image_id;
        private String unit_id;

        public String getImage_id() {
            return image_id;
        }

        public void setImage_id(String image_id) {
            this.image_id = image_id;
        }

        public String getUnit_id() {
            return unit_id;
        }

        public void setUnit_id(String unit_id) {
            this.unit_id = unit_id;
        }
    }
}
