package com.anloq.anleke.ble;

import java.util.HashMap;

/**
 * GATT属性配置的工具类(比如Uuid等)
 */
public class BleGattAttributes {

    public static String CLIENT_CHARACTERISTIC_CONFIG = "00002901-0000-1000-8000-00805f9b34fb";

    public static String lookup(String uuid, String defaultName) {
        String name = attributes.get(uuid);
        return name == null ? defaultName : name;
    }

    //新模块
    public static HashMap<String, String> attributes = new HashMap();
    public static String BLE_SPP_Service = "0000fff0-0000-1000-8000-00805f9b34fb";
    public static String HEART_RATE_MEASUREMENT = "0000C004-0000-1000-8000-00805f9b34fb";
    public static String BLE_SPP_Notify_Characteristic = "0000fff7-0000-1000-8000-00805f9b34fb";
    public static String BLE_SPP_Write_Characteristic = "0000fff6-0000-1000-8000-00805f9b34fb";
    public static String BLE_SPP_Read_Characteristic = "0000fff7-0000-1000-8000-00805f9b34fb";

    static {
        attributes.put("0000fff00000-1000-8000-00805f9b34fb", "Heart Rate Service");
        attributes.put("0000180a-0000-1000-8000-00805f9b34fb", "Device Information Service");
        attributes.put(HEART_RATE_MEASUREMENT, "Heart Rate Measurement");
        attributes.put("00002a29-0000-1000-8000-00805f9b34fb", "Manufacturer Name String");
    }

}
