package com.anloq.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.anloq.anleke.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

// 通知栏消息点击详情页
public class NotificationDetail extends Activity {

    private static final String TAG = NotificationDetail.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.ivShare)
    ImageView ivShare;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.tvContent)
    TextView tvContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_detail);
        ButterKnife.bind(this);
        initData();
    }

    private void initData() {
        String title = getIntent().getStringExtra("title");
        String content = getIntent().getStringExtra("content");
        Log.e(TAG, "title===" + title + ",content===" + content);
        tvTitle.setText(title);
        tvContent.setText(content);
    }

    @OnClick({R.id.ivBack, R.id.ivShare})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.ivShare:
                Toast.makeText(NotificationDetail.this, "分享", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
