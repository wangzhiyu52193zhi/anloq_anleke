package com.anloq.receiver;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.anloq.activity.MainActivity;
import com.anloq.model.EventBusMsg;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by xpf on 2017/6/3 :)
 * Function:Ble蓝牙状态的接收器
 */

public class BleStateReceiver extends BroadcastReceiver {

    private static final String TAG = BleStateReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                BluetoothAdapter.ERROR);
        switch (state) {
            case BluetoothAdapter.STATE_OFF:
                Log.e(TAG, "STATE_OFF 手机蓝牙关闭");
                sendState("ble_close");
                break;
            case BluetoothAdapter.STATE_TURNING_OFF:
                Log.e(TAG, "STATE_TURNING_OFF 手机蓝牙正在关闭");
                break;
            case BluetoothAdapter.STATE_ON:
                Log.e(TAG, "STATE_ON 手机蓝牙开启");
                sendState("ble_open");
                break;
            case BluetoothAdapter.STATE_TURNING_ON:
                Log.e(TAG, "STATE_TURNING_ON 手机蓝牙正在开启");
                break;
        }
    }

    /**
     * 发送状态到通知页面
     * @param state
     */
    private void sendState(String state) {
        if (MainActivity.isVisible) {
            EventBus.getDefault().post(new EventBusMsg(state, ""));
        }
    }
}
