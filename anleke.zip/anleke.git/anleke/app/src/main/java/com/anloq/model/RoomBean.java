package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/3/28 :)
 * Function:房间Bean类
 */
public class RoomBean {

    /**
     * name : rooms
     * object : [{"room_id":22,"room_name":"101室","has_key":false},{"room_id":23,"room_name":"102室","has_key":false},{"room_id":24,"room_name":"103室","has_key":false},{"room_id":25,"room_name":"104室","has_key":false},{"room_id":26,"room_name":"201室","has_key":false},{"room_id":27,"room_name":"202室","has_key":false},{"room_id":28,"room_name":"203室","has_key":false},{"room_id":29,"room_name":"204室","has_key":false},{"room_id":30,"room_name":"301室","has_key":false},{"room_id":31,"room_name":"302室","has_key":false},{"room_id":32,"room_name":"303室","has_key":false},{"room_id":33,"room_name":"304室","has_key":false},{"room_id":34,"room_name":"401室","has_key":false},{"room_id":35,"room_name":"402室","has_key":false},{"room_id":36,"room_name":"402室","has_key":false},{"room_id":37,"room_name":"404室","has_key":false},{"room_id":38,"room_name":"501室","has_key":false},{"room_id":39,"room_name":"502室","has_key":false},{"room_id":40,"room_name":"502室","has_key":false},{"room_id":41,"room_name":"504室","has_key":false}]
     * code : 200
     */

    private String name;
    private int code;
    private List<ObjectBean> object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<ObjectBean> getObject() {
        return object;
    }

    public void setObject(List<ObjectBean> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * room_id : 22
         * room_name : 101室
         * has_key : false
         */

        private int room_id;
        private String room_name;
        private boolean has_key;

        public int getRoom_id() {
            return room_id;
        }

        public void setRoom_id(int room_id) {
            this.room_id = room_id;
        }

        public String getRoom_name() {
            return room_name;
        }

        public void setRoom_name(String room_name) {
            this.room_name = room_name;
        }

        public boolean isHas_key() {
            return has_key;
        }

        public void setHas_key(boolean has_key) {
            this.has_key = has_key;
        }
    }
}
