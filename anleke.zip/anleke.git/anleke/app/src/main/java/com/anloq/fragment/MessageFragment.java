package com.anloq.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anloq.MyApplication;
import com.anloq.adapter.MsgListAdapter;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.base.BaseFragment;
import com.anloq.model.EventBusMsg;
import com.anloq.model.MessageBean;
import com.anloq.model.NoticeMsgBean;
import com.anloq.model.RequestKeyBean;
import com.anloq.ui.NotifcationView;
import com.anloq.utils.DensityUtil;
import com.anloq.utils.MessageProvider;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.MediaType;

/**
 * Created by xpf on 2017/3/22 :)
 * Function:消息通知页面的Fragment
 */

public class MessageFragment extends BaseFragment {

    private static final String TAG = MessageFragment.class.getSimpleName();
    @BindView(R.id.listView)
    SwipeMenuListView listView;
    @BindView(R.id.tvNoData)
    TextView tvNoData;
    @BindView(R.id.rlNetError)
    RelativeLayout rlNetError;
    private Handler handler;
    private List<MessageBean> mMsgList; // 所有消息列表
    private MsgListAdapter listAdapter;

    private int firstCount = 0;//加急置顶
    private int secondCount = 0;//加急
    private int thirdCount = 0;//置顶
    private String accept_msg = "";//接收到的消息
    private String count = "";
    private int index = 0;//插入消息的位置

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBus.getDefault().register(this);
    }

    @Override
    public View initView() {
        View view = View.inflate(mContext, R.layout.fragment_message, null);
        ButterKnife.bind(this, view);
        View footerView = View.inflate(mContext, R.layout.messagelist_footer, null);
        listView.addFooterView(footerView);
        NotifcationView.cancelNotice();
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        handler = new Handler();
        boolean netstate = SpUtil.getInstance().getBoolean("netstate", true);
        if (!netstate) {
            rlNetError.setVisibility(View.VISIBLE);
        }
        initListener();
        getTypeNumber();
        initLocalMsgList();
    }

    /**
     * 获取各种类型消息的数量
     */
    private void getTypeNumber() {
        List<String> messageTypeNumber = MessageProvider.getInstance().getMessageTypeNumber();
        if (messageTypeNumber != null && messageTypeNumber.size() == 3) {
            firstCount = Integer.parseInt(messageTypeNumber.get(0));
            secondCount = Integer.parseInt(messageTypeNumber.get(1));
            thirdCount = Integer.parseInt(messageTypeNumber.get(2));
        }
    }

    /**
     * 初始化本地消息列表
     */
    private void initLocalMsgList() {
        mMsgList = MessageProvider.getInstance().getLocalData();
        if (mMsgList != null && mMsgList.size() > 0) {
            tvNoData.setVisibility(View.GONE);
            setAdapter();
        } else {
            tvNoData.setVisibility(View.VISIBLE);
        }
    }

    private void initListener() {
        // step 1. create a MenuCreator
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        MyApplication.getContext());
                deleteItem.setBackground(R.drawable.delete_bg_shape);
                deleteItem.setWidth(DensityUtil.dp2px(mContext, 60));
                deleteItem.setTitle("删除");
                deleteItem.setTitleSize(10);
                deleteItem.setTitleColor(Color.WHITE);
                deleteItem.setIcon(R.drawable.btn_shanchu_normal);
                menu.addMenuItem(deleteItem);
            }
        };
        // set creator
        listView.setMenuCreator(creator);

        // step 2. listener item click event
        listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(final int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        if (mMsgList != null && mMsgList.size() > 0) {
                            if (position <= mMsgList.size() - 1) {
                                String type = mMsgList.get(position).getType();
                                if ("rqkeymsg".equals(type)) {
                                    final String content = mMsgList.get(position).getContent();
                                    new AlertDialog.Builder(mContext)
                                            .setTitle("您确定要删除并驳回此申请吗？")
                                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    rejectRequest(content);
                                                    deleteMessage(position);
                                                }
                                            })
                                            .setNegativeButton("取消", null)
                                            .show();
                                } else {
                                    deleteMessage(position);
                                }
                            }
                        }
                        break;
                }
                return false;
            }
        });

        // set SwipeListener
        listView.setOnSwipeListener(new SwipeMenuListView.OnSwipeListener() {

            @Override
            public void onSwipeStart(int position) {
                // swipe start
            }

            @Override
            public void onSwipeEnd(int position) {
                // swipe end
            }
        });

        // set MenuStateChangeListener
        listView.setOnMenuStateChangeListener(new SwipeMenuListView.OnMenuStateChangeListener() {
            @Override
            public void onMenuOpen(int position) {
            }

            @Override
            public void onMenuClose(int position) {
            }
        });
    }

    private void rejectRequest(String json) {
        RequestKeyBean object = new Gson().fromJson(json, RequestKeyBean.class);
        RequestKeyBean.ObjectBean objectBean = object.getObject();
        String user_phone = objectBean.getUser_phone();
        String user_name = objectBean.getUser_name();
        String auth_start_date = objectBean.getKey_start_date();
        String auth_end_date = objectBean.getKey_end_date();
        int ship = objectBean.getUser_type();
        int zoneid = objectBean.getZone_id();
        String zonename = objectBean.getZone_name();
        int buildingid = objectBean.getBuilding_id();
        String buildingname = objectBean.getBuilding_name();
        int unitid = objectBean.getUnit_id();
        String unitname = objectBean.getUnit_name();
        int roomid = objectBean.getRoom_id();
        String room_name = objectBean.getRoom_name();
        int user_id = objectBean.getUser_id();
        int resident_id = objectBean.getResident_id();
        int master_resident_id = objectBean.getMaster_resident_id();

        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.AUTHKEY + uid + Constants.TOKEN + token;
        Log.e(TAG, "AUTHKEY_url===" + url);

        HashMap<String, Object> map = new HashMap<>();
        map.put("zone_id", zoneid);
        map.put("zone_name", zonename);
        map.put("building_id", buildingid);
        map.put("building_name", buildingname);
        map.put("unit_id", unitid);
        map.put("unit_name", unitname);
        map.put("room_id", roomid);
        map.put("room_name", room_name);
        map.put("user_type", ship);
        map.put("user_phone", user_phone);
        map.put("auth_type", 1);
        map.put("auth_cmd", 2); // 1-授权通过，2-驳回
        map.put("key_start_date", auth_start_date);
        map.put("key_end_date", auth_end_date);
        map.put("user_id", user_id);
        map.put("user_name", user_name);
        map.put("resident_id", resident_id);
        map.put("master_resident_id", master_resident_id);

        String content = new Gson().toJson(map);
        Log.e(TAG, "content===" + content);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e(TAG, "授权结果联网失败===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "授权结果联网成功===" + response);
                        parseResult(response);
                    }
                });
    }

    private void parseResult(String response) {
        String code = RequestUtil.getCode(mContext, response);
        if ("200".equals(code)) {
            ToastUtil.show("驳回成功");
        }
    }

    /**
     * 删除消息(内存、本地)
     */
    private void deleteMessage(int position) {
        if (mMsgList != null && mMsgList.size() > 0) {
            if (position <= mMsgList.size() - 1) {
                String type = mMsgList.get(position).getType();
                if ("noticemsg".equals(type)) {
                    String noticeJson = mMsgList.get(position).getContent();
                    NoticeMsgBean nm = new Gson().fromJson(noticeJson, NoticeMsgBean.class);
                    //1 普通  2  置顶 3  加急  4  加急置顶
                    switch (nm.getObject().getStatus()) {
                        case "4": //加急置顶
                            firstCount--;
                            break;
                        case "3": //置顶
                            secondCount--;
                            break;
                        case "2": //加急
                            thirdCount--;
                            break;
                        case "1": //普通
                            break;
                    }
                }
                removeMsgFromMemory(position);
            }
        } else {
            tvNoData.setVisibility(View.VISIBLE);
        }
    }

    private void removeMsgFromMemory(int position) {
        // 1.从内存移除
        mMsgList.remove(position);
        if (listAdapter != null) {
            tvNoData.setVisibility(View.GONE);
            listAdapter.notifyDataSetChanged();
        }
        if (mMsgList.size() <= 0) {
            tvNoData.setVisibility(View.VISIBLE);
        }
        // 2.从本地存储移除
        MessageProvider.getInstance().deleteMessageById(position);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBusMsg msg) {
        Logger.t(TAG).i("onEventMainThread收到了EventBusMsg消息~");
        switch (msg.getType()) {
            case "nodata":
                tvNoData.setVisibility(View.VISIBLE);
                mMsgList.clear();
                break;
            case "net_error": // 收到网络错误
                if (mContext != null) {
                    ((Activity) mContext).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (rlNetError != null && rlNetError.getVisibility() != View.VISIBLE) {
                                rlNetError.setVisibility(View.VISIBLE);
                            }
                        }
                    });
                }
                break;
            case "net_nice": // 收到网络可用
                if (mContext != null) {
                    ((Activity) mContext).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (rlNetError != null && rlNetError.getVisibility() != View.GONE) {
                                rlNetError.setVisibility(View.GONE);
                            }
                        }
                    });
                }
                break;
            case "setreadstate":
                String position = msg.getContent();
                MessageBean msgBean = mMsgList.get(Integer.parseInt(position));
                msgBean.setRead(true);
                if (listAdapter != null) {
                    listAdapter.notifyDataSetChanged();
                }
                break;
            case "deleteauthmsg":
                deleteMessage(Integer.parseInt(msg.getContent()));
                break;
            case "setrejectread":
                MessageProvider.getInstance().setReadState(Integer.parseInt(msg.getContent()));
                break;
            default:
                break;
        }
    }

    /**
     * 消息接收专用，勿用于其他消息！！！
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MessageBean msg) {
        Logger.t(TAG).i("onEventMainThread收到了MessageBean消息~");
        if (mMsgList == null) {
            mMsgList = new ArrayList<>();
        }

        if ("noticemsg".equals(msg.getType())) {
            accept_msg = msg.getContent();
            NoticeMsgBean nm = new Gson().fromJson(accept_msg, NoticeMsgBean.class);
            //1 普通  2  置顶 3  加急  4  加急置顶
            count = nm.getObject().getStatus();
            switch (count) {
                case "4": //加急置顶
                    firstCount++;
                    mMsgList.add(0, msg);
                    break;
                case "3": //置顶
                    secondCount++;
                    mMsgList.add(firstCount, msg);
                    break;
                case "2": //加急
                    thirdCount++;
                    mMsgList.add(firstCount + secondCount, msg);
                    break;
                case "1": //普通
                    mMsgList.add(firstCount + secondCount + thirdCount, msg);
                    break;
            }

        } else {
            if (mMsgList.size() == 0) {
                index = 0;
            } else {
                index = firstCount + secondCount + thirdCount;
            }
            try {
                mMsgList.add(index, msg);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        setAdapter();
        saveMsgList();
    }

    /**
     * 保存当前消息列表的信息
     */
    private void saveMsgList() {
        // 排过序的保存到本地
        MessageProvider.getInstance().saveReverseMsgList(mMsgList);
        List<String> msgNumber = new ArrayList<>();
        msgNumber.add("" + firstCount);
        msgNumber.add("" + secondCount);
        msgNumber.add("" + thirdCount);
        MessageProvider.getInstance().saveMessageTypeNumber(msgNumber);
    }

    private void setAdapter() {
        if (mMsgList != null && mMsgList.size() > 0) {
            tvNoData.setVisibility(View.GONE);
            if (listAdapter != null) {
                listAdapter.notifyDataSetChanged(); // 刷新数据
            } else {
                listAdapter = new MsgListAdapter(mContext, mMsgList);
                listView.setAdapter(listAdapter);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
        handler.removeCallbacksAndMessages(null);
    }

}
