package com.anloq.receiver;


import android.content.Context;
import android.util.Log;

import com.anloq.utils.ParseUtil;
import com.anloq.utils.SpUtil;
import com.xiaomi.mipush.sdk.ErrorCode;
import com.xiaomi.mipush.sdk.MiPushClient;
import com.xiaomi.mipush.sdk.MiPushCommandMessage;
import com.xiaomi.mipush.sdk.MiPushMessage;
import com.xiaomi.mipush.sdk.PushMessageReceiver;

import java.util.List;

/**
 * Created by Steven on 2017/8/10.
 * 小米推送接收PushMessageReceiver
 */


public class MiBroadCastReceive extends PushMessageReceiver {
    private String TAG = "MiBroadCastReceive";
    protected String mRegId;
    protected String mMessage;
    protected String mTopic;
    protected String mAlias;
    protected String mUserAccount;
    protected String alias = "steven";//别名
    protected String userAccount = "13461029851";//用户账号
    protected String topic = "call";//

    @Override
    public void onReceivePassThroughMessage(Context context, MiPushMessage message) {
        // 用来接收服务器发送的透传消息
        Log.e(TAG, "onReceivePassThroughMessage: " + message.getContent());
    }

    @Override
    public void onReceiveMessage(Context context, MiPushMessage message) {
        // 消息入队
        ParseUtil.joinQueue(message.getContent());
    }

    /**
     * 用来接收服务器发来的通知栏消息（用户点击通知栏时触发）
     *
     * @param context
     * @param miPushMessage
     */
    @Override
    public void onNotificationMessageClicked(Context context, MiPushMessage miPushMessage) {
        Log.e(TAG, "onNotificationMessageClicked()");
    }

    /**
     * 用来接收服务器发来的通知栏消息（消息到达客户端时触发，并且可以接收应用在前台时不弹出通知的通知消息）
     * 收到服务端推送的消息
     *
     * @param context
     * @param message
     */
    @Override
    public void onNotificationMessageArrived(Context context, MiPushMessage message) {
        // 弹起页面
        Log.e(TAG, "onNotificationMessageArrived: " + mMessage);

    }

    @Override
    public void onCommandResult(Context context, MiPushCommandMessage miPushCommandMessage) {
        // 用来接收客户端向服务器发送命令消息后返回的响应
        Log.e(TAG, "onCommandResult()");
    }

    @Override
    public void onReceiveRegisterResult(Context context, MiPushCommandMessage message) {
        //用来接受客户端向服务器发送注册命令消息后返回的响应
        String command = message.getCommand();
        List<String> arguments = message.getCommandArguments();
        String cmdArg1 = ((arguments != null && arguments.size() > 0) ? arguments.get(0) : null);
        //String cmdArg2 = ((arguments != null && arguments.size() > 1) ? arguments.get(1) : null);
        if (MiPushClient.COMMAND_REGISTER.equals(command)) {
            if (message.getResultCode() == ErrorCode.SUCCESS) {
                mRegId = cmdArg1;//需要传递的参数
                SpUtil.getInstance().save("regId", mRegId);
                //订阅
                //MiPushClient.setAlias(context, alias, null);//设置别名
                //MiPushClient.setUserAccount(context, userAccount, null);//设置账号
                //MiPushClient.subscribe(context, topic, null);//订阅呼叫
                Log.e(TAG, "onReceiveRegisterResult: " + mRegId);
            }
        }
    }
}
