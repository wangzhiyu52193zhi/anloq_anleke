package com.anloq.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

import com.anloq.MyApplication;
import com.anloq.activity.WebRtcActivity;
import com.anloq.api.Constants;
import com.anloq.manager.FeatureManager;
import com.anloq.model.CallPushBean;
import com.anloq.nfcservice.EmqttService;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.ArrayList;
import java.util.HashMap;

import okhttp3.Call;
import okhttp3.MediaType;

/**
 * Created by xpf on 2017/8/12 :)
 * Function:消息解析工具类
 */

public class ParseUtil {

    private static final String TAG = ParseUtil.class.getSimpleName();

    /**
     * 消息入队
     *
     * @param msg
     */
    public static void joinQueue(String msg) {
        int hash = msg.hashCode(); // 生成对应的hashcode值
        int queueSize = MyApplication.getMessageQuene().size();
        Log.e(TAG, "当前queueSize===" + queueSize + ",hashCode===" + hash);

        if (queueSize >= 2) {
            MyApplication.getMessageQuene().clear();
        }

        if (!MyApplication.getMessageQuene().contains(hash)) {
            // 如果不存在去判断是不是已经有其他的值
            if (queueSize == 0) {
                if (!isServiceWorked(MyApplication.getContext(), "com.anloq.nfcservice.EmqttService"))
                    MyApplication.getContext().startService(new Intent(MyApplication.getContext(), EmqttService.class));
                // 解析消息
                parseCalling(msg);
            }
            MyApplication.getMessageQuene().add(hash);
        }
    }

    /**
     * 检测service是否在运行
     *
     * @param context
     * @param serviceName
     * @return
     */
    public static boolean isServiceWorked(Context context, String serviceName) {
        ActivityManager myManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ArrayList<ActivityManager.RunningServiceInfo> runningService = (ArrayList<ActivityManager.RunningServiceInfo>) myManager.getRunningServices(Integer.MAX_VALUE);
        Log.e(TAG, "当前运行的: " + runningService);
        for (int i = 0; i < runningService.size(); i++) {
            if (runningService.get(i).service.getClassName().toString().equals(serviceName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 解析呼叫消息
     *
     * @param json
     */
    public static void parseCalling(String json) {
        if (TextUtils.isEmpty(json)) return;
        CallPushBean object = new Gson().fromJson(json, CallPushBean.class);
        if (object != null) {
            if (object.getCommand() == 0) { // 呼叫
                // 通话中又如果来电即不处理
//                if (WebRtcActivity.iscalling) {
//                    Log.e(TAG, "您呼叫的用户正在通话中请稍后再拨！！！");
//                    uploadBusyState(object.getBaoid());
//                    return;
//                }
                String eqt_id = object.getEqt_id();
                String unit_id = object.getUnit_id();
                String baoid = object.getBaoid();
                String eqt_name = object.getEqt_name();
                Log.e(TAG, "eqt_id===" + eqt_id + ",unit_id===" + unit_id + ",baoid===" + baoid + ",eqt_name===" + eqt_name);

                FeatureManager.wakeUpAndUnlock();
                Intent intent = new Intent(MyApplication.getContext(), WebRtcActivity.class);
                intent.putExtra("eqt_id", eqt_id);
                intent.putExtra("unit_id", unit_id);
                intent.putExtra("baoid", baoid);
                intent.putExtra("eqt_name", eqt_name);
                // 此处必须加flag，不然从后台无法弹起！！！
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.addFlags(Intent.FLAG_FROM_BACKGROUND);
                MyApplication.getContext().startActivity(intent);
                //overridePendingTransition(R.anim.bottom_in, R.anim.bottom_out);

            }
        }
    }

    /**
     * 上传繁忙状态
     *
     * @param baoid
     */
    public static void uploadBusyState(String baoid) {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");

        HashMap map = new HashMap();
        map.put("baoid", baoid);
        Logger.t(TAG).i("content===" + map.toString());

        String url = Constants.CALLBUSYMSG + uid + Constants.TOKEN + token;
        Log.e(TAG, "CALLBUSYMSG_URL===" + url);

        OkHttpUtils
                .postString()
                .url(url)
                .content(new Gson().toJson(map))
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e("Exception===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                    }
                });
    }

}
