package com.anloq.model;

import org.litepal.crud.DataSupport;

/**
 * Created by xpf on 2017/9/30 :)
 * Function:设备mac地址对应的设备id和单元id
 */

public class BtDeviceBean extends DataSupport {

    private String mac_attr;
    private int deviceid;
    private int unit_id;

    public BtDeviceBean() {
    }

    public BtDeviceBean(String mac_attr, int deviceid, int unit_id) {
        this.mac_attr = mac_attr;
        this.deviceid = deviceid;
        this.unit_id = unit_id;
    }

    public String getMac_attr() {
        return mac_attr;
    }

    public void setMac_attr(String mac_attr) {
        this.mac_attr = mac_attr;
    }

    public int getDeviceid() {
        return deviceid;
    }

    public void setDeviceid(int deviceid) {
        this.deviceid = deviceid;
    }

    public int getUnit_id() {
        return unit_id;
    }

    public void setUnit_id(int unit_id) {
        this.unit_id = unit_id;
    }
}
