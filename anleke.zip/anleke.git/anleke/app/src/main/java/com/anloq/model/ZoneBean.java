package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/3/27 :)
 * Function:小区Bean数据
 */
public class ZoneBean {

    /**
     * name : zones
     * object : [{"zone_id":8,"zone_name":"芳草地小区","address":"朝外街道"},{"zone_id":9,"zone_name":"劲松北社区","address":"劲松街道"},{"zone_id":10,"zone_name":"建国里社区","address":"建外街道"},{"zone_id":11,"zone_name":"金台里社区","address":"呼家楼街道"},{"zone_id":12,"zone_name":"红庙社区","address":"八里庄街道"}]
     * code : 200
     */

    private String name;
    private int code;
    private List<ObjectBean> object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<ObjectBean> getObject() {
        return object;
    }

    public void setObject(List<ObjectBean> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * zone_id : 8
         * zone_name : 芳草地小区
         * address : 朝外街道
         */

        private int zone_id;
        private String zone_name;
        private String address;

        public int getZone_id() {
            return zone_id;
        }

        public void setZone_id(int zone_id) {
            this.zone_id = zone_id;
        }

        public String getZone_name() {
            return zone_name;
        }

        public void setZone_name(String zone_name) {
            this.zone_name = zone_name;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }
    }
}
