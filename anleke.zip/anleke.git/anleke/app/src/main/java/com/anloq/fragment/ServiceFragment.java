package com.anloq.fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.anloq.adapter.ServiceListAdapter;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.base.BaseFragment;
import com.anloq.model.EventBusMsg;
import com.anloq.model.ServiceDataBean;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.Call;
import pub.devrel.easypermissions.EasyPermissions;
import pub.devrel.easypermissions.PermissionRequest;

/**
 * Created by xpf on 2017/3/22 :)
 * Function:服务页面的Fragment
 */

public class ServiceFragment extends BaseFragment implements EasyPermissions.PermissionCallbacks {

    private static final String TAG = ServiceFragment.class.getSimpleName();
    @BindView(R.id.listView)
    ListView listView;
    @BindView(R.id.tvNoData)
    TextView tvNoData;
    private ServiceListAdapter serviceListAdapter;
    private List<ServiceDataBean.ObjectBean> serviceList;
    private String currentZoneId = "";
    private int mPosition;

    @Override
    public View initView() {
        Log.e(TAG, "服务页面的视图初始化了");
        View view = View.inflate(mContext, R.layout.fragment_service, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        Log.e(TAG, "服务页面的数据初始化了");
        EventBus.getDefault().register(this);
        currentZoneId = SpUtil.getInstance().getString("zoneid", "");
        getData();
        initListener();
    }

    private void initListener() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mPosition = position;
                requestCameraPermission();
            }
        });
    }

    private void getData() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.SERVICETELS + uid + Constants.TOKEN + token + Constants.ZONEID + currentZoneId;
        Log.e(TAG, "SERVICETELS_url===" + url);

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e(TAG, "服务数据获取失败===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "服务数据获取成功Result===" + response);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        // 先清空旧数据
        if (serviceList != null && serviceList.size() > 0) {
            serviceList.clear();
        }
        ServiceDataBean serviceData = new Gson().fromJson(json, ServiceDataBean.class);
        serviceList = serviceData.getObject();
        if (serviceList != null && serviceList.size() > 0) {
            tvNoData.setVisibility(View.GONE);
            serviceListAdapter = new ServiceListAdapter(mContext, serviceList);
            listView.setAdapter(serviceListAdapter);
        } else {
            if (serviceListAdapter != null) {
                serviceListAdapter.notifyDataSetChanged();
            }
            tvNoData.setVisibility(View.VISIBLE);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBusMsg msg) {
        String type = msg.getType();
        if ("updateservicenumber".equals(type)) {
            Log.e(TAG, "收到了切换卡片时更新服务号码的通知");
            currentZoneId = msg.getContent();
            Log.e(TAG, "currentZoneId===" + currentZoneId);
            getData();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    private String[] call_phone = {Manifest.permission.CALL_PHONE};

    private void requestCameraPermission() {
        EasyPermissions.requestPermissions(
                new PermissionRequest.Builder(this, 520, call_phone)
                        .setRationale("need permissions")
                        .setPositiveButtonText("confirm")
                        .setNegativeButtonText("reject")
                        .build());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Forward results to EasyPermissions
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        switch (requestCode) {
            case 520:
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + serviceList.get(mPosition)));
                mContext.startActivity(intent);
                break;
        }
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        ToastUtil.show("you reject permission!");
    }
}
