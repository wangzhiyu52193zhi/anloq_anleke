package com.anloq.activity;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.adapter.TradeRecordAdapter;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.model.AccountTradeBean;
import com.anloq.ui.sticky.FloatingItemDecoration;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

import static android.content.ContentValues.TAG;

// 可用金额明细页面
public class AvailableDetail extends Activity {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;

    private HashMap<Integer, String> keys = new HashMap<>();//存放所有key的位置和内容

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_available_detail);
        ButterKnife.bind(this);
        tvTitle.setText("可用金额明细");
        getDataList();
    }

    private void getDataList() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.TRADERECORDS + uid + Constants.TOKEN + token;
        Logger.t(TAG).i("TradeRecords_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        AccountTradeBean tradeBean = new Gson().fromJson(json, AccountTradeBean.class);
        List<AccountTradeBean.ObjectBean> records = tradeBean.getObject();
        List<AccountTradeBean.ObjectBean.RecordsBean> allRecordsList = new ArrayList<>();
        if (records != null && records.size() > 0) {
            for (int i = 0; i < records.size(); i++) {
                AccountTradeBean.ObjectBean objectBean = records.get(i);
                // 加入吸附头数据
                keys.put(allRecordsList.size(), objectBean.getMonth());
                allRecordsList.addAll(objectBean.getRecords());
            }

            if (allRecordsList.size() > 0) {
                final FloatingItemDecoration floatingItemDecoration = new FloatingItemDecoration(this, Color.GRAY, 1, 1);
                floatingItemDecoration.setKeys(keys);
                floatingItemDecoration.setmTitleHeight((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 40, getResources().getDisplayMetrics()));
                recyclerView.addItemDecoration(floatingItemDecoration);
                TradeRecordAdapter adapter = new TradeRecordAdapter(AvailableDetail.this, allRecordsList);
                recyclerView.setHasFixedSize(true);
                recyclerView.setAdapter(adapter);
                LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
                recyclerView.setLayoutManager(layoutManager);
            }
        }
    }

    @OnClick(R.id.ivBack)
    public void onClick() {
        finish();
    }
}
