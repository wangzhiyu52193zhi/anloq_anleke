package com.anloq.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.model.AnloqContactBean;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/5/23 :)
 * Function:安络联系人数据的适配器
 */

public class AnloqContactAdapter extends BaseAdapter {

    private Context mContext;
    private List<AnloqContactBean> allAnloqContacts;

    public AnloqContactAdapter(Context mContext, List<AnloqContactBean> allAnloqContacts) {
        this.mContext = mContext;
        this.allAnloqContacts = allAnloqContacts;
    }

    @Override
    public int getCount() {
        return allAnloqContacts.size();
    }

    @Override
    public Object getItem(int position) {
        return allAnloqContacts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_anloq_contact, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        AnloqContactBean anloqContactBean = allAnloqContacts.get(position);
        holder.tvName.setText(anloqContactBean.getName());
        holder.tvPhone.setText(anloqContactBean.getPhone());
        return convertView;
    }

    static class ViewHolder {
        @BindView(R.id.ivIcon)
        ImageView ivIcon;
        @BindView(R.id.tvName)
        TextView tvName;
        @BindView(R.id.tvPhone)
        TextView tvPhone;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
