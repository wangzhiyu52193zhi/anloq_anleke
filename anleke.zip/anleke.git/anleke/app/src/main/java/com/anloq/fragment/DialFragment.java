package com.anloq.fragment;

import android.util.Log;
import android.view.View;

import com.anloq.anleke.R;
import com.anloq.base.BaseFragment;

/**
 * Created by xpf on 2017/3/22 :)
 * Function: 拨号页面的Fragment
 */

public class DialFragment extends BaseFragment {

    @Override
    public View initView() {
        View view = View.inflate(mContext, R.layout.fragment_dial, null);
        Log.e("TAG", " 拨号页面的视图初始化了");
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        Log.e("TAG", " 拨号页面的数据初始化了");
    }

}
