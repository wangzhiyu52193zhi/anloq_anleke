package com.anloq.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.model.QrCodeBean;
import com.anloq.utils.DensityUtil;
import com.anloq.utils.ImgUtils;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.xys.libzxing.zxing.encoding.EncodingUtils;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.MediaType;

// 二维码授权页面
public class QrcodeAuth extends Activity {

    private static final String TAG = QrcodeAuth.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.tvZoneName)
    TextView tvZoneName;
    @BindView(R.id.ivQrcode)
    ImageView ivQrcode;
    @BindView(R.id.tvSave)
    TextView tvSave;
    @BindView(R.id.tvWechat)
    TextView tvWechat;
    @BindView(R.id.tvQQ)
    TextView tvQQ;
    private Context mContext;
    private String platformName = "";
    private String platformToastName = "";
    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode_auth);
        ButterKnife.bind(this);
        mContext = this;
        tvTitle.setText(R.string.qrcode_auth);
        Intent intent = getIntent();
        int key_id = intent.getIntExtra("keyId", -1);
        String zoneName = intent.getStringExtra("zoneName");
        String buildingName = intent.getStringExtra("buildingName");
        tvZoneName.setText(zoneName + buildingName);
        getQrCodeNum(key_id);
    }

    private void getQrCodeNum(int keyId) {
        if (keyId == -1) return;
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        HashMap map = new HashMap();
        map.put("key_id", keyId);
        Logger.t(TAG).i("content===" + map.toString());
        String url = Constants.INIT_QRCODE_NUM + uid + Constants.TOKEN + token;
        Logger.t(TAG).i("INIT_QRCODE_NUM_URL===" + url);

        OkHttpUtils
                .postString()
                .url(url)
                .content(new Gson().toJson(map))
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e("Exception===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseQrCode(response);
                    }
                });
    }

    private void parseQrCode(String json) {
        if (!TextUtils.isEmpty(json)) {
            QrCodeBean qrCodeBean = new Gson().fromJson(json, QrCodeBean.class);
            QrCodeBean.ObjectBean object = qrCodeBean.getObject();
            if (object != null) {
                produceQrcodeImg(object.getNum());
            }
        }
    }

    private void produceQrcodeImg(String num) {
        Bitmap logoBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.qrcode_img);
        bitmap = EncodingUtils.createQRCode(num,
                DensityUtil.dp2px(mContext, 200), DensityUtil.dp2px(mContext, 200), logoBitmap);
        ivQrcode.setImageBitmap(bitmap);
    }

    @OnClick({R.id.ivBack, R.id.tvSave, R.id.tvWechat, R.id.tvQQ})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.tvSave:
                saveQrcode();
                break;
            case R.id.tvWechat:
                //微信分享
                shareContent(bitmap, SHARE_MEDIA.WEIXIN);
                break;
            case R.id.tvQQ:
                //qq分享
                shareContent(bitmap, SHARE_MEDIA.QQ);
                break;
        }
    }

    private void saveQrcode() {
        boolean isSaveSuccess = ImgUtils.saveImageToGallery(mContext, bitmap);
        if (isSaveSuccess) {
            ToastUtil.show("保存成功");
        } else {
            ToastUtil.show("保存失败");
        }
    }

    private void shareContent(Bitmap bitmap, SHARE_MEDIA platform) {
        if (UMShareAPI.get(this).isInstall(this, platform)) {
            UMImage thumb = new UMImage(this, bitmap);
            thumb.setThumb(thumb);  //缩略图
            new ShareAction(QrcodeAuth.this)
                    .withMedia(thumb)
                    .setPlatform(platform)
                    .setCallback(umShareListener).share();
        } else {
            getPlatformName(platform.toString());
            ToastUtil.show(getString(R.string.not_install_text) + platformToastName);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }

    private UMShareListener umShareListener = new UMShareListener() {
        @Override
        public void onStart(SHARE_MEDIA platform) {
            //分享开始的回调
        }

        @Override
        public void onResult(SHARE_MEDIA platform) {
            platformName = platform.toString();
            getPlatformName(platformName);
            Toast.makeText(QrcodeAuth.this, platformToastName + getString(R.string.share_success), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable t) {
            platformName = platform.toString();
            getPlatformName(platformName);
        }

        @Override
        public void onCancel(SHARE_MEDIA platform) {
            platformName = platform.toString();
            if (platformName.equals("QQ"))
                return;
            getPlatformName(platformName);
            Toast.makeText(QrcodeAuth.this, platformToastName + getString(R.string.share_cancel), Toast.LENGTH_SHORT).show();
        }
    };

    private void getPlatformName(String str) {
        switch (str) {
            case "SINA":
                platformToastName = getString(R.string.SINA);
                break;
            case "QQ":
                platformToastName = getString(R.string.QQ);
                break;
            case "WEIXIN":
                platformToastName = getString(R.string.WEIXIN);
                break;
            case "WEIXIN_CIRCLE":
                platformToastName = getString(R.string.WEIXIN_CIRCLE);
                break;
        }
    }

}
