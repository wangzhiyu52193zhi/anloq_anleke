package com.anloq.model;

import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xpf on 2017/4/6 :)
 * Function:虚拟钥匙(数据库)
 */

public class VkeyBean extends DataSupport {

    private int key_id;
    private int expire_type;
    private String auth_start_date;
    private String auth_end_date;
    private int auth_count;
    private String user_phone;
    private String device_key_sr;
    private String first_key;
    private int key_status;
    private int relation;
    private boolean is_freeze;
    private boolean is_deleted;
    private String room_admin_name;
    private String unit_name;
    private String building_name;
    private String zone_name;
    private String image_url;
    private String province_name;
    private String city_name;
    private int city_id;
    private int room_id;
    private int unit_id;
    private int building_id;
    private int province_id;
    private int zone_id;
    private String zone_key_color;
    private String room_name;
    private List<String> bt_device_mac = new ArrayList<>();

    public List<String> getBt_device_mac() {
        return bt_device_mac;
    }

    public void setBt_device_mac(List<String> bt_device_mac) {
        this.bt_device_mac = bt_device_mac;
    }

    public String getUser_phone() {
        return user_phone;
    }

    public void setUser_phone(String user_phone) {
        this.user_phone = user_phone;
    }

    public boolean is_deleted() {
        return is_deleted;
    }

    public String getRoom_name() {
        return room_name;
    }

    public void setRoom_name(String room_name) {
        this.room_name = room_name;
    }

    public String getZone_key_color() {
        return zone_key_color;
    }

    public void setZone_key_color(String zone_key_color) {
        this.zone_key_color = zone_key_color;
    }

    public int getZone_id() {
        return zone_id;
    }

    public void setZone_id(int zone_id) {
        this.zone_id = zone_id;
    }

    public VkeyBean() {
    }

    public int getCity_id() {
        return city_id;
    }

    public void setCity_id(int city_id) {
        this.city_id = city_id;
    }

    public int getRoom_id() {
        return room_id;
    }

    public void setRoom_id(int room_id) {
        this.room_id = room_id;
    }

    public int getUnit_id() {
        return unit_id;
    }

    public void setUnit_id(int unit_id) {
        this.unit_id = unit_id;
    }

    public int getBuilding_id() {
        return building_id;
    }

    public void setBuilding_id(int building_id) {
        this.building_id = building_id;
    }

    public int getProvince_id() {
        return province_id;
    }

    public void setProvince_id(int province_id) {
        this.province_id = province_id;
    }

    public String getUnit_name() {
        return unit_name;
    }

    public void setUnit_name(String unit_name) {
        this.unit_name = unit_name;
    }

    public String getBuilding_name() {
        return building_name;
    }

    public void setBuilding_name(String building_name) {
        this.building_name = building_name;
    }

    public String getZone_name() {
        return zone_name;
    }

    public void setZone_name(String zone_name) {
        this.zone_name = zone_name;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getProvince_name() {
        return province_name;
    }

    public void setProvince_name(String province_name) {
        this.province_name = province_name;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getRoom_admin_name() {
        return room_admin_name;
    }

    public void setRoom_admin_name(String room_admin_name) {
        this.room_admin_name = room_admin_name;
    }

    public int getRelation() {
        return relation;
    }

    public void setRelation(int relation) {
        this.relation = relation;
    }

    public int getKey_id() {
        return key_id;
    }

    public void setKey_id(int key_id) {
        this.key_id = key_id;
    }

    public int getExpire_type() {
        return expire_type;
    }

    public void setExpire_type(int expire_type) {
        this.expire_type = expire_type;
    }

    public String getAuth_start_date() {
        return auth_start_date;
    }

    public void setAuth_start_date(String auth_start_date) {
        this.auth_start_date = auth_start_date;
    }

    public String getAuth_end_date() {
        return auth_end_date;
    }

    public void setAuth_end_date(String auth_end_date) {
        this.auth_end_date = auth_end_date;
    }

    public int getAuth_count() {
        return auth_count;
    }

    public void setAuth_count(int auth_count) {
        this.auth_count = auth_count;
    }

    public String getDevice_key_sr() {
        return device_key_sr;
    }

    public void setDevice_key_sr(String device_key_sr) {
        this.device_key_sr = device_key_sr;
    }

    public String getFirst_key() {
        return first_key;
    }

    public void setFirst_key(String first_key) {
        this.first_key = first_key;
    }

    public int getKey_status() {
        return key_status;
    }

    public void setKey_status(int key_status) {
        this.key_status = key_status;
    }

    public boolean is_freeze() {
        return is_freeze;
    }

    public void setIs_freeze(boolean is_freeze) {
        this.is_freeze = is_freeze;
    }

    public boolean isIs_deleted() {
        return is_deleted;
    }

    public void setIs_deleted(boolean is_freeze) {
        this.is_deleted = is_freeze;
    }

}
