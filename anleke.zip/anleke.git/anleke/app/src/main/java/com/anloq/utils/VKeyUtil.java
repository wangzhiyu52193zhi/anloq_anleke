package com.anloq.utils;

/**
 * Created by tianjh on 17/3/11.
 */
public class VKeyUtil {
    static {
        System.loadLibrary("anlokvkey");
    }
//    typedef enum   //命令类型
//    {
//        TYPE_UNLOCK = 1, //开锁
//        TYPE_TOLOCK = 2, //上锁
//        TYPE_INLOCK = 3, //反锁
//    } TYPE_THELOCK;

    public native byte[] vkeyCommandPack(byte[] cert,byte[] device_key_sr,byte[] first_key,int command);
}