package com.anloq.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.backport.webp.WebPFactory;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewAnimator;

import com.anloq.MyApplication;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.VibratorManager;
import com.anloq.model.CallRecordBean;
import com.anloq.model.EventBusMsg;
import com.anloq.model.LoginBean;
import com.anloq.nfcservice.EmqttService;
import com.anloq.ui.BlurBitmapUtil;
import com.anloq.ui.ProgressLoading;
import com.anloq.utils.MessageProvider;
import com.anloq.utils.ParseUtil;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SoundPoolUtils;
import com.anloq.utils.SpUtil;
import com.anloq.utils.TimeUtil;
import com.anloq.utils.ToastUtil;
import com.common.DEVICE;
import com.common.ID;
import com.common.SDK;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.rtc.base.ActionCallback;
import com.rtc.base.ClientContext;
import com.rtc.base.ConnectionStats;
import com.rtc.base.LocalCameraStream;
import com.rtc.base.LocalCameraStreamParameters;
import com.rtc.base.MediaCodec;
import com.rtc.base.RemoteStream;
import com.rtc.base.WoogeenException;
import com.rtc.base.WoogeenIllegalArgumentException;
import com.rtc.p2p.PeerClient;
import com.rtc.p2p.PeerClientConfiguration;
import com.rtc.p2p.PublishOptions;
import com.socketclient.SocketSignalingChannel;
import com.socketclient.WoogeenSurfaceRenderer;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.EglBase;
import org.webrtc.PeerConnection;
import org.webrtc.SurfaceViewRenderer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.iwgang.countdownview.CountdownView;
import okhttp3.Call;
import okhttp3.MediaType;
import pub.devrel.easypermissions.EasyPermissions;
import pub.devrel.easypermissions.PermissionRequest;

import static com.anloq.manager.VibratorManager.startVibrate;
import static com.anloq.manager.VibratorManager.stopViberate;

// 视频通话页面
public class WebRtcActivity extends Activity implements View.OnClickListener, EasyPermissions.PermissionCallbacks {
    private static final String TAG = WebRtcActivity.class.getSimpleName();
    public static boolean isVisiblity = false;
    @BindView(R.id.callerPhoto)
    ImageView callerPhoto;
    @BindView(R.id.local_view_container)
    LinearLayout localViewContainer;
    @BindView(R.id.remote_view_container)
    LinearLayout remoteViewContainer;
    @BindView(R.id.tvUnlock)
    TextView tvUnlock;
    @BindView(R.id.ivEndCall)
    ImageView ivEndCall;
    @BindView(R.id.ivAccept)
    ImageView ivAccept;
    @BindView(R.id.tvCaller)
    TextView tvCaller;
    @BindView(R.id.ivVideo)
    ImageView ivVideo;
    @BindView(R.id.btnMute)
    ImageButton btnMute;
    @BindView(R.id.btnSwitch)
    ImageButton btnSwitch;
    @BindView(R.id.btnVideo)
    ImageButton btnVideo;
    @BindView(R.id.ivMute)
    ImageView ivMute;
    @BindView(R.id.btnFree)
    ImageButton btnFree;
    @BindView(R.id.llTopMenu)
    LinearLayout llTopMenu;
    @BindView(R.id.llCallTime)
    LinearLayout llCallTime;
    @BindView(R.id.sample_output)
    ViewAnimator output;
    @BindView(R.id.btnExchange)
    ImageButton btnExchange;
    @BindView(R.id.countDownView)
    CountdownView countDownView;
    @BindView(R.id.blurView)
    ImageView blurView;

    private Context mContext;
    private Handler mHandler;
    private String selfId = "";
    private String destId = "";
    private String eqt_id = "";
    private String unit_id = "";
    private Boolean isInCallState = false;
    private PeerClient peerClient;
    private LocalCameraStream localStream;
    private RemoteStream remoteStream;
    private EglBase rootEglBase;
    private HandlerThread peerThread;
    private PeerHandler peerHandler;
    private Message message;
    private String msgString;
    private WoogeenSurfaceRenderer localStreamRenderer;
    private WoogeenSurfaceRenderer remoteStreamRenderer;
    private SurfaceViewRenderer localStreamRender_Sink;
    private boolean isExchange = false; // 记录是否已经切换本地远程视频(默认为没有切换)
    private String publishPeerId = "";
    private int cameraID = 0;
    private int rtcLoginCount = 0;

    private final static int LOGIN = 1;
    private final static int LOGOUT = 2;
    private final static int INVITE = 3;
    private final static int STOP = 4;
    private final static int PUBLISH = 5;
    private final static int UNPUBLISH = 6;
    private final static int SWITCH_CAMERA = 7;
    private final static int SEND_DATA = 8;
    private final static int DISABLE_VIDEO = 9;
    private final static int PUBLISHAUDIO = 10;
    private final static int VIEW_STATUS = 0;
    private final static int VIEW_CALLING = 1;
    private final static int VIEW_LOG = 2;
    public static boolean iscalling = false;
    private Timer statsTimer;
    private boolean viewLog = false;
    private int viewNew;
    private ID userId;
    private DEVICE device = new DEVICE("MOBILE", "Android", "V4.4", null);
    private SDK sdk = new SDK("Android", "V1.0");
    private boolean mirror = true;     // 默认开启前置镜头
    private MediaPlayer mMediaPlayer;  // 手机媒体播放器对象
    private AudioManager audioManager; // 手机音频管理者对象
    private boolean isMuteOpen = false;    // 默认关闭手机静音
    private boolean isSpeakerOpen = true;  // 默认开启手机扬声器
    private boolean isVideoOpen = true;    // 默认开启手机视频
    private boolean isFrontCamera = true;  // 默认开启前置相机
    private static int currVolume = 0;     // 当前音量
    private boolean isAccepted;
    private boolean isCalling = false;
    private String eqt_name;
    private long startCallTime = 0, endCallTime = 0;
    private int command = -1;
    private List<Bitmap> images; // 轮播图集合
    private boolean isIvMuteBtnIconSwitched = false; // 铃声静音按钮图标是否切换(为仅语音通话模式开关）
    private boolean isIvAcceptBtnIconSwitched = false; // 接听按钮图标是否切换(为静音开关)
    private boolean isLocalStreamPushed = false; // 是否已推流
    private boolean isSwitchedToAudioMode = false; // 是否切换为仅语音通话模式
    private boolean isStopRing = true; // 是否停止响铃
    private boolean isPressHome = false;
    public static boolean isLaunch = false;//是否启动了该页面
    public static boolean isHome = false;//判断是否按了home键
    private ProgressLoading mProgressLoading;

    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    if (tvUnlock.getText().toString().equals(getString(R.string.unlocking))) {
                        tvUnlock.setEnabled(true);
                        tvUnlock.setText(getString(R.string.unlock));
                        ToastUtil.show("开锁失败");
                    }
                    break;
                case 1:
                    if (mProgressLoading != null && mProgressLoading.isShowing()) {
                        ToastUtil.show("当前网络环境较差！");
                        WebRtcActivity.this.finish();
                    }
                    break;
            }
        }
    };

    // 情景模式切换广播接受者
    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // 如果是情景模式切换的广播
            if (AudioManager.RINGER_MODE_CHANGED_ACTION.equals(intent.getAction())) {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                handleRingMode(am.getRingerMode());// 对情景模式做不同的处理
            }
        }
    };

    private BroadcastReceiver mHomeKeyEventReceiver = new BroadcastReceiver() {
        String SYSTEM_REASON = "reason";
        String SYSTEM_HOME_KEY = "homekey";
        String SYSTEM_HOME_KEY_LONG = "recentapps";

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) {
                String reason = intent.getStringExtra(SYSTEM_REASON);
                if (TextUtils.equals(reason, SYSTEM_HOME_KEY)) {
                    // 表示按了home键,程序到了后台
                    Log.e("TAG", "home");
                    SpUtil.getInstance().save("presshome", true);
                    isPressHome = true;
                    isHome = true;
                } else if (TextUtils.equals(reason, SYSTEM_HOME_KEY_LONG)) {
                    //表示长按home键,显示最近使用的程序列表
                }
            }
        }
    };

    /**
     * 处理情景模式
     */
    private void handleRingMode(int ringerMode) {
        stopAlarm(); // 关闭铃声
        VibratorManager.stopViberate(); // 关闭震动
        switch (ringerMode) {
            case AudioManager.RINGER_MODE_NORMAL://标准模式（铃声和震动）
                startAlarm();
                if (SpUtil.getInstance().getBoolean("ringandvibrate", true)) {
                    startVibrate();
                }
                break;
            case AudioManager.RINGER_MODE_SILENT://静音模式
                break;
            case AudioManager.RINGER_MODE_VIBRATE://震动模式(开启震动不要忘记系统震动权限)
                startVibrate();
                break;
        }
    }

    /**
     * 监听情景切换（注册情景模式变化广播接收者）
     */
    private void ringerModeListening() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AudioManager.RINGER_MODE_CHANGED_ACTION);
        registerReceiver(broadcastReceiver, intentFilter);
        IntentFilter mVideoDisconnectReceiverFilter = new IntentFilter();
        mVideoDisconnectReceiverFilter.addAction("video_disconnect");
        registerReceiver(mVideoStateReceive, mVideoDisconnectReceiverFilter);
    }

    private String[] audio = {Manifest.permission.RECORD_AUDIO};
    private String[] camera = {Manifest.permission.CAMERA};

    private void requestAudioPermission() {
        EasyPermissions.requestPermissions(
                new PermissionRequest.Builder(this, 520, audio)
                        .setRationale("need permissions")
                        .setPositiveButtonText("confirm")
                        .setNegativeButtonText("reject")
                        .build());
    }

    private void requestCameraPermission() {
        EasyPermissions.requestPermissions(
                new PermissionRequest.Builder(this, 521, camera)
                        .setRationale("need permissions")
                        .setPositiveButtonText("confirm")
                        .setNegativeButtonText("reject")
                        .build());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Forward results to EasyPermissions
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        switch (requestCode) {
            case 520:
                pushLocalAudio();
                break;
            case 521:
                onClickKeyStar();
                //pushLocalStream();
                break;
        }
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        Toast.makeText(this, "you reject permission!", Toast.LENGTH_SHORT).show();
    }

    private void pushLocalAudio() {
        if (localStream == null) {
            LocalCameraStreamParameters msp;
            try {
                msp = new LocalCameraStreamParameters(
                        false, true);
                msp.setResolution(320, 240);
                msp.setCameraId(cameraID);
                localStream = new LocalCameraStream(msp);
                //localStream.attach(localStreamRenderer);
            } catch (WoogeenException e1) {
                e1.printStackTrace();
                if (localStream != null) {
                    localStream.close();
                    localStream = null;
                    localStreamRenderer.cleanFrame();
                }
            }
        }
        //destId = "11";
        //destId = EnterNumber.getText().toString();
        PublishOptions optionaudio = new PublishOptions();
        optionaudio.setMaximumVideoBandwidth(200);
        //Be careful when you set up the audio bandwidth, as difference audio codec requires different minimum bandwidth.
        //option.setMaximumAudioBandwidth(30);
        peerClient.publish(localStream, destId, optionaudio,
                new ActionCallback<Void>() {

                    @Override
                    public void onSuccess(Void result) {
                        publishPeerId = destId;
                        runOnUiThread(new Runnable() {
                            public void run() {

                            }
                        });

                        statsTimer = new Timer();
                        statsTimer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                if (peerClient != null) {
                                    peerClient.getConnectionStats(destId, localStream, new ActionCallback<ConnectionStats>() {
                                        @Override
                                        public void onSuccess(ConnectionStats result) {
                                            Log.e(TAG, "result:" + result.mediaTracksStatsList.size());
                                            Log.e(TAG, "connection stats: " + result.timeStamp
                                                    + " available transmit bitrate: " + result.videoBandwidthStats.transmitBitrate
                                                    + " retransmit bitrate: " + result.videoBandwidthStats.reTransmitBitrate);
                                        }

                                        @Override
                                        public void onFailure(WoogeenException e) {
                                        }
                                    });
                                }
                            }
                        }, 0, 10000);
                    }

                    @Override
                    public void onFailure(WoogeenException e) {
                        Log.e(TAG, e.getMessage());
                        if (localStream != null) {
                            localStream.close();
                            localStream = null;
                            localStreamRenderer.cleanFrame();
                        }
                    }
                });
    }

    private void pushLocalStream() {
        if (localStream != null) {
            localStream.close();
            localStream = null;
        }
        if (localStream == null) {
            LocalCameraStreamParameters msp;
            try {
                msp = new LocalCameraStreamParameters(
                        true, true);
                msp.setResolution(320, 240);
                msp.setCameraId(cameraID);
                localStream = new LocalCameraStream(msp);
                localStream.attach(localStreamRenderer);
                //@localStream.attach_local(localStreamRenderer, localStreamRender_Sink);
                //@localStream.attach(remoteStreamRenderer);
            } catch (WoogeenException e1) {
                e1.printStackTrace();
                if (localStream != null) {
                    localStream.close();
                    localStream = null;
                    localStreamRenderer.cleanFrame();
                }
            }
        }
        //destId = "11";
        //destId = EnterNumber.getText().toString();
        PublishOptions option = new PublishOptions();
        option.setMaximumVideoBandwidth(2000);
        //Be careful when you set up the audio bandwidth, as difference audio codec requires different minimum bandwidth.
        //option.setMaximumAudioBandwidth(30);
        peerClient.publish(localStream, destId, option,
                new ActionCallback<Void>() {

                    @Override
                    public void onSuccess(Void result) {
                        publishPeerId = destId;
                        runOnUiThread(new Runnable() {
                            public void run() {
                            }
                        });

                        //This is a sample usage of get the statistic data for a specific stream, in this sample, localStream
                        //that has just been published. If you would like to get all the data for the peerconnection, including
                        //the data for the streams had been published before, please refer to the sample code in onChatStarted.
                        //ATTENTION: DO NOT use getConnectionStats(), getConnectionStats(localstream)and getAudioLevels() at the same time.
                        statsTimer = new Timer();
                        statsTimer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                peerClient.getConnectionStats(destId, localStream, new ActionCallback<ConnectionStats>() {
                                    @Override
                                    public void onSuccess(ConnectionStats result) {
                                        Log.e(TAG, "result:" + result.mediaTracksStatsList.size());
                                        Log.e(TAG, "connection stats: " + result.timeStamp
                                                + " available transmit bitrate: " + result.videoBandwidthStats.transmitBitrate
                                                + " retransmit bitrate: " + result.videoBandwidthStats.reTransmitBitrate);
                                    }

                                    @Override
                                    public void onFailure(WoogeenException e) {
                                    }
                                });
                            }
                        }, 0, 10000);
                    }

                    @Override
                    public void onFailure(WoogeenException e) {
                        Log.e(TAG, e.getMessage());
                        if (localStream != null) {
                            localStream.close();
                            localStream = null;
                            localStreamRenderer.cleanFrame();
                        }
                    }
                });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); // 保持手机屏幕常亮
        setContentView(R.layout.activity_web_rtc);
        ButterKnife.bind(this);
        EventBus.getDefault().register(this);
        mContext = this;
        ivVideo.setEnabled(false);
        mProgressLoading = new ProgressLoading(this);
        initData();
        initListener();
    }

    private void initListener() {
        // 设置倒计时结束时的监听
        countDownView.setOnCountdownEndListener(new CountdownView.OnCountdownEndListener() {
            @Override
            public void onEnd(CountdownView cv) {
                // 倒计时结束仍然在通话中就挂断
                if (isCalling) {
                    finish();
                }
            }
        });
    }

    private void initData() {
        mHandler = new Handler();
        isAccepted = false;
        iscalling = true;
        audioManager = ((AudioManager) getSystemService(AUDIO_SERVICE));
        OpenSpeaker();
        images = new ArrayList<>();

        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        userId = new ID("RESIDENT", "" + uid, token);
        Log.e(TAG, "uid===" + uid + ",token===" + token);

        int ringerMode = audioManager.getRingerMode();
        handleRingMode(ringerMode);
        getActivityData();

        try {
            initVideoStreamsViews(); // 初始化视频流视图
            //releaseResource();
            initPeerClient();        // 初始化点对点客户端
        } catch (WoogeenException e) {
            e.printStackTrace();
        }
    }

    private void getActivityData() {
        Intent intent = getIntent();
        eqt_id = intent.getStringExtra("eqt_id");
        unit_id = intent.getStringExtra("unit_id");
        destId = intent.getStringExtra("baoid");
        eqt_name = intent.getStringExtra("eqt_name");
        tvCaller.setText(eqt_name);
        Log.e(TAG, "eqt_id===" + eqt_id + ",unit_id===" + unit_id + ",baoid" + destId);
        callerPhoto.setImageResource(R.drawable.img_lianluo_tupiandiushi);
        SpUtil.getInstance().save("eqt_id", eqt_id);
        SpUtil.getInstance().save("unit_id", unit_id);
    }

    @OnClick({R.id.ivVideo, R.id.ivEndCall, R.id.ivAccept, R.id.btnMute, R.id.btnSwitch, R.id.btnVideo,
            R.id.btnFree, R.id.btnExchange, R.id.tvUnlock, R.id.ivMute})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivVideo:
                if (!isLocalStreamPushed) { // 如果未推流
                    //onClickKeyStar();
                    requestCameraPermission();
                    isLocalStreamPushed = true;
                    ivVideo.setImageResource(R.drawable.btn_shipin_normal); // 图标置黑
                } else {
                    if (localStream != null) {
                        if (isVideoOpen) {
                            localStreamRenderer.setVisibility(View.INVISIBLE);
                            localStream.getMediaStream().videoTracks.get(0).setEnabled(false);
                            ivVideo.setImageResource(R.drawable.btn_shipin_highlight); // 图标置绿
                            Toast.makeText(WebRtcActivity.this, R.string.turn_off_video, Toast.LENGTH_SHORT).show();
                            isVideoOpen = false;
                        } else {
                            localStreamRenderer.setVisibility(View.VISIBLE);
                            localStream.getMediaStream().videoTracks.get(0).setEnabled(true);
                            ivVideo.setImageResource(R.drawable.btn_shipin_normal); // 图标置黑
                            Toast.makeText(WebRtcActivity.this, R.string.turn_on_video, Toast.LENGTH_SHORT).show();
                            isVideoOpen = true;
                        }
                    }
                }
                break;
            case R.id.ivEndCall: // 挂断
                isPressHome = false;
                toEndCall();
                break;
            case R.id.ivAccept: // 接听
                Logger.t(TAG).i("接听按钮点击了~");
                stopAlarm();
                stopViberate();
                if (mProgressLoading != null) {
                    mProgressLoading.show(getString(R.string.accepting));
                    handler.sendEmptyMessageDelayed(1, 12000);
                }
                if (!tvUnlock.isEnabled()) {
                    tvUnlock.setEnabled(true);
                }
                if (!isIvAcceptBtnIconSwitched) {
                    ivVideo.setEnabled(true);
                    tvUnlock.setVisibility(View.VISIBLE);
                    message = peerHandler.obtainMessage();
                    message.what = LOGIN;
                    peerHandler.sendMessage(message);
                } else { // 话筒（麦克风）开启、关闭
                    if (isMuteOpen) { // 如果话筒已打开
                        ivAccept.setImageResource(R.drawable.btn_huatongjingyin_normal); // 图标置黑
                        if (localStream != null) {
                            localStream.enableAudio();
                            ToastUtil.show(getString(R.string.turn_on_mic));
                        }
                    } else {
                        ivAccept.setImageResource(R.drawable.btn_huatongjingyin_highlight); // 图标置绿
                        if (localStream != null) {
                            localStream.disableAudio();
                            ToastUtil.show(getString(R.string.turn_off_mic));
                        }
                    }
                    isMuteOpen = !isMuteOpen;
                }
                break;
            case R.id.btnMute: // 打开、关闭静音
                isMuteOpen = !isMuteOpen;
                btnMute.setBackgroundResource(
                        isMuteOpen ? R.drawable.jy_press_true : R.drawable.jy_press_false);
                isMute(isMuteOpen);
                break;
            case R.id.btnSwitch: // 切换手机前后镜头
                isFrontCamera = !isFrontCamera;
                btnSwitch.setBackgroundResource(
                        isFrontCamera ? R.drawable.qh_press_true : R.drawable.qh_press_false);
                message = peerHandler.obtainMessage();
                message.what = SWITCH_CAMERA;
                message.sendToTarget();
                break;
            case R.id.btnVideo: // 视频、语音切换
                isVideoOpen = !isVideoOpen;
                btnVideo.setBackgroundResource(
                        isVideoOpen ? R.drawable.sp_press_true : R.drawable.sp_press_false);

                if (localStream != null) {
                    try {
                        localStream.detach(localStreamRenderer);
                        localStream.enableAudio();
                        localStream.getMediaStream().videoTracks.get(0).setEnabled(false);
                        localStreamRenderer.cleanFrame();
                    } catch (WoogeenIllegalArgumentException e) {
                        e.printStackTrace();
                    }
                    /*message = peerHandler.obtainMessage();
                    message.what = DISABLE_VIDEO;
                    message.sendToTarget();
                    Toast.makeText(this, "切换到语音", Toast.LENGTH_SHORT).show();*/
                }
                break;
            case R.id.btnFree: // 打开关闭扬声器
                isSpeakerOpen = !isSpeakerOpen;
                btnFree.setBackgroundResource(
                        isSpeakerOpen ? R.drawable.mt_press_true : R.drawable.mt_press_false);
                if (isSpeakerOpen) {
                    OpenSpeaker();
                } else {
                    CloseSpeaker();
                }
                break;
            case R.id.btnExchange: // 本地、远端视频切换
                if (localStream != null) {
                    if (isExchange) {
                        localViewContainer.removeView(localStreamRenderer);  // 移除本地视频流到容器
                        remoteViewContainer.removeView(remoteStreamRenderer);// 移除远程视频流到容器
                        localViewContainer.addView(remoteStreamRenderer);  // 添加远程视频流到容器
                        remoteViewContainer.addView(localStreamRenderer);  // 添加本地视频流到容器
                    } else {
                        localViewContainer.removeView(remoteStreamRenderer);  // 移除本地视频流到容器
                        Log.e(TAG, "localViewContainer.getParent()=" + localViewContainer.getParent());
                        remoteViewContainer.removeView(localStreamRenderer);// 移除远程视频流到容器
                        localViewContainer.addView(localStreamRenderer);  // 添加远程视频流到容器
                        remoteViewContainer.addView(remoteStreamRenderer);  // 添加本地视频流到容器
                    }
                    isExchange = !isExchange;
                }
                break;
            case R.id.tvUnlock:
                tvUnlock.setText(R.string.unlocking);
                tvUnlock.setEnabled(false);
                command = 1;
                unLock();
                break;
            case R.id.ivMute: // 切换成仅语音通话
                if (!isIvMuteBtnIconSwitched) {
                    if (isStopRing) {
                        ivMute.setImageResource(R.drawable.btn_jingyin_highlight);
                        stopAlarm();
                        ToastUtil.show(getString(R.string.turn_on_mute));
                    } else {
                        ivMute.setImageResource(R.drawable.btn_jingyin_normal);
                        startAlarm();
                        ToastUtil.show(getString(R.string.turn_off_mute));
                    }
                    isStopRing = !isStopRing;
                } else {
                    if (!isSwitchedToAudioMode) {
                        ToastUtil.show(getString(R.string.turn_on_audio));
                        if (localStream != null) {
                            try {
                                localStream.detach(localStreamRenderer);
                                localStream.enableAudio();
                                localStream.getMediaStream().videoTracks.get(0).setEnabled(false);
                                localStreamRenderer.cleanFrame();
                            } catch (WoogeenIllegalArgumentException e) {
                                e.printStackTrace();
                            }
                        }
                        message = peerHandler.obtainMessage();
                        message.what = DISABLE_VIDEO;
                        message.sendToTarget();
                        if (remoteStream != null) { // 关闭远端视频
                            remoteStream.disableVideo();
                        }
                        ivVideo.setVisibility(View.GONE);
                        localStreamRenderer.setVisibility(View.GONE);
                        isSwitchedToAudioMode = true;
                        blurView.setVisibility(View.VISIBLE);

                        if (images != null && images.size() > 0) {
                            Bitmap blurBitmap = BlurBitmapUtil.blurBitmap(mContext, images.get(0), 20);
                            blurView.setImageBitmap(blurBitmap);
                        } else {
                            blurView.setImageResource(R.drawable.img_mohu);
                        }
                    } else { // 扬声器开启、关闭
                        isSpeakerOpen = !isSpeakerOpen;
                        if (isSpeakerOpen) {
                            ivMute.setImageResource(R.drawable.btn_tingtongjieting_normal); // 图标置绿
                            OpenSpeaker();
                            ToastUtil.show(getString(R.string.turn_on_speaker));
                        } else {
                            ivMute.setImageResource(R.drawable.btn_tingtongjieting_highlight); // 图标置黑
                            CloseSpeaker();
                            ToastUtil.show(getString(R.string.turn_off_speaker));
                        }
                    }
                }
                break;
        }
    }

    /**
     * 主动挂断
     */
    private void toEndCall() {
        stopAlarm();
        VibratorManager.stopViberate();
        command = 2;
        unLock();
        if (isCalling) {
            cutVideo();
        } else {
            // case1:未接听主动挂断
            addToCallRecord();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        isLaunch = true;
        if (!ParseUtil.isServiceWorked(MyApplication.getContext(), "com.anloq.nfcservice.EmqttService")) {
            startService(new Intent(MyApplication.getContext(), EmqttService.class));
        }
        //注册广播
        registerReceiver(mHomeKeyEventReceiver, new IntentFilter(
                Intent.ACTION_CLOSE_SYSTEM_DIALOGS));
        ringerModeListening();
        isVisiblity = true;
        // 电源键监听
        final IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mBatInfoReceiver, filter);
        /*if (localStream != null) {
            localStream.enableVideo();
            localStream.enableAudio();
            Toast.makeText(this, "欢迎回来", Toast.LENGTH_SHORT).show();
        }*/
        // 如果通话中点到其他地方回来后停止震动和响铃！！！
        Log.e(TAG, "isCalling===" + isCalling);
        if (isCalling) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    stopViberate();
                    stopAlarm();
                }
            }, 500);
        }
        // 页面初始化完成通知开始发送呼叫照片
        EventBus.getDefault().post(new EventBusMsg("start_send_photo", ""));
    }

    private final BroadcastReceiver mBatInfoReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(final Context context, final Intent intent) {
            final String action = intent.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                Log.e("TAG", "电源键监听");
                stopAlarm();
                stopViberate();
            }
        }
    };

    /**
     * 添加到通话记录中
     */
    private void addToCallRecord() {
        CallRecordBean callRecord = new CallRecordBean();
        callRecord.setEqtName(eqt_name);
        callRecord.setCurrentTime(TimeUtil.getCurrentCallTimeFormat());
        long temp = endCallTime - startCallTime;
        if (!isCalling) {
            // 如果没通话挂断时通话时间为0
            callRecord.setCallTime("");
        } else {
            if (temp == 0) {
                callRecord.setCallTime("");
            } else {
                callRecord.setCallTime("" + DateFormat.format("mm:ss", temp));
            }
        }
        EventBus.getDefault().post(callRecord);
        MessageProvider.getInstance().saveCallRecord(callRecord);
        isLaunch = false;
        isHome = false;//判断是否按了home键
        finish();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(byte[] decode) {
        Log.e(TAG, "onEventMainThread收到了Image消息");
        try {
            Bitmap webpBitmap = WebPFactory.nativeDecodeByteArray(decode, null);
            if (webpBitmap != null) {
                images.add(webpBitmap);
                callerPhoto.setVisibility(View.VISIBLE);
                callerPhoto.setImageBitmap(webpBitmap);
                if (!tvUnlock.isEnabled()) {
                    tvUnlock.setEnabled(true);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onMessageEvent(EventBusMsg msg) {
        String type = msg.getType();
        Logger.t(TAG).i("onEventMainThread收到了消息type===" + type);
        switch (type) {
            case "receivedendcall":
                stopAlarm();
                stopViberate();
                isPressHome = false;
                if (isCalling) {
                    cutVideo();
                } else {
                    // case2:没接通时被动挂断
                    addToCallRecord();
                }
                break;
            case "net_error": // 收到网络错误
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ToastUtil.show(getString(R.string.net_disconnect));
                    }
                });
                toEndCall(); // 挂断
                break;
            case "net_nice": // 收到网络可用
                break;
            case "unlockresult":
                handler.removeMessages(0);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!tvUnlock.isEnabled()) {
                            tvUnlock.setEnabled(true);
                            tvUnlock.setText(R.string.unlock_text);
                        }
                    }
                });
                break;
        }
    }

    /**
     * 播放系统声音
     */
    private void startAlarm() {
        if (mMediaPlayer == null) {//有的手机铃声会创建失败，如果创建失败，播放我们自己的铃声
            SoundPoolUtils.playCallWaitingAudio();//自己定义的铃音播放工具类。具体实现见下方
        } else {
            mMediaPlayer.setLooping(true);// 设置循环
            try {
                mMediaPlayer.prepare();
            } catch (Exception e) {
                e.printStackTrace();
            }
            mMediaPlayer.start();
        }
    }

    /**
     * 停止播放来电声音
     */
    private void stopAlarm() {
        if (mMediaPlayer != null) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.stop();
                mMediaPlayer.release();
                mMediaPlayer = null;
            }
        }
        SoundPoolUtils.stopCallWaitingAudio();
    }

    private void onClickKeyStar() {
        message = peerHandler.obtainMessage();
        LocalCameraStreamParameters.CameraType[] cameraType
                = LocalCameraStreamParameters.getCameraList();
        int cameraNum = cameraType.length;
        if (cameraNum == 0) {
            ToastUtil.show("你的手机没有相机");
            return;
        }
        String cameraLists[] = new String[cameraNum];
        cameraID = -1;
        for (int i = 0; i < cameraNum; i++) {
            if (cameraType[i] == LocalCameraStreamParameters.CameraType.BACK) {
                cameraLists[i] = "Back";
            } else if (cameraType[i] == LocalCameraStreamParameters.CameraType.FRONT) {
                cameraLists[i] = "Front";
                cameraID = i;
            } else if (cameraType[i] == LocalCameraStreamParameters.CameraType.UNKNOWN) {
                cameraLists[i] = "Unknown";
            }
        }
        if (cameraID >= 0) {
            message.what = PUBLISH;
            message.sendToTarget();
        }
    }

    /**
     * 直接开锁
     */
    private void unLock() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String account = SpUtil.getInstance().getString("account", "");
        String eqt_id = SpUtil.getInstance().getString("eqt_id", "");
        String unit_id = SpUtil.getInstance().getString("unit_id", "");

        String url = Constants.UNLOCKINCALLING + uid + Constants.TOKEN + token;
        Log.e(TAG, "UNLOCKINCALLING_url===" + url);

        HashMap<String, Object> map = new HashMap<>();
        map.put("eqt_id", eqt_id);
        map.put("unit_id", unit_id);
        map.put("command", command);
        map.put("phone", account);
        Log.e(TAG, "content===" + map.toString());

        OkHttpUtils
                .postString()
                .url(url)
                .content(new Gson().toJson(map))
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        if (command == 1) {
                            tvUnlock.setEnabled(true);
                            tvUnlock.setText(R.string.unlock_text);
                            ToastUtil.show(getString(R.string.open_door_fail));
                        }
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseResult(response);
                    }
                });
    }

    private void parseResult(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            Logger.t(TAG).i("开锁||挂断命令发送成功");
            handler.sendEmptyMessageDelayed(0, 10000);
        }
    }

    /**
     * 设置手机静音
     */
    private void isMute(boolean isMuteOpen) {
        if (isMuteOpen) {
            int volume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            SpUtil.getInstance().save("last_media_volume", volume);
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
        } else {
            int i = SpUtil.getInstance().getInt("last_media_volume", 0);
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, i, 0);
        }
    }

    /**
     * 打开扬声器
     */
    public void OpenSpeaker() {
        try {
            audioManager.setMode(AudioManager.ROUTE_SPEAKER);
            // 获取当前通话音量
            currVolume = audioManager.getStreamVolume(AudioManager.STREAM_VOICE_CALL);
            if (!audioManager.isSpeakerphoneOn()) {
                audioManager.setSpeakerphoneOn(true);
                audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                        audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL),
                        AudioManager.STREAM_VOICE_CALL);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 关闭扬声器
     */
    public void CloseSpeaker() {
        try {
            if (audioManager != null) {
                if (audioManager.isSpeakerphoneOn()) {
                    audioManager.setSpeakerphoneOn(false);
                    audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, currVolume,
                            AudioManager.STREAM_VOICE_CALL);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 切断视频连接
     */
    private void cutVideo() {
        // 1.先切断流
        message = peerHandler.obtainMessage();
        message.what = UNPUBLISH;
        message.sendToTarget();
        // 2.挂断(视频、语音)通话
        message = peerHandler.obtainMessage();
        message.what = STOP;
        message.sendToTarget();
    }

    /**
     * 初始化视频流视图
     */
    private void initVideoStreamsViews() throws WoogeenException {
        rootEglBase = EglBase.create();
        ClientContext.setApplicationContext(this);
        //@ClientContext.setVideoHardwareAccelerationOptions(rootEglBase.getEglBaseContext());
        ClientContext.setVideoHardwareAccelerationOptions(rootEglBase.getEglBaseContext(), rootEglBase.getEglBaseContext());
        localStreamRenderer = new WoogeenSurfaceRenderer(this);
        SurfaceHolder holder = localStreamRenderer.getHolder();
        localStreamRenderer.setZOrderOnTop(true); // 设置小视频浮在大视频上面
        holder.setFormat(PixelFormat.TRANSPARENT); // 设置小视频背景透明
        remoteStreamRenderer = new WoogeenSurfaceRenderer(this);
        localViewContainer.addView(localStreamRenderer);  // 添加本地视频流到容器
        remoteViewContainer.addView(remoteStreamRenderer);// 添加远程视频流到容器
        localStreamRenderer.init(rootEglBase.getEglBaseContext(), null);
        remoteStreamRenderer.init(rootEglBase.getEglBaseContext(), null);
        localStreamRenderer.setMirror(mirror);
//@
//        localStreamRender_Sink = new SurfaceViewRenderer(this);
//        localStreamRender_Sink.setZOrderOnTop(true);
//        //@localViewContainer.addView(localStreamRender_Sink);
//        localStreamRender_Sink.init(rootEglBase.getEglBaseContext(), null);
//        localStreamRender_Sink.setMirror(mirror);
//@
    }

    /**
     * 初始化点对点客户端
     */
    private void initPeerClient() {
        try {
            List<PeerConnection.IceServer> iceServers = new ArrayList<PeerConnection.IceServer>();
            String loginjson = SpUtil.getInstance().getString("loginjson", "");
            if (!TextUtils.isEmpty(loginjson)) {
                LoginBean loginBean = new Gson().fromJson(loginjson, LoginBean.class);
                List<String> ice_servers = loginBean.getObject().getIce_servers();
                if (ice_servers != null && ice_servers.size() > 0) {
                    Log.e(TAG, "ice_servers.size()===" + ice_servers.size());
                    for (int i = 0; i < ice_servers.size(); i++) {
                        String url = ice_servers.get(i);
                        if (url.startsWith("stun")) {
                            iceServers.add(new PeerConnection.IceServer(url));
                        } else if (url.startsWith("turn")) {
                            iceServers.add(new PeerConnection.IceServer(url, "xuejp", "xuejipeng911"));
                        }
                    }
                }

                PeerClientConfiguration config = new PeerClientConfiguration();
                config.setIceServers(iceServers);
                config.setVideoCodec(MediaCodec.VideoCodec.VP8); // 设置VP8视频编码
                String socket_cluster = SpUtil.getInstance().getString("socket_cluster", "");
                Log.e(TAG, "socket_cluster===" + socket_cluster);
                peerClient = new PeerClient(config, new SocketSignalingChannel(socket_cluster), userId, device);
                peerClient.addObserver(observer);
                peerThread = new HandlerThread("PeerThread");
                peerThread.start();
                peerHandler = new PeerHandler(peerThread.getLooper());
            }

        } catch (WoogeenException e1) {
            e1.printStackTrace();
        }
    }

    /**
     * 点对点客户端观察者对象，例如当收到音频、视频邀请等时回调
     */
    PeerClient.PeerClientObserver observer = new PeerClient.PeerClientObserver() {

        /**
         * 当收到邀请时的回调
         */
        @Override
        public void onInvited(final String peerId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    destId = peerId;
                    final AlertDialog.Builder builder = new AlertDialog.Builder(WebRtcActivity.this);
                    builder.setTitle("视频呼叫");
                    builder.setMessage("来自" + peerId + "单元门禁的视频呼叫");
                    builder.setPositiveButton("接受",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    peerClient.accept(destId,
                                            new ActionCallback<Void>() {
                                                @Override
                                                public void onSuccess(Void result) {
                                                    runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {

                                                        }
                                                    });
                                                }

                                                @Override
                                                public void onFailure(
                                                        WoogeenException e) {
                                                    Log.e(TAG, e.getMessage());
                                                }
                                            });
                                }
                            });
                    builder.setNeutralButton("拒绝",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    peerClient.deny(destId,
                                            new ActionCallback<Void>() {

                                                @Override
                                                public void onSuccess(Void result) {
                                                    Log.e(TAG, "拒绝了来自" + destId + "的邀请");
                                                }

                                                @Override
                                                public void onFailure(WoogeenException e) {
                                                    Log.e(TAG, e.getMessage());
                                                }
                                            });
                                }
                            });
                    builder.create().show();
                }
            });
        }

        /**
         * 当接受邀请时的回调
         */
        @Override
        public void onAccepted(final String peerId) {
            if (!isAccepted) {
                isInCallState = true;
                Log.e(TAG, "接受了来自" + peerId + "的邀请");
                runOnUiThread(new Runnable() {
                    public void run() {
                        SwitchView();
                    }
                });
                isAccepted = true;
            }
        }

        /**
         * 当拒绝邀请时的回调
         */
        @Override
        public void onDenied(final String peerId) {
            isInCallState = false;
            Log.e(TAG, "收到来自peerId===" + peerId + "的拒绝");
            runOnUiThread(new Runnable() {
                public void run() {
                    SwitchView();
                }
            });
        }

        /**
         * 当流被添加时的回调
         * @param stream
         */
        @Override
        public void onStreamAdded(final RemoteStream stream) {
            Log.e(TAG, "添加了一个来自ID=" + stream.getRemoteUserId() + "的远程流");
            remoteStream = stream;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        stream.attach(remoteStreamRenderer);
                        isExchange = true;
                        isCalling = true;
                    } catch (WoogeenException e) {
                        Log.e(TAG, e.getMessage());
                    }
                }
            });
        }

        /**
         * 当收到数据时的回调
         */
        @Override
        public void onDataReceived(final String peerId, final String msg) {
            runOnUiThread(new Runnable() {
                public void run() {
                }
            });
        }

        /**
         * 当流被移除时的回调
         */
        @Override
        public void onStreamRemoved(final RemoteStream stream) {
            Log.e(TAG, "视频流已被移除...");
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        remoteStreamRenderer.cleanFrame();
                        stream.detach(remoteStreamRenderer);
                    } catch (WoogeenIllegalArgumentException e) {
                        e.printStackTrace();
                    }
                }
            });

            if (localStream != null) {
                try {
                    localStream.attach(localStreamRenderer);//@
                    //@localStream.attach_local(localStreamRenderer, localStreamRender_Sink);
                } catch (WoogeenIllegalArgumentException e) {
                    e.printStackTrace();
                    localStream.close();
                    localStream = null;
                    localStreamRenderer.cleanFrame();
                }
            }

            remoteStreamRenderer.cleanFrame();
            remoteStreamRenderer.destroyDrawingCache();
            if (statsTimer != null) {
                statsTimer.cancel();
            }
        }

        @Override
        public void onDisableVideo(String var1) {
            remoteStreamRenderer.cleanFrame();
        }

        /**
         * 当聊天被停止时的回调
         */
        @Override
        public void onChatStopped(final String peerId) {
            endCallTime = System.currentTimeMillis();
            isInCallState = false;
            Log.e(TAG, "onChatStop:" + peerId);
            runOnUiThread(new Runnable() {
                public void run() {
                    SwitchView();
                }
            });
            if (localStream != null) {
                localStream.close();
                localStream = null;
            }
            remoteStreamRenderer.cleanFrame();
            localStreamRenderer.cleanFrame();
            if (statsTimer != null) {
                statsTimer.cancel();
            }
            // case3:接通时主动或被动挂断
            addToCallRecord();
        }

        /**
         * 当开始聊天时的回调
         */
        @Override
        public void onChatStarted(final String peerId) {
            startCallTime = System.currentTimeMillis();
            isInCallState = true;
            Log.e(TAG, "onChatStart:" + peerId);
            runOnUiThread(new Runnable() {
                public void run() {
                    if (mProgressLoading != null) {
                        mProgressLoading.dismiss();
                    }
                    ivVideo.setVisibility(View.VISIBLE);//设置显示
                    ivMute.setImageResource(R.drawable.btn_tingtongjieting_normal);
                    ivAccept.setImageResource(R.drawable.btn_huatongjingyin_normal);
                    isIvMuteBtnIconSwitched = true;
                    isIvAcceptBtnIconSwitched = true;
                    SwitchView();
                    callerPhoto.setVisibility(View.GONE);
                    message = peerHandler.obtainMessage();
                    message.what = PUBLISHAUDIO;
                    message.sendToTarget();
                    llCallTime.setVisibility(View.VISIBLE);
                    countDownView.start(120000);
                }
            });
        }

        /**
         * 当服务断开时的回调
         */
        @Override
        public void onServerDisconnected() {
            isInCallState = false;
            runOnUiThread(new Runnable() {
                public void run() {
                    remoteStreamRenderer.cleanFrame();
                    localStreamRenderer.cleanFrame();
                    SwitchView();
                    Log.e(TAG, "Rtc Server Disconnect...");
                }
            });
        }
    };

    class PeerHandler extends Handler {
        public PeerHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case LOGIN: // 登录
                    JSONObject loginObject = new JSONObject();
                    try {
                        String socket_cluster = SpUtil.getInstance().getString("socket_cluster", "");
                        Log.e(TAG, "socket_cluster===" + socket_cluster);
                        loginObject.put("host", socket_cluster);
                        loginObject.put("id", new Gson().toJson(userId));
                        loginObject.put("device", new Gson().toJson(device));
                        loginObject.put("sdk", new Gson().toJson(sdk));
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }

                    peerClient.connect(loginObject.toString(),
                            new ActionCallback<String>() {
                                @Override
                                public void onSuccess(String result) {
                                    Log.e(TAG, "登录成功");
                                    message = peerHandler.obtainMessage();
                                    message.what = isInCallState ? STOP : INVITE;
                                    message.sendToTarget();
                                }

                                @Override
                                public void onFailure(WoogeenException e) {
                                    Log.e(TAG, "连接服务器失败" + e.getMessage());
                                    // 连接服务器失败PeerClient is connected or connecting to a signaling server.
                                    if (rtcLoginCount < 10) {
                                        rtcLoginCount++;
                                        message = peerHandler.obtainMessage();
                                        message.what = LOGIN;
                                        peerHandler.sendMessageDelayed(message, 1000);
                                    }
                                }
                            });
                    break;
                case LOGOUT: // 退出登录
                    if (peerClient != null) {
                        peerClient.disconnect(new ActionCallback<Void>() {
                            @Override
                            public void onSuccess(Void result) {
                                if (localStream != null) {
                                    localStream.close();
                                    localStream = null;
                                }
                                if (localStreamRenderer != null) {
                                    localStreamRenderer.cleanFrame();
                                    localStreamRenderer.resetStatistics();
                                    localStreamRenderer.release();
                                    localStreamRenderer = null;
                                }
                            }

                            @Override
                            public void onFailure(WoogeenException e) {
                                Log.e(TAG, e.getMessage());
                            }
                        });
                    }
                    break;
                case INVITE: // 邀请
                    isAccepted = false;
                    ID calleeId = new ID("RESIDENT", destId, "123456789");
                    peerClient.invite(calleeId, new ActionCallback<Void>() {
                        @Override
                        public void onSuccess(Void result) {
                            Log.e(TAG, "RTC INVITE onSuccess()");
                        }

                        @Override
                        public void onFailure(WoogeenException e) {
                            Log.e(TAG, "RTC INVITE WoogeenException===" + e.toString());
                        }

                    });
                    break;
                case STOP: // 停止视频聊天
                    peerClient.stop(destId, new ActionCallback<Void>() {
                        @Override
                        public void onSuccess(Void result) {
                            if (localStream != null) {
                                localStream.close();
                                localStream = null;
                                localStreamRenderer.cleanFrame();
                            }
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    ToastUtil.show(getString(R.string.end_call));
                                }
                            });
                        }

                        @Override
                        public void onFailure(WoogeenException e) {
                            Log.e(TAG, e.getMessage());
                        }

                    });
                    break;
                case PUBLISHAUDIO:
//                    if (localStream == null) {
//                        LocalCameraStreamParameters msp;
//                        try {
//                            msp = new LocalCameraStreamParameters(false, true);
//                            msp.setResolution(640, 480);
//                            msp.setCameraId(cameraID);
//                            localStream = new LocalCameraStream(msp);
//                            //localStream.attach(localStreamRenderer);
//                        } catch (WoogeenException e1) {
//                            e1.printStackTrace();
//                            if (localStream != null) {
//                                localStream.close();
//                                localStream = null;
//                                localStreamRenderer.cleanFrame();
//                            }
//                        }
//                    }
//                    PublishOptions optionaudio = new PublishOptions();
//                    optionaudio.setMaximumVideoBandwidth(200);
//                    //Be careful when you set up the audio bandwidth, as difference audio codec requires different minimum bandwidth.
//                    //option.setMaximumAudioBandwidth(30);
//                    peerClient.publish(localStream, destId, optionaudio,
//                            new ActionCallback<Void>() {
//
//                                @Override
//                                public void onSuccess(Void result) {
//                                    publishPeerId = destId;
//                                    runOnUiThread(new Runnable() {
//                                        public void run() {
//                                        }
//                                    });
//
//                                    //This is a sample usage of get the statistic data for a specific stream, in this sample, localStream
//                                    //that has just been published. If you would like to get all the data for the peerconnection, including
//                                    //the data for the streams had been published before, please refer to the sample code in onChatStarted.
//                                    //ATTENTION: DO NOT use getConnectionStats(), getConnectionStats(localstream)and getAudioLevels() at the same time.
//                                    statsTimer = new Timer();
//                                    statsTimer.schedule(new TimerTask() {
//                                        @Override
//                                        public void run() {
//                                            peerClient.getConnectionStats(destId, localStream, new ActionCallback<ConnectionStats>() {
//                                                @Override
//                                                public void onSuccess(ConnectionStats result) {
//                                                    Log.e(TAG, "result:" + result.mediaTracksStatsList.size());
//                                                    Log.e(TAG, "connection stats: " + result.timeStamp
//                                                            + " available transmit bitrate: " + result.videoBandwidthStats.transmitBitrate
//                                                            + " retransmit bitrate: " + result.videoBandwidthStats.reTransmitBitrate);
//                                                }
//
//                                                @Override
//                                                public void onFailure(WoogeenException e) {
//                                                }
//                                            });
//                                        }
//                                    }, 0, 10000);
//                                }
//
//                                @Override
//                                public void onFailure(WoogeenException e) {
//                                    Log.e(TAG, e.getMessage());
//                                    if (localStream != null) {
//                                        localStream.close();
//                                        localStream = null;
//                                        localStreamRenderer.cleanFrame();
//                                    }
//                                }
//                            });
                    requestAudioPermission();
                    break;
                case PUBLISH: // 打开本地视频
                    Log.e("TAG", "cameraID===" + cameraID);
                    if (localStream != null) {
                        localStream.close();
                        localStream = null;
                    }
                    if (localStream == null) {
                        LocalCameraStreamParameters msp;
                        try {
                            msp = new LocalCameraStreamParameters(
                                    true, true);
                            msp.setResolution(640, 480);
                            msp.setCameraId(cameraID);
                            localStream = new LocalCameraStream(msp);
                            localStream.attach(localStreamRenderer);
                            //@localStream.attach_local(localStreamRenderer, localStreamRender_Sink);
                            //@localStream.attach(remoteStreamRenderer);
                        } catch (WoogeenException e1) {
                            e1.printStackTrace();
                            if (localStream != null) {
                                localStream.close();
                                localStream = null;
                                localStreamRenderer.cleanFrame();
                            }
                        }
                    }
                    PublishOptions option = new PublishOptions();
                    option.setMaximumVideoBandwidth(1000);
                    //Be careful when you set up the audio bandwidth, as difference audio codec requires different minimum bandwidth.
                    //option.setMaximumAudioBandwidth(30);
                    peerClient.publish(localStream, destId, option,
                            new ActionCallback<Void>() {
                                @Override
                                public void onSuccess(Void result) {
                                    publishPeerId = destId;
                                    runOnUiThread(new Runnable() {
                                        public void run() {
                                        }
                                    });
                                    //This is a sample usage of get the statistic data for a specific stream, in this sample, localStream
                                    //that has just been published. If you would like to get all the data for the peerconnection, including
                                    //the data for the streams had been published before, please refer to the sample code in onChatStarted.
                                    //ATTENTION: DO NOT use getConnectionStats(), getConnectionStats(localstream)and getAudioLevels() at the same time.
                                    statsTimer = new Timer();
                                    statsTimer.schedule(new TimerTask() {
                                        @Override
                                        public void run() {
                                            if (peerClient != null) {
                                                peerClient.getConnectionStats(destId, localStream, new ActionCallback<ConnectionStats>() {
                                                    @Override
                                                    public void onSuccess(ConnectionStats result) {
                                                        Log.e(TAG, "result:" + result.mediaTracksStatsList.size());
                                                        Log.e(TAG, "connection stats: " + result.timeStamp
                                                                + " available transmit bitrate: " + result.videoBandwidthStats.transmitBitrate
                                                                + " retransmit bitrate: " + result.videoBandwidthStats.reTransmitBitrate);
                                                    }

                                                    @Override
                                                    public void onFailure(WoogeenException e) {
                                                    }
                                                });
                                            }
                                        }
                                    }, 0, 10000);
                                }

                                @Override
                                public void onFailure(WoogeenException e) {
                                    Log.e(TAG, e.getMessage());
                                    if (localStream != null) {
                                        localStream.close();
                                        localStream = null;
                                        localStreamRenderer.cleanFrame();
                                    }
                                }
                            });
                    break;
                case UNPUBLISH: // 关闭本地视频
                    if (localStream != null) {
                        peerClient.unpublish(localStream, publishPeerId,
                                new ActionCallback<Void>() {
                                    @Override
                                    public void onSuccess(Void result) {
                                        try {
                                            localStream.detach(localStreamRenderer);
                                        } catch (WoogeenIllegalArgumentException err) {
                                            err.printStackTrace();
                                        }
                                        localStream.close();
                                        localStream = null;
                                        localStreamRenderer.cleanFrame();
                                        runOnUiThread(new Runnable() {
                                            public void run() {
                                            }
                                        });
                                    }

                                    @Override
                                    public void onFailure(WoogeenException e) {
                                        Log.e(TAG, e.getMessage());
                                    }
                                });
                    }
                    break;
                case SWITCH_CAMERA: // 切换相机
                    if (localStream == null) return;
                    localStream.switchCamera(new ActionCallback<Boolean>() {
                        @Override
                        public void onSuccess(final Boolean isFrontCamera) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    //switchCameraBtn.setEnabled(true);
                                    ToastUtil.show("切换到" + (isFrontCamera ? "前置" : "后置") + "镜头");
                                }
                            });
                            mirror = !mirror;
                            localStreamRenderer.setMirror(mirror);
                        }

                        @Override
                        public void onFailure(final WoogeenException e) {
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    //switchCameraBtn.setEnabled(true);
                                    ToastUtil.show("切换相机失败" + e.getLocalizedMessage());
                                }
                            });
                        }

                    });
                    break;
                case SEND_DATA: // 发送数据
                    msgString = "";
                    Log.e(TAG, "send data:" + msgString + " to " + destId);
                    peerClient.send(msgString, destId, new ActionCallback<Void>() {
                        @Override
                        public void onSuccess(Void result) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    ToastUtil.show("发送成功");
                                }
                            });
                        }

                        @Override
                        public void onFailure(final WoogeenException e) {
                            Log.e(TAG, e.getMessage());
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    ToastUtil.show(e.getMessage());
                                }
                            });
                        }
                    });
                    break;
                case DISABLE_VIDEO: // 发送数据
                    msgString = "0";
                    Log.e(TAG, "send data:" + msgString + " to " + destId);
                    peerClient.disableVideo(destId, new ActionCallback<Void>() {
                        @Override
                        public void onSuccess(Void var1) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    ToastUtil.show("发送成功");
                                }
                            });
                        }

                        @Override
                        public void onFailure(final WoogeenException var1) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    ToastUtil.show(var1.getMessage());
                                }
                            });
                            Log.e(TAG, var1.getMessage());
                        }
                    });
                    break;
            }
            super.handleMessage(msg);
        }
    }

    private void SwitchView() {
        int view;
        if (isInCallState) {
            view = VIEW_CALLING;
        } else {
            view = VIEW_STATUS;
        }
        if (viewLog) {
            view = VIEW_LOG;
        }
        viewNew = view;
        if (viewNew != output.getDisplayedChild()) {
            output.setDisplayedChild(viewNew);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e(TAG, "onPause()");
        if (!isPressHome) {
            SpUtil.getInstance().save("presshome", false);
        }
        SpUtil.getInstance().save("iscaller", false);
        stopAlarm();
        stopViberate();
        /*if (localStream != null) {
            if (localStream.hasVideo()) {
                localStream.disableVideo();
            }
            if (localStream.hasAudio()) {
                localStream.disableAudio();
            }
            Log.e(TAG, "Woogeen is running in the background.");
        }*/
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e(TAG, "onStop()");
        isVisiblity = false;
        iscalling = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Logger.t(TAG).e("onDestroy()");
        // 通知清理呼叫缓存图片 -> EmqttService
        EventBus.getDefault().post(new EventBusMsg("clearphoto", ""));
        unregisterReceiver(broadcastReceiver);
        unregisterReceiver(mBatInfoReceiver);
        unregisterReceiver(mHomeKeyEventReceiver);
        unregisterReceiver(mVideoStateReceive);
        EventBus.getDefault().unregister(this);
        mHandler.removeCallbacksAndMessages(null);
        if (localStream != null) {
            localStream.close();
        }
        releaseResource();
        MyApplication.getMessageQuene().clear();//清空消息队列
    }

    private void releaseResource() {
        SystemClock.sleep(200); // 等待挂断消息
        if (peerHandler != null) {
            Message message = peerHandler.obtainMessage();
            message.what = LOGOUT;
            peerHandler.sendMessage(message);
        }
        if (peerClient != null) {
            peerClient.removeObserver(observer);
            peerClient = null;
        }
        if (peerHandler != null) {
            peerHandler.removeCallbacksAndMessages(null);
            peerHandler = null;
        }
        if (peerThread != null) {
            peerThread.quitSafely();
            peerThread = null;
        }

        if (localStreamRenderer != null) {
            localStreamRenderer.cleanFrame();
            localStreamRenderer.resetStatistics();
            localStreamRenderer.release();
            localStreamRenderer = null;
        }

        if (remoteStreamRenderer != null) {
            remoteStreamRenderer.cleanFrame();
            remoteStreamRenderer.resetStatistics();
            remoteStreamRenderer.release();
            remoteStreamRenderer = null;
        }
    }

    private BroadcastReceiver mVideoStateReceive = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ("video_disconnect".equals(intent.getAction())) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (peerClient.getPeerState() == PeerClient.PeerClientState.CONNECTING) {
                            //对方中断
                            Log.e("video", "对方网络异常或已经断开！！！" + peerClient.getPeerState());
                        } else if (peerClient.getPeerState() == PeerClient.PeerClientState.CONNECTED) {
                            //自己中断
                            Log.e("video", "自己网络异常或已经断开！！！" + peerClient.getPeerState());
                        }
                    }
                });
            }
        }
    };

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return true;//不执行父类点击事件
        }
        return super.onKeyDown(keyCode, event);//继续执行父类其他点击事件
    }
}
