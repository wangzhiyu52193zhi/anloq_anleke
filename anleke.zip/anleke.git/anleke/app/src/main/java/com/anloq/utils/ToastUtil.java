package com.anloq.utils;

import android.content.Context;
import android.os.Handler;
import android.widget.Toast;

import com.anloq.MyApplication;

/**
 * Created by tianjh on 17/5/4.
 */
public class ToastUtil {

    public static void showToastInfo_Fail(final Context context, final String info) {
        Handler handler = new Handler(context.getMainLooper());
        handler.post(new Runnable() {
            public void run() {
                //TastyToast.makeText(context.getApplicationContext(), info, TastyToast.LENGTH_LONG, TastyToast.WARNING);
            }
        });
    }

    public static void showToastInfo_Success(final Context context, final String info) {
        Handler handler = new Handler(context.getMainLooper());
        handler.post(new Runnable() {
            public void run() {
                //TastyToast.makeText(context.getApplicationContext(), info, TastyToast.LENGTH_LONG, TastyToast.SUCCESS);
            }
        });
    }

    /**
     * 显示short Toast
     */
    public static void show(String text) {
        Toast.makeText(MyApplication.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    /**
     * 显示Long Toast
     */
    public static void showLong(String text) {
        Toast.makeText(MyApplication.getContext(), text, Toast.LENGTH_LONG).show();
    }
}
