package com.anloq.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.ProfileManager;
import com.anloq.model.ProfileBean;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

import static com.anloq.MyApplication.mContext;

// 免打扰设置页面
public class NoDisturbActivity extends Activity {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.rbOpen)
    RadioButton rbOpen;
    @BindView(R.id.rbInDark)
    RadioButton rbInDark;
    @BindView(R.id.rbClose)
    RadioButton rbClose;
    @BindView(R.id.rgDisturb)
    RadioGroup rgDisturb;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    private int currentState = 2; // 默认关闭免打扰

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_disturb);
        ButterKnife.bind(this);
        tvTitle.setText(R.string.activity_disturb_1);
        initListener();
        initToggle();
    }

    private void initToggle() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.GETPROFILE + uid + Constants.TOKEN + token;
        Logger.i("GETPROFILE_url===" + url);

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.e(e.toString());
                        setErrorSetting();
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.json(response);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        ProfileBean profileBean = new Gson().fromJson(json, ProfileBean.class);
        if (profileBean != null) {
            ProfileBean.ObjectBean object = profileBean.getObject();
            if (object != null) {
                int no_distrub = object.getNo_distrub();
                switch (no_distrub - 1) {
                    case 0:
                        rgDisturb.check(R.id.rbOpen); // 默认开启免打扰
                        break;
                    case 1:
                        rgDisturb.check(R.id.rbInDark); // 夜间开启免打扰
                        break;
                    case 2:
                        rgDisturb.check(R.id.rbClose); // 关闭免打扰
                        break;
                    default:
                        rgDisturb.check(R.id.rbClose);
                        break;
                }
            }
        }
    }

    private void setErrorSetting() {
        int disturb_state = SpUtil.getInstance().getInt(SpUtil.getDisturbStateKey(), currentState);
        switch (disturb_state - 1) {
            case 0:
                rgDisturb.check(R.id.rbOpen); // 默认开启免打扰
                break;
            case 1:
                rgDisturb.check(R.id.rbInDark); // 夜间开启免打扰
                break;
            case 2:
                rgDisturb.check(R.id.rbClose); // 关闭免打扰
                break;
        }
        currentState = disturb_state;
        // 保存当前的状态
        SpUtil.getInstance().save(SpUtil.getDisturbStateKey(), currentState);
    }

    private void initListener() {
        rgDisturb.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbOpen:
                        currentState = 0;
                        break;
                    case R.id.rbInDark:
                        currentState = 1;
                        break;
                    case R.id.rbClose:
                        currentState = 2;
                        break;
                }
                Log.e("TAG", "disturb_state===" + currentState);
                SpUtil.getInstance().save(SpUtil.getDisturbStateKey(), currentState + 1);
                loadSetting(currentState + 1);
            }
        });
    }

    /**
     * 上传用户设置
     */
    private void loadSetting(int index) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("no_distrub", index);
        ProfileManager.update(map, new ProfileManager.OnProfileUpdateListener() {
            @Override
            public void onUpdate(String result) {
                String code = RequestUtil.getCode(mContext, result);
                if ("200".equals(code)) {
                    Logger.i("免打扰设置成功！");
                }
            }
        });
    }

    @OnClick(R.id.ivBack)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
        }
    }
}
