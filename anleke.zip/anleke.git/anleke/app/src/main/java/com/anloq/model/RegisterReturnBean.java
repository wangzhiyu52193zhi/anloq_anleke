package com.anloq.model;

/**
 * Created by xpf on 2017/2/27:)
 * Function:注册完成后服务的返回数据时的Bean类
 */

public class RegisterReturnBean {

    /**
     * name : token
     * object : {"uid":1,"token":"CigIUAoGPDIACloFKAoIAFoBHlADMh4EUDwJCigEABQJFCgERkYFAAAAAAE="}
     * code : 200
     */

    private String name;
    private ObjectBean object;
    private int code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public static class ObjectBean {
        /**
         * uid : 1
         * token : CigIUAoGPDIACloFKAoIAFoBHlADMh4EUDwJCigEABQJFCgERkYFAAAAAAE=
         */

        private int uid;
        private String token;

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }
    }

}
