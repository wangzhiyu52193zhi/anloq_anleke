package com.anloq.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.anloq.adapter.VkeyPkgAdapter;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.model.VKeysPkgBean;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

// 我的钥匙包
public class KeyPkgActivity extends Activity {

    private static final String TAG = KeyPkgActivity.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.listView)
    ListView listView;
    @BindView(R.id.tvNoData)
    TextView tvNoData;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    private Context mContext;
    private VkeyPkgAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_key_bag);
        ButterKnife.bind(this);
        mContext = this;
        tvTitle.setText(R.string.my_vkey_package);
        getKeyBagData();
    }

    /**
     * 获取钥匙包数据
     */
    private void getKeyBagData() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.KEYPACKAGE + uid + Constants.TOKEN + token;// + Constants.STARTTIME + lasttime;
        Log.e(TAG, "KEYPACKAGE_url===" + url);

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        String vkeyjson = SpUtil.getInstance().getString("vkeyjson", "");
                        if (!"".equals(vkeyjson)) {
                            parseJson(vkeyjson);
                        }
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "KEYPACKAGE_Result===" + response);
                        keysIsChange(response);
                    }
                });
    }

    private void keysIsChange(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            parseJson(json);
        }
    }

    private void parseJson(String json) {
        VKeysPkgBean vKeysPkgBean = new Gson().fromJson(json, VKeysPkgBean.class);
        if (vKeysPkgBean != null) {
            List<List<VKeysPkgBean.ObjectBean>> zoneVkeyList = vKeysPkgBean.getObject();
            List<VKeysPkgBean.ObjectBean> vkeyList = new ArrayList<>();
            if (zoneVkeyList != null && zoneVkeyList.size() > 0) {
                tvNoData.setVisibility(View.GONE);
                for (int i = 0; i < zoneVkeyList.size(); i++) {
                    List<VKeysPkgBean.ObjectBean> vkeyPkg = zoneVkeyList.get(i);
                    vkeyList.addAll(vkeyPkg);
                }
                adapter = new VkeyPkgAdapter(mContext, vkeyList);
                listView.setAdapter(adapter);
            } else {
                tvNoData.setVisibility(View.VISIBLE);
            }
        }
    }

    @OnClick({R.id.ivBack, R.id.tvNoData})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.tvNoData:
                getKeyBagData();
                break;
        }
    }
}
