package com.anloq.model;

/**
 * Created by xpf on 2017/8/16 :)
 * Function:拉取呼叫照片返回结果的Bean
 */

public class ImageResultBean {

    /**
     * name : get call image
     * object : {"img_buf":"UklGRioaAABXRUJQVlA4IB4"}
     */

    private String name;
    private ObjectBean object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * img_buf : UklGRioaAABXRUJQVlA4IB4
         */

        private String img_buf;

        public String getImg_buf() {
            return img_buf;
        }

        public void setImg_buf(String img_buf) {
            this.img_buf = img_buf;
        }
    }
}
