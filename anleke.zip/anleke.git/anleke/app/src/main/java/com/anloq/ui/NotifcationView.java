package com.anloq.ui;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

import com.anloq.MyApplication;
import com.anloq.activity.MainActivity;
import com.anloq.activity.MessageNoticeDetail;
import com.anloq.activity.NormalAuthActivity;
import com.anloq.anleke.R;
import com.anloq.manager.FeatureManager;
import com.anloq.model.RequestKeyBean;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;

/**
 * Created by xpf on 2017/5/11 :)
 * Function:通知栏显示视图
 */

public class NotifcationView {

    private static int i = 1;
    public static NotificationManager manager;

    public static void show(String title, String content) {
        if (MainActivity.isVisible) {
            return;
        }
        manager = (NotificationManager) MyApplication.getContext()
                .getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder mBuilder = new NotificationCompat
                .Builder(MyApplication.getContext());
        mBuilder.setContentTitle(title)//设置通知栏标题
                .setContentText("点击查看详情") //设置通知栏显示内容
                .setContentIntent(getDefalutIntent(title, content)) //设置通知栏点击意图
                .setNumber(i++) //设置通知集合的数量
                .setTicker("消息通知来啦") //通知首次出现在通知栏，带上升动画效果的
                .setWhen(System.currentTimeMillis())//通知产生的时间，会在通知信息里显示，一般是系统获取到的时间
                .setPriority(Notification.PRIORITY_DEFAULT) //设置该通知优先级
                .setAutoCancel(true)//设置这个标志当用户单击面板就可以让通知将自动取消
                .setOngoing(false)//ture，设置他为一个正在进行的通知。他们通常是用来表示一个后台任务,用户积极参与(如播放音乐)或以某种方式正在等待,因此占用设备(如一个文件下载,同步操作,主动网络连接)
                //.setDefaults(Notification.DEFAULT_ALL)//向通知添加声音、闪灯和振动效果的最简单、最一致的方式是使用当前的用户默认设置，使用defaults属性，可以组合
                //Notification.DEFAULT_ALL  Notification.DEFAULT_SOUND 添加声音 // requires VIBRATE permission
                .setSmallIcon(R.drawable.logo);//设置通知小ICON

        boolean messagesounds = SpUtil.getInstance().getBoolean("messagesounds", true);
        boolean messagevibrate = SpUtil.getInstance().getBoolean("messagevibrate", true);
        if (messagesounds && messagevibrate) {
            mBuilder.setDefaults(Notification.DEFAULT_ALL);
        } else {
            if (!messagesounds && !messagevibrate) {

            } else {
                if (messagesounds) {
                    mBuilder.setDefaults(Notification.DEFAULT_SOUND);
                } else {
                    mBuilder.setDefaults(Notification.DEFAULT_VIBRATE);
                }
            }
        }

        manager.notify(i++, mBuilder.build());
        FeatureManager.wakeUpAndUnlock();
    }

    /**
     * 取消所有通知栏显示
     */
    public static void cancelNotice() {
        if (manager != null)
            manager.cancelAll();
    }

    public static PendingIntent getDefalutIntent(String title, String content) {
        Intent intent = new Intent(MyApplication.getContext(), MessageNoticeDetail.class);
        if (content.startsWith("http")) {
            intent.putExtra("type", "url");
            intent.putExtra("url", content);

        } else if (content.startsWith("{\"name\":\"rqkeymsg\"")) {
            intent = startToNormalActivity(content);

        } else {
            intent.putExtra("type", "text");
            intent.putExtra("title", title);
            intent.putExtra("content", content);
        }
        return PendingIntent.getActivity(MyApplication.getContext(), 1,
                intent, PendingIntent.FLAG_CANCEL_CURRENT);
    }

    /**
     * 跳转到授权页面
     *
     * @param json
     */
    private static Intent startToNormalActivity(String json) {
        RequestKeyBean requestKeyBean = new Gson().fromJson(json, RequestKeyBean.class);
        RequestKeyBean.ObjectBean objectBean = requestKeyBean.getObject();
        Intent intent = new Intent(MyApplication.getContext(), NormalAuthActivity.class);
        intent.putExtra("user_phone", objectBean.getUser_phone());
        intent.putExtra("user_name", objectBean.getUser_name());
        intent.putExtra("start_time", objectBean.getKey_start_date());
        intent.putExtra("end_time", objectBean.getKey_end_date());
        intent.putExtra("ship", objectBean.getUser_type());
        intent.putExtra("zoneid", objectBean.getZone_id());
        intent.putExtra("zonename", objectBean.getZone_name());
        intent.putExtra("buildingid", objectBean.getBuilding_id());
        intent.putExtra("buildingname", objectBean.getBuilding_name());
        intent.putExtra("unitid", objectBean.getUnit_id());
        intent.putExtra("unitname", objectBean.getUnit_name());
        intent.putExtra("roomid", objectBean.getRoom_id());
        intent.putExtra("roomname", objectBean.getRoom_name());
        intent.putExtra("user_id", objectBean.getUser_id());
        intent.putExtra("resident_id", objectBean.getResident_id());
        intent.putExtra("master_resident_id", objectBean.getMaster_resident_id());
        SpUtil.getInstance().save("isrequestauth", true);
        return intent;
    }
}
