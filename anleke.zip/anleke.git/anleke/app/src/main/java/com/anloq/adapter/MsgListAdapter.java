package com.anloq.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.anloq.activity.HelpActivity;
import com.anloq.activity.MessageNoticeDetail;
import com.anloq.activity.NormalAuthActivity;
import com.anloq.anleke.R;
import com.anloq.model.GuideMessageBean;
import com.anloq.model.KeyPassMsgBean;
import com.anloq.model.MessageBean;
import com.anloq.model.NoticeMsgBean;
import com.anloq.model.RequestKeyBean;
import com.anloq.model.ServiceMsgBean;
import com.anloq.utils.MessageProvider;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/4/14 :)
 * Function:消息、通知列表的适配器
 */

public class MsgListAdapter extends BaseAdapter {

    private Context mContext;
    private List<MessageBean> mMsgList;

    public MsgListAdapter(Context mContext, List<MessageBean> mMsgList) {
        this.mContext = mContext;
        this.mMsgList = mMsgList;
    }

    @Override
    public int getCount() {
        return mMsgList.size();
    }

    @Override
    public Object getItem(int position) {
        return mMsgList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_message, null);
            ButterKnife.bind(convertView);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        MessageBean msgBean = mMsgList.get(position);
        String type = msgBean.getType();
        String content = msgBean.getContent();
        boolean read = msgBean.isRead();

        switch (type) {
            case "servicemsg":
                ServiceMsgBean serviceMsgBean = new Gson().fromJson(content, ServiceMsgBean.class);
                loadServiceMsg(msgBean, holder, serviceMsgBean, position, read);
                break;
            case "rqkeymsg":
                RequestKeyBean requestKeyBean = new Gson().fromJson(content, RequestKeyBean.class);
                loadRequestKey(msgBean, holder, requestKeyBean, position, read);
                break;
            case "noticemsg":
                NoticeMsgBean noticeMsgBean = new Gson().fromJson(content, NoticeMsgBean.class);
                loadNoticeMsg(msgBean, holder, noticeMsgBean, position, read);
                break;
            case "keypassmsg":
                KeyPassMsgBean keyPassMsgBean = new Gson().fromJson(content, KeyPassMsgBean.class);
                loadKeyPassMsg(msgBean, holder, keyPassMsgBean, position, read);
                break;
            case "guidemsg":
                GuideMessageBean guideMessageBean = new Gson().fromJson(content, GuideMessageBean.class);
                loadGuideMsg(msgBean, holder, guideMessageBean, position, read);
                break;
        }
        return convertView;
    }

    private void loadGuideMsg(final MessageBean msgBean, final ViewHolder holder, GuideMessageBean guideMessageBean, final int position, final boolean read) {
        GuideMessageBean.ObjectBean object = guideMessageBean.getObject();
        final String title = object.getTitle();
        final String content = object.getContent();

        holder.ivJinJi.setVisibility(View.GONE);
        holder.ivZhiDing.setVisibility(View.GONE);
        holder.ivShouquan.setVisibility(View.GONE);
        holder.ivWuye.setVisibility(View.GONE);
        holder.ivXitong.setVisibility(View.VISIBLE);
        holder.tvTitle.setText(title);
        holder.tvContent.setText(content);
        if (read) {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
        } else {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
        }
        holder.tvDate.setText(guideMessageBean.getTime());
        holder.llMessageItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!read) { // 如果是未读就去设置为已读
                    msgBean.setRead(true);
                    setReadState(position, holder);
                }
                mContext.startActivity(new Intent(mContext, HelpActivity.class));
            }
        });
    }

    /**
     * 装载服务消息(例如申请被驳回的消息)
     */
    private void loadServiceMsg(final MessageBean msgBean, final ViewHolder holder, ServiceMsgBean serviceMsgBean, final int position, final boolean read) {
        ServiceMsgBean.ObjectBean object = serviceMsgBean.getObject();
        final String title = object.getTitle();
        final String content = object.getContent();

        holder.ivJinJi.setVisibility(View.GONE);
        holder.ivZhiDing.setVisibility(View.GONE);
        holder.ivShouquan.setVisibility(View.VISIBLE);
        holder.ivWuye.setVisibility(View.GONE);
        holder.ivXitong.setVisibility(View.GONE);
        holder.tvTitle.setText(title);
        holder.tvContent.setText(content);
        if (read) {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
        } else {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
        }
        final String time = serviceMsgBean.getTime();
        holder.tvDate.setText(time);
        holder.llMessageItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!read) {
                    msgBean.setRead(true);
                    setReadState(position, holder);
                }
                startActivityToMessageNoticeDetail("text", title, content, position, time);
            }
        });
    }

    /**
     * 装载钥匙审核通过的消息
     */
    private void loadKeyPassMsg(final MessageBean msgBean, final ViewHolder holder, KeyPassMsgBean object, final int position, final boolean read) {
        KeyPassMsgBean.ObjectBean keyPassMsg = object.getObject();
        final String title = keyPassMsg.getTitle();
        final String content = keyPassMsg.getContent();
        holder.ivJinJi.setVisibility(View.GONE);
        holder.ivZhiDing.setVisibility(View.GONE);
        holder.ivShouquan.setVisibility(View.VISIBLE);
        holder.ivWuye.setVisibility(View.GONE);
        holder.ivXitong.setVisibility(View.GONE);
        holder.tvTitle.setText(title);
        holder.tvContent.setText(content);
        if (read) {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
        } else {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
        }
        final String time = object.getTime();
        holder.tvDate.setText(time);
        holder.llMessageItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!read) {
                    msgBean.setRead(true);
                    setReadState(position, holder);
                }
                startActivityToMessageNoticeDetail("text", title, content, position, time);
            }
        });
    }

    /**
     * 装载申请钥匙请求的数据
     */
    private void loadRequestKey(final MessageBean msgBean, final ViewHolder holder, RequestKeyBean object, final int position, final boolean read) {
        final RequestKeyBean.ObjectBean objectBean = object.getObject();
        holder.ivJinJi.setVisibility(View.GONE);
        holder.ivZhiDing.setVisibility(View.GONE);
        holder.ivShouquan.setVisibility(View.VISIBLE);
        holder.ivWuye.setVisibility(View.GONE);
        holder.ivXitong.setVisibility(View.GONE);
        holder.tvTitle.setText(objectBean.getTitle());
        holder.tvContent.setText(objectBean.getContent());
        if (read) {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
        } else {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
        }
        holder.tvDate.setText(object.getTime());
        holder.llMessageItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean aBoolean = SpUtil.getInstance().getBoolean("reject_auth_success" + position, false);
                if (aBoolean) {
                    Intent intent = new Intent(mContext, MessageNoticeDetail.class);
                    intent.putExtra("type", "text");
                    intent.putExtra("title", objectBean.getTitle());
                    intent.putExtra("content", objectBean.getContent());
                    mContext.startActivity(intent);
                } else {
                    //msgBean.setRead(true);
                    //setReadState(position, holder); // 设为已读
                    Intent intent = new Intent(mContext, NormalAuthActivity.class);
                    intent.putExtra("position", position);
                    intent.putExtra("user_phone", objectBean.getUser_phone());
                    intent.putExtra("user_name", objectBean.getUser_name());
                    intent.putExtra("start_time", objectBean.getKey_start_date());
                    intent.putExtra("end_time", objectBean.getKey_end_date());
                    intent.putExtra("ship", objectBean.getUser_type());
                    intent.putExtra("zoneid", objectBean.getZone_id());
                    intent.putExtra("zonename", objectBean.getZone_name());
                    intent.putExtra("buildingid", objectBean.getBuilding_id());
                    intent.putExtra("buildingname", objectBean.getBuilding_name());
                    intent.putExtra("unitid", objectBean.getUnit_id());
                    intent.putExtra("unitname", objectBean.getUnit_name());
                    intent.putExtra("roomid", objectBean.getRoom_id());
                    intent.putExtra("roomname", objectBean.getRoom_name());
                    intent.putExtra("user_id", objectBean.getUser_id());
                    intent.putExtra("resident_id", objectBean.getResident_id());
                    intent.putExtra("master_resident_id", objectBean.getMaster_resident_id());
                    SpUtil.getInstance().save("isrequestauth", true);
                    mContext.startActivity(intent);
                }
            }
        });
    }

    /**
     * 装载消息公告数据
     */
    private void loadNoticeMsg(final MessageBean msgBean, final ViewHolder holder, NoticeMsgBean noticeMsg, final int position, final boolean read) {
        final String url = noticeMsg.getObject().getContent();
        switch (Integer.parseInt(noticeMsg.getObject().getStatus())) {
            case 1:
                holder.ivJinJi.setVisibility(View.GONE);
                holder.ivZhiDing.setVisibility(View.GONE);
                break;
            case 2:
                holder.ivJinJi.setVisibility(View.VISIBLE);
                holder.ivZhiDing.setVisibility(View.GONE);
                break;
            case 3:
                holder.ivJinJi.setVisibility(View.GONE);
                holder.ivZhiDing.setVisibility(View.VISIBLE);
                break;
            case 4:
                holder.ivJinJi.setVisibility(View.VISIBLE);
                holder.ivZhiDing.setVisibility(View.VISIBLE);
                break;
        }
        holder.ivShouquan.setVisibility(View.GONE);
        holder.ivWuye.setVisibility(View.VISIBLE);
        holder.ivXitong.setVisibility(View.GONE);
        holder.tvTitle.setText(noticeMsg.getObject().getTitle());
        holder.tvContent.setText(noticeMsg.getObject().getAbstractX().replace(" ", ""));
        if (read) {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
        } else {
            holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
            holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_4f4f4f));
        }
        holder.tvDate.setText(noticeMsg.getObject().getRelease_date());
        holder.llMessageItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!read) {
                    msgBean.setRead(true);
                    setReadState(position, holder);
                }
                Intent intent = new Intent(mContext, MessageNoticeDetail.class);
                intent.putExtra("type", "url");
                intent.putExtra("url", url);
                intent.putExtra("position", position);
                mContext.startActivity(intent);
            }
        });
    }

    /**
     * 设置已阅读状态
     */
    private void setReadState(int position, ViewHolder holder) {
        MessageProvider.getInstance().setReadState(position);
        holder.tvTitle.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
        holder.tvContent.setTextColor(mContext.getResources().getColor(R.color.text_color_bdbdbd));
    }

    /**
     * 跳转到消息详情页面
     */
    private void startActivityToMessageNoticeDetail(String type, String title, String content, int position, String time) {
        Intent intent = new Intent(mContext, MessageNoticeDetail.class);
        intent.putExtra("time", time);
        intent.putExtra("type", type);
        intent.putExtra("title", title);
        intent.putExtra("content", content);
        intent.putExtra("position", position);
        mContext.startActivity(intent);
    }

    static class ViewHolder {
        @BindView(R.id.ivWuye)
        ImageView ivWuye;
        @BindView(R.id.ivShouquan)
        ImageView ivShouquan;
        @BindView(R.id.ivXitong)
        ImageView ivXitong;
        @BindView(R.id.tvTitle)
        TextView tvTitle;
        @BindView(R.id.ivJinJi)
        ImageView ivJinJi;
        @BindView(R.id.ivZhiDing)
        ImageView ivZhiDing;
        @BindView(R.id.tvDate)
        TextView tvDate;
        @BindView(R.id.tvContent)
        TextView tvContent;
        @BindView(R.id.llMessageItem)
        LinearLayout llMessageItem;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
