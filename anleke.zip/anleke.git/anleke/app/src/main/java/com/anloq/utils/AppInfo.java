package com.anloq.utils;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.anloq.MyApplication;

/**
 * Created by xpf on 2017/5/20 :)
 * Function:获取当前APP信息
 */

public class AppInfo {

    public static String getVersionName() {
        PackageInfo packInfo = null;
        String version = "";
        try {
            PackageManager packageManager = MyApplication.getContext().getPackageManager();
            // 是你当前类的包名，0代表是获取版本信息
            packInfo = packageManager.getPackageInfo("com.anloq.anleke", 0);
            version = packInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return version;
    }

}
