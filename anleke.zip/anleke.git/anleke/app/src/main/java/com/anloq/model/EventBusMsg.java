package com.anloq.model;

/**
 * Created by xpf on 2017/4/21 :)
 * Function:EventBus发送消息的Bean
 */

public class EventBusMsg {
    private String type;
    private String content;

    public EventBusMsg() {
    }

    public EventBusMsg(String type, String content) {
        this.type = type;
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "EventBusMsg{" +
                "type='" + type + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
