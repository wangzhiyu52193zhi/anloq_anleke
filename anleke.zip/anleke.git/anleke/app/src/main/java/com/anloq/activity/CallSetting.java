package com.anloq.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.ProfileManager;
import com.anloq.model.ProfileBean;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

import static com.anloq.MyApplication.mContext;

// 通话设置
public class CallSetting extends Activity {

    private static final String TAG = CallSetting.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.toggleSounds)
    ToggleButton toggleSounds;
    @BindView(R.id.toggleShake)
    ToggleButton toggleShake;
    @BindView(R.id.rlRings)
    RelativeLayout rlRings;
    @BindView(R.id.toggleRingShake)
    ToggleButton toggleRingShake;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_setting);
        ButterKnife.bind(this);
        tvTitle.setText(R.string.calling_set);
        setListener();
        initToggle();
    }

    private void initToggle() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.GETPROFILE + uid + Constants.TOKEN + token;
        Logger.t(TAG).i("GETPROFILE_url===" + url);

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e(e.toString());
                        setErrorSetting();
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseJson(response);
                    }
                });
    }

    private void setErrorSetting() {
        // 设置新消息声音
        boolean messagesounds = SpUtil.getInstance().getBoolean("messagesounds", true);
        toggleSounds.setChecked(messagesounds);
        SpUtil.getInstance().save("messagesounds", messagesounds);
        // 设置新消息震动
        boolean messagevibrate = SpUtil.getInstance().getBoolean("messagevibrate", true);
        toggleShake.setChecked(messagevibrate);
        SpUtil.getInstance().save("messagevibrate", messagevibrate);
        // 设置响铃时震动
        boolean ringandvibrate = SpUtil.getInstance().getBoolean("ringandvibrate", true);
        toggleRingShake.setChecked(ringandvibrate);
        SpUtil.getInstance().save("ringandvibrate", ringandvibrate);
    }

    private void parseJson(String json) {
        ProfileBean profileBean = new Gson().fromJson(json, ProfileBean.class);
        if (profileBean != null) {
            ProfileBean.ObjectBean object = profileBean.getObject();
            if (object != null) {
                boolean sound_enable = object.isSound_enable();
                boolean shake_enable = object.isShake_enable();
                boolean ring_shake = object.isRing_shake();
                toggleSounds.setChecked(sound_enable);
                toggleShake.setChecked(shake_enable);
                toggleRingShake.setChecked(ring_shake);
            }
        }
    }

    private void setListener() {
        toggleSounds.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.e(TAG, "新消息声音===" + isChecked);
                SpUtil.getInstance().save("messagesounds", isChecked);
                uploadSetting("sound_enable", isChecked);
            }
        });
        toggleShake.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.e(TAG, "新消息震动===" + isChecked);
                SpUtil.getInstance().save("messagevibrate", isChecked);
                uploadSetting("shake_enable", isChecked);
            }
        });
        toggleRingShake.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.e(TAG, "响铃时震动===" + isChecked);
                SpUtil.getInstance().save("ringandvibrate", isChecked);
                uploadSetting("ring_shake", isChecked);
            }
        });
    }

    /**
     * 上传用户设置
     *
     * @param type
     * @param isChecked
     */
    private void uploadSetting(String type, final boolean isChecked) {
        Logger.t(TAG).i("是否绑定硬件===" + isChecked);
        HashMap map = new HashMap();
        map.put(type, isChecked);
        ProfileManager.update(map, new ProfileManager.OnProfileUpdateListener() {
            @Override
            public void onUpdate(String result) {
                String code = RequestUtil.getCode(mContext, result);
                if ("200".equals(code)) {
                    Logger.t(TAG).i("通话设置成功isChecked===" + isChecked);
                }
            }
        });
    }

    @OnClick({R.id.ivBack, R.id.rlRings})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.rlRings:
                startActivity(new Intent(CallSetting.this, RingSelectActivity.class));
                break;
        }
    }
}
