package com.anloq.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anloq.activity.MyKeyPackageDetail;
import com.anloq.anleke.R;
import com.anloq.model.VKeysPkgBean;
import com.anloq.ui.GlideRoundTransform;
import com.bumptech.glide.Glide;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/4/8 :)
 * Function:钥匙包数据的的适配器
 */

public class VkeyPkgAdapter extends BaseAdapter {

    private Context mContext;
    private List<VKeysPkgBean.ObjectBean> vkeyList;

    public VkeyPkgAdapter(Context mContext, List<VKeysPkgBean.ObjectBean> vkeyList) {
        this.mContext = mContext;
        this.vkeyList = vkeyList;
    }

    @Override
    public int getCount() {
        return vkeyList.size();
    }

    @Override
    public Object getItem(int position) {
        return vkeyList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_my_vkeypkg, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        VKeysPkgBean.ObjectBean vkey = vkeyList.get(position);
        final int key_id = vkey.getKey_info().getKey_id();
        final String cardColor = vkey.getRoom_info().getZone_key_color();
        holder.tvCover.setEnabled(true);
        Glide.with(mContext)
                .load(vkey.getRoom_info().getImage())
                .transform(new GlideRoundTransform(mContext))
                .crossFade()
                .into(holder.ivCard);
        holder.tvZone.setText(vkey.getRoom_info().getZone_name());
        holder.tvBuilding.setText(vkey.getRoom_info().getBuilding_name());
        holder.tvUnit.setText(vkey.getRoom_info().getUnit_name());
        holder.tvRoom.setText("(" + vkey.getRoom_info().getRoom_name() + "室)");
        holder.tvDistrict.setText(vkey.getRoom_info().getProvince_name() + "·" +
                vkey.getRoom_info().getCity_name());
        holder.tvStartDate.setText(vkey.getKey_info().getAuth_start_date().substring(0, 13).replace("T", " ") + "时");
        holder.tvEndDate.setText(vkey.getKey_info().getAuth_end_date().substring(0, 13).replace("T", " ") + "时");
        switch (vkey.getKey_info().getKey_status()) {
            // "key_status": 1, //钥匙状态 1-待审核，2-已通过，3-已驳回
            case 1:
                holder.llInDate.setVisibility(View.GONE);
                holder.tvApply.setVisibility(View.VISIBLE);
                holder.tvApply.setVisibility(View.VISIBLE);
                break;
            case 2:
                holder.tvApply.setVisibility(View.GONE);
                if (!vkey.getKey_info().isIs_freeze()) {
                    setCardBgColor(holder, cardColor);
                }
                break;
            case 3:
                holder.tvApply.setVisibility(View.VISIBLE);
                break;
        }
        holder.rlCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, MyKeyPackageDetail.class);
                intent.putExtra("position", position);
                mContext.startActivity(intent);
            }
        });
        return convertView;
    }

    /**
     * 设置卡片对应的颜色
     */
    private void setCardBgColor(ViewHolder holder, String cardColor) {
        // 根据小区ID来设置不同的cardSrc颜色
        if ("1".equals(cardColor)) {
            holder.tvCover.setBackground(mContext.getResources().getDrawable(R.drawable.card_pale_blue_shape));
        } else if ("2".equals(cardColor)) {
            holder.tvCover.setBackground(mContext.getResources().getDrawable(R.drawable.card_sea_blue_shape));
        } else if ("3".equals(cardColor)) {
            holder.tvCover.setBackground(mContext.getResources().getDrawable(R.drawable.card_yellow_purple_shape));
        } else if ("4".equals(cardColor)) {
            holder.tvCover.setBackground(mContext.getResources().getDrawable(R.drawable.card_orange_shape));
        } else if ("5".equals(cardColor)) {
            holder.tvCover.setBackground(mContext.getResources().getDrawable(R.drawable.card_grass_green_shape));
        }
    }

    static class ViewHolder {
        @BindView(R.id.ivCard)
        ImageView ivCard;
        @BindView(R.id.tvCover)
        TextView tvCover;
        @BindView(R.id.tvDistrict)
        TextView tvDistrict;
        @BindView(R.id.ivNfc)
        ImageView ivNfc;
        @BindView(R.id.ivBle)
        ImageView ivBle;
        @BindView(R.id.tvZone)
        TextView tvZone;
        @BindView(R.id.tvBuilding)
        TextView tvBuilding;
        @BindView(R.id.tvUnit)
        TextView tvUnit;
        @BindView(R.id.tvRoom)
        TextView tvRoom;
        @BindView(R.id.tvStartDate)
        TextView tvStartDate;
        @BindView(R.id.tvEndDate)
        TextView tvEndDate;
        @BindView(R.id.llInDate)
        LinearLayout llInDate;
        @BindView(R.id.tvApply)
        TextView tvApply;
        @BindView(R.id.rlCard)
        RelativeLayout rlCard;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

}
