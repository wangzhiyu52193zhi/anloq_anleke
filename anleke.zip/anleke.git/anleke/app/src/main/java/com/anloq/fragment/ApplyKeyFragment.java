package com.anloq.fragment;

import android.content.Intent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;

import com.anloq.activity.ApplyVirtualKey;
import com.anloq.anleke.R;
import com.anloq.base.BaseFragment;
import com.anloq.utils.SpUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by xpf on 2017/4/6 :)
 * Function:申请钥匙包
 */

public class ApplyKeyFragment extends BaseFragment {

    private static final String TAG = ApplyKeyFragment.class.getSimpleName();
    @BindView(R.id.llAllView)
    LinearLayout llAllView;
    @BindView(R.id.llCard)
    LinearLayout llCard;
    private boolean isMeasured = false;

    @Override
    public View initView() {
        View view = View.inflate(mContext, R.layout.fragment_apply_card, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        getHeight();
    }

    private void getHeight() {
        ViewTreeObserver observer = llCard.getViewTreeObserver();
        observer.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            public boolean onPreDraw() {
                if (!isMeasured) {
                    int cardHeight = llCard.getMeasuredHeight();
                    SpUtil.getInstance().save("cardheight", cardHeight);
                    isMeasured = true;
                }
                return true;
            }
        });
    }

    @OnClick({R.id.llCard})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llCard:
                mContext.startActivity(new Intent(mContext, ApplyVirtualKey.class));
                break;
        }
    }

}
