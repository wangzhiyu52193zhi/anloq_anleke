package com.anloq.nfcservice;

import android.app.ActivityManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.util.Log;

import java.util.List;

public class ObserverService extends Service {

    private static final String TAG = ObserverService.class.getSimpleName();

    /**
     * 锁屏的管理类叫KeyguardManager，
     * 通过调用其内部类KeyguardLockmKeyguardLock的对象的disableKeyguard方法可以取消系统锁屏，
     * newKeyguardLock的参数用于标识是谁隐藏了系统锁屏
     */
    private BroadcastReceiver mScreenOReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals("android.intent.action.SCREEN_ON")) {
                Log.e(TAG, "—— SCREEN_ON ——");
                keepServiceAlive();
            } else if (action.equals("android.intent.action.SCREEN_OFF")) {
                Log.e(TAG, "—— SCREEN_OFF ——");
                keepServiceAlive();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e(TAG, "onCreate()");
        /* 注册屏幕唤醒时的广播 */
        IntentFilter mScreenOnFilter = new IntentFilter("android.intent.action.SCREEN_ON");
        registerReceiver(mScreenOReceiver, mScreenOnFilter);
        /* 注册机器锁屏时的广播 */
        IntentFilter mScreenOffFilter = new IntentFilter("android.intent.action.SCREEN_OFF");
        registerReceiver(mScreenOReceiver, mScreenOffFilter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        keepServiceAlive();
        //return super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    private void keepServiceAlive() {
        boolean isAlive = checkIsAlive();
        Log.e(TAG, "Emqtt Service is alive===" + isAlive);
        if (!isAlive) {
            //startService(new Intent(ObserverService.this, EmqttService.class));
        }
    }

    /**
     * 检测Emqtt service 是否活着
     */
    private boolean checkIsAlive() {
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> serviceList = activityManager
                .getRunningServices(Integer.MAX_VALUE);

        if (!(serviceList.size() > 0)) {
            return false;
        }

        for (int i = 0; i < serviceList.size(); i++) {
            ActivityManager.RunningServiceInfo serviceInfo = serviceList.get(i);
            ComponentName serviceName = serviceInfo.service;
            if (serviceName.getClassName().equals(EmqttService.class.getName())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy()");
        unregisterReceiver(mScreenOReceiver);
        // 重新启动自己
        restartMyself();
    }

    private void restartMyself() {
        //startService(new Intent(ObserverService.this, ObserverService.class));
    }
}
