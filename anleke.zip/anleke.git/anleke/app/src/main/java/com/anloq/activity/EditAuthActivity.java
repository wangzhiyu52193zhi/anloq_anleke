package com.anloq.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.BrightnessManager;
import com.anloq.manager.DBManager;
import com.anloq.model.VkeyBean;
import com.anloq.ui.CardView;
import com.anloq.ui.GlideRoundTransform;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.TimeUtil;
import com.anloq.utils.ToastUtil;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.wangchenlong.datescroller.widget.DateScrollerDialog;
import org.wangchenlong.datescroller.widget.data.Type;
import org.wangchenlong.datescroller.widget.listener.OnDateSetListener;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.MediaType;

// 编辑授权页面
public class EditAuthActivity extends FragmentActivity {
    private static final String TAG = EditAuthActivity.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.ivCard)
    ImageView ivCard;
    @BindView(R.id.tvPhone)
    TextView tvPhone;
    @BindView(R.id.tvStartTime)
    TextView tvStartTime;
    @BindView(R.id.llStartTime)
    LinearLayout llStartTime;
    @BindView(R.id.tvEndTime)
    TextView tvEndTime;
    @BindView(R.id.llEndTime)
    LinearLayout llEndTime;
    @BindView(R.id.tvShip)
    TextView tvShip;
    @BindView(R.id.llShip)
    LinearLayout llShip;
    @BindView(R.id.btnSave)
    Button btnSave;
    @BindView(R.id.btnDelete)
    Button btnDelete;
    @BindView(R.id.tvCover)
    TextView tvCover;
    @BindView(R.id.ivNfc)
    ImageView ivNfc;
    @BindView(R.id.ivBle)
    ImageView ivBle;
    @BindView(R.id.tvZone)
    TextView tvZone;
    @BindView(R.id.tvBuilding)
    TextView tvBuilding;
    @BindView(R.id.tvUnit)
    TextView tvUnit;
    @BindView(R.id.tvRoom)
    TextView tvRoom;
    @BindView(R.id.tvStartDate)
    TextView tvStartDate;
    @BindView(R.id.tvEndDate)
    TextView tvEndDate;
    @BindView(R.id.llInDate)
    LinearLayout llInDate;
    @BindView(R.id.tvApply)
    TextView tvApply;
    @BindView(R.id.rlCard)
    RelativeLayout rlCard;

    private String image_url = "";
    private long mLastTime = System.currentTimeMillis(); // 上次设置的时间
    private boolean isStartTime = true;
    private int is_freeze = -1; // 0-解冻，1-被冻结
    private int is_deleted = -1; // 0-默认，1-删除
    private int uid;
    private String token;
    private int user_id;
    private int resident_id;
    private int auth_key_id;
    private int master_resident_id;
    private int user_type;
    private String user_phone;
    private boolean isCountsAuth = false; // 是否是按次授权(否则为按时间授权)
    private int auth_cmd = -1; // 1-授权通过，2-驳回
    private int auth_type = 1; // 授权类型：1-按时间授权，2-按次授权

    private boolean isFreeze;
    private boolean isPause = true; // 是否是暂停授权，否则为开启授权
    private int key_status; //"key_status": 1, //钥匙状态 1-待审核，2-已通过，3-已驳回
    private String room_admin_name, unit_name, building_name, zone_name,
            province_name, city_name, auth_start_date, auth_end_date, room_name, master_start_date, master_end_date;
    private int zoneid, roomid, expire_type, auth_count, city_id, room_id, unit_id, building_id,
            province_id, zone_id, relation, key_id;
    private static int keyid;

    private PopupWindow popupShip;
    private View popupShipView;
    private TranslateAnimation animation;
    private Context mContext;
    private String authedName = "";
    private long dateScrollMin;
    private long dateScrollMax;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_auth);
        ButterKnife.bind(this);
        mContext = this;
        tvTitle.setText(R.string.edit_auth);
        getActivityData();
        initCardInformation();
        dateScrollMin = TimeUtil.parseDate(master_start_date);
        dateScrollMax = TimeUtil.parseDate(master_end_date);
    }

    /**
     * 初始化卡片信息
     */
    private void initCardInformation() {
        VkeyBean object = DBManager.getInstance().getVKeyByKeyId(keyid);
        if (object != null) {
            key_id = object.getKey_id();
            expire_type = object.getExpire_type();
            master_start_date = object.getAuth_start_date();
            master_end_date = object.getAuth_end_date();
            auth_count = object.getAuth_count();
            key_status = object.getKey_status();
            isFreeze = object.is_freeze();
            image_url = object.getImage_url();
            zone_name = object.getZone_name();
            province_name = object.getProvince_name();
            city_name = object.getCity_name();
            building_name = object.getBuilding_name();
            unit_name = object.getUnit_name();
            city_id = object.getCity_id();
            room_id = object.getRoom_id();
            room_name = object.getRoom_name();
            unit_id = object.getUnit_id();
            building_id = object.getBuilding_id();
            province_id = object.getProvince_id();
            room_admin_name = object.getRoom_admin_name();
            zone_id = object.getZone_id();

            if (!"".equals(image_url)) {
                Glide.with(mContext)
                        .load(image_url)
                        .transform(new GlideRoundTransform(mContext))
                        .into(ivCard);
            }

            tvZone.setText(zone_name);
            tvBuilding.setText(building_name);
            tvUnit.setText(unit_name);
            tvRoom.setText("(" + room_name + "室)");
            if (auth_start_date != null && !"".equals(auth_start_date)) {
                tvStartDate.setText(auth_start_date.substring(0, 13).replace("T", " ") + "时");
            }
            if (auth_end_date != null && !"".equals(auth_end_date)) {
                tvEndDate.setText(auth_end_date.substring(0, 13).replace("T", " ") + "时");
            }

            if (!isFreeze) {
                // 判断卡片是否过期
                boolean invalidDate = TimeUtil.checkIsInvalidDate(auth_start_date, auth_end_date);
                if (!invalidDate) {
                    CardView.setColor(mContext, zoneid, tvCover, ivCard);
                } else {
                    llInDate.setVisibility(View.GONE);
                    tvApply.setVisibility(View.VISIBLE);
                    tvApply.setText(R.string.card_invalid);
                    tvCover.setBackground(getResources().getDrawable(R.drawable.card_gray_shape));
                }
            } else {
                llInDate.setVisibility(View.GONE);
                tvApply.setVisibility(View.VISIBLE);
                tvApply.setText(R.string.pause_auth);
            }
        }
    }

    private void getActivityData() {
        Intent intent = getIntent();
        user_id = intent.getIntExtra("user_id", -1);
        resident_id = intent.getIntExtra("resident_id", -1);
        auth_key_id = intent.getIntExtra("auth_key_id", -1);
        master_resident_id = intent.getIntExtra("master_resident_id", -1);
        user_type = intent.getIntExtra("user_type", -1);
        user_phone = intent.getStringExtra("user_phone");
        auth_start_date = intent.getStringExtra("auth_start_date");
        auth_end_date = intent.getStringExtra("auth_end_date");
        tvPhone.setText(user_phone);
        tvStartTime.setText(auth_start_date.substring(0, 16).replace("T", " "));
        tvEndTime.setText(auth_end_date.substring(0, 16).replace("T", " "));
        zoneid = intent.getIntExtra("zoneid", -1);
        roomid = intent.getIntExtra("roomid", -1);
        keyid = intent.getIntExtra("keyid", -1);
        relation = intent.getIntExtra("relation", -1);
        switch (user_type) {
            case 2:
                tvShip.setText(R.string.family);
                break;
            case 3:
                tvShip.setText(R.string.renter);
                break;
            case 4:
                tvShip.setText(R.string.visiter);
                break;
        }
    }

    @OnClick({R.id.llStartTime, R.id.llEndTime, R.id.llShip, R.id.btnSave, R.id.btnDelete, R.id.ivBack})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llStartTime:
                isStartTime = true;
                showDate(view);
                break;
            case R.id.llEndTime:
                isStartTime = false;
                showDate(view);
                break;
            case R.id.llShip:
                selectShip();
                BrightnessManager.lightoff(mContext);
                break;
            case R.id.btnSave:
                auth_cmd = 1;
                getKeyInfo();
                break;
            case R.id.btnDelete:
                new AlertDialog.Builder(mContext)
                        .setTitle(R.string.confirm_delete)
                        .setPositiveButton(R.string.btn_confirm, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                deleteAuth();
                            }
                        })
                        .setNegativeButton(R.string.cancel_textview, null)
                        .show();
                break;
            case R.id.ivBack:
                finish();
                break;
        }
    }

    /**
     * 根据rooid获取当前房间的其他信息字段
     */
    private void getKeyInfo() {
        VkeyBean object = DBManager.getInstance().getVKeyByRoomId(roomid);
        Log.e(TAG, "roomid===" + roomid);
        if (object != null) {
            key_id = object.getKey_id();
            expire_type = object.getExpire_type();
            master_start_date = object.getAuth_start_date();
            master_end_date = object.getAuth_end_date();
            auth_count = object.getAuth_count();
            key_status = object.getKey_status();
            isFreeze = object.is_freeze();
            image_url = object.getImage_url();
            zone_name = object.getZone_name();
            province_name = object.getProvince_name();
            city_name = object.getCity_name();
            building_name = object.getBuilding_name();
            unit_name = object.getUnit_name();
            city_id = object.getCity_id();
            room_id = object.getRoom_id();
            room_name = object.getRoom_name();
            unit_id = object.getUnit_id();
            building_id = object.getBuilding_id();
            province_id = object.getProvince_id();
            room_admin_name = object.getRoom_admin_name();
            zone_id = object.getZone_id();
        }
        toAuth();
    }

    /**
     * 删除授权
     */
    private void deleteAuth() {
        is_freeze = 0;
        is_deleted = 1;
        sendRequest();
    }

    private void sendRequest() {
        uid = SpUtil.getInstance().getInt("uid", -1);
        token = SpUtil.getInstance().getString("token", "");

        HashMap map = new HashMap();
        map.put("auth_key_id", auth_key_id);
        map.put("master_resident_id", master_resident_id);
        map.put("user_id", user_id);
        map.put("resident_id", resident_id);
        map.put("is_freeze", is_freeze);
        map.put("is_deleted", is_deleted);
        String content = new Gson().toJson(map);
        Log.e(TAG, "content===" + content);

        String url = Constants.MODIFYVKEY + uid + Constants.TOKEN + token;
        Log.e(TAG, "MODIFYVKEY_url===" + url);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "response===" + response);
                        parseResult2(response);
                    }
                });
    }

    private void parseResult2(String json) {
        String code = RequestUtil.getCode(mContext, json);
        Log.e(TAG, "code===" + code);
        if ("200".equals(code)) {
            ToastUtil.show(getString(R.string.delete_success));
            finish();
        } else {
            ToastUtil.show(getString(R.string.delete_fail));
        }
    }

    /**
     * 立即授权
     */
    private void toAuth() {
        if ("".equals(auth_start_date) || "".equals(auth_end_date)) {
            ToastUtil.show(getString(R.string.you_has_blank_column));
            return;
        }
        if (TimeUtil.parseIsSameHour(auth_start_date, auth_end_date)) {
            ToastUtil.show(getString(R.string.endtime_must_more_starttime));
            return;
        }

        uid = SpUtil.getInstance().getInt("uid", -1);
        token = SpUtil.getInstance().getString("token", "");
        String url = Constants.AUTHKEY + uid + Constants.TOKEN + token;
        Log.e(TAG, "AUTHKEY_url===" + url);

        HashMap map = new HashMap();
        map.put("zone_id", zoneid);
        map.put("zone_name", zone_name);
        map.put("building_id", building_id);
        map.put("building_name", building_name);
        map.put("unit_id", unit_id);
        map.put("unit_name", unit_name);
        map.put("room_id", room_id);
        map.put("room_name", room_name);
        map.put("user_type", user_type);
        map.put("user_phone", user_phone);
        map.put("auth_type", auth_type);
        map.put("auth_cmd", auth_cmd); // 1-授权通过，2-驳回

        if (isCountsAuth) {
            map.put("auth_count", auth_count);
        } else {
            map.put("key_start_date", auth_start_date);
            map.put("key_end_date", auth_end_date);
        }

        String content = new Gson().toJson(map);
        Log.e(TAG, "content===" + content);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e(TAG, "授权结果联网失败===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "授权结果联网成功===" + response);
                        parseResult(response);
                    }
                });
    }

    private void parseResult(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            SpUtil.getInstance().save("dealedrequest", true); // 表示处理过请求，置灰按钮
            btnSave.setEnabled(false);
            btnDelete.setEnabled(false);
            ToastUtil.show(getString(R.string.auth_success));
        } else {
            ToastUtil.show(getString(R.string.auth_fail));
        }
        finish();
    }

    /**
     * 选择关系
     */
    private void selectShip() {
        if (popupShip == null) {
            popupShipView = View.inflate(this, R.layout.item_relation, null);
            popupShip = new PopupWindow(popupShipView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);

            popupShip.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(mContext);
                }
            });

            popupShip.setBackgroundDrawable(new BitmapDrawable());
            popupShip.setFocusable(true);
            popupShip.setOutsideTouchable(true);
            animation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0, Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 1, Animation.RELATIVE_TO_PARENT, 0);
            animation.setInterpolator(new AccelerateInterpolator());
            animation.setDuration(200);

            TextView tvFamily = (TextView) popupShipView.findViewById(R.id.tvFamily);
            tvFamily.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tvShip.setText(R.string.family);
                    user_type = 2;
                    popupShip.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            TextView tvRenter = (TextView) popupShipView.findViewById(R.id.tvRenter);
            tvRenter.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tvShip.setText(R.string.renter);
                    user_type = 3;
                    popupShip.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            TextView tvVisitor = (TextView) popupShipView.findViewById(R.id.tvVisitor);
            tvVisitor.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tvShip.setText(R.string.visiter);
                    user_type = 4;
                    popupShip.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            switch (relation) {
                case 2:
                    tvFamily.setVisibility(View.GONE);
                    break;
                case 3:
                    tvFamily.setVisibility(View.GONE);
                    tvRenter.setVisibility(View.GONE);
                    break;
            }
        }
        if (popupShip.isShowing()) {
            popupShip.dismiss();
            BrightnessManager.lighton(mContext);
        }

        // 设置popupWindow的显示位置，此处是在手机屏幕底部且水平居中的位置
        popupShip.showAtLocation(EditAuthActivity.this.findViewById(R.id.activity_upate_auth),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        popupShipView.startAnimation(animation);
    }

    /**
     * 显示日期(配置最大、最小时间伐值)
     */
    public void showDate(View view) {
        DateScrollerDialog dialog = new DateScrollerDialog.Builder()
                .setType(Type.YEAR_MONTH_DAY_HOUR)
                .setTitleStringId(getString(R.string.please_select_date))
                .setMinMilliseconds(dateScrollMin)
                .setMaxMilliseconds(dateScrollMax)
                .setCurMilliseconds(mLastTime)
                .setCallback(mOnDateSetListener)
                .build();

        if (dialog != null) {
            if (!dialog.isAdded()) {
                dialog.show(getSupportFragmentManager(), "year_month_day");
            }
        }
    }

    // 数据的回调
    private OnDateSetListener mOnDateSetListener = new OnDateSetListener() {
        @Override
        public void onDateSet(DateScrollerDialog timePickerView, long milliseconds) {
            mLastTime = milliseconds;
            String text = TimeUtil.getAuthTime(milliseconds);
            if (isStartTime) {
                auth_start_date = text;
                tvStartTime.setText(text.substring(0, 16).replace("T", " "));
            } else {
                auth_end_date = text;
                tvEndTime.setText(text.substring(0, 16).replace("T", " "));
            }
        }
    };

}
