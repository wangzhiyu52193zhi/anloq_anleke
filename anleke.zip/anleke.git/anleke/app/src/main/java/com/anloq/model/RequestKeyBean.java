package com.anloq.model;

import com.anloq.utils.TimeUtil;

/**
 * Created by xpf on 2017/4/14 :)
 * Function:收到申请钥匙请求的Bean
 */

public class RequestKeyBean {

    /**
     * name : rqkeymsg
     * object : {"title":"授权通知","content":"您有一条授权请求：小辛2正在请求中关村小区1号楼1单元的门禁虚拟钥匙，点击查看详情","zone_id":1,"zone_name":"中关村小区","command":0,"resident_id":250,"master_resident_id":235,"building_id":1,"building_name":"1号楼","unit_id":2,"unit_name":"1单元","room_id":2,"room_name":"101","user_id":"16","user_name":"小辛2","user_type":0,"user_phone":"180","key_start_date":"2017-04-14T14:33:17.865Z","key_end_date":"2017-04-21T14:33:17.865Z","master_key_start_date":"2017-04-14T14:14:29.000Z","master_key_end_date":"2017-04-21T14:14:29.000Z"}
     */

    private String name;
    private ObjectBean object;
    private String time;

    public String getTime() {
        return TimeUtil.getTime(time);
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * title : 授权通知
         * content : 您有一条授权请求：小辛2正在请求中关村小区1号楼1单元的门禁虚拟钥匙，点击查看详情
         * zone_id : 1
         * zone_name : 中关村小区
         * command : 0
         * resident_id : 250
         * master_resident_id : 235
         * building_id : 1
         * building_name : 1号楼
         * unit_id : 2
         * unit_name : 1单元
         * room_id : 2
         * room_name : 101
         * user_id : 16
         * user_name : 小辛2
         * user_type : 0
         * user_phone : 180
         * key_start_date : 2017-04-14T14:33:17.865Z
         * key_end_date : 2017-04-21T14:33:17.865Z
         * master_key_start_date : 2017-04-14T14:14:29.000Z
         * master_key_end_date : 2017-04-21T14:14:29.000Z
         */

        private String title;
        private String content;
        private int zone_id;
        private String zone_name;
        private int command;
        private int resident_id;
        private int master_resident_id;
        private int building_id;
        private String building_name;
        private int unit_id;
        private String unit_name;
        private int room_id;
        private String room_name;
        private int user_id;
        private String user_name;
        private int user_type;
        private String user_phone;
        private String key_start_date;
        private String key_end_date;
        private String master_key_start_date;
        private String master_key_end_date;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getZone_id() {
            return zone_id;
        }

        public void setZone_id(int zone_id) {
            this.zone_id = zone_id;
        }

        public String getZone_name() {
            return zone_name;
        }

        public void setZone_name(String zone_name) {
            this.zone_name = zone_name;
        }

        public int getCommand() {
            return command;
        }

        public void setCommand(int command) {
            this.command = command;
        }

        public int getResident_id() {
            return resident_id;
        }

        public void setResident_id(int resident_id) {
            this.resident_id = resident_id;
        }

        public int getMaster_resident_id() {
            return master_resident_id;
        }

        public void setMaster_resident_id(int master_resident_id) {
            this.master_resident_id = master_resident_id;
        }

        public int getBuilding_id() {
            return building_id;
        }

        public void setBuilding_id(int building_id) {
            this.building_id = building_id;
        }

        public String getBuilding_name() {
            return building_name;
        }

        public void setBuilding_name(String building_name) {
            this.building_name = building_name;
        }

        public int getUnit_id() {
            return unit_id;
        }

        public void setUnit_id(int unit_id) {
            this.unit_id = unit_id;
        }

        public String getUnit_name() {
            return unit_name;
        }

        public void setUnit_name(String unit_name) {
            this.unit_name = unit_name;
        }

        public int getRoom_id() {
            return room_id;
        }

        public void setRoom_id(int room_id) {
            this.room_id = room_id;
        }

        public String getRoom_name() {
            return room_name;
        }

        public void setRoom_name(String room_name) {
            this.room_name = room_name;
        }

        public int getUser_id() {
            return user_id;
        }

        public void setUser_id(int user_id) {
            this.user_id = user_id;
        }

        public String getUser_name() {
            return user_name;
        }

        public void setUser_name(String user_name) {
            this.user_name = user_name;
        }

        public int getUser_type() {
            return user_type;
        }

        public void setUser_type(int user_type) {
            this.user_type = user_type;
        }

        public String getUser_phone() {
            return user_phone;
        }

        public void setUser_phone(String user_phone) {
            this.user_phone = user_phone;
        }

        public String getKey_start_date() {
            return key_start_date;
        }

        public void setKey_start_date(String key_start_date) {
            this.key_start_date = key_start_date;
        }

        public String getKey_end_date() {
            return key_end_date;
        }

        public void setKey_end_date(String key_end_date) {
            this.key_end_date = key_end_date;
        }

        public String getMaster_key_start_date() {
            return master_key_start_date;
        }

        public void setMaster_key_start_date(String master_key_start_date) {
            this.master_key_start_date = master_key_start_date;
        }

        public String getMaster_key_end_date() {
            return master_key_end_date;
        }

        public void setMaster_key_end_date(String master_key_end_date) {
            this.master_key_end_date = master_key_end_date;
        }
    }
}
