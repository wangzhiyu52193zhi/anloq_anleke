package com.anloq.nfcservice;

import android.nfc.cardemulation.HostApduService;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.anloq.utils.VKeyUtil;

import java.nio.ByteBuffer;
import java.util.Arrays;

public class NFCEmuService extends HostApduService {
    private static final String TAG = "NFCEmuService";
    private static final String ANLOQ_EMU_CARD_AID = "FA1E222222";
    // ISO-DEP command HEADER for selecting an AID.
    // Format: [Class | Instruction | Parameter 1 | Parameter 2]
    private static final String SELECT_APDU_HEADER = "00A40400";
    // Format: [Class | Instruction | Parameter 1 | Parameter 2]
    private static final String GET_DATA_APDU_HEADER = "00CA0000";
    private static final String GET_DATA_APDU_PACKAGE = "00CB0000";
    private static final String GET_DATA_APDU_OVER = "00CC0000";
    private static final String GET_DATA_APDU_DEVICEID = "00CD0000";
    // "OK" status word sent in response to SELECT AID command (0x9000)
    private static final byte[] SELECT_OK_SW = HexStringToByteArray("9000");
    // "UNKNOWN" status word sent in response to invalid APDU command (0x0000)
    private static final byte[] UNKNOWN_CMD_SW = HexStringToByteArray("0000");
    private String mFirst_Key = null;
    private String mDevice_Key_Sr = null;
    private byte[] mPackData = null;
    private byte[] mDeviceID = null;

    @Override
    public void onCreate() {
        super.onCreate();
        //showToastInfo("NFC解锁开始,请保持不要移开...");
    }

    @Override
    public void onDeactivated(int reason) {
        Log.i(TAG, "onDeactivated for: " + reason);
        if (reason == HostApduService.DEACTIVATION_DESELECTED) {
            //Toast.makeText(getApplicationContext(), "已选择其它应用", Toast.LENGTH_LONG).show();
        } else {
            //Toast.makeText(getApplicationContext(), "连接断开", Toast.LENGTH_LONG).show();
        }
    }

//    public void writeFile(byte[] data, String fileName) throws IOException {
//        FileOutputStream out = new FileOutputStream(fileName);
//        out.write(data);
//        out.write('\n');
//        out.write('\n');
//        out.flush();
//        out.close();
//    }
    String mAccount;
    @Override
    public byte[] processCommandApdu(byte[] commandApdu, Bundle extras) {
        String stringCommand = ByteArrayToHexString(commandApdu);
        //showToastInfo("stringCommand:"+stringCommand);
        if (stringCommand.startsWith(SELECT_APDU_HEADER)) {
            int Key_id = SpUtil.getInstance().getInt("key_id", 0);
            long lkey = 10000000000l+Key_id;
            mAccount = ""+lkey;
            byte[] accountBytes = mAccount.getBytes();
            return ConcatArrays(accountBytes, SELECT_OK_SW);
        } else if (stringCommand.startsWith(GET_DATA_APDU_DEVICEID)) {
            String deviceidtmp = stringCommand.replace(GET_DATA_APDU_DEVICEID, "");
            String deviceid = deviceidtmp.substring(2, deviceidtmp.length() - 2);
            mDeviceID = HexStringToByteArray(deviceid);
            //showToastInfo("获取到装置标识:" + new String(mDeviceID));

            return SELECT_OK_SW;
        } else if (stringCommand.startsWith(GET_DATA_APDU_HEADER)) {
            String tokentmp = stringCommand.replace(GET_DATA_APDU_HEADER, "");
            String token = tokentmp.substring(2, tokentmp.length() - 2);
            byte[] tokenArray = HexStringToByteArray(token);
            mDevice_Key_Sr = SpUtil.getInstance().getString("device_key_sr", "");
            mFirst_Key = SpUtil.getInstance().getString("first_key", "");
            if (mDevice_Key_Sr.length() == 0 || mFirst_Key.length() == 0) {
                mFirst_Key = "3D428950-A474-F5DD-D674-25B03014739B20170311-11:00:12";
                mDevice_Key_Sr = "SpjyZio6UtF1GO9cyyCvYoWYT5XQ7+9B+xSZTKtODuU1l9XdBOiMJtATQR/mfrl1mean5ZBfFw5zahKQRdeeyd9isNIrmA2rczpUyXS9bIKYuVyge2mIOWqhqXXistHnScmp0Ii2FT9z+vrRSpcddsnmMUMYb/Ws6NfZdg7SB8mAIE6mq3qTvBPU3VWghNpLdtk++mWhJx45MX8Vowxw1MKubNV5sEsRb3/sgQJQUaXycJMcQbx5Gs+7j9XLTgTGGa1byF9r78TlZs7oouXhqAXR1wvJjJp7SDk8uoza300UCpiqwrHxSonF4E+VM03Tqzu2TEkVcH4Q+7F4ZfeWYC8Ye4/ZWL2T1JNTVRDe4aF8AvG6oSfkf95uBztPVJctfGA6GUo2GWf0UbuQeFKa9cxlDmRkMTXfaPbQEc5JBpdpvmkZBdLBrmWhMF+jwcdbfnZ5DoKdMtfzU3+bezoR14CX/nIhL1lad2Pt8TyRBAzxjj/6RDIAQfeAPWpUeZf3Js31vSqyEqxG/PhKFo0ff5Vp1Tq1dT6DolGs4BxNhc1SLQ1jIojatlbMY0ddUjZJgZCVagpiHMMgFSwVIj1N0LLWUwnFCwu3WZXn8AGeGQ1pjQe75d31kyv8jUvAYWaCSl1STgXlqe+xI3nI5LMzxF+CDJrcGcgizihM2ZPaeoZwTwfOUcBOd1gJKkG0tz9C2OlBYROuA2vRCpHKD0bEOZLC+BwLeo9nnHSC1v0/bgy492dl7tFLfdSbL6AQGYc06pEeVQuCeEZsKO0Em3z5C3NtTNz2t9UcwN0FwDqVajltqJKAYHPxbGAKb0j0uUEo7WHnUsRY30tCFkLWxiqFhy/18m584QwxkILJjzKMsYEVxa7KrTwfgqY69nMDqrFelkzRpEF7Z1F34fPhob3LalIBod82y7I7RZRVU2b94pVa9bBN7aKuwvHf0IwHkkDA";
            }
            Log.e("TAG", "mFirst_Key===" + mFirst_Key + ",mDevice_Key_Sr===" + mDevice_Key_Sr);
            byte[] dksr = Base64.decode(mDevice_Key_Sr, Base64.DEFAULT);
            //showToastInfo("获得安乐保令牌"+tokenArray.length+"bytes:"+new String(tokenArray));
            //start transfer data pack.
            mPackData = new VKeyUtil().vkeyCommandPack(tokenArray, dksr, Base64.decode(mFirst_Key, Base64.DEFAULT), 1);//stringToSend.getBytes();
//            try {
//                writeFile(mPackData, Environment.getExternalStorageDirectory() + File.separator+"packdata.txt");
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
            Log.e("johnny", "mPackData length:" + mPackData.length);
            byte[] packLength = ByteBuffer.allocate(2).putShort((short) mPackData.length).array();
            byte[] sendPg = null;
            if (mPackData.length > 246) {
                sendPg = ConcatArrays2(packLength, 2, mPackData, 246, SELECT_OK_SW, 2);
            } else {
                sendPg = ConcatArrays2(packLength, 2, mPackData, mPackData.length, SELECT_OK_SW, 2);
            }
            return sendPg;
        } else if (stringCommand.startsWith(GET_DATA_APDU_PACKAGE)) {
            String packtmp = stringCommand.replace(GET_DATA_APDU_PACKAGE, "");
            int packrange = ByteBuffer.wrap(HexStringToByteArray(packtmp)).getShort();//add 2 data length header.
            byte[] sendPg = null;
            if ((mPackData.length - packrange) > 246) {
                //showToastInfo("packrange:" + packrange);
                sendPg = ConcatArrays2(Arrays.copyOfRange(mPackData, packrange, packrange + 246), 246, SELECT_OK_SW, 2, null, 0);
            } else {
                //showToastInfo("packrange last:" + packrange);
                sendPg = ConcatArrays2(Arrays.copyOfRange(mPackData, packrange, mPackData.length), mPackData.length - packrange, SELECT_OK_SW, 2, null, 0);
            }
            return sendPg;
        } else if (stringCommand.startsWith(GET_DATA_APDU_OVER)) {
            String rettmp = stringCommand.replace(GET_DATA_APDU_OVER, "");
            int retNumber = ByteBuffer.wrap(HexStringToByteArray(rettmp)).getShort();
            if (retNumber == 1) {
                ToastUtil.show("已开门!");
            } else {
                ToastUtil.show("开门失败!");
            }
            return SELECT_OK_SW;
        } else {
            return UNKNOWN_CMD_SW;

        }
    }

    public void showToastInfo(final String info) {
        Handler handler = new Handler(this.getMainLooper());
        handler.post(new Runnable() {
            public void run() {
                Toast.makeText(getApplicationContext(), info, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public static String ByteArrayToHexString(byte[] bytes) {
        final char[] hexArray = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        char[] hexChars = new char[bytes.length * 2]; // Each byte has two hex characters (nibbles)
        int v;
        for (int j = 0; j < bytes.length; j++) {
            v = bytes[j] & 0xFF; // Cast bytes[j] to int, treating as unsigned value
            hexChars[j * 2] = hexArray[v >>> 4]; // Select hex character from upper nibble
            hexChars[j * 2 + 1] = hexArray[v & 0x0F]; // Select hex character from lower nibble
        }
        return new String(hexChars);
    }

    public static byte[] HexStringToByteArray(String s) throws IllegalArgumentException {
        int len = s.length();
        if (len % 2 == 1) {
            throw new IllegalArgumentException("Hex string must have even number of characters");
        }
        byte[] data = new byte[len / 2]; // Allocate 1 byte per 2 hex characters
        for (int i = 0; i < len; i += 2) {
            // Convert each character into a integer (base-16), then bit-shift into place
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    public static byte[] ConcatArrays(byte[] first, byte[]... rest) {
        int totalLength = first.length;
        for (byte[] array : rest) {
            totalLength += array.length;
        }
        byte[] result = Arrays.copyOf(first, totalLength);
        int offset = first.length;
        for (byte[] array : rest) {
            System.arraycopy(array, 0, result, offset, array.length);
            offset += array.length;
        }
        return result;
    }

    public static byte[] ConcatArrays2(byte[] first, int firstLength, byte[] two, int twoLength, byte[] three, int threeLength) {
        int totalLength = firstLength + twoLength + threeLength;
        byte[] result = Arrays.copyOf(first, totalLength);
        int offset = firstLength;
        System.arraycopy(two, 0, result, offset, twoLength);
        offset += twoLength;
        if (three != null)
            System.arraycopy(three, 0, result, offset, threeLength);
        return result;
    }

}
