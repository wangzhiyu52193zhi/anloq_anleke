package com.anloq.model;

/**
 * Created by xpf on 2017/4/6 :)
 * Function:原始虚拟钥匙(下发的)
 */

public class OriginVkeyBean {

    /**
     * name : vkey
     * object : {"key_id":324,"key_status":2,"expire_type":1,"auth_start_date":"2017-04-06T06:42:33.253Z","auth_end_date":"2087-04-06T06:42:33.253Z","auth_count":null,"is_freeze":false,"device_key_sr":"LRnYHWFLgLmJYkfBacJnCto5B5T3v7nMHqgXYtKo7emrSmGAGuwKkbpJxL/7elfsX5L1Ml84CEGXtu5faQQFlZsb6XY3Jo7OheGq2F7tDzVn8+ahzHY3JZALfwLxDsLI99p6x+tevZHvOYRfhJ61c5f64xx9uY1YQo+nzihoAlin2cqrfyTI+fBY/EDz8vS74LaKLKrVqzsmPCXLegsM4aXI2l4tsZjuYPubnJPbjDWZeMLqJDYYNbQ4g7W4aaIFBG7blLdn8YK7fCnaWsA7MVNklaEwu7sBomi+FpqxUhjCEQ6D93CsprPxF3jN5bi28rDyHl86gUE3kPYwD4kmJ0nbsE2Ob7AI/Z997jjga43Exs/xZxqEBaV618hKkfeVdZFGDqdz7Z/FpX62lMzPGR16+2O1IXonI0KdPfRut+I3F0Z8F8cGG8AYauvxKQ2PuyjUPj5KBwnpe+3A/9n9rGzEXG7tiUkrnV7kTPf8jyoc9m2HGIE4rhy5lp1DAPdnHuUX1+WL4mUDhPgI+wvr8TrRh5snIMZQ83LzgL+ZuhBVC0WaUnPAnS1AcmtpBqDNnX5vDNAPeK+LFnZOcRvlpowxT/k3XNjeWp3ZxVWppmVoamFkLvQh366ayfUZrj5obuujHtuYZzM7mNrnUFDwJhBbW3SEF4zHCVa1wr8vx2vi+3QNjLCUNmqtHZoxdJzMDWUeGQJ6+xmZ7VvmVvUjEIkI4EmMhIHXqLBTF3l09MElOLmKWcFYfooZd3o7dE6TtakBfESJhp1g5inUJam23VdI/u8BDxO2VgJh0+a17Ls61UkAN9DXEeQ9oJQTviqdrMVXEJs7SrGVw/69BcnwQ4JqsNbIua+Kb2nMUVeIgibECx9NnheF5Tq+NSnag+qgkxHSuejGH8Td47NvNZ8JnNQsJzzT6GfWQTdn+82kdvgOAXKX2H5hqW0/Zk9scU+N\n","first_key":"Y2NkNDM2ZGQtYTRjZC00YzBiLWFlN2ItODI3NDI3NWU5MDNjMjEwMDEyMTItMTI6MTI6MTIx"}
     */

    private String name;
    private ObjectBean object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * key_id : 324
         * key_status : 2
         * expire_type : 1
         * auth_start_date : 2017-04-06T06:42:33.253Z
         * auth_end_date : 2087-04-06T06:42:33.253Z
         * auth_count : null
         * is_freeze : false
         * device_key_sr : LRnYHWFLgLmJYkfBacJnCto5B5T3v7nMHqgXYtKo7emrSmGAGuwKkbpJxL/7elfsX5L1Ml84CEGXtu5faQQFlZsb6XY3Jo7OheGq2F7tDzVn8+ahzHY3JZALfwLxDsLI99p6x+tevZHvOYRfhJ61c5f64xx9uY1YQo+nzihoAlin2cqrfyTI+fBY/EDz8vS74LaKLKrVqzsmPCXLegsM4aXI2l4tsZjuYPubnJPbjDWZeMLqJDYYNbQ4g7W4aaIFBG7blLdn8YK7fCnaWsA7MVNklaEwu7sBomi+FpqxUhjCEQ6D93CsprPxF3jN5bi28rDyHl86gUE3kPYwD4kmJ0nbsE2Ob7AI/Z997jjga43Exs/xZxqEBaV618hKkfeVdZFGDqdz7Z/FpX62lMzPGR16+2O1IXonI0KdPfRut+I3F0Z8F8cGG8AYauvxKQ2PuyjUPj5KBwnpe+3A/9n9rGzEXG7tiUkrnV7kTPf8jyoc9m2HGIE4rhy5lp1DAPdnHuUX1+WL4mUDhPgI+wvr8TrRh5snIMZQ83LzgL+ZuhBVC0WaUnPAnS1AcmtpBqDNnX5vDNAPeK+LFnZOcRvlpowxT/k3XNjeWp3ZxVWppmVoamFkLvQh366ayfUZrj5obuujHtuYZzM7mNrnUFDwJhBbW3SEF4zHCVa1wr8vx2vi+3QNjLCUNmqtHZoxdJzMDWUeGQJ6+xmZ7VvmVvUjEIkI4EmMhIHXqLBTF3l09MElOLmKWcFYfooZd3o7dE6TtakBfESJhp1g5inUJam23VdI/u8BDxO2VgJh0+a17Ls61UkAN9DXEeQ9oJQTviqdrMVXEJs7SrGVw/69BcnwQ4JqsNbIua+Kb2nMUVeIgibECx9NnheF5Tq+NSnag+qgkxHSuejGH8Td47NvNZ8JnNQsJzzT6GfWQTdn+82kdvgOAXKX2H5hqW0/Zk9scU+N
         * <p>
         * first_key : Y2NkNDM2ZGQtYTRjZC00YzBiLWFlN2ItODI3NDI3NWU5MDNjMjEwMDEyMTItMTI6MTI6MTIx
         */

        private int key_id;
        private int key_status;
        private int expire_type;
        private String auth_start_date;
        private String auth_end_date;
        private int auth_count;
        private boolean is_freeze;
        private String device_key_sr;
        private String first_key;
        private String user_phone;
        private String bt_device_mac;

        public String getBt_device_mac() {
            return bt_device_mac;
        }

        public void setBt_device_mac(String user_phone) {
            this.bt_device_mac = user_phone;
        }
        public int getKey_id() {
            return key_id;
        }

        public void setKey_id(int key_id) {
            this.key_id = key_id;
        }

        public int getKey_status() {
            return key_status;
        }

        public void setKey_status(int key_status) {
            this.key_status = key_status;
        }

        public int getExpire_type() {
            return expire_type;
        }

        public void setExpire_type(int expire_type) {
            this.expire_type = expire_type;
        }

        public String getAuth_start_date() {
            return auth_start_date;
        }

        public void setAuth_start_date(String auth_start_date) {
            this.auth_start_date = auth_start_date;
        }
        public String getUser_phone() {
            return user_phone;
        }

        public void setUser_phone(String user_phone) {
            this.user_phone = user_phone;
        }
        public String getAuth_end_date() {
            return auth_end_date;
        }

        public void setAuth_end_date(String auth_end_date) {
            this.auth_end_date = auth_end_date;
        }

        public int getAuth_count() {
            return auth_count;
        }

        public void setAuth_count(int auth_count) {
            this.auth_count = auth_count;
        }

        public boolean isIs_freeze() {
            return is_freeze;
        }

        public void setIs_freeze(boolean is_freeze) {
            this.is_freeze = is_freeze;
        }

        public String getDevice_key_sr() {
            return device_key_sr;
        }

        public void setDevice_key_sr(String device_key_sr) {
            this.device_key_sr = device_key_sr;
        }

        public String getFirst_key() {
            return first_key;
        }

        public void setFirst_key(String first_key) {
            this.first_key = first_key;
        }
    }
}
