package com.anloq.model;

import com.anloq.utils.TimeUtil;

/**
 * Created by xpf on 2017/5/24 :)
 * Function:钥匙业务通知的Bean(例如钥匙被驳回通知)
 */

public class ServiceMsgBean {

    /**
     * name : servicemsg
     * object : {"title":"授权通知","content":"您申请的\"102\"房屋的虚拟钥匙被\"中关村物业\"物业驳回，请联系物业或申请其他房屋的虚拟钥匙！","command":0}
     * time : 2017-05-24T15:35:34.885Z
     */

    private String name;
    private ObjectBean object;
    private String time;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public String getTime() {
        return TimeUtil.getTime(time);
    }

    public void setTime(String time) {
        this.time = time;
    }

    public static class ObjectBean {
        /**
         * title : 授权通知
         * content : 您申请的"102"房屋的虚拟钥匙被"中关村物业"物业驳回，请联系物业或申请其他房屋的虚拟钥匙！
         * command : 0
         */

        private String title;
        private String content;
        private int command;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getCommand() {
            return command;
        }

        public void setCommand(int command) {
            this.command = command;
        }
    }
}
