package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/4/25 :)
 * Function:开锁记录的Bean类
 */

public class UnlockRecordBean {

    /**
     * name : openrecords
     * object : {"data":[{"record_id":100313,"open_type":4,"open_time":"2017-06-14T21:55:23.000Z","user_name":"大水哥","headpic":"","eqp_type":2},{"record_id":100312,"open_type":4,"open_time":"2017-06-14T21:55:05.000Z","user_name":"大水哥","headpic":"","eqp_type":2},{"record_id":100311,"open_type":4,"open_time":"2017-06-14T21:53:26.000Z","user_name":"我是霉女","headpic":"http://47.93.7.216:3001/upload/headpic/U100025.jpg","eqp_type":2},{"record_id":100310,"open_type":4,"open_time":"2017-06-14T21:43:57.000Z","user_name":"大水哥","headpic":"","eqp_type":2}],"page":{"totalpage":1,"pagesize":20,"pagenum":1}}
     * code : 200
     */

    private String name;
    private ObjectBean object;
    private int code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public static class ObjectBean {
        /**
         * data : [{"record_id":100313,"open_type":4,"open_time":"2017-06-14T21:55:23.000Z","user_name":"大水哥","headpic":"","eqp_type":2},{"record_id":100312,"open_type":4,"open_time":"2017-06-14T21:55:05.000Z","user_name":"大水哥","headpic":"","eqp_type":2},{"record_id":100311,"open_type":4,"open_time":"2017-06-14T21:53:26.000Z","user_name":"我是霉女","headpic":"http://47.93.7.216:3001/upload/headpic/U100025.jpg","eqp_type":2},{"record_id":100310,"open_type":4,"open_time":"2017-06-14T21:43:57.000Z","user_name":"大水哥","headpic":"","eqp_type":2}]
         * page : {"totalpage":1,"pagesize":20,"pagenum":1}
         */

        private PageBean page;
        private List<DataBean> data;

        public PageBean getPage() {
            return page;
        }

        public void setPage(PageBean page) {
            this.page = page;
        }

        public List<DataBean> getData() {
            return data;
        }

        public void setData(List<DataBean> data) {
            this.data = data;
        }

        public static class PageBean {
            /**
             * totalpage : 1
             * pagesize : 20
             * pagenum : 1
             */

            private int totalpage;
            private int pagesize;
            private int pagenum;

            public int getTotalpage() {
                return totalpage;
            }

            public void setTotalpage(int totalpage) {
                this.totalpage = totalpage;
            }

            public int getPagesize() {
                return pagesize;
            }

            public void setPagesize(int pagesize) {
                this.pagesize = pagesize;
            }

            public int getPagenum() {
                return pagenum;
            }

            public void setPagenum(int pagenum) {
                this.pagenum = pagenum;
            }
        }

        public static class DataBean {
            /**
             * record_id : 100313
             * open_type : 4
             * open_time : 2017-06-14T21:55:23.000Z
             * user_name : 大水哥
             * headpic :
             * eqp_type : 2
             */

            private int record_id;
            private int open_type;
            private String open_time;
            private String user_name;
            private String headpic;
            private int eqp_type;

            public int getRecord_id() {
                return record_id;
            }

            public void setRecord_id(int record_id) {
                this.record_id = record_id;
            }

            public int getOpen_type() {
                return open_type;
            }

            public void setOpen_type(int open_type) {
                this.open_type = open_type;
            }

            public String getOpen_time() {
                return open_time;
            }

            public void setOpen_time(String open_time) {
                this.open_time = open_time;
            }

            public String getUser_name() {
                return user_name;
            }

            public void setUser_name(String user_name) {
                this.user_name = user_name;
            }

            public String getHeadpic() {
                return headpic;
            }

            public void setHeadpic(String headpic) {
                this.headpic = headpic;
            }

            public int getEqp_type() {
                return eqp_type;
            }

            public void setEqp_type(int eqp_type) {
                this.eqp_type = eqp_type;
            }
        }
    }
}
