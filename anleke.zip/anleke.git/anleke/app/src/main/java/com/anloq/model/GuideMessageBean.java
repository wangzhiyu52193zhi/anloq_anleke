package com.anloq.model;

import com.anloq.utils.TimeUtil;

/**
 * Created by xpf on 2017/7/13 :)
 * Function:新手引导消息的Bean
 */

public class GuideMessageBean {

    /**
     * name : guidemsg
     * time : 2017-05-20T13:04:52.863Z
     * object : {"title":"新手引导","content":"欢迎使用安络客，点击卡片申请钥匙，长按卡片开锁。详细操作在\u201c我的\u201d->\u201c帮助\u201d页面查看","command":0}
     */

    private String name;
    private String time;
    private ObjectBean object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return TimeUtil.getTime(time);
    }

    public void setTime(String time) {
        this.time = time;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * title : 新手引导
         * content : 欢迎使用安络客，点击卡片申请钥匙，长按卡片开锁。详细操作在“我的”->“帮助”页面查看
         * command : 0
         */

        private String title;
        private String content;
        private int command;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getCommand() {
            return command;
        }

        public void setCommand(int command) {
            this.command = command;
        }
    }
}
