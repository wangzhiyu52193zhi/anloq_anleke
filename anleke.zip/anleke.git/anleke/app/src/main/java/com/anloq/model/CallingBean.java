package com.anloq.model;

/**
 * Created by xpf on 2017/4/5 :)
 * Function:收到呼叫的Bean类
 */

public class CallingBean {

    /**
     * name : eqtcall
     * object : {"eqt_name":"中关村小区·100号楼1单元","eqt_id":"100003","unit_id":"100000","baoid":"94:a1:a2:a5:67:08","command":2}
     * time : 2017-05-27T15:43:21.390Z
     */

    private String name;
    private ObjectBean object;
    private String time;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public static class ObjectBean {
        /**
         * eqt_name : 中关村小区·100号楼1单元
         * eqt_id : 100003
         * unit_id : 100000
         * baoid : 94:a1:a2:a5:67:08
         * command : 2
         */

        private String eqt_name;
        private String eqt_id;
        private String unit_id;
        private String baoid;
        private int command;
        private String token;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getEqt_name() {
            return eqt_name;
        }

        public void setEqt_name(String eqt_name) {
            this.eqt_name = eqt_name;
        }

        public String getEqt_id() {
            return eqt_id;
        }

        public void setEqt_id(String eqt_id) {
            this.eqt_id = eqt_id;
        }

        public String getUnit_id() {
            return unit_id;
        }

        public void setUnit_id(String unit_id) {
            this.unit_id = unit_id;
        }

        public String getBaoid() {
            return baoid;
        }

        public void setBaoid(String baoid) {
            this.baoid = baoid;
        }

        public int getCommand() {
            return command;
        }

        public void setCommand(int command) {
            this.command = command;
        }
    }
}
