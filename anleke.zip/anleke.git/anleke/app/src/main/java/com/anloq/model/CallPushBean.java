package com.anloq.model;

/**
 * Created by xpf on 2017/8/12 :)
 * Function:呼叫推送的Bean
 */

public class CallPushBean {

    /**
     * eqt_name : 中关村小区·666号楼6单元
     * eqt_id : 100010
     * unit_id : 100014
     * baoid : 5c:f8:21:de:55:8c
     * command : 0
     */

    private String eqt_name;
    private String eqt_id;
    private String unit_id;
    private String baoid;
    private int command;

    public String getEqt_name() {
        return eqt_name;
    }

    public void setEqt_name(String eqt_name) {
        this.eqt_name = eqt_name;
    }

    public String getEqt_id() {
        return eqt_id;
    }

    public void setEqt_id(String eqt_id) {
        this.eqt_id = eqt_id;
    }

    public String getUnit_id() {
        return unit_id;
    }

    public void setUnit_id(String unit_id) {
        this.unit_id = unit_id;
    }

    public String getBaoid() {
        return baoid;
    }

    public void setBaoid(String baoid) {
        this.baoid = baoid;
    }

    public int getCommand() {
        return command;
    }

    public void setCommand(int command) {
        this.command = command;
    }
}
