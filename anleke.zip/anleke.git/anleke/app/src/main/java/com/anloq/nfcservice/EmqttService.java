package com.anloq.nfcservice;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.util.Log;

import com.anloq.activity.MainActivity;
import com.anloq.activity.WebRtcActivity;
import com.anloq.manager.DBManager;
import com.anloq.manager.GetManager;
import com.anloq.manager.VibratorManager;
import com.anloq.model.CallingBean;
import com.anloq.model.CallingImageBean;
import com.anloq.model.CheckZoneBean;
import com.anloq.model.EventBusMsg;
import com.anloq.model.GuideMessageBean;
import com.anloq.model.ImageResultBean;
import com.anloq.model.KeyPassMsgBean;
import com.anloq.model.MessageBean;
import com.anloq.model.NoticeMsgBean;
import com.anloq.model.PopMessageBean;
import com.anloq.model.RequestKeyBean;
import com.anloq.model.ServiceMsgBean;
import com.anloq.model.VkeyBean;
import com.anloq.ui.NotifcationView;
import com.anloq.utils.Base64Util;
import com.anloq.utils.MD5Utils;
import com.anloq.utils.MessageProvider;
import com.anloq.utils.ParseUtil;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.TimeUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttMessageListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.litepal.crud.DataSupport;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by xpf on 2017/4/1 :)
 * Function:消息接收、推送服务
 */

public class EmqttService extends Service {

    private static final String TAG = EmqttService.class.getSimpleName();
    private String clientId = ""; // 客户端唯一标识符
    private MqttAndroidClient mqttAndroidClient;
    private MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
    /**
     * a，安络平台系统消息，topic值为：anloq/system/
     * b，小区消息，topic值为：anloq/zone/小区ID
     * c，用户私人消息，topic值为：anloq/用户手机号＋用户密码
     * d，图片消息，topic值为："anloq/img/" + account + md5
     */
    private String[] mTopics;
    private ArrayList<String> mZoneTopics = new ArrayList<>();
    private List<byte[]> photoByteList = new ArrayList<>();
    private int[] qos;
    private String account = "";
    private String token = "";
    private String title = "";
    private String info = "";
    private IMqttMessageListener[] mqttList;

    // MQTT消息到达的监听器
    private IMqttMessageListener onMessageListener = new IMqttMessageListener() {
        @Override
        public void messageArrived(String topic, MqttMessage message) throws Exception {
            Logger.t(TAG).i("收到了一条Topic为：" + topic + "的消息~");
            Message msg = Message.obtain();
            msg.what = 1;
            msg.obj = message.toString();
            handler.sendMessage(msg);
        }
    };

    // MQTT连接状态的监听器
    private IMqttActionListener iMqttActionListener = new IMqttActionListener() {
        @Override
        public void onSuccess(IMqttToken asyncActionToken) {
            Logger.t(TAG).i("连接消息MQTT服务器成功~");
            DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
            disconnectedBufferOptions.setBufferEnabled(true);
            disconnectedBufferOptions.setBufferSize(100);
            disconnectedBufferOptions.setPersistBuffer(false);
            disconnectedBufferOptions.setDeleteOldestMessages(false);
            mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);
            subscribeSomeTopics(); // 连接成功后去订阅话题
        }

        @Override
        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
            Logger.t(TAG).e("Failed to connect to mqtt server,EXCEPTION===" + exception.toString());
        }
    };

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    try {
                        String obj = (String) msg.obj;
                        String json = new String(Base64.decode(obj, Base64.DEFAULT), "UTF-8");
                        Logger.t(TAG).json(json);
                        parseMsgType(json);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 3:
                    Logger.t(TAG).e("连接失败，系统正在重连");
                    break;
                case 4:
                    VibratorManager.stopViberate();
                    break;
                default:
                    break;
            }
        }
    };

    /**
     * 锁屏的管理类叫KeyguardManager，
     * 通过调用其内部类KeyguardLockmKeyguardLock的对象的disableKeyguard方法可以取消系统锁屏，
     * newKeyguardLock的参数用于标识是谁隐藏了系统锁屏
     */
    private BroadcastReceiver mScreenOReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.SCREEN_ON".equals(action)) {
                Logger.t(TAG).i("—— SCREEN_ON ——");
                //initData();
            } else if ("android.intent.action.SCREEN_OFF".equals(action)) {
                Logger.t(TAG).i("—— SCREEN_OFF ——");
                //initData();
            }
        }
    };

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onMessageEvent(EventBusMsg msg) {
        Logger.t(TAG).i("onEventMainThread收到了消息~");
        switch (msg.getType()) {
            case "start_send_photo":
                if (photoByteList != null && photoByteList.size() > 0) {
                    for (int i = 0; i < photoByteList.size(); i++) {
                        byte[] bytes = photoByteList.get(i);
                        EventBus.getDefault().post(bytes);
                    }
                }
                break;
            case "unsubscribe": // 退订
                // 1.退订系统、私人、呼叫topic
                for (int i = 0; i < mTopics.length; i++) {
                    unsubscribeOneTopic(mTopics[i]);
                }
                // 2.退订所有小区的topic
                for (int i = 0; i < mZoneTopics.size(); i++) {
                    unsubscribeOneTopic(mZoneTopics.get(i));
                }
                break;
            case "clearphoto": // 清理缓存照片
                if (photoByteList != null && photoByteList.size() > 0) {
                    photoByteList.clear();
                }
                break;
            default:
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onMessageEvent(CheckZoneBean zoneBean) {
        Logger.t(TAG).i("onEventMainThread收到了检测小区是否需要订阅的消息~");
        final String zoneId = zoneBean.getZoneId();
        final boolean isFreeze = zoneBean.isFreeze();
        // 延迟2S去订阅，避免消息服务器还没连接成功就去订阅！
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                checkZoneMessageLogic(zoneId, isFreeze);
            }
        }, 2000);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Logger.t(TAG).i("onCreate()消息服务创建了");
        EventBus.getDefault().register(this);
        /* 注册屏幕唤醒时的广播 */
        IntentFilter mScreenOnFilter = new IntentFilter("android.intent.action.SCREEN_ON");
        registerReceiver(mScreenOReceiver, mScreenOnFilter);
        /* 注册机器锁屏时的广播 */
        IntentFilter mScreenOffFilter = new IntentFilter("android.intent.action.SCREEN_OFF");
        registerReceiver(mScreenOReceiver, mScreenOffFilter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 放到此处是为了解决呼叫过程中断网重连问题，后续可接收网络变化广播来处理
        initData();
        return START_STICKY;
    }

    public void initData() {
        account = SpUtil.getInstance().getString("account", "");
        token = SpUtil.getInstance().getString("token", "");
        String password = SpUtil.getInstance().getString("password", "");
        String md5 = MD5Utils.MD5(password);
        clientId = account;
        String systemTopic = "anloq/system/";//系统消息
        String privateTopic = "anloq/" + account + md5;
        String callTopic = "anloq/call/" + account + md5;
        qos = new int[]{2, 2, 0};
        mTopics = new String[]{systemTopic, privateTopic, callTopic};
        mqttList = new IMqttMessageListener[]{onMessageListener, onMessageListener, onMessageListener};
        setListener();
        connect();
    }

    /**
     * 解析收到的消息类型
     */
    private void parseMsgType(String json) {
        String name = RequestUtil.getName(json);
        switch (name) { // 收到钥匙
            case "vkey":
                DBManager.getInstance().updateVkeyList(json); // 保存在本地数据库
                break;
            case "eqtcall": // 收到呼叫消息(不需要缓存)
                parseCalling(json);
                break;
            case "popmsg": // 收到顶部弹窗消息(例如远程开门后收到的消息)
                // TODO: 顶部弹窗提示 2017/5/24 现暂用toast代替
                Logger.t(TAG).json(json);
                PopMessageBean popMessageBean = new Gson().fromJson(json, PopMessageBean.class);
                String titleResult = popMessageBean.getObject().getTitle();
                String content = popMessageBean.getObject().getContent();
                ToastUtil.show(titleResult + ":" + content);
                EventBus.getDefault().post(new EventBusMsg("unlockresult", ""));
                break;
            case "servicemsg": // 收到钥匙业务通知(例如钥匙被驳回、冻结、解冻、删除通知)
                // false表示未读消息
                MessageBean servicemsg = new MessageBean("servicemsg", json, false);
                EventBus.getDefault().post(servicemsg);
                if (json.contains("驳回")) { // 如果是驳回申请才去更新cards，重新授权不需要更新卡片！！！
                    EventBusMsg msg = new EventBusMsg("updatecards", "");
                    EventBus.getDefault().post(msg);
                }
                ServiceMsgBean serviceMsgBean = new Gson().fromJson(json, ServiceMsgBean.class);
                title = serviceMsgBean.getObject().getTitle();
                info = serviceMsgBean.getObject().getContent();
                if (!MainActivity.isVisible) {
                    MessageProvider.getInstance().addMsgData(servicemsg);
                }
                break;
            case "rqkeymsg": // 收到申请钥匙请求
                MessageBean rqkeymsg = new MessageBean("rqkeymsg", json, false);
                EventBus.getDefault().post(rqkeymsg);
                RequestKeyBean requestKeyBean = new Gson().fromJson(json, RequestKeyBean.class);
                title = requestKeyBean.getObject().getTitle();
                info = json;
                if (!MainActivity.isVisible) {
                    MessageProvider.getInstance().addMsgData(rqkeymsg);
                }
                break;
            case "noticemsg": // 收到公告通知
                // 1.堵漏处理：查询本地的虚拟钥匙数量
                List<VkeyBean> allVkeys = DBManager.getInstance().getAllVkeys();
                // 2.如果没有一把虚拟钥匙就不让其收到公告消息
                if (allVkeys == null || allVkeys.size() == 0) {
                    return;
                }

                MessageBean noticemsg = new MessageBean("noticemsg", json, false);
                EventBus.getDefault().post(noticemsg);
                NoticeMsgBean noticeMsgBean = new Gson().fromJson(json, NoticeMsgBean.class);
                title = "收到一条公告消息";
                info = noticeMsgBean.getObject().getContent();
                if (!MainActivity.isVisible) {
                    MessageProvider.getInstance().addMsgData(noticemsg);
                }
                break;
            case "keypassmsg": // 收到key审核通过通知
                MessageBean keypassmsg = new MessageBean("keypassmsg", json, false);
                EventBus.getDefault().post(keypassmsg);
                KeyPassMsgBean keyPassMsgBean = new Gson().fromJson(json, KeyPassMsgBean.class);
                title = keyPassMsgBean.getObject().getTitle();
                info = keyPassMsgBean.getObject().getContent();
                if (!MainActivity.isVisible) {
                    MessageProvider.getInstance().addMsgData(keypassmsg);
                }
                break;
            case "modifyvkey": // 收到钥匙被删除、冻结等消息
                DBManager.getInstance().modifyKeys(json);
                break;
            case "guidemsg":
                MessageBean guidemsg = new MessageBean("guidemsg", json, false);
                EventBus.getDefault().post(guidemsg);
                GuideMessageBean guideMessageBean = new Gson().fromJson(json, GuideMessageBean.class);
                title = guideMessageBean.getObject().getTitle();
                info = guideMessageBean.getObject().getContent();
                if (!MainActivity.isVisible) {
                    MessageProvider.getInstance().addMsgData(guidemsg);
                }
                break;
            case "getcallimg":
                CallingImageBean imageBean = new Gson().fromJson(json, CallingImageBean.class);
                CallingImageBean.ObjectBean object = imageBean.getObject();
                if (object != null) {
                    String unit_id = object.getUnit_id();
                    String image_id = object.getImage_id();
                    GetManager.getInstance().getImage(unit_id, image_id
                            , new GetManager.OnCallingListener() {
                                @Override
                                public void onImageComing(String result) {
                                    if (!"".equals(result)) {
                                        Log.e("TAG", "result===" + result);
                                        ImageResultBean bean = new Gson().fromJson(result, ImageResultBean.class);
                                        ImageResultBean.ObjectBean image = bean.getObject();
                                        if (image != null) {
                                            byte[] bytes = Base64Util.stringToDecodeByte(image.getImg_buf());
                                            if (WebRtcActivity.isVisiblity) {
                                                try {
                                                    EventBus.getDefault().post(bytes);
                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                }
                                            } else {
                                                photoByteList.add(bytes);
                                            }
                                        }
                                    }
                                }
                            });
                }
                break;
            default:
                break;
        }

        if (!"".equals(title) && !"".equals(info)) {
            int disturb_state = SpUtil.getInstance().getInt(SpUtil.getDisturbStateKey(), 2);
            Logger.t(TAG).i("disturb_state===" + disturb_state);
            if (disturb_state == 0) {
                return;
            } else if (disturb_state == 1) {
                if (TimeUtil.isInSection()) {
                    Logger.t(TAG).e("当前在免打扰时间段内");
                    return;
                }
            }
            boolean messagevibrate = SpUtil.getInstance().getBoolean("messagevibrate", true);
            if (messagevibrate) {
                VibratorManager.startVibrate();
                handler.sendEmptyMessageDelayed(4, 2000);
            }
            NotifcationView.show(title, info);
            title = "";
            info = "";
        }
    }

    private void parseCalling(final String json) {
        CallingBean callingBean = new Gson().fromJson(json, CallingBean.class);
        String time = callingBean.getTime();

        // TODO 暂不实现此功能 是否需要接听
        /*if (!SpUtil.getInstance().getBoolean("isaccept", true)) {
            Log.e(TAG, "您当前的设置为不可接听状态");
            return;
        }*/
        // 来电或挂断时间超过2min之前即不处理
        if (TimeUtil.isMoreTwoMinutes(time)) {
            Logger.t(TAG).e("您呼叫的用户已经超过2min请稍后再拨。");
            return;
        }

        // 对比token是否过期################# 暂不处理token校验！！！
        /*String romote_token = callingBean.getObject().getToken();
        String local_token = SpUtil.getInstance().getString("token", "");
        if (local_token != null) {
            if (!local_token.equals(romote_token)) {
                RequestUtil.showInvalidView(this);
                Log.e("TAG", "呼叫或挂断时本地token与远程token不一致！");
                return;
            }
        }*/

        int disturb_state = SpUtil.getInstance().getInt(SpUtil.getDisturbStateKey(), 2);
        Logger.t(TAG).e("disturb_state===" + disturb_state);
        if (disturb_state == 0) {
            return;
        } else if (disturb_state == 1) {
            if (TimeUtil.isInSection()) {
                Logger.t(TAG).e("当前在免打扰时间段内");
                return;
            }
        }

        CallingBean.ObjectBean object = callingBean.getObject();
        if (object != null) {
            switch (object.getCommand()) {
                case 0: // 呼叫
                    String content = "{\"eqt_name\":\"" + object.getEqt_name() + "\",\"baoid\":\"" + object.getBaoid()
                            + "\",\"eqt_id\":\"" + object.getEqt_id() + "\",\"unit_id\":\"" + object.getUnit_id()
                            + "\",\"command\":" + object.getCommand() + "}";
                    Log.e("content", content);
                    // 通话中又如果来电即不处理
                    if (WebRtcActivity.iscalling) {
                        Log.e(TAG, "您呼叫的用户正在通话中，请稍后再拨！！！");
                        ParseUtil.uploadBusyState(object.getBaoid());
                    } else {
                        ParseUtil.joinQueue(content);
                    }
                    break;
                case 2: // 挂断
                    // 1.处理通话中按HOME键后，还没进入APP，但安络保已经挂断的异常！！！
                    SpUtil.getInstance().save("iscaller", false);
                    SpUtil.getInstance().save("presshome", false);
                    // 2.发送挂断消息 -> WebRtcActivity
                    EventBus.getDefault().post(new EventBusMsg("receivedendcall", ""));
                    break;
                default:
                    break;
            }

        }
    }

    /**
     * 小区消息的逻辑处理,在这里定义
     *
     * @param zone_id
     * @param addkey  false为退订，true为添加topic并订阅
     */
    public void checkZoneMessageLogic(String zone_id, boolean addkey) {
        int count = 0;
        String topic = "anloq/zone/" + zone_id;

        if (zone_id != null) {
            if (addkey) {
                if (!mZoneTopics.contains(topic)) {
                    mZoneTopics.add(topic);
                    subscribeOneTopic(topic, 2);
                }
            } else {
                List<VkeyBean> keyList = DataSupport.where("zone_id = ?", zone_id).find(VkeyBean.class);
                // 如果没有当前小区的钥匙了就退订当前小区的topic,否则不处理
                if (keyList == null || keyList.size() == 0) {
                    if (mZoneTopics.contains(topic)) {
                        mZoneTopics.remove(topic);
                    }
                    unsubscribeOneTopic(topic);
                } else {
                    for (int i = 0; i < keyList.size(); i++) {
                        VkeyBean vkeyBean = keyList.get(i);
                        // 1.查找有效钥匙的数量
                        if (!vkeyBean.is_freeze() && vkeyBean.getKey_status() == 2) {
                            count++;
                        }
                    }
                    // 2.如果有效的钥匙为0个就退订
                    if (count == 0) {
                        if (mZoneTopics.contains(topic)) {
                            mZoneTopics.remove(topic);
                        }
                        unsubscribeOneTopic(topic);
                    }
                }
            }
        } else {
            Logger.t(TAG).e("checkZoneMessageLogic zone_id == null！！！");
        }

    }

    /**
     * 退订单个Topic
     *
     * @param topic
     */
    private void unsubscribeOneTopic(final String topic) {
        try {
            mqttAndroidClient.unsubscribe(topic, getApplicationContext(), new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Logger.t(TAG).i("退订Topic:" + topic + "成功~");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Logger.t(TAG).e("退订Topic:" + topic + "失败！");
                }
            });
            mqttAndroidClient.unsubscribe(topic);

        } catch (MqttException e) {
            Logger.t(TAG).e("unsubscribeOneTopic Exception!");
            e.printStackTrace();
        }
    }

    private void setListener() {
        String mqtt_server = SpUtil.getInstance().getString("mqtt_server", "");
        Logger.t(TAG).i("MQTT Server===" + mqtt_server);
        mqttAndroidClient = new MqttAndroidClient(getApplicationContext(), mqtt_server, clientId);
        mqttAndroidClient.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                if (reconnect) {
                    Logger.t(TAG).e("Reconnected to : " + serverURI);
                    // Because Clean Session is true, we need to re-subscribe
                    // subscribeSomeTopics(); // @避免重复订阅
                } else {
                    Logger.t(TAG).i("Connected to: " + serverURI);
                }
            }

            @Override
            public void connectionLost(Throwable cause) {
                Logger.t(TAG).e("The Connection was lost.");
                // TODO: 2017/6/11  connect();//@是否需要再次连接
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Logger.t(TAG).i("收到了一条Topic:" + topic + "的消息");
                Message msg = Message.obtain();
                msg.what = 1;
                msg.obj = message.toString();
                handler.sendMessage(msg);
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Logger.t(TAG).i("deliveryComplete()");
            }
        });
    }

    /**
     * 连接到消息服务器
     */
    private void connect() throws RuntimeException {
        if ("".equals(account) || "".equals(token)) {
            Log.e(TAG, "To connect MQTT server failed because account or token is null!");
        } else {
            mqttConnectOptions.setAutomaticReconnect(true);
            mqttConnectOptions.setCleanSession(false); // 不清理会话，即设置消息缓存
            mqttConnectOptions.setUserName(account);
            mqttConnectOptions.setPassword(token.toCharArray());
            mqttConnectOptions.setConnectionTimeout(30);
            mqttConnectOptions.setKeepAliveInterval(20);

            try {
                mqttAndroidClient.connect(mqttConnectOptions, null, iMqttActionListener);
            } catch (MqttException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * 订阅一组Topics
     */
    private void subscribeSomeTopics() {
        try {
            mqttAndroidClient.subscribe(mTopics, qos, getApplicationContext(),
                    new IMqttActionListener() {
                        @Override
                        public void onSuccess(IMqttToken asyncActionToken) {
                            Logger.t(TAG).i("mTopics订阅成功~");
                        }

                        @Override
                        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                            Logger.t(TAG).e("mTopics订阅失败！");
                        }
                    });

            mqttAndroidClient.subscribe(mTopics, qos, mqttList);

        } catch (NullPointerException ex) {
            Logger.t(TAG).e("NullPointerException===" + ex.toString());
        } catch (MqttException ex) {
            Logger.t(TAG).i("Exception whilst subscribing");
            ex.printStackTrace();
        }
    }

    /**
     * 订阅一个Topic
     */
    private void subscribeOneTopic(final String topic, int qos) {
        try {
            mqttAndroidClient.subscribe(topic, qos, getApplicationContext(),
                    new IMqttActionListener() {
                        @Override
                        public void onSuccess(IMqttToken asyncActionToken) {
                            Logger.t(TAG).i("Topic:" + topic + "订阅成功~");
                        }

                        @Override
                        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                            Logger.t(TAG).e("Topic:" + topic + "订阅失败！");
                        }
                    });

            mqttAndroidClient.subscribe(topic, qos, onMessageListener);

        } catch (NullPointerException ex) {
            Logger.t(TAG).e("NullPointerException===" + ex.toString());
        } catch (MqttException ex) {
            Logger.t(TAG).i("While subscribing Exception===" + ex.toString());
            ex.printStackTrace();
        }
    }

    /**
     * 发布指定Topic的消息
     */
    private void publishMessage(String et_content) {
        String publishTopic = "World"; // 发布话题
        try {
            MqttMessage message = new MqttMessage();
            message.setPayload(et_content.getBytes("UTF-8"));
            mqttAndroidClient.publish(publishTopic, message);
            Logger.t(TAG).i("Message Published");
            if (!mqttAndroidClient.isConnected()) {
                Logger.t(TAG).i(mqttAndroidClient.getBufferedMessageCount() + " messages in buffer.");
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MqttException e) {
            Logger.t(TAG).e("Error Publishing: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Logger.t(TAG).e("onDestroy()");
        EventBus.getDefault().unregister(this);
        handler.removeCallbacksAndMessages(null);
        unregisterReceiver(mScreenOReceiver);
        // 避免对象被销毁，杀死服务后仍能收到消息！！！
        if (mqttAndroidClient != null && mqttAndroidClient.isConnected()) {
            try {
                mqttAndroidClient.disconnect();
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
    }

}
