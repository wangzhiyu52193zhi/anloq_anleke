package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/3/28 :)
 * Function:楼栋数据的Bean类
 */
public class BuildingBean {

    /**
     * name : buildings
     * object : [{"building_id":1,"building_name":"1号楼"},{"building_id":2,"building_name":"2号楼"},{"building_id":3,"building_name":"3号楼"},{"building_id":4,"building_name":"4号楼"},{"building_id":5,"building_name":"5号楼"},{"building_id":6,"building_name":"6号楼"}]
     * code : 200
     */

    private String name;
    private int code;
    private List<ObjectBean> object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<ObjectBean> getObject() {
        return object;
    }

    public void setObject(List<ObjectBean> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * building_id : 1
         * building_name : 1号楼
         */

        private int building_id;
        private String building_name;

        public int getBuilding_id() {
            return building_id;
        }

        public void setBuilding_id(int building_id) {
            this.building_id = building_id;
        }

        public String getBuilding_name() {
            return building_name;
        }

        public void setBuilding_name(String building_name) {
            this.building_name = building_name;
        }
    }
}
