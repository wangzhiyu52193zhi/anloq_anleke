package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/11/1 :)
 * Function:账户交易的Bean
 */

public class AccountTradeBean {

    /**
     * name : account trade
     * object : [{"month":"2017-11","records":[{"time":"2017-11-01 23:59:59","amount":"+0.37","type":4,"status":4}]},{"month":"2017-10","records":[{"time":"2017-10-31 23:59:59","amount":"+14.55","type":4,"status":4},{"time":"2017-10-30 23:59:59","amount":"+22.03","type":4,"status":4},{"time":"2017-10-29 23:59:59","amount":"+13.21","type":4,"status":4},{"time":"2017-10-28 23:59:59","amount":"+4.55","type":4,"status":4},{"time":"2017-10-27 23:59:59","amount":"+2.03","type":4,"status":4},{"time":"2017-10-26 23:59:59","amount":"+3.21","type":4,"status":4},{"time":"2017-10-25 23:59:59","amount":"+1.15","type":4,"status":4},{"time":"2017-10-17 23:59:59","amount":"+11.11","type":4,"status":4}]}]
     * code : 200
     */

    private String name;
    private int code;
    private List<ObjectBean> object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<ObjectBean> getObject() {
        return object;
    }

    public void setObject(List<ObjectBean> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * month : 2017-11
         * records : [{"time":"2017-11-01 23:59:59","amount":"+0.37","type":4,"status":4}]
         */

        private String month;
        private List<RecordsBean> records;

        public String getMonth() {
            return month;
        }

        public void setMonth(String month) {
            this.month = month;
        }

        public List<RecordsBean> getRecords() {
            return records;
        }

        public void setRecords(List<RecordsBean> records) {
            this.records = records;
        }

        public static class RecordsBean {
            /**
             * time : 2017-11-01 23:59:59
             * amount : +0.37
             * type : 4
             * status : 4
             */

            private String time;
            private String amount;
            private int type;
            private int status;

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getAmount() {
                return amount;
            }

            public void setAmount(String amount) {
                this.amount = amount;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }
    }
}
