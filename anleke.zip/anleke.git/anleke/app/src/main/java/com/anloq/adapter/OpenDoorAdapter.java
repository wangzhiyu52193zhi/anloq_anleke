package com.anloq.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.model.UnlockRecordBean;
import com.anloq.ui.GlideCircleTransform;
import com.bumptech.glide.Glide;

import java.util.List;

/**
 * Created by xpf on 2017/6/6 :)
 * Function:开门记录的适配器
 */

public class OpenDoorAdapter extends RecyclerView.Adapter {

    private Context mContext;
    private List<UnlockRecordBean.ObjectBean.DataBean> allData;
    private LayoutInflater mLayoutInflater;
    private String lastDate = "";

    public OpenDoorAdapter(Context mContext, List<UnlockRecordBean.ObjectBean.DataBean> allData) {
        this.mContext = mContext;
        this.allData = allData;
        mLayoutInflater = LayoutInflater.from(mContext);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(mLayoutInflater.inflate(R.layout.item_opendoor_record, null));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyViewHolder myHolder = (MyViewHolder) holder;
        myHolder.setData(position);
    }

    @Override
    public int getItemCount() {
        return allData.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView tvTime;
        private ImageView ivIcon;
        private TextView tvName;
        private TextView tvType;
        private TextView tvLocation;
        private TextView tvTitleDate;

        public MyViewHolder(View itemView) {
            super(itemView);
            tvTime = (TextView) itemView.findViewById(R.id.tvTime);
            tvName = (TextView) itemView.findViewById(R.id.tvName);
            tvType = (TextView) itemView.findViewById(R.id.tvType);
            tvLocation = (TextView) itemView.findViewById(R.id.tvLocation);
            tvTitleDate = (TextView) itemView.findViewById(R.id.tvTitleDate);
            ivIcon = (ImageView) itemView.findViewById(R.id.ivIcon);
        }

        public void setData(int position) {
            UnlockRecordBean.ObjectBean.DataBean record = allData.get(position);
            if (record.getHeadpic() != null && !"".equals(record.getHeadpic())) {
                Glide.with(mContext)
                        .load(record.getHeadpic())
                        .transform(new GlideCircleTransform(mContext))
                        .crossFade()
                        .into(ivIcon);

            }
            tvName.setText(record.getUser_name());
            tvTime.setText(record.getOpen_time().substring(11, 16));
            String currentDate = record.getOpen_time().substring(0, 10);
            if (lastDate.equals(currentDate)) {
                tvTitleDate.setVisibility(View.GONE);
            } else {
                tvTitleDate.setText(currentDate);
                lastDate = currentDate;
            }
            switch (record.getOpen_type()) {
                case 1:
                    tvType.setText("蓝牙");
                    break;
                case 2:
                    tvType.setText("RFID卡");
                    break;
                case 3:
                    tvType.setText("NFC");
                    break;
                case 4:
                    tvType.setText("远程");
                    break;
                case 5:
                    tvType.setText("二维码");
                    break;
            }
            switch (record.getEqp_type()) {
                case 1:
                    tvLocation.setText("(小区门禁)");
                    break;
                case 2:
                    tvLocation.setText("(单元门禁)");
                    break;
            }
        }
    }

}
