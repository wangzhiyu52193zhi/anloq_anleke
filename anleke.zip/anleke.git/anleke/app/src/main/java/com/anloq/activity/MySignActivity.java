package com.anloq.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import com.anloq.anleke.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

// 我的徽章页面
public class MySignActivity extends Activity {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.listView)
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_sign);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.ivBack)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
        }
    }
}
