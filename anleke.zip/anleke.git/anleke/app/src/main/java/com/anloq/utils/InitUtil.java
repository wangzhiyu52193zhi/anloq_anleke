package com.anloq.utils;

import com.anloq.model.BuildingBean;
import com.anloq.model.RoomBean;
import com.anloq.model.UnitBean;

import java.util.List;


/**
 * Created by xpf on 2017/5/21 :)
 * Function:初始化数据的工具类
 */

public class InitUtil {

    /**
     * 初始化楼栋数据
     *
     * @param list
     * @return
     */
    public static String[] initBuildingData(List<BuildingBean.ObjectBean> list) {
        String[] mData = null;
        if (list != null && list.size() > 0) {
            mData = new String[list.size()];
            for (int i = 0; i < list.size(); i++) {
                mData[i] = list.get(i).getBuilding_name();
            }
        }
        return mData;
    }

    /**
     * 初始化单元数据
     *
     * @param list
     * @return
     */
    public static String[] initUnitData(List<UnitBean.ObjectBean> list) {
        String[] mData = null;
        if (list != null && list.size() > 0) {
            mData = new String[list.size()];
            for (int i = 0; i < list.size(); i++) {
                mData[i] = list.get(i).getUnit_name();
            }
        }
        return mData;
    }

    /**
     * 初始化房间数据
     *
     * @param list
     * @return
     */
    public static String[] initRoomData(List<RoomBean.ObjectBean> list) {
        String[] mData = null;
        if (list != null && list.size() > 0) {
            mData = new String[list.size()];
            for (int i = 0; i < list.size(); i++) {
                mData[i] = list.get(i).getRoom_name();
            }
        }
        return mData;
    }
}
