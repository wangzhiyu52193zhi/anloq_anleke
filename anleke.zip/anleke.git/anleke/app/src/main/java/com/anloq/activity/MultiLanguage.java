package com.anloq.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.utils.LocaleUtils;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;

import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

// 多语言选择页面
public class MultiLanguage extends Activity {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvSave)
    TextView tvSave;
    @BindView(R.id.rbSimpleChinese)
    RadioButton rbSimpleChinese;
    @BindView(R.id.rbFantiChinese)
    RadioButton rbFantiChinese;
    @BindView(R.id.rbEnglish)
    RadioButton rbEnglish;
    @BindView(R.id.rgLanguages)
    RadioGroup rgLanguages;
    private int currentLanguage = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multi_language);
        ButterKnife.bind(this);
        initData();
        initListener();
    }

    private void initData() {
        int language = SpUtil.getInstance().getInt("currentlanguage", currentLanguage);
        switch (language) {
            case 0:
                rgLanguages.check(R.id.rbSimpleChinese);
                break;
            case 1:
                rgLanguages.check(R.id.rbFantiChinese);
                break;
            case 2:
                rgLanguages.check(R.id.rbEnglish);
                break;
        }
    }

    private void initListener() {
        rgLanguages.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbSimpleChinese:
                        currentLanguage = 0;
                        break;
                    case R.id.rbFantiChinese:
                        currentLanguage = 1;
                        break;
                    case R.id.rbEnglish:
                        currentLanguage = 2;
                        break;
                }
            }
        });
    }

    @OnClick({R.id.ivBack, R.id.tvSave})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.tvSave:
                changeAppLanguage();
                break;
        }
    }

    private void changeAppLanguage() {
        SpUtil.getInstance().save("currentlanguage", currentLanguage);
        Locale myLocale = Locale.SIMPLIFIED_CHINESE;
        // 0 简体中文 1 繁体中文 2 English
        switch (currentLanguage) {
            case 0:
                myLocale = Locale.SIMPLIFIED_CHINESE;
                break;
            case 1:
                myLocale = Locale.TRADITIONAL_CHINESE;
                break;
            case 2:
                myLocale = Locale.ENGLISH;
                break;
        }
        // 本地语言设置
        if (LocaleUtils.needUpdateLocale(this, myLocale)) {
            LocaleUtils.updateLocale(this, myLocale);
        }
        ToastUtil.show(getString(R.string.set_success));
        reloadApp();
    }

    /**
     * 重启app生效
     */
    public void reloadApp() {
        Intent intent = new Intent(MultiLanguage.this, WelcomeActivity.class);
        intent.setAction(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        overridePendingTransition(0, 0);
    }

}
