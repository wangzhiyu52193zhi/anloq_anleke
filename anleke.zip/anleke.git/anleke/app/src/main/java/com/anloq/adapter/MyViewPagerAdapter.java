package com.anloq.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.anloq.base.BaseFragment;

import java.util.List;

/**
 * Created by xpf on 2017/5/4 :)
 * Function:首页底部ViewPager卡片的适配器
 */

public class MyViewPagerAdapter extends FragmentStatePagerAdapter {

    private List<BaseFragment> cardFragments;

    public MyViewPagerAdapter(FragmentManager fm, List<BaseFragment> cardFragments) {
        super(fm);
        this.cardFragments = cardFragments;
    }

    @Override
    public Fragment getItem(int position) {
        return cardFragments.get(position);
    }

    @Override
    public int getCount() {
        return cardFragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return null;
    }

}
