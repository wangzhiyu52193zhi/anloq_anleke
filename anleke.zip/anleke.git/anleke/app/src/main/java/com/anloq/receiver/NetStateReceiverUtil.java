package com.anloq.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.anloq.MyApplication;
import com.anloq.activity.MainActivity;
import com.anloq.activity.WebRtcActivity;
import com.anloq.model.EventBusMsg;
import com.anloq.nfcservice.EmqttService;
import com.anloq.utils.WorkUtil;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by xpf on 2018/1/29 :)
 * Function:接收网络状态改变的广播(7.0之后只能动态注册)
 */

public class NetStateReceiverUtil {

    private Context mContext;
    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // @开启我们的Observere service
            //context.startService(new Intent(context, ObserverService.class));
            NetworkInfo.State wifiState = null;
            NetworkInfo.State mobileState = null;
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) {
                return;
            }
            NetworkInfo netinfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            if (netinfo != null) {
                wifiState = netinfo.getState();
            }
            netinfo = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            if (netinfo != null) {
                mobileState = netinfo.getState();
            }

            if (wifiState != null && mobileState != null
                    && NetworkInfo.State.CONNECTED != wifiState
                    && NetworkInfo.State.CONNECTED == mobileState) {
                // 手机网络连接成功
                sendState("net_nice");
            } else if (wifiState != null && mobileState != null
                    && NetworkInfo.State.CONNECTED != wifiState
                    && NetworkInfo.State.CONNECTED != mobileState) {
                // 手机没有任何的网络
                sendState("net_error");
            } else if (wifiState != null && NetworkInfo.State.CONNECTED == wifiState) {
                // 无线网络连接成功
                sendState("net_nice");
            }
        }
    };

    /**
     * constructor
     *
     * @param context
     */
    public NetStateReceiverUtil(Context context) {
        this.mContext = context;
    }

    /**
     * register
     */
    public void register() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        mContext.registerReceiver(receiver, intentFilter);
    }

    /**
     * unregister
     */
    public void unregister() {
        mContext.unregisterReceiver(receiver);
    }

    /**
     * 发送状态到通知页面
     *
     * @param state
     */
    private void sendState(String state) {
        // 网络异常时处理
        switch (state) {
            case "net_nice":
                if (WorkUtil.isServiceWorked(MyApplication.getContext(), "com.anloq.nfcservice.EmqttService")) {
                    MyApplication.getContext().startService(new Intent(MyApplication.getContext(), EmqttService.class));
                }
                break;
            case "net_error":
                MyApplication.getContext().stopService(
                        new Intent(MyApplication.getContext(), EmqttService.class));
                break;
        }
        if (MainActivity.isVisible || WebRtcActivity.isVisiblity) {
            EventBus.getDefault().post(new EventBusMsg(state, ""));
        }
    }

}
