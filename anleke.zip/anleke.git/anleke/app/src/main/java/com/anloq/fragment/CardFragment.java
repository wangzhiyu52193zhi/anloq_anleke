package com.anloq.fragment;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anloq.activity.ManagerAuth;
import com.anloq.activity.NormalAuthActivity;
import com.anloq.activity.QrcodeAuth;
import com.anloq.anleke.R;
import com.anloq.base.BaseFragment;
import com.anloq.manager.FeatureManager;
import com.anloq.model.EventBusMsg;
import com.anloq.model.VKeysPkgBean;
import com.anloq.ui.CardView;
import com.anloq.ui.GlideCircleTransform;
import com.anloq.ui.GlideRoundTransform;
import com.anloq.utils.TimeUtil;
import com.bumptech.glide.Glide;
import com.orhanobut.logger.Logger;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by xpf on 2017/3/22:)
 * Function:卡片页面的Fragment
 */

public class CardFragment extends BaseFragment {

    private final static String TAG = CardFragment.class.getSimpleName();
    @BindView(R.id.ivOwner)
    ImageView ivOwner;
    @BindView(R.id.tvOwnerName)
    TextView tvOwnerName;
    @BindView(R.id.ivPosition)
    ImageView ivPosition;
    @BindView(R.id.tvPositionName)
    TextView tvPositionName;
    @BindView(R.id.tvNormal)
    TextView tvNormal;
    @BindView(R.id.tvQrcode)
    TextView tvQrcode;
    @BindView(R.id.tvManager)
    TextView tvManager;
    @BindView(R.id.llAllView)
    LinearLayout llAllView;
    @BindView(R.id.llInDate)
    LinearLayout llInDate;
    @BindView(R.id.ivCard)
    ImageView ivCard;
    @BindView(R.id.tvCover)
    TextView tvCover;
    @BindView(R.id.tvDistrict)
    TextView tvDistrict;
    @BindView(R.id.ivNfc)
    ImageView ivNfc;
    @BindView(R.id.ivBle)
    ImageView ivBle;
    @BindView(R.id.tvZone)
    TextView tvZone;
    @BindView(R.id.tvBuilding)
    TextView tvBuilding;
    @BindView(R.id.tvUnit)
    TextView tvUnit;
    @BindView(R.id.tvRoom)
    TextView tvRoom;
    @BindView(R.id.tvStartDate)
    TextView tvStartDate;
    @BindView(R.id.tvEndDate)
    TextView tvEndDate;
    @BindView(R.id.tvApply)
    TextView tvApply;
    @BindView(R.id.tvNoPower)
    TextView tvNoPower;
    @BindView(R.id.rlCard)
    RelativeLayout rlCard;
    @BindView(R.id.ivNoPower)
    ImageView ivNoPower;
    @BindView(R.id.llNoPower)
    LinearLayout llNoPower;
    private VKeysPkgBean.ObjectBean objectBean;
    private boolean is_freeze;
    private String device_key_sr;
    private String first_key;
    private int key_status; //"key_status": 1, //钥匙状态 1-待审核，2-已通过，3-已驳回
    private String room_admin_name, unit_name, building_name, zone_name, image_url,
            province_name, city_name, auth_start_date, auth_end_date, bt_device_mac;
    private int expire_type, auth_count, city_id, room_id, unit_id, building_id,
            province_id, zone_id, relation, key_id;
    private String zone_key_color, room_name, user_phone;

    public String getDevice_key_sr() {
        return device_key_sr;
    }

    public String getFirst_key() {
        return first_key;
    }

    public String getUser_phone() {
        return user_phone;
    }

    public int getKey_id() {
        return key_id;
    }

    public VKeysPkgBean.ObjectBean getVKeysObjectBean() {
        return objectBean;
    }

    public void setObjectBean(VKeysPkgBean.ObjectBean objectBean) {
        this.objectBean = objectBean;
    }

    @Override
    public View initView() {
        View view = View.inflate(mContext, R.layout.fragment_card, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        EventBus.getDefault().register(this);
        initCardInformation();
        initListener();
    }

    /**
     * 初始化卡片信息
     */
    private void initCardInformation() {
        if (objectBean != null) {
            VKeysPkgBean.ObjectBean.KeyInfoBean object = objectBean.getKey_info();
            VKeysPkgBean.ObjectBean.RoomInfoBean room_info = objectBean.getRoom_info();
            VKeysPkgBean.ObjectBean.AdminInfoBean admin_info = objectBean.getAdmin_info();
            key_id = object.getKey_id();
            user_phone = object.getUser_phone();
            expire_type = object.getExpire_type();
            auth_start_date = object.getAuth_start_date();
            auth_end_date = object.getAuth_end_date();
            auth_count = object.getAuth_count();
            device_key_sr = object.getDevice_key_sr();
            first_key = object.getFirst_key();
            key_status = object.getKey_status();
            is_freeze = object.isIs_freeze();
            relation = room_info.getRelation();
            image_url = room_info.getImage();
            zone_name = room_info.getZone_name();
            province_name = room_info.getProvince_name();
            city_name = room_info.getCity_name();
            building_name = room_info.getBuilding_name();
            unit_name = room_info.getUnit_name();
            city_id = room_info.getCity_id();
            room_id = room_info.getRoom_id();
            room_name = room_info.getRoom_name();
            unit_id = room_info.getUnit_id();
            building_id = room_info.getBuilding_id();
            province_id = room_info.getProvince_id();
            room_admin_name = admin_info.getRoom_admin_name();
            zone_id = room_info.getZone_id();
            zone_key_color = room_info.getZone_key_color();

            if (!"".equals(image_url)) {
                Glide.with(mContext)
                        .load(image_url)
                        .transform(new GlideRoundTransform(mContext))
                        .crossFade()
                        .into(ivCard);
            }
            String room_admin_headpic = admin_info.getRoom_admin_headpic();
            if (room_admin_headpic != null && !"".equals(room_admin_headpic)) {
                Glide.with(mContext)
                        .load(room_admin_headpic)
                        .transform(new GlideCircleTransform(mContext))
                        .crossFade()
                        .into(ivOwner);
            }

            tvZone.setText(zone_name);
            tvBuilding.setText(building_name);
            tvUnit.setText(unit_name);
            tvRoom.setText("(" + room_name + "室)");
            tvDistrict.setText(province_name + "·" + city_name);
            tvOwnerName.setText(room_admin_name);
            if (auth_start_date != null && !"".equals(auth_start_date)) {
                tvStartDate.setText(auth_start_date.substring(0, 13).replace("T", " ") + "时");
            }
            if (auth_end_date != null && !"".equals(auth_end_date)) {
                tvEndDate.setText(auth_end_date.substring(0, 13).replace("T", " ") + "时");
            }
            switch (relation) {
                case 1:
                    tvPositionName.setText("业主");
                    ivPosition.setImageResource(R.drawable.img_yezhutouxiang);
                    break;
                case 2:
                    tvPositionName.setText("家人");
                    ivPosition.setImageResource(R.drawable.img_jiarentouxiang);
                    break;
                case 3:
                    tvPositionName.setText("租客");
                    ivPosition.setImageResource(R.drawable.img_zuketouxiang);
                    break;
                case 4:
                    tvPositionName.setText("访客");
                    ivPosition.setImageResource(R.drawable.img_fangketouxiang);
                    tvNormal.setVisibility(View.GONE);
                    tvQrcode.setVisibility(View.GONE);
                    tvManager.setVisibility(View.GONE);
                    llNoPower.setVisibility(View.VISIBLE);
                    tvNoPower.setText("当前身份是访客");
                    break;
            }

            //if (relation != 4) {
            switch (key_status) {
                // "key_status": 1, //钥匙状态 1-待审核，2-已通过，3-已驳回
                case 1:
                    llInDate.setVisibility(View.GONE);
                    tvApply.setVisibility(View.VISIBLE);
                    llAllView.setVisibility(View.INVISIBLE);
                    hideAndShowViews();
                    break;
                case 2:
                    if (!is_freeze) {
                        // 判断卡片是否过期
                        boolean invalidDate = TimeUtil.checkIsInvalidDate(auth_start_date, auth_end_date);
                        if (!invalidDate) {
                            CardView.setBgColor(tvCover, zone_key_color);
                        } else {
                            llInDate.setVisibility(View.GONE);
                            tvApply.setVisibility(View.VISIBLE);
                            tvApply.setText("授权已过期！");
                            tvCover.setBackground(getResources().getDrawable(R.drawable.card_gray_shape));
                            hideAndShowViews();
                        }
                    } else {
                        llInDate.setVisibility(View.GONE);
                        tvApply.setVisibility(View.VISIBLE);
                        tvApply.setText("已暂停授权");
                        hideAndShowViews();
                    }
                    break;
                case 3:
                    hideAndShowViews();
                    break;
            }
            //}
            initBleAndNfcView();
        }
    }

    /**
     * 初始化蓝牙和nfc视图
     */
    private void initBleAndNfcView() {
        int blestate = FeatureManager.bleState();
        switch (blestate) {
            case 0:
                ivBle.setVisibility(View.GONE);
                break;
            case 1:
                ivBle.setEnabled(true);
                break;
            case 2:
                ivBle.setEnabled(false);
                break;
        }
        int nfcstate = FeatureManager.nfcState();
        switch (nfcstate) {
            case 0:
                ivNfc.setVisibility(View.GONE);
                break;
            case 1:
                ivNfc.setEnabled(true);
                break;
            case 2:
                ivNfc.setEnabled(false);
                break;
        }
    }

    /**
     * 根据卡片当前的状态显示隐藏View视图
     */
    private void hideAndShowViews() {
        tvNormal.setVisibility(View.GONE);
        tvQrcode.setVisibility(View.GONE);
        tvManager.setVisibility(View.GONE);
        llNoPower.setVisibility(View.VISIBLE);
        switch (key_status) {
            case 1:
                tvNoPower.setText(R.string.applying);
                // TODO: 2017/6/21 根据身份显示不同的暂停图片
                ivNoPower.setImageResource(R.drawable.img_shenqinyaoshibao_yezhu);
                break;
            case 2:
                if (!is_freeze) {
                    tvNoPower.setText(R.string.shouquan_outdate);
                    // TODO: 2017/6/21 根据身份显示不同的暂停图片
                    ivNoPower.setImageResource(R.drawable.img_guoqizanting);
                } else {
                    tvNoPower.setText(R.string.shouquan_outdate);
                    ivNoPower.setImageResource(R.drawable.img_guoqizanting);
                }
                break;
            case 3:

                break;
        }
    }

    private void initListener() {
        rlCard.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Logger.t(TAG).e("卡片被长按了，发送key_id===" + key_id);
                // 业务1.发送key_id -> MainActivity
                EventBus.getDefault().post(new EventBusMsg("unlock", String.valueOf(key_id)));
                return true;
            }
        });
    }

    @OnClick({R.id.tvNormal, R.id.tvQrcode, R.id.tvManager, R.id.rlCard})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNormal:
                normalAuth();
                break;
            case R.id.tvQrcode:
                Intent qrIntent = new Intent(mContext, QrcodeAuth.class);
                qrIntent.putExtra("keyId", key_id);
                qrIntent.putExtra("zoneName", zone_name);
                qrIntent.putExtra("buildingName", building_name);
                startActivity(qrIntent);
                break;
            case R.id.tvManager:
                Intent intent = new Intent(mContext, ManagerAuth.class);
                intent.putExtra("keyid", key_id);
                intent.putExtra("zoneid", zone_id);
                intent.putExtra("relation", relation);
                startActivity(intent);
                break;
        }
    }

    private void normalAuth() {
        Intent intent = new Intent(mContext, NormalAuthActivity.class);
        VKeysPkgBean.ObjectBean.RoomInfoBean room_info = objectBean.getRoom_info();
        VKeysPkgBean.ObjectBean.KeyInfoBean key_info = objectBean.getKey_info();
        intent.putExtra("buildingid", room_info.getBuilding_id());
        intent.putExtra("buildingname", room_info.getBuilding_name());
        intent.putExtra("zoneid", room_info.getZone_id());
        intent.putExtra("zonename", room_info.getZone_name());
        intent.putExtra("unitid", room_info.getUnit_id());
        intent.putExtra("unitname", room_info.getUnit_name());
        intent.putExtra("roomid", room_info.getRoom_id());
        intent.putExtra("roomname", room_info.getRoom_name());
        intent.putExtra("key_id", key_id);
        intent.putExtra("relation", relation);
        startActivity(intent);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBusMsg event) {
        Log.e(TAG, "onEventMainThread收到了消息：" + event);
        String type = event.getType();
        if ("ble_open".equals(type)) {
            ivBle.setEnabled(true);
        } else if ("ble_close".equals(type)) {
            ivBle.setEnabled(false);
        } else if ("nfc_open".equals(type)) {
            ivNfc.setEnabled(true);
        } else if ("nfc_close".equals(type)) {
            ivNfc.setEnabled(false);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

}
