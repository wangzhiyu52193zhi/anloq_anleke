package com.anloq.nfcservice;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.support.api.client.PendingResult;
import com.huawei.hms.support.api.client.ResultCallback;
import com.huawei.hms.support.api.push.HuaweiPush;
import com.huawei.hms.support.api.push.TokenResult;

import app.project.IMyAidlInterface;

/**
 * Created by Steven on 2017/8/9.
 * 测试华为推送
 */

public class HuaweiService extends Service implements HuaweiApiClient.ConnectionCallbacks, HuaweiApiClient.OnConnectionFailedListener {
    private String TAG = "HuaweiService";
    private HuaweiApiClient client = null;
    MyBinder binder;
    MyConn conn;

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        binder = new MyBinder();
        conn = new MyConn();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // ToastUtil.show("push推送打开！");
        if (client == null) {
            client = new HuaweiApiClient.Builder(this)
                    .addApi(HuaweiPush.PUSH_API)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .build();
        }
        //建议在oncreate的时候连接华为移动服务
        //业务可以根据自己业务的形态来确定client的连接和断开的时机，但是确保connect和disconnect必须成对出现
        client.connect();
        this.bindService(new Intent(HuaweiService.this, GuardService.class), conn, Context.BIND_IMPORTANT);
        return START_STICKY;
    }

    @Override
    public void onConnected() {
        // 华为移动服务client连接成功，在这边处理业务自己的事件
        Log.e(TAG, "HuaweiApiClient 连接成功");
        getTokenAsyn();//申请token值
        setReceiveNormalMsg(true);//透传
    }

    @Override
    public void onConnectionSuspended(int arg0) {
        //HuaweiApiClient异常断开连接, if 括号里的条件可以根据需要修改
        client.connect();
        Log.e(TAG, "HuaweiApiClient 连接断开");
    }

    private void setReceiveNormalMsg(boolean flag) {
        if (!client.isConnected()) {
            Log.i(TAG, "设置是否接收push消息失败，原因：HuaweiApiClient未连接");
            client.connect();
            return;
        }
        if (flag) {
            Log.i(TAG, "允许应用接收push透传消息");
        } else {
            Log.i(TAG, "禁止应用接收push透传消息");
        }
        HuaweiPush.HuaweiPushApi.enableReceiveNormalMsg(client, flag);
    }

    @Override
    public void onConnectionFailed(ConnectionResult arg0) {
        Log.i(TAG, "HuaweiApiClient连接失败，错误码：" + arg0.getErrorCode());
    }

    private void getTokenAsyn() {
        if (!client.isConnected()) {
            Log.e(TAG, "获取token失败，原因：HuaweiApiClient未连接");
            client.connect();
            return;
        }

        Log.i(TAG, "异步接口获取push token");
        PendingResult<TokenResult> tokenResult = HuaweiPush.HuaweiPushApi.getToken(client);
        tokenResult.setResultCallback(new ResultCallback<TokenResult>() {
            @Override
            public void onResult(TokenResult result) {
                Log.e(TAG, "onResult: " + result);
            }
        });
    }

    class MyBinder extends IMyAidlInterface.Stub {
        @Override
        public String getServiceName() throws RemoteException {
            return HuaweiService.class.getSimpleName();
        }
    }

    class MyConn implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            //开启远程服务
            HuaweiService.this.startService(new Intent(HuaweiService.this, GuardService.class));
            //绑定远程服务
            HuaweiService.this.bindService(new Intent(HuaweiService.this, GuardService.class), conn, Context.BIND_IMPORTANT);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        client.disconnect();
        Log.e("GuardService", "onDestroy: " + "HuaweiService进程被杀死！");
        //开启远程服务
        HuaweiService.this.startService(new Intent(HuaweiService.this, GuardService.class));
        //绑定远程服务
        HuaweiService.this.bindService(new Intent(HuaweiService.this, GuardService.class), conn, Context.BIND_IMPORTANT);
    }
}
