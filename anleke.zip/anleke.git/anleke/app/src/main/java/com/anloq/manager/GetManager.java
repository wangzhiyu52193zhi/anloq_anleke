package com.anloq.manager;

import com.anloq.api.Constants;
import com.anloq.utils.SpUtil;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import okhttp3.Call;

/**
 * Created by xpf on 2017/8/15 :)
 * Function:获取呼叫图片
 */

public class GetManager {

    private static final String TAG = GetManager.class.getSimpleName();

    private GetManager() {
    }

    private static GetManager instance = new GetManager();

    public static GetManager getInstance() {
        return instance;
    }

    public void getImage(String unitId, String imageId, final OnCallingListener onCallingListener) {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String phone = SpUtil.getInstance().getString("account", "");
        String url = Constants.GETCALLIMG + uid + Constants.TOKEN + token + Constants.PHONE + phone
                + Constants.UNITID + unitId + Constants.IMAGEID + imageId;
        Logger.t(TAG).i("GETCALLIMG_url===" + url);

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        if (onCallingListener != null) {
                            onCallingListener.onImageComing(response);
                        }
                    }
                });
    }

    public interface OnCallingListener {
        void onImageComing(String result);
    }
}
