package com.anloq.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.anloq.MyApplication;
import com.anloq.adapter.CallRecordAdapter;
import com.anloq.anleke.R;
import com.anloq.base.BaseFragment;
import com.anloq.model.CallRecordBean;
import com.anloq.utils.DensityUtil;
import com.anloq.utils.MessageProvider;
import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/3/22 :)
 * Function:通话记录页面的Fragment
 */

public class CallRecFragment extends BaseFragment {

    @BindView(R.id.listView)
    SwipeMenuListView listView;
    @BindView(R.id.tvNoData)
    TextView tvNoData;
    private CallRecordAdapter callRecordAdapter;
    private List<CallRecordBean> allRecord = new ArrayList<>();
    private static final String TAG = CallRecFragment.class.getSimpleName();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBus.getDefault().register(this);
    }

    @Override
    public View initView() {
        Log.e(TAG, "通话记录页面的视图初始化了");
        View view = View.inflate(mContext, R.layout.fragment_call_record, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        Log.e(TAG, "通话记录页面的数据初始化了");
        initListener();
        initLocalCallRecordList();
    }

    private void initListener() {

        // step 1. create a MenuCreator
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        MyApplication.getContext());
                deleteItem.setBackground(R.drawable.delete_bg_shape);
                deleteItem.setWidth(DensityUtil.dp2px(mContext, 60));
                deleteItem.setTitle("删除");
                deleteItem.setTitleSize(10);
                deleteItem.setTitleColor(Color.WHITE);
                //deleteItem.setIcon(R.drawable.btn_shanchu_normal);
                menu.addMenuItem(deleteItem);
            }
        };
        // set creator
        listView.setMenuCreator(creator);

        // step 2. listener item click event
        listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(final int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        if (allRecord != null && allRecord.size() > 0) {
                            if (position <= allRecord.size() - 1) {
                                removeCallRecordByPosition(position);
                            }
                        }
                        break;
                }
                return false;
            }
        });

        // set SwipeListener
        listView.setOnSwipeListener(new SwipeMenuListView.OnSwipeListener() {

            @Override
            public void onSwipeStart(int position) {
                // swipe start
            }

            @Override
            public void onSwipeEnd(int position) {
                // swipe end
            }
        });

        // set MenuStateChangeListener
        listView.setOnMenuStateChangeListener(new SwipeMenuListView.OnMenuStateChangeListener() {
            @Override
            public void onMenuOpen(int position) {
            }

            @Override
            public void onMenuClose(int position) {
            }
        });
    }

    private void removeCallRecordByPosition(int position) {
        // 1.从内存移除
        allRecord.remove(position);
        if (callRecordAdapter != null) {
            tvNoData.setVisibility(View.GONE);
            callRecordAdapter.notifyDataSetChanged();
        }
        if (allRecord.size() <= 0) {
            tvNoData.setVisibility(View.VISIBLE);
        }
        // 2.从本地存储移除
        MessageProvider.getInstance().deleteCallRecordById(position);
    }

    /**
     * 初始化本地通话记录列表
     */
    private void initLocalCallRecordList() {
        allRecord = MessageProvider.getInstance().getCallRecordData();
        if (allRecord != null && allRecord.size() > 0) {
            tvNoData.setVisibility(View.GONE);
            callRecordAdapter = new CallRecordAdapter(mContext, allRecord);
            listView.setAdapter(callRecordAdapter);
        } else {
            tvNoData.setVisibility(View.VISIBLE);
        }
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onMessageEvent(CallRecordBean callRecord) {
        // 在收到CallRecordBean实例后，我们将其中携带的消息取出
        Log.e(TAG, "onEventMainThread收到了消息：CallRecordBean");
        allRecord.add(0, callRecord);
        MessageProvider.getInstance().saveCallRecord(callRecord);
        if (allRecord != null && allRecord.size() > 0) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tvNoData.setVisibility(View.GONE);
                    if (callRecordAdapter == null) {
                        callRecordAdapter = new CallRecordAdapter(mContext, allRecord);
                        listView.setAdapter(callRecordAdapter);
                    } else {
                        callRecordAdapter.notifyDataSetChanged();
                    }
                }
            });
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }
}
