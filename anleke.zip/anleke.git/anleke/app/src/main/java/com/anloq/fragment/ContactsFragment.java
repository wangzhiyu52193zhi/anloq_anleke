package com.anloq.fragment;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.anloq.adapter.AnloqContactAdapter;
import com.anloq.anleke.R;
import com.anloq.base.BaseFragment;
import com.anloq.model.AnloqContactBean;
import com.anloq.utils.MessageProvider;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by xpf on 2017/3/22:)
 * Function:联系人页面的Fragment
 */

public class ContactsFragment extends BaseFragment {

    private static final String TAG = ContactsFragment.class.getSimpleName();
    @BindView(R.id.etSearch)
    EditText etSearch;
    @BindView(R.id.tvAdd)
    TextView tvAdd;
    @BindView(R.id.tvNoData)
    TextView tvNoData;
    @BindView(R.id.llSearch)
    LinearLayout llSearch;
    @BindView(R.id.listView)
    ListView listView;
    private List<AnloqContactBean> allAnloqContacts;
    private AnloqContactAdapter adapter;

    @Override
    public View initView() {
        Log.e(TAG, "联系人页面的视图初始化了");
        View view = View.inflate(mContext, R.layout.fragment_contacts, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        Log.e(TAG, "联系人页面的数据初始化了");
        intContactData();
        initListener();
    }

    private void initListener() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String phone = allAnloqContacts.get(position).getPhone();
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phone));
                mContext.startActivity(intent);
            }
        });
    }

    private void intContactData() {
        allAnloqContacts = MessageProvider.getInstance().getAllAnloqContacts();
        if (allAnloqContacts != null && allAnloqContacts.size() > 0) {
            tvNoData.setVisibility(View.GONE);
            adapter = new AnloqContactAdapter(mContext, allAnloqContacts);
            listView.setAdapter(adapter);
        } else {
            tvNoData.setVisibility(View.VISIBLE);
        }
    }

    @OnClick(R.id.tvAdd)
    public void onClick() {
    }

}
