package com.anloq.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.anloq.activity.GuideActivity;
import com.anloq.model.EventBusMsg;
import com.anloq.model.LoginBean;
import com.anloq.model.VkeyBean;
import com.anloq.nfcservice.EmqttService;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;
import org.litepal.crud.DataSupport;

/**
 * Created by xpf on 2017/5/11 :)
 * Function:网络请求的工具类
 */

public class RequestUtil {

    private static final String TAG = RequestUtil.class.getSimpleName();

    /**
     * 保存登录成功的信息
     *
     * @param json
     */
    public static void saveLoginSuccessInfo(String json) {
        Logger.t(TAG).json(json);
        json = json.replace("\"[", "[");
        json = json.replace("]\"", "]");
        LoginBean loginBean = new Gson().fromJson(json, LoginBean.class);
        LoginBean.ObjectBean object = loginBean.getObject();
        if (object != null) {
            SpUtil.getInstance().save("loginjson", json);
            SpUtil.getInstance().save("uid", object.getUid());
            SpUtil.getInstance().save("token", object.getToken());
            SpUtil.getInstance().save("mqtt_server", object.getMqtt_server());
            SpUtil.getInstance().save("socket_cluster", object.getSocket_cluster());
            SpUtil.getInstance().save("ring_state", object.getRing() - 1);
            SpUtil.getInstance().save("accountVisible", object.isAccount_visible());
            SpUtil.getInstance().save("lastsuccess", true);
        }
    }

    /**
     * 获取网络请求的code码
     */
    public static String getCode(Context context, String json) {
        JSONObject jsonObject = null;
        String code = "";
        try {
            jsonObject = new JSONObject(json);
            code = jsonObject.getString("code");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        switch (code) {
            case "1001":
                ToastUtil.show("短信验证码错误");
                break;
            case "1002":
                //ToastUtil.show("http请求参数错误");
                break;
            case "1003":
                showInvalidView(context);
                break;
            case "1004":
                ToastUtil.show("账号或密码错误");
                break;
            case "1005":
                ToastUtil.show("密码错误");
                break;
            case "1006":
                ToastUtil.show("发送短信验证失败");
                break;
            case "1007":
                ToastUtil.show("缓存失效");
                break;
            case "1008":
                Logger.e("资源不存在，即没有更新的数据了...");
                break;
            case "1009":
                ToastUtil.show("创建住户失败");
                break;
            case "1010":
                ToastUtil.show("创建住户房间信息失败");
                break;
            case "1011":
                ToastUtil.show("创建虚拟钥匙失败");
                break;
            case "1012":
                Logger.e("获取业主信息失败");
                break;
            case "1013":
                ToastUtil.show("头像超过大小限制");
                break;
            case "1014":
                ToastUtil.show("头像保存失败");
                break;
            case "1015":
                ToastUtil.show("业主不存在");
                break;
            case "1016":
                ToastUtil.show("无授权权限");
                break;
            case "1017":
                ToastUtil.show("ERROR_SAVE_FEEDBACK");
                break;
            case "1018":
                ToastUtil.show("ERROR_DATABASE_OPERATE");
                break;
            case "1019":
                ToastUtil.show("您已经注册过，不能重复注册");
                break;
            case "2001":
                Logger.e("设备未激活！！！");
                break;
            case "2002":
                ToastUtil.show("设备已失效");
                break;
            case "2003":
                ToastUtil.show("上传截图失败");
                break;
            case "2050":
                ToastUtil.show("ERROR_MESSAGE_SENDFAIL");
                break;
            case "10000":
                ToastUtil.show("ERROR_HACKER");
                break;
            default:
                break;
        }

        return code;
    }

    /**
     * 获取网络请求的name
     */
    public static String getName(String json) {
        JSONObject jsonObject = null;
        String name = "";
        try {
            jsonObject = new JSONObject(json);
            name = jsonObject.getString("name");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return name;
    }

    /**
     * 提示过期，调到登录页面
     */
    public static void showInvalidView(Context context) {
        Logger.t(TAG).e("Token过期，需重新登陆");
        ToastUtil.show("您的账号在其他设备登录，密码可能已经泄露，请及时更改密码");
        // 1.删除sp存储
        SpUtil.getInstance().clearAll();
        // 2.删除虚拟钥匙
        DataSupport.deleteAll(VkeyBean.class);
        // 3.发送取消订阅的消息 -> EmqttService
        EventBus.getDefault().post(new EventBusMsg("unsubscribe", ""));
        context.stopService(new Intent(context, EmqttService.class));
        context.startActivity(new Intent(context, GuideActivity.class));
        Activity activity = (Activity) context;
        activity.finish();
    }
}
