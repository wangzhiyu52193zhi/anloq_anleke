package com.anloq.manager;

import android.content.Context;
import android.os.Vibrator;

import com.anloq.MyApplication;

/**
 * Created by xpf on 2017/6/3 :)
 * Function:震动服务的管理者
 */

public class VibratorManager {

    private static Vibrator vibrator;

    /**
     * 开启震动
     */
    public static void startVibrate() {
        if (vibrator == null) {
            //获取震动服务
            vibrator = (Vibrator) MyApplication.getContext()
                    .getSystemService(Context.VIBRATOR_SERVICE);
        }
        //震动模式隔1秒震动1.4秒
        long[] pattern = {1000, 1400};
        //震动重复，从数组的0开始（-1表示不重复）
        vibrator.vibrate(pattern, 0);
    }

    /**
     * 停止震动
     */
    public static void stopViberate() {
        if (vibrator != null) {
            vibrator.cancel();
        }
    }
}
