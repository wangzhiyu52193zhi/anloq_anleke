package com.anloq.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.anloq.adapter.AuthManagerAdapter;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.DBManager;
import com.anloq.model.AuthManagerBean;
import com.anloq.model.VkeyBean;
import com.anloq.ui.CardView;
import com.anloq.ui.GlideRoundTransform;
import com.anloq.utils.DensityUtil;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.TimeUtil;
import com.anloq.utils.ToastUtil;
import com.baoyz.swipemenulistview.SwipeMenu;
import com.anloq.utils.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.anloq.utils.SwipeMenuListView;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.MediaType;

// 授权管理
public class ManagerAuth extends Activity {
    private static final String TAG = ManagerAuth.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.ivCard)
    ImageView ivCard;
    @BindView(R.id.tvCover)
    TextView tvCover;
    @BindView(R.id.ivNfc)
    ImageView ivNfc;
    @BindView(R.id.ivBle)
    ImageView ivBle;
    @BindView(R.id.tvZone)
    TextView tvZone;
    @BindView(R.id.tvBuilding)
    TextView tvBuilding;
    @BindView(R.id.tvUnit)
    TextView tvUnit;
    @BindView(R.id.tvRoom)
    TextView tvRoom;
    @BindView(R.id.tvStartDate)
    TextView tvStartDate;
    @BindView(R.id.tvEndDate)
    TextView tvEndDate;
    @BindView(R.id.llInDate)
    LinearLayout llInDate;
    @BindView(R.id.tvApply)
    TextView tvApply;
    @BindView(R.id.rlCard)
    RelativeLayout rlCard;
    @BindView(R.id.listView)
    SwipeMenuListView listView;
    @BindView(R.id.tvNoData)
    TextView tvNoData;

    private Context mContext;
    private AuthManagerAdapter adapter;
    private List<AuthManagerBean.ObjectBean> authBeanList;
    private List<SwipeMenu> menuList;
    private int is_freeze = -1; // 0-解冻，1-被冻结
    private int is_deleted = -1; // 0-默认，1-删除
    private int uid;
    private String token;
    private int user_id;
    private int resident_id;
    private int auth_key_id;
    private int master_resident_id;
    private int currentPos = 0;
    private int currentDeal = -1;
    private String cardColor = "";
    private String image_url = "";

    private boolean isFreeze;
    private boolean isPause = true; // 是否是暂停授权，否则为开启授权
    private String device_key_sr;
    private String first_key;
    private int key_status; //"key_status": 1, //钥匙状态 1-待审核，2-已通过，3-已驳回
    private String room_admin_name, unit_name, building_name, zone_name, room_name,
            province_name, city_name, auth_start_date, auth_end_date;
    private int keyid, zoneid, expire_type, auth_count, city_id, room_id, unit_id, building_id,
            province_id, zone_id, relation, key_id;
    private String zone_key_color;
    private String auth_end_date1, auth_start_date1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_auth);
        ButterKnife.bind(this);
        mContext = this;
        tvTitle.setText(R.string.manager_auth);
        Intent intent = getIntent();
        keyid = intent.getIntExtra("keyid", -1);
        zoneid = intent.getIntExtra("zoneid", -1);
        Log.e(TAG, "zoneid===" + zoneid);
        relation = intent.getIntExtra("relation", -1);
        initCardInformation();
        //initData();
        initListener();
    }

    private SwipeMenu mMenu;

    /**
     * 初始化卡片信息
     */
    private void initCardInformation() {
        VkeyBean object = DBManager.getInstance().getVKeyByKeyId(keyid);
        if (object != null) {
            key_id = object.getKey_id();
            expire_type = object.getExpire_type();
            auth_start_date = object.getAuth_start_date();
            auth_end_date = object.getAuth_end_date();
            auth_count = object.getAuth_count();
            device_key_sr = object.getDevice_key_sr();
            first_key = object.getFirst_key();
            key_status = object.getKey_status();
            isFreeze = object.is_freeze();
            image_url = object.getImage_url();
            zone_name = object.getZone_name();
            province_name = object.getProvince_name();
            city_name = object.getCity_name();
            building_name = object.getBuilding_name();
            unit_name = object.getUnit_name();
            city_id = object.getCity_id();
            room_id = object.getRoom_id();
            room_name = object.getRoom_name();
            unit_id = object.getUnit_id();
            building_id = object.getBuilding_id();
            province_id = object.getProvince_id();
            room_admin_name = object.getRoom_admin_name();
            zone_id = object.getZone_id();

            if (!"".equals(image_url)) {
                Glide.with(mContext).load(image_url)
                        .transform(new GlideRoundTransform(mContext)).into(ivCard);
            }

            tvZone.setText(zone_name);
            tvBuilding.setText(building_name);
            tvUnit.setText(unit_name);
            tvRoom.setText("(" + room_name + "室)");
            if (auth_start_date != null && !"".equals(auth_start_date)) {
                tvStartDate.setText(auth_start_date.substring(0, 13).replace("T", " ") + "时");
            }
            if (auth_end_date != null && !"".equals(auth_end_date)) {
                tvEndDate.setText(auth_end_date.substring(0, 13).replace("T", " ") + "时");
            }

            if (!isFreeze) {
                // 判断卡片是否过期
                boolean invalidDate = TimeUtil.checkIsInvalidDate(auth_start_date, auth_end_date);
                if (!invalidDate) {
                    CardView.setColor(mContext, zoneid, tvCover, ivCard);
                } else {
                    llInDate.setVisibility(View.GONE);
                    tvApply.setVisibility(View.VISIBLE);
                    tvApply.setText(R.string.card_invalid);
                    tvCover.setBackground(getResources().getDrawable(R.drawable.card_gray_shape));
                }
            } else {
                llInDate.setVisibility(View.GONE);
                tvApply.setVisibility(View.VISIBLE);
                tvApply.setText(R.string.pause_auth);
            }
        }
    }

    private void initListener() {
        // step 1. create a MenuCreator
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu, int position) {
                // create "delete" item
                menuList.add(position, menu);
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        getApplicationContext());
                deleteItem.setBackground(R.drawable.delete_auth_shape);
                deleteItem.setWidth(DensityUtil.dp2px(mContext, 60));
                deleteItem.setTitle(getString(R.string.delete_text));
                deleteItem.setId(0);
                deleteItem.setTitleSize(18);
                deleteItem.setTitleColor(Color.WHITE);
                //deleteItem.setIcon(R.drawable.btn_shanchu_normal);
                menu.addMenuItem(deleteItem);
                if (!authBeanList.get(currentPos).isIs_freeze()) {
                    SwipeMenuItem startItem = new SwipeMenuItem(
                            getApplicationContext());
                    startItem.setBackground(R.drawable.pause_auth_shape);
                    startItem.setWidth(DensityUtil.dp2px(mContext, 60));
                    startItem.setTitle(getString(R.string.pause_text));
                    startItem.setId(1);
                    startItem.setTitleSize(18);
                    startItem.setTitleColor(Color.WHITE);
                    menu.addMenuItem(startItem);
                } else {
                    SwipeMenuItem startItem = new SwipeMenuItem(
                            getApplicationContext());
                    startItem.setBackground(R.drawable.start_auth_shape);
                    startItem.setWidth(DensityUtil.dp2px(mContext, 60));
                    startItem.setTitle(getString(R.string.open_text));
                    startItem.setId(1);
                    startItem.setTitleSize(18);
                    startItem.setTitleColor(Color.WHITE);
                    menu.addMenuItem(startItem);
                }
            }
        };

        // set creator
        listView.setMenuCreator(creator);
        // step 2. listener item click event
        listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                AuthManagerBean.ObjectBean objectBean = authBeanList.get(position);
                currentPos = position;
                user_id = objectBean.getUser_id();
                resident_id = objectBean.getResident_id();
                auth_key_id = objectBean.getAuth_key_id();
                master_resident_id = objectBean.getMaster_resident_id();
                auth_end_date1 = objectBean.getAuth_end_date();
                auth_start_date1 = objectBean.getAuth_start_date();
                boolean is_freeze = objectBean.isIs_freeze();
                switch (index) {
                    case 0:
                        currentDeal = 0;
                        new AlertDialog.Builder(mContext)
                                .setTitle(R.string.confirm_delete_auth)
                                .setPositiveButton(R.string.btn_confirm, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        deleteAuth();
                                    }
                                })
                                .setNegativeButton(R.string.cancel_textview, null)
                                .show();
                        break;
                    case 1: // 暂停授权
                        if (is_freeze) {
                            if (!TimeUtil.checkIsInvalidDate(auth_start_date1, auth_end_date1)) {
                                currentDeal = 2;
                                startAuth();
                            } else {
                                ToastUtil.show(getString(R.string.vkey_was_pause));
                            }
                        } else {
                            if (!TimeUtil.checkIsInvalidDate(auth_start_date1, auth_end_date1)) {
                                currentDeal = 1;
                                pauseAuth();
                            } else {
                                ToastUtil.show(getString(R.string.vkey_invalid));
                            }
                        }
                        break;
                }
                return false;
            }
        });

        listView.setOnSwipeListener(new SwipeMenuListView.OnSwipeListener() {

            @Override
            public void onSwipeStart(int position) {
                // swipe start
                currentPos = position;
                if (!authBeanList.get(currentPos).isIs_freeze()) {
                    menuList.get(currentPos).getMenuItem(1).setTitle(R.string.pause_text);
                    menuList.get(currentPos).getMenuItem(1).setBackground(R.drawable.pause_auth_shape);
                } else {
                    menuList.get(currentPos).getMenuItem(1).setTitle(R.string.open_text);
                    menuList.get(currentPos).getMenuItem(1).setBackground(R.drawable.start_auth_shape);
                }
                listView.postInvalidate();
            }

            @Override
            public void onSwipeEnd(int position) {
                // swipe end
            }
        });

        // set MenuStateChangeListener
        listView.setOnMenuStateChangeListener(new SwipeMenuListView.OnMenuStateChangeListener() {
            @Override
            public void onMenuOpen(int position) {
                // create "pause" item

            }

            @Override
            public void onMenuClose(int position) {
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        initData();
    }

    /**
     * 开启授权
     */
    private void startAuth() {
        is_freeze = 0;
        is_deleted = 0;
        sendRequest();
    }

    /**
     * 删除授权
     */
    private void deleteAuth() {
        is_freeze = 0;
        is_deleted = 1;
        sendRequest();
    }

    /**
     * 暂停授权
     */
    private void pauseAuth() {
        is_freeze = 1;
        is_deleted = 0;
        sendRequest();
    }

    private void sendRequest() {
        HashMap map = new HashMap();
        map.put("auth_key_id", auth_key_id);
        map.put("master_resident_id", master_resident_id);
        map.put("user_id", user_id);
        map.put("resident_id", resident_id);
        map.put("is_freeze", is_freeze);
        map.put("is_deleted", is_deleted);
        String content = new Gson().toJson(map);
        Log.e(TAG, "content===" + content);
        String url = Constants.MODIFYVKEY + uid + Constants.TOKEN + token;
        Log.e(TAG, "MODIFYVKEY_url===" + url);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "response===" + response);
                        parseResult(response);
                    }
                });
    }

    private void parseResult(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            switch (currentDeal) {
                case 0:
                    Toast.makeText(ManagerAuth.this, R.string.delete_success, Toast.LENGTH_SHORT).show();
                    authBeanList.remove(currentPos);
                    adapter.notifyDataSetChanged();
                    if (authBeanList != null && authBeanList.size() <= 0) {
                        tvNoData.setVisibility(View.VISIBLE);
                    }
                    break;
                case 1:
                    Toast.makeText(ManagerAuth.this, R.string.pause_success, Toast.LENGTH_SHORT).show();
                    if (authBeanList.size() > 0) {
                        authBeanList.clear();
                        adapter.notifyDataSetChanged();
                        initData(); // 更新数据
                    }
                    break;
                case 2:
                    Toast.makeText(ManagerAuth.this, R.string.open_success, Toast.LENGTH_SHORT).show();
                    if (authBeanList.size() > 0) {
                        authBeanList.clear();
                        adapter.notifyDataSetChanged();
                        initData(); // 更新数据
                    }
                    break;
                default:
                    Log.e(TAG, "code===" + code);
            }

        }
    }

    private void initData() {
        Intent intent = getIntent();
        int keyId = intent.getIntExtra("keyid", -1);
        uid = SpUtil.getInstance().getInt("uid", -1);
        token = SpUtil.getInstance().getString("token", "");
        String url = Constants.KEYSBYME + uid + Constants.TOKEN + token + Constants.KEYID + keyId;
        Log.e(TAG, "KEYSBYME_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "response===" + response);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            AuthManagerBean authManagerBean = new Gson().fromJson(json, AuthManagerBean.class);
            if (authBeanList != null && authBeanList.size() > 0) {
                authBeanList.clear();
            }
            authBeanList = authManagerBean.getObject();
            if (authBeanList != null && authBeanList.size() > 0) {
                tvNoData.setVisibility(View.GONE);
                if (adapter == null) {
                    adapter = new AuthManagerAdapter(mContext, authBeanList, keyid, zoneid, relation, room_id);
                    menuList = new ArrayList(authBeanList.size());
                    listView.setAdapter(adapter);
                } else {
                    adapter = new AuthManagerAdapter(mContext, authBeanList, keyid, zoneid, relation, room_id);
                    menuList = new ArrayList(authBeanList.size());
                    listView.setAdapter(adapter);
                }
            } else {
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }
                tvNoData.setVisibility(View.VISIBLE);
            }
        }
    }

    @OnClick(R.id.ivBack)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
        }
    }
}
