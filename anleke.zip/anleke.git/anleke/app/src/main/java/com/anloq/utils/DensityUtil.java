package com.anloq.utils;

import android.content.Context;
import android.view.WindowManager;

import static com.anloq.MyApplication.getContext;

/**
 * 手机屏幕参数相关工具类
 */
public class DensityUtil {

    /**
     * dp2px转换工具类
     */
    public static int dp2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    /**
     * px2dp转换工具类
     */
    public static int px2dp(Context context, float pxValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }

    /**
     * 获取卡片的高度
     */
    public static int getDelta(Context context) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (152 * scale + 0.5f);
    }

    /**
     * 获取屏幕高度
     */
    public static int getSreenHeight() {
        WindowManager wm = (WindowManager) getContext()
                .getSystemService(Context.WINDOW_SERVICE);
        return wm.getDefaultDisplay().getHeight();
    }

    /**
     * 获取屏幕宽度
     */
    public static int getSreenWidth() {
        WindowManager wm = (WindowManager) getContext()
                .getSystemService(Context.WINDOW_SERVICE);
        return wm.getDefaultDisplay().getWidth();
    }

}