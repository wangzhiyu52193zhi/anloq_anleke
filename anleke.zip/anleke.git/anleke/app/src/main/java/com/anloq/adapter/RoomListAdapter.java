package com.anloq.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.model.RoomBean;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/4/19 :)
 * Function:房间列表数据的适配器
 */

public class RoomListAdapter extends BaseAdapter {

    private Context mContext;
    private List<RoomBean.ObjectBean> roomList;

    public RoomListAdapter(Context mContext, List<RoomBean.ObjectBean> roomList) {
        this.mContext = mContext;
        this.roomList = roomList;
    }

    @Override
    public int getCount() {
        return roomList.size();
    }

    @Override
    public Object getItem(int position) {
        return roomList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_textview, null);
            ButterKnife.bind(convertView);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        RoomBean.ObjectBean objectBean = roomList.get(position);
        holder.textView.setText(objectBean.getRoom_name());
        return convertView;
    }

    static class ViewHolder {
        @BindView(R.id.textView)
        TextView textView;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
