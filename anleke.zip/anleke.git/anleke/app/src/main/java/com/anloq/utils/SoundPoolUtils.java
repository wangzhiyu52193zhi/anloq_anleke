package com.anloq.utils;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.util.SparseIntArray;

import com.anloq.anleke.R;

/**
 * Created by xpf on 2017/4/5 :)
 * Function:铃声音效播放工具类
 * (软件启动之前需要先调用SoundPoolUtils.init()方法做初始化)
 * 系统权限：MEDIA_CONTENT_CONTROL、MODIFY_AUDIO_SETTINGS、READ_EXTERNAL_STORAGE
 */
public class SoundPoolUtils {

    // 标记是否已经初始化过
    private static boolean inited = false;
    private static final int MAX_STREAMS = 10;
    private static SoundPool soundPool;

    private static final int RING1 = 1;
    private static final int RING2 = 2;
    private static final int RING3 = 3;
    private static final int RING4 = 4;
    private static final int RING5 = 5;

    // 声音池
    private static SparseIntArray soundMap = new SparseIntArray();

    /**
     * 声音录制准备完毕（一般开始录制前需要播放）的索引号
     */
    public static final int RECORD_PREPARED = 1;
    /**
     * 消息成功发送的音频提示索引号
     */
    public static final int MSG_SEND = 2;
    /**
     * 语音接通中的等待音
     */
    public static final int CALL_WAITING = 3;
    // 正在播放的等待音的ID
    private static int CALL_PLAYING_ID = -1;
    /**
     * 切换群组的提示音
     */
    public static final int GROUP_SWITCH_TIP = 4;

    /**
     * 初始化铃声池
     *
     * @param context
     */
    @SuppressWarnings("deprecation")
    public static void init(Context context) {
        if (context != null) {
            if (!inited) {
                soundPool = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
                soundMap.append(RING1, soundPool.load(context, R.raw.calling1, 1));
                soundMap.append(RING2, soundPool.load(context, R.raw.calling2, 1));
                soundMap.append(RING3, soundPool.load(context, R.raw.calling3, 1));
                soundMap.append(RING4, soundPool.load(context, R.raw.calling4, 1));
                soundMap.append(RING5, soundPool.load(context, R.raw.calling5, 1));
                inited = true;
            }
        }
    }

    /**
     * 播放录音准备音
     */
    public static void playRecordPreAudio() {
        soundPool.play(soundMap.get(RECORD_PREPARED), 1, 1, 0, 0, 1);
    }

    /**
     * 播放消息发送成功（或者是录制完毕的提示音）
     */
    public static void playMessageSendAudio() {
        soundPool.play(soundMap.get(MSG_SEND), 1, 1, 0, 0, 1);
    }

    /**
     * 播放语音连接中的等待音（这个声音会循环播放很久，类似手机来电声音效果）
     */
    public static void playCallWaitingAudio() {
        int ring_state = SpUtil.getInstance().getInt("ring_state", 0);
        CALL_PLAYING_ID = soundPool.play(soundMap.get(ring_state + 1), 1, 1, 0, -1, 1);
    }

    /**
     * 停止播放等待音
     */
    public static void stopCallWaitingAudio() {
        soundPool.stop(CALL_PLAYING_ID);
        CALL_PLAYING_ID = -1;
    }

    /**
     * 播放群组切换成功的提示音
     */
    public static void playGroupSwitchTipAudio() {
        soundPool.play(soundMap.get(GROUP_SWITCH_TIP), 1, 1, 0, 0, 1);
    }
}
