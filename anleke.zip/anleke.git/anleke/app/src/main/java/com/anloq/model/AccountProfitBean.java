package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/11/1 :)
 * Function:账户收益的Bean
 */

public class AccountProfitBean {

    /**
     * code : 200
     * name : account profit
     * object : {"records":[{"amount":0.2,"time":"2017-10-31"},{"amount":0.29,"time":"2017-10-30"},{"amount":0.11,"time":"2017-10-29"}],"sum":0.6}
     */

    private int code;
    private String name;
    private ObjectBean object;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * records : [{"amount":0.2,"time":"2017-10-31"},{"amount":0.29,"time":"2017-10-30"},{"amount":0.11,"time":"2017-10-29"}]
         * sum : 0.6
         */

        private double sum;
        private List<RecordsBean> records;

        public double getSum() {
            return sum;
        }

        public void setSum(double sum) {
            this.sum = sum;
        }

        public List<RecordsBean> getRecords() {
            return records;
        }

        public void setRecords(List<RecordsBean> records) {
            this.records = records;
        }

        public static class RecordsBean {
            /**
             * amount : 0.2
             * time : 2017-10-31
             */

            private double amount;
            private String time;

            public double getAmount() {
                return amount;
            }

            public void setAmount(double amount) {
                this.amount = amount;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }
        }
    }
}
