package com.anloq.manager;

import android.widget.Toast;

import com.anloq.MyApplication;
import com.anloq.model.BtDeviceBean;
import com.anloq.model.CheckZoneBean;
import com.anloq.model.EventBusMsg;
import com.anloq.model.KeyModifyBean;
import com.anloq.model.OpinionZoneBean;
import com.anloq.model.OriginVkeyBean;
import com.anloq.model.VKeysPkgBean;
import com.anloq.model.VkeyBean;
import com.anloq.utils.TimeUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;

import org.greenrobot.eventbus.EventBus;
import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xpf on 2017/5/9 :)
 * Function:数据库操作的管理类
 */

public class DBManager {

    private static final String TAG = DBManager.class.getSimpleName();

    private DBManager() {
    }

    private static DBManager instance = new DBManager();

    public static DBManager getInstance() {
        return instance;
    }

    /**
     * 判断申请RoomId的钥匙是否已经拥有
     *
     * @param currentRoomId
     * @return true:有钥匙 false:无钥匙或者钥匙是其他状态
     */
    public boolean isHasKey(int currentRoomId) {
        List<VkeyBean> keyList = DataSupport.where("room_id = ?", "" + currentRoomId).find(VkeyBean.class);
        if (keyList.size() > 0) {
            if (keyList.get(0).getKey_status() == 2 || keyList.get(0).getKey_status() == 1) {
                Logger.t(TAG).i("是否已经有钥匙===" + keyList.size());
                Toast.makeText(MyApplication.getContext(), "您已经申请过此房屋钥匙，不能重复申请", Toast.LENGTH_SHORT).show();
                return true;
            }
        }
        return false;
    }

    /**
     * 获取卡片当前的状态：已通过、已驳回...
     */
    public int getCardState(int key_id) {
        List<VkeyBean> keyList = DataSupport.where("key_id = ?", String.valueOf(key_id)).find(VkeyBean.class);
        for (int i = 0; i < keyList.size(); i++) {
            return keyList.get(i).getKey_status();
        }
        return -1;
    }

    /**
     * 查询指定key_id的钥匙
     */
    public VkeyBean getVKeyByKeyId(int key_id) {
        // 查询
        List<VkeyBean> keyList = DataSupport.where("key_id = ?", String.valueOf(key_id)).find(VkeyBean.class);
        Logger.t(TAG).i("查询到keyid===" + key_id + "的钥匙有" + keyList.size() + "把");
        for (int i = 0; i < keyList.size(); i++) {
            return keyList.get(0);
        }
        return null;
    }

    /**
     * 查询您所有的虚拟钥匙
     */
    public List<VkeyBean> getAllVkeys() {
        List<VkeyBean> keyList = DataSupport.findAll(VkeyBean.class);
        Logger.t(TAG).i("查询到您所有的虚拟钥匙有" + keyList.size() + "把");
        return keyList;
    }

    /**
     * 查询指定key_id的钥匙包列表
     */
    public List<VkeyBean> getVKeyListByKeyId(int key_id) {
        List<VkeyBean> keyList = DataSupport.where("key_id = ?", String.valueOf(key_id)).find(VkeyBean.class);
        Logger.t(TAG).i("查询到keyid===" + key_id + "的钥匙List有" + keyList.size() + "把");
        if (keyList.size() > 0) {
            return keyList;
        }
        return null;
    }

    /**
     * 查询指定roomid的钥匙
     */
    public VkeyBean getVKeyByRoomId(int roomid) {
        List<VkeyBean> keyList = DataSupport.where("room_id = ?", String.valueOf(roomid)).find(VkeyBean.class);
        Logger.t(TAG).i("查询到roomid===" + roomid + "有" + keyList.size() + "把");
        if (keyList.size() > 0) {
            return keyList.get(0);
        }
        return null;
    }

    /**
     * 查询并删除指定key_id的钥匙
     */
    public void deleteKeyByKeyId(int key_id) {
        // 查询并删除旧数据
        List<VkeyBean> keyList = DataSupport.where("key_id = ?", String.valueOf(key_id)).find(VkeyBean.class);
        for (int i = 0; i < keyList.size(); i++) {
            keyList.get(i).delete();
            Logger.t(TAG).i("删除key_id===" + key_id + ",Index===" + i);
        }
    }

    /**
     * 查询指定key_id的zoneid
     */
    public String getZoneIdByKeyId(int key_id) {
        // 查询并删除旧数据
        String zone_id = null;
        List<VkeyBean> keyList = DataSupport.where("key_id = ?", String.valueOf(key_id)).find(VkeyBean.class);
        for (int i = 0; i < keyList.size(); i++) {
            zone_id = "" + keyList.get(i).getZone_id();
        }
        return zone_id;
    }

    /**
     * 查询指定key_id的钥匙是否有在效期内
     */
    public boolean isInvalidKey(int key_id) {
        List<VkeyBean> keyList = DataSupport.where("key_id = ?", String.valueOf(key_id)).find(VkeyBean.class);
        VkeyBean vkeyBean = null;
        for (int i = 0; i < keyList.size(); i++) {
            vkeyBean = keyList.get(0);
        }
        if (vkeyBean != null) {
            String auth_start_date = vkeyBean.getAuth_start_date();
            String auth_end_date = vkeyBean.getAuth_end_date();
            return TimeUtil.checkIsInvalidDate(auth_start_date, auth_end_date);
        }
        return false;
    }

    public void update() {

    }

    public void select() {

    }

    public void selectAll() {

    }

    /**
     * 获取所有可用卡片的小区数据
     */
    public List<OpinionZoneBean> getAllZones() {
        List<OpinionZoneBean> list = new ArrayList<>();
        List<VkeyBean> keyList = DataSupport.findAll(VkeyBean.class);
        for (int i = 0; i < keyList.size(); i++) {
            boolean freeze = keyList.get(i).is_freeze();
            if (!freeze) {
                int zone_id = keyList.get(i).getZone_id();
                String zone_name = keyList.get(i).getZone_name();
                boolean existZoneId = isExistZoneId(list, zone_id);
                if (!existZoneId) {
                    OpinionZoneBean bean = new OpinionZoneBean(zone_id, zone_name);
                    list.add(bean);
                }
            }
        }
        return list;
    }

    /**
     * 判断集合中是否存在相同的zoneid
     */
    private boolean isExistZoneId(List<OpinionZoneBean> list, int zone_id) {
        if (list.size() > 0) {
            for (int j = 0; j < list.size(); j++) {
                if (list.get(j).getZone_id() == zone_id) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 保存虚拟钥匙包列表(首页初始化)
     *
     * @param objectBean
     */
    public void saveVkeyList(VKeysPkgBean.ObjectBean objectBean) {
        boolean is_freeze;
        String device_key_sr;
        String first_key;
        String room_admin_name, unit_name, building_name, zone_name, image_url,
                province_name, city_name, auth_start_date, auth_end_date, zone_key_color, room_name;
        int expire_type, auth_count, city_id, room_id, unit_id, building_id,
                province_id, zone_id, relation, key_id, key_status; //"key_status": 1, //钥匙状态 1-待审核，2-已通过，3-已驳回
        VKeysPkgBean.ObjectBean.KeyInfoBean object = objectBean.getKey_info();
        VKeysPkgBean.ObjectBean.RoomInfoBean room_info = objectBean.getRoom_info();
        VKeysPkgBean.ObjectBean.AdminInfoBean admin_info = objectBean.getAdmin_info();
        key_id = object.getKey_id();
        expire_type = object.getExpire_type();
        auth_start_date = object.getAuth_start_date();
        auth_end_date = object.getAuth_end_date();
        auth_count = object.getAuth_count();
        device_key_sr = object.getDevice_key_sr();
        first_key = object.getFirst_key();
        key_status = object.getKey_status();
        is_freeze = object.isIs_freeze();
        relation = room_info.getRelation();
        image_url = room_info.getImage();
        zone_name = room_info.getZone_name();
        province_name = room_info.getProvince_name();
        city_name = room_info.getCity_name();
        building_name = room_info.getBuilding_name();
        unit_name = room_info.getUnit_name();
        city_id = room_info.getCity_id();
        room_id = room_info.getRoom_id();
        room_name = room_info.getRoom_name();
        unit_id = room_info.getUnit_id();
        building_id = room_info.getBuilding_id();
        province_id = room_info.getProvince_id();
        room_admin_name = admin_info.getRoom_admin_name();
        zone_id = room_info.getZone_id();
        zone_key_color = room_info.getZone_key_color();
        String user_phone = object.getUser_phone();
        List<String> bt_device_mac = object.getBt_device_mac();
        List<VKeysPkgBean.ObjectBean.KeyInfoBean.BtDeviceBean> bt_device = object.getBt_device();
        // 查询并删除旧数据
        deleteKeyByKeyId(key_id);

        VkeyBean vkeyBean = new VkeyBean();
        vkeyBean.setKey_id(key_id);
        vkeyBean.setBt_device_mac(bt_device_mac);
        vkeyBean.setUser_phone(user_phone);
        vkeyBean.setExpire_type(expire_type);
        vkeyBean.setAuth_start_date(auth_start_date);
        vkeyBean.setAuth_end_date(auth_end_date);
        vkeyBean.setAuth_count(auth_count);
        vkeyBean.setDevice_key_sr(device_key_sr);
        vkeyBean.setFirst_key(first_key);
        vkeyBean.setKey_status(key_status);
        vkeyBean.setIs_freeze(is_freeze);
        vkeyBean.setRelation(relation);
        vkeyBean.setRoom_admin_name(room_admin_name);
        vkeyBean.setProvince_id(province_id);
        vkeyBean.setCity_id(city_id);
        vkeyBean.setBuilding_id(building_id);
        vkeyBean.setRoom_id(room_id);
        vkeyBean.setRoom_name(room_name);
        vkeyBean.setZone_id(zone_id);
        vkeyBean.setUnit_id(unit_id);
        vkeyBean.setZone_key_color(zone_key_color);
        vkeyBean.setBuilding_name(building_name);
        vkeyBean.setUnit_name(unit_name);
        vkeyBean.setZone_name(zone_name);
        vkeyBean.setImage_url(image_url);
        vkeyBean.setProvince_name(province_name);
        vkeyBean.setCity_name(city_name);
        if (bt_device != null && bt_device.size() > 0) {
            for (int i = 0; i < bt_device.size(); i++) {
                VKeysPkgBean.ObjectBean.KeyInfoBean.BtDeviceBean btDeviceBean = bt_device.get(i);
                BtDeviceBean bean = new BtDeviceBean();
                bean.setMac_attr(btDeviceBean.getMac_attr());
                bean.setDeviceid(btDeviceBean.getDeviceid());
                bean.setUnit_id(btDeviceBean.getUnit_id());
                boolean save = bean.save();
                Logger.t(TAG).i("保存mac_attr" + (save ? "成功" : "失败"));
            }
        }
        boolean save = vkeyBean.save();
        Logger.t(TAG).i("保存" + (save ? "成功" : "失败"));
    }

    /**
     * 当钥匙被冻结、解冻、删除修改时的逻辑处理
     *
     * @param json
     */
    public void modifyKeys(String json) {
        String zone_id = null;
        KeyModifyBean modifyBean = new Gson().fromJson(json, KeyModifyBean.class);
        if (modifyBean != null) {
            int key_id = modifyBean.getObject().getKey_id();
            Logger.t(TAG).i("modifyKeys keyid===" + key_id);

            if (modifyBean.getObject().getIs_deleted()) {
                VkeyBean vkeyDeleted = null;
                List<VkeyBean> keyList = DataSupport.where("key_id = ?", String.valueOf(modifyBean.getObject().getKey_id())).find(VkeyBean.class);
                for (int i = 0; i < keyList.size(); i++) {
                    zone_id = "" + keyList.get(i).getZone_id();
                    vkeyDeleted = keyList.get(i);
                    // 1.删除所有Keyid对应的钥匙
                    if (vkeyDeleted != null) {
                        vkeyDeleted.delete();
                    }
                }
                // 2.重新校验是否订阅或者退订小区消息 -> MQTT Service
                EventBus.getDefault().post(new CheckZoneBean(zone_id, false));

            } else {
                List<VkeyBean> keyList = DBManager.getInstance().getVKeyListByKeyId(key_id);
                if (keyList.size() <= 0) {
                    return;
                }
                for (int i = 0; i < keyList.size(); i++) {
                    boolean is_freeze = modifyBean.getObject().getIs_freeze();
                    zone_id = "" + keyList.get(i).getZone_id();
                    VkeyBean vkeyIsFreezed = keyList.get(i);
                    // 1.设置数据库钥匙的状态
                    vkeyIsFreezed.setIs_freeze(is_freeze);
                    vkeyIsFreezed.save();
                    // 2.重新校验是否订阅或者退订小区消息 -> MQTT Service
                    EventBus.getDefault().post(new CheckZoneBean(zone_id, !is_freeze));
                }
            }
            // 3.发送消息去通知更新卡片 -> MainActivity
            EventBus.getDefault().post(new EventBusMsg("updatecards", ""));
        }
    }

    /**
     * 更新虚拟钥匙包列表
     *
     * @param json
     */
    public void updateVkeyList(String json) {
        OriginVkeyBean originVkeyBean = new Gson().fromJson(json, OriginVkeyBean.class);
        OriginVkeyBean.ObjectBean object = originVkeyBean.getObject();
        if (object != null) {
            // 1.取出新下发钥匙的ZoneId
            String zoneId = DBManager.getInstance().getZoneIdByKeyId(object.getKey_id());
            if (zoneId != null) {
                // 2.重新校验是否订阅或者删除小区消息 -> MQTT Service
                EventBus.getDefault().post(new CheckZoneBean(zoneId, true));
            }
        }
        // 3.发送消息去通知更新卡片 -> MainActivity
        EventBusMsg msg = new EventBusMsg("updatecards", "");
        EventBus.getDefault().post(msg);
    }

}
