package com.anloq.model;

/**
 * Created by xpf on 2017/4/8 :)
 * Function:个人信息的Bean
 */

public class ProfileBean {

    /**
     * code : 200
     * name : profile
     * object : {"bind_hardware":false,"call_answer":true,"headpic":"","nickname":"17600733534","no_distrub":3,"ring":1,"ring_shake":true,"shake_enable":true,"sound_enable":true}
     */

    private int code;
    private String name;
    private ObjectBean object;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * bind_hardware : false
         * call_answer : true
         * headpic :
         * nickname : 17600733534
         * no_distrub : 3
         * ring : 1
         * ring_shake : true
         * shake_enable : true
         * sound_enable : true
         */

        private boolean bind_hardware;
        private boolean call_answer;
        private String headpic;
        private String nickname;
        private int no_distrub;
        private int ring;
        private boolean ring_shake;
        private boolean shake_enable;
        private boolean sound_enable;

        public boolean isBind_hardware() {
            return bind_hardware;
        }

        public void setBind_hardware(boolean bind_hardware) {
            this.bind_hardware = bind_hardware;
        }

        public boolean isCall_answer() {
            return call_answer;
        }

        public void setCall_answer(boolean call_answer) {
            this.call_answer = call_answer;
        }

        public String getHeadpic() {
            return headpic;
        }

        public void setHeadpic(String headpic) {
            this.headpic = headpic;
        }

        public String getNickname() {
            return nickname;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public int getNo_distrub() {
            return no_distrub;
        }

        public void setNo_distrub(int no_distrub) {
            this.no_distrub = no_distrub;
        }

        public int getRing() {
            return ring;
        }

        public void setRing(int ring) {
            this.ring = ring;
        }

        public boolean isRing_shake() {
            return ring_shake;
        }

        public void setRing_shake(boolean ring_shake) {
            this.ring_shake = ring_shake;
        }

        public boolean isShake_enable() {
            return shake_enable;
        }

        public void setShake_enable(boolean shake_enable) {
            this.shake_enable = shake_enable;
        }

        public boolean isSound_enable() {
            return sound_enable;
        }

        public void setSound_enable(boolean sound_enable) {
            this.sound_enable = sound_enable;
        }
    }
}
