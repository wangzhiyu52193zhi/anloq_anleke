package com.anloq.ui;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.anloq.anleke.R;

/**
 * Created by xpf on 2017/5/11 :)
 * Function:顶部状态栏提示工具类
 */

public class StatusToast {

    public static final int RED = 1;
    public static final int GREEN = 2;
    public static final int ORANGE = 3;
    private static PopupWindow popupWindow;

    private static Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    popupWindow.dismiss();
                    popupWindow = null;
                    break;
            }
        }
    };

    public static void show(Context mContext, int type, String content, View view) {
        popupWindow = null;
        View popupView = null;
        TranslateAnimation animation = null;
        if (popupWindow == null) {
            popupView = View.inflate(mContext, R.layout.item_status_toast, null);
            // 参数2,3：指明popupwindow的宽度和高度
            popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);

            // 设置背景图片， 必须设置，不然动画没作用
            popupWindow.setBackgroundDrawable(new BitmapDrawable());
            //popupWindow.setFocusable(true);
            // 设置点击popupwindow外屏幕其它地方消失
            popupWindow.setOutsideTouchable(true);
            // 平移动画相对于手机屏幕的底部开始，X轴不变，Y轴从1变0
            animation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0, Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, -10, Animation.RELATIVE_TO_PARENT, 0);
            animation.setInterpolator(new AccelerateInterpolator());
            animation.setDuration(500);

            TextView tvToast = (TextView) popupView.findViewById(R.id.tvToast);
            tvToast.setText(content);

            switch (type) {
                case RED:
                    tvToast.setBackground(mContext.getResources().getDrawable(R.drawable.red_status));
                    break;
                case GREEN:
                    tvToast.setBackground(mContext.getResources().getDrawable(R.drawable.green_status));
                    break;
                case ORANGE:
                    tvToast.setBackground(mContext.getResources().getDrawable(R.drawable.orange_status));
                    break;
            }
        }
        // 在点击之后设置popupwindow的销毁
        if (popupWindow.isShowing()) {
            handler.sendEmptyMessageDelayed(1, 2000);
        }

        // 设置popupWindow的显示位置，此处是在手机屏幕底部且水平居中的位置
        popupWindow.showAsDropDown(view, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0);
        //popupView.startAnimation(animation);
        popupWindow.setAnimationStyle(R.anim.pop_anim_in);
    }

}
