package com.anloq.model;

/**
 * Created by xpf on 2017/2/27:)
 * Function:请求修改密码返回数据的Bean类
 */

public class PwdReturnBean {

    /**
     * name : token
     * object : {"uid":"1","token":"CigIUAoHRjIGChQGUAoIAFoBHlADMh4EUDwJCigEABQJFCgERkYFAAAAAAE="}
     * code : 200
     */
    private String name;
    private ObjectBean object;
    private int code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public static class ObjectBean {
        /**
         * uid : 1
         * token : CigIUAoHRjIGChQGUAoIAFoBHlADMh4EUDwJCigEABQJFCgERkYFAAAAAAE=
         */

        private String uid;
        private String token;

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }
    }
}
