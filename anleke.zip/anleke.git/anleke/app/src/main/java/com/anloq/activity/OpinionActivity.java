package com.anloq.activity;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.anloq.adapter.OpinionZoneAdapter;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.BrightnessManager;
import com.anloq.manager.DBManager;
import com.anloq.model.OpinionZoneBean;
import com.anloq.utils.DensityUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.MediaType;

// 意见反馈
public class OpinionActivity extends Activity {

    private static final String TAG = OpinionActivity.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.etContent)
    EditText etContent;
    @BindView(R.id.btnCommit)
    Button btnCommit;
    @BindView(R.id.tvSelectZone)
    TextView tvSelectZone;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

    private Context mContext;
    private String content;
    private PopupWindow popupWindow;
    private View popupView;
    private OpinionZoneAdapter adapter;
    private int zone_id = -1;
    private List<OpinionZoneBean> allZones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opinion);
        ButterKnife.bind(this);
        mContext = this;
        tvTitle.setText(R.string.opinion_feedback);
        initListener();
    }

    private void initListener() {
        etContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() <= 50 && s.length() >= 6 && zone_id != -1) {
                    //btnCommit.setEnabled(true);
                } else {
                    //btnCommit.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @OnClick({R.id.ivBack, R.id.btnCommit, R.id.tvSelectZone})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.btnCommit:
                content = etContent.getText().toString().trim();
                String hoseAddress = tvSelectZone.getText().toString().trim();
                Log.e(TAG, "content===" + content + "hoseAddress==" + hoseAddress);
                if (hoseAddress.equals("")) {
                    ToastUtil.show(getString(R.string.please_zone));
                } else {
                    if (content.equals("")) {
                        ToastUtil.show(getString(R.string.input_content));
                    } else {
                        if (content.length() > 50) {
                            ToastUtil.show(getString(R.string.feedback_not_fifty_chars));
                        } else {
                            uploadOpinion();
                        }
                    }
                }
                break;
            case R.id.tvSelectZone:
                allZones = DBManager.getInstance().getAllZones();
                if (allZones != null && allZones.size() > 0) {
                    showPopupWindow();
                    BrightnessManager.lightoff(mContext);
                } else {
                    ToastUtil.show("暂时还没有您的小区信息");
                }
                break;
        }
    }

    /**
     * 选择小区popupWindow
     */
    private void showPopupWindow() {
        if (popupWindow == null) {
            popupView = View.inflate(this, R.layout.item_select_zone, null);
            popupWindow = new PopupWindow(popupView, RelativeLayout.LayoutParams.MATCH_PARENT,
                    DensityUtil.dp2px(mContext, 200));
            popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(mContext);
                }
            });
            popupWindow.setBackgroundDrawable(new BitmapDrawable());
            popupWindow.setFocusable(true);
            popupWindow.setOutsideTouchable(true);

            ListView listView = (ListView) popupView.findViewById(R.id.listView);
            adapter = new OpinionZoneAdapter(mContext, allZones);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (allZones != null && allZones.size() > 0) {
                        OpinionZoneBean bean = allZones.get(position);
                        if (bean != null) {
                            zone_id = bean.getZone_id();
                            tvSelectZone.setText(bean.getZone_name());
                            if (etContent.getText().length() >= 6) {
                                if (!btnCommit.isEnabled()) {
                                    //btnCommit.setEnabled(true);
                                }
                            }
                            BrightnessManager.lighton(mContext);
                            if (popupWindow.isShowing()) {
                                popupWindow.dismiss();
                            }
                        }
                    }
                }
            });
        }
        if (popupWindow.isShowing()) {
            popupWindow.dismiss();
            BrightnessManager.lighton(mContext);
        }
        // 设置popupWindow的显示位置
        popupWindow.showAsDropDown(tvSelectZone);
    }

    private void uploadOpinion() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String phone = SpUtil.getInstance().getString("account", "");
        String text = new String(Base64.encode(content.getBytes(), Base64.DEFAULT));

        HashMap map = new HashMap();
        map.put("phone", phone);
        map.put("content", text);
        map.put("zone_id", zone_id);
        String content = new Gson().toJson(map);
        Log.e(TAG, "content===" + content);
        String url = Constants.ADDFEEDBACK + uid + Constants.TOKEN + token;
        Log.e(TAG, "ADDFEEDBACK_url===" + url);

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e(TAG, "反馈联网失败===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "反馈联网成功===" + response);
                        Toast.makeText(OpinionActivity.this, R.string.commit_succeed, Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }

}
