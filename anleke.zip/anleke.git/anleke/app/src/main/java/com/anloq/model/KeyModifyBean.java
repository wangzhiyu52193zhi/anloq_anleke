package com.anloq.model;

import com.anloq.utils.TimeUtil;

/**
 * Created by tianjh on 17/4/28.
 */
public class KeyModifyBean {
    /**
     * name : modifyvkey
     * object : {"key_id ":1,"is_freeze":1,"is_deleted":0}
     */

    private String name;
    private ObjectBean object;
    private String time;

    public String getTime() {
        return TimeUtil.getTime(time);
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * key_id  :
         */

        private boolean is_freeze;
        private boolean is_deleted;
        private int key_id;

        public boolean getIs_freeze() {
            return is_freeze;
        }

        public void setIs_freeze(boolean userid) {
            this.is_freeze = userid;
        }

        public boolean getIs_deleted() {
            return is_deleted;
        }

        public void setIs_deleted(boolean command) {
            this.is_deleted = command;
        }

        public int getKey_id() {
            return key_id;
        }

        public void setKey_id(int command) {
            this.key_id = command;
        }
    }
}
