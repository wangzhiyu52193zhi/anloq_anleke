package com.anloq.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.model.CityBean;

import java.util.List;

/**
 * Created by xpf on 2017/3/27 :)
 * Function:城市地区数据的适配器
 */

public class CityBeanAdapter extends BaseAdapter {


    private Context mContext;
    private List<CityBean.ObjectBean> districList;

    public CityBeanAdapter(Context mContext, List<CityBean.ObjectBean> districList) {
        this.mContext = mContext;
        this.districList = districList;
    }

    @Override
    public int getCount() {
        return districList.size();
    }

    @Override
    public Object getItem(int position) {
        return districList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        viewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_zone, null);
            holder = new viewHolder();
            holder.tv = (TextView) convertView.findViewById(R.id.tv);
            convertView.setTag(holder);
        } else {
            holder = (viewHolder) convertView.getTag();
        }

        CityBean.ObjectBean objectBean = districList.get(position);
        holder.tv.setText(objectBean.getCity_name());
        return convertView;
    }

    static class viewHolder {
        TextView tv;
    }
}
