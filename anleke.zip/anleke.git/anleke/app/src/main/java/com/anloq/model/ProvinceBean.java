package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/3/24 :)
 * Function:
 */

public class ProvinceBean {

    /**
     * name : provinces
     * object : [{"province_id":1,"province_name":"北京市"},{"province_id":2,"province_name":"天津市"}]
     * code : 200
     */

    private String name;
    private int code;
    private List<ObjectBean> object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<ObjectBean> getObject() {
        return object;
    }

    public void setObject(List<ObjectBean> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * province_id : 1
         * province_name : 北京市
         */

        private int province_id;
        private String province_name;

        public int getProvince_id() {
            return province_id;
        }

        public void setProvince_id(int province_id) {
            this.province_id = province_id;
        }

        public String getProvince_name() {
            return province_name;
        }

        public void setProvince_name(String province_name) {
            this.province_name = province_name;
        }
    }
}
