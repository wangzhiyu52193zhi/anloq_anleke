package com.anloq.utils;

import android.content.Context;
import android.os.Handler;
import android.view.View;

import com.anloq.MyApplication;


/**
 * Created by xpf on 2017/05/16 :)
 * Function:获取ui操作的相关工具类
 */

public class UIUtils {

    // 获取程序需要的上下文对象:返回的是MyApplication的对象
    public static Context getContext() {
        return MyApplication.getContext();
    }

    // 获取程序需要的消息处理器的对象
    public static Handler getHandler() {
        return MyApplication.mHandler;
    }

    // 返回指定id对应的颜色
    public static int getColor(int colorId) {
        return getContext().getResources().getColor(colorId);
    }

    // 返回指定布局id,所对应的视图对象
    public static View getView(int layoutId) {
        View view = View.inflate(getContext(), layoutId, null);
        return view;
    }

    // 返回指定id的字符串数组
    public static String[] getStrArray(int strArrayId) {
        String[] stringArray = getContext().getResources().getStringArray(strArrayId);
        return stringArray;
    }

    // 保证如下的操作在主线程中执行的
    public static void runOnUiThread(Runnable runnable) {
        if (isMainThread()) {
            runnable.run();
        } else {
            UIUtils.getHandler().post(runnable);
        }
    }

    // 判断当前的线程是否是主线程
    private static boolean isMainThread() {
        int currentThreadId = android.os.Process.myTid();
        return MyApplication.mainThreadId == currentThreadId;
    }
}
