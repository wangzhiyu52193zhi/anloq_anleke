package com.anloq.fragment;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.anloq.MyApplication;
import com.anloq.activity.ForgetPwdActivity;
import com.anloq.activity.GuideActivity;
import com.anloq.activity.MainActivity;
import com.anloq.activity.RegisterActivity;
import com.anloq.activity.SmsCodeLogin;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.base.BaseFragment;
import com.anloq.manager.DeviceInfoManager;
import com.anloq.nfcservice.GuardService;
import com.anloq.nfcservice.HuaweiService;
import com.anloq.utils.MD5Utils;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.anloq.utils.Validator;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.orhanobut.logger.Logger;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.MediaType;

/**
 * Created by xpf on 2017/4/13 :)
 * Function:登录页面的Fragment
 */

public class LoginFragment extends BaseFragment {

    private static final String TAG = LoginFragment.class.getSimpleName();
    @BindView(R.id.tvRegister)
    TextView tvRegister;
    @BindView(R.id.tvLogin)
    TextView tvLogin;
    @BindView(R.id.et_userId)
    EditText etUserId;
    @BindView(R.id.et_userPwd)
    EditText etUserPwd;
    @BindView(R.id.tvCheckCodeLogin)
    TextView tvCheckCodeLogin;
    @BindView(R.id.tvForgetPwd)
    TextView tvForgetPwd;
    @BindView(R.id.btnLogin)
    Button btnLogin;
    @BindView(R.id.ivWechat)
    ImageView ivWechat;
    @BindView(R.id.ivQQ)
    ImageView ivQQ;
    @BindView(R.id.ivWeibo)
    ImageView ivWeibo;
    @BindView(R.id.llLoginWindow)
    LinearLayout llLoginWindow;
    private String account;
    private String pwd;
    private boolean lastsuccess = false; // 记录上次是否登录成功
    private PopupWindow popupWindow;
    protected String devicetoken = "";
    protected int device_type = 0;
    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    popupWindow.dismiss();
                    popupWindow = null;
                    mContext.startActivity(new Intent(mContext, MainActivity.class));
                    GuideActivity guideActivity = (GuideActivity) mContext;
                    guideActivity.overridePendingTransition(R.anim.tran_next_enter, R.anim.tran_next_exit);
                    guideActivity.finish();
                    if (lastsuccess) {
                        ToastUtil.show("网络连接错误");
                    } else {
                        ToastUtil.show("登录成功");
                    }
                    break;
                case 2:
                    popupWindow.dismiss();
                    ToastUtil.show("连接服务器超时");
                    break;
                case 3:
                    login();
                    break;
            }
        }
    };

    @Override
    public View initView() {
        Logger.t(TAG).i("登录页面的视图初始化了");
        View view = View.inflate(mContext, R.layout.fragment_login, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        Logger.t(TAG).i("登录页面的数据初始化了");
        initInputListener();
        String account = SpUtil.getInstance().getString("account", "");
        if (!"".equals(account)) {
            etUserId.setText(account);
        }
        mContext.startService(new Intent(mContext, HuaweiService.class));
        mContext.startService(new Intent(mContext, GuardService.class));
    }

    private void initInputListener() {
        etUserId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (etUserId.getText().toString().length() > 11) {
                    ToastUtil.show("手机号码格式有误");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        etUserPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (etUserPwd.getText().toString().length() >= 6) {
                    btnLogin.setEnabled(true);
                } else {
                    btnLogin.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @OnClick({R.id.tvRegister, R.id.tvCheckCodeLogin, R.id.tvForgetPwd, R.id.btnLogin,
            R.id.ivWechat, R.id.ivQQ, R.id.ivWeibo})
    public void onClick(View view) {
        GuideActivity guideActivity = (GuideActivity) mContext;
        switch (view.getId()) {
            case R.id.tvRegister:
                startActivity(new Intent(mContext, RegisterActivity.class));
                guideActivity.finish();
                break;
            case R.id.tvCheckCodeLogin:
                startActivity(new Intent(mContext, SmsCodeLogin.class));
                guideActivity.finish();
                break;
            case R.id.tvForgetPwd:
                startActivity(new Intent(mContext, ForgetPwdActivity.class));
                break;
            case R.id.btnLogin:
                checkBeforeLogin();
                break;
            case R.id.ivWechat:
                ToastUtil.show(getString(R.string.coming_soon));
                //UMShareAPI.get(this.getActivity()).getPlatformInfo(this.getActivity(), SHARE_MEDIA.WEIXIN, umAuthListener);
                break;
            case R.id.ivQQ:
                ToastUtil.show(getString(R.string.coming_soon));
                //UMShareAPI.get(this.getActivity()).getPlatformInfo(this.getActivity(), SHARE_MEDIA.QQ, umAuthListener);
                break;
            case R.id.ivWeibo:
                ToastUtil.show(getString(R.string.coming_soon));
                //UMShareAPI.get(this.getActivity()).getPlatformInfo(this.getActivity(), SHARE_MEDIA.SINA, umAuthListener);
                break;
        }
    }

    //添加监听
    private UMAuthListener umAuthListener = new UMAuthListener() {
        @Override
        public void onStart(SHARE_MEDIA platform) {
            //授权开始的回调
        }

        @Override
        public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
            Logger.t(TAG).i(data + "");
            Toast.makeText(MyApplication.getContext(), "Authorize succeed", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(SHARE_MEDIA platform, int action, Throwable t) {
            Toast.makeText(MyApplication.getContext(), "Authorize fail", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCancel(SHARE_MEDIA platform, int action) {
            Toast.makeText(MyApplication.getContext(), "Authorize cancel", Toast.LENGTH_SHORT).show();
        }
    };

    private void checkBeforeLogin() {
        account = etUserId.getText().toString().trim();
        pwd = etUserPwd.getText().toString().trim();
        if (TextUtils.isEmpty(account) || TextUtils.isEmpty(pwd)) {
            ToastUtil.show("用户名或密码不能为空");
            return;
        }
        if (!Validator.isChinaPhoneLegal(account)) {
            ToastUtil.show("手机号码非法");
            return;
        }
        showLoginView();
    }

    /**
     * 显示登录动画视图
     */
    private void showLoginView() {
        View popupView = View.inflate(mContext, R.layout.video_popupwindow, null);
        popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT);

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
            }
        });

        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setFocusable(true);
        ImageView ivLoading = (ImageView) popupView.findViewById(R.id.ivLoading);
        TextView tvContent = (TextView) popupView.findViewById(R.id.tvContent);
        tvContent.setText(R.string.logining);
        Glide.with(mContext).load(R.drawable.juhua)
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(ivLoading);

        if (popupWindow.isShowing()) {
            popupWindow.dismiss();
        }
        popupWindow.showAtLocation(getActivity().findViewById(R.id.fragment_login),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        // 发送延时消息，通知动画结束
        handler.sendEmptyMessageDelayed(3, 2000);
    }

    private void login() {
        //需要进行判断是什么机型
        device_type = DeviceInfoManager.getDeviceType();
        switch (device_type) {
            case 2: // 华为手机
                devicetoken = SpUtil.getInstance().getString("devicetoken", "");
                break;
            case 3: // 小米手机
                devicetoken = SpUtil.getInstance().getString("regId", "");
                break;
            default: // 其他手机
                devicetoken = "";
                break;
        }
        String md5Pwd = MD5Utils.MD5(pwd);
        HashMap<String, Object> map = new HashMap<>();
        map.put("phone", account);
        map.put("password", md5Pwd);
        map.put("devicetoken", devicetoken);
        map.put("device_type", device_type);// 2代表华为 3代表小米 0代表其他
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String content = gson.toJson(map);
        Logger.t(TAG).json(content);
        String url = Constants.LOGIN;

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e("登录联网失败===" + e.toString());
                        lastsuccess = SpUtil.getInstance().getBoolean("lastsuccess", false);
                        SpUtil.getInstance().save("netstate", false);
                        if (lastsuccess) {
                            handler.sendEmptyMessageDelayed(1, 1000);
                        } else {
                            popupWindow.dismiss();
                            ToastUtil.show("登录联网错误");
                        }
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        SpUtil.getInstance().save("netstate", true);
                        parseJson(response);
                    }
                });
    }


    private void parseJson(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            RequestUtil.saveLoginSuccessInfo(json);
            SpUtil.getInstance().save("account", account);
            SpUtil.getInstance().save("password", pwd);
            handler.sendEmptyMessage(1);
        } else {
            popupWindow.dismiss();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }

}
