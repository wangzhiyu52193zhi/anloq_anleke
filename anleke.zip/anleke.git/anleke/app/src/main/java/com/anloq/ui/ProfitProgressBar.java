package com.anloq.ui;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;

import com.anloq.anleke.R;

/**
 * Created by xpf on 2017/10/30 :)
 * Function:自定义我的收益
 */

public class ProfitProgressBar extends View {

    // 背景色
    private static final int DEFAULT_BACK_COLOR = Color.parseColor("#FFFFFF");
    // 字的颜色
    private static final int DEFAULT_TEXT_COLOR = Color.parseColor("#FFFFFF");
    // 进度条背景颜色
    private static final int DEFAULT_PROGRESS_COLOR = Color.parseColor("#BDBDBD");
    // 进度条默认的高度
    private static final float DEFAULT_PROGRESS_HEIGHT = 120f;
    // 文字的大小
    private static final float DEFAULT_TEXT_SIZE = 50;
    /**
     * 收益进度条左右两边margin大小
     */
    private static final int MARGIN_SIZE = 20;
    /**
     * 背景颜色的画笔
     */
    private Paint backgroundPaint;
    /**
     * 收益进度颜色的画笔
     */
    private Paint progressPaint;
    /**
     * 画文字的画笔
     */
    private Paint textPaint;
    /**
     * 背景的宽度
     */
    private int view_background_width;
    /**
     * 背景的高度
     */
    private float view_background_height = DEFAULT_PROGRESS_HEIGHT;
    /**
     * 日期
     */
    private String date = "2017/10/30";
    /**
     * 描叙(百分比/元)
     */
    private String desc = "5.20";
    /**
     * 要显示的长度的百分比
     */
    private int progress = 70;
    // 进度条颜色
    private int progressColor = DEFAULT_PROGRESS_COLOR;
    // 背景色
    private int progressBgColor = DEFAULT_BACK_COLOR;
    // 字的颜色
    private int textColor = DEFAULT_TEXT_COLOR;
    // 字的大小
    private float textSize = DEFAULT_TEXT_SIZE;

    public ProfitProgressBar(Context context) {
        this(context, null);
    }

    public ProfitProgressBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ProfitProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    private void initView(Context context) {
        TypedArray typedArray = context.obtainStyledAttributes(R.styleable.ProfitProgressBar);
        // 进度条的背景颜色
        progressColor = typedArray.getColor(R.styleable.ProfitProgressBar_progressColor, DEFAULT_PROGRESS_COLOR);
        // 进度条的背景颜色
        progressBgColor = typedArray.getColor(R.styleable.ProfitProgressBar_backgroundColor, DEFAULT_BACK_COLOR);
        // 文字颜色
        textColor = typedArray.getColor(R.styleable.ProfitProgressBar_textColor, DEFAULT_TEXT_COLOR);
        // 文字大小
        textSize = typedArray.getDimension(R.styleable.ProfitProgressBar_textSize, DEFAULT_TEXT_SIZE);
        // 初始化背景的画笔
        backgroundPaint = new Paint();
        backgroundPaint.setStrokeWidth(10);
        backgroundPaint.setColor(progressBgColor);
        backgroundPaint.setDither(true);
        backgroundPaint.setAntiAlias(true);
        // 初始化进度条的画笔
        progressPaint = new Paint();
        progressPaint.setStrokeWidth(10);
        progressPaint.setColor(progressColor);
        progressPaint.setDither(true);
        progressPaint.setAntiAlias(true);
        // 初始化文字的画笔
        textPaint = new Paint();
        textPaint.setStrokeWidth(10);
        textPaint.setDither(true);
        textPaint.setAntiAlias(true);
        textPaint.setTextSize(textSize);
        DisplayMetrics d = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(d);
        view_background_width = d.widthPixels;
    }

    /**
     * 初始化进度条
     *
     * @param date
     * @param desc
     * @param progress
     * @param progressColor
     */
    public void init(String date, String desc, int progress, int progressColor) {
        this.date = date;
        this.desc = desc;
        this.progress = progress;
        this.progressColor = progressColor;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        view_background_height = this.getMeasuredHeight();
        RectF r = new RectF();
        r.left = 0;
        r.top = 0;
        r.right = view_background_width;
        r.bottom = view_background_height;
        canvas.drawRect(r, backgroundPaint);
        RectF r1 = new RectF();
        r1.left = 0;
        r1.top = 0;
        r1.right = view_background_width * progress / 100;
        r1.bottom = view_background_height;
        canvas.drawRect(r1, progressPaint);
        textPaint.setColor(textColor);
        Rect r2 = new Rect();
        textPaint.getTextBounds(date, 0, date.length(), r2);
        canvas.drawText(date, MARGIN_SIZE, (view_background_height - r2.top) / 2, textPaint);//日期
        Rect r3 = new Rect();
        textPaint.getTextBounds(desc, 0, desc.length(), r3);
        if (progress > 95 && progress < 100) {
            canvas.drawText(desc, r1.right - textPaint.measureText(desc) - MARGIN_SIZE - 30, (view_background_height - r3.top) / 2, textPaint);
        } else if (progress >= 100) {
            canvas.drawText(desc, r1.right - textPaint.measureText(desc) - MARGIN_SIZE - 45, (view_background_height - r3.top) / 2, textPaint);
        } else {
            canvas.drawText(desc, r1.right - textPaint.measureText(desc) - MARGIN_SIZE, (view_background_height - r3.top) / 2, textPaint);
        }
        invalidate();
    }

}
