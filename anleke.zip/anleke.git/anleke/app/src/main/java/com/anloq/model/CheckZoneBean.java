package com.anloq.model;

/**
 * Created by xpf on 2017/8/16 :)
 * Function:EventBus检测小区订阅小区的Bean
 */

public class CheckZoneBean {

    private String zoneId;
    private boolean isFreeze;

    public CheckZoneBean() {
    }

    public CheckZoneBean(String zoneId, boolean isFreeze) {
        this.zoneId = zoneId;
        this.isFreeze = isFreeze;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public boolean isFreeze() {
        return isFreeze;
    }

    public void setFreeze(boolean freeze) {
        isFreeze = freeze;
    }
}
