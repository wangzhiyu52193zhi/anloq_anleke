package com.anloq.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.anloq.adapter.ProfitAdapter;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.model.AccountProfitBean;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

import static android.content.ContentValues.TAG;

// 昨日收益页面
public class ProfitDetailActivity extends Activity {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.tvAllProfit)
    TextView tvAllProfit;
    @BindView(R.id.listView)
    ListView listView;
    private ProfitAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profit_detail);
        ButterKnife.bind(this);
        tvTitle.setText("累计收益");
        getRecentProfit();
    }

    private void getRecentProfit() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.PROFITRECORDS + uid + Constants.TOKEN + token;
        Logger.t(TAG).i("ProfitRecords_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        AccountProfitBean profitBean = new Gson().fromJson(json, AccountProfitBean.class);
        AccountProfitBean.ObjectBean object = profitBean.getObject();
        if (object != null) {
            List<AccountProfitBean.ObjectBean.RecordsBean> records = object.getRecords();
            if (records != null && records.size() > 0) {
                tvAllProfit.setText(String.valueOf(object.getSum()));
                double maxProfit = calculateMaxProfit(records);
                adapter = new ProfitAdapter(ProfitDetailActivity.this, records, maxProfit);
                listView.setAdapter(adapter);
            }
        }
    }

    /**
     * 计算最大收益
     *
     * @param records
     * @return
     */
    private double calculateMaxProfit(List<AccountProfitBean.ObjectBean.RecordsBean> records) {
        double max = 0;
        for (int i = 0; i < records.size(); i++) {
            AccountProfitBean.ObjectBean.RecordsBean bean = records.get(i);
            double amount = bean.getAmount();
            if (amount > max) {
                max = amount;
            }
        }
        return max;
    }

    @OnClick(R.id.ivBack)
    public void onClick() {
        finish();
    }
}
