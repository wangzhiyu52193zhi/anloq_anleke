package com.anloq.fragment;

import android.view.View;

import com.anloq.anleke.R;
import com.anloq.base.BaseFragment;

/**
 * Created by xpf on 2017/4/13 :)
 * Function:引导页1页面的Fragment
 */

public class GuideFragment1 extends BaseFragment {

    @Override
    public View initView() {
        return View.inflate(mContext, R.layout.fragment_guide1, null);
    }

    @Override
    public void initData() {
        super.initData();
    }
}
