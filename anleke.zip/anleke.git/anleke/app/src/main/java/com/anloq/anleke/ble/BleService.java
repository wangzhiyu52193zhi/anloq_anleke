/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.anloq.anleke.ble;

import android.annotation.TargetApi;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

import com.anloq.utils.ToastUtil;

import java.util.List;
import java.util.UUID;

/**
 * GATT管理ble设备的状态、连接、数据通信的服务类
 */
public class BleService extends Service {

    private final static String TAG = BleService.class.getSimpleName();
    private final IBinder mBinder = new LocalBinder();
    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothDevice mSearchedDevice = null;
    private BluetoothGatt mBluetoothGattServer = null;
    private int delayCount = 0; // 延迟次数

    /**
     * 全局读、写、通知的Characteristic
     */
    private BluetoothGattCharacteristic mReadCharacteristic = null;
    private BluetoothGattCharacteristic mWriteCharacteristic = null;
    private BluetoothGattCharacteristic mNotifyCharacteristic = null;

    /**
     * 连接状态变化时的Action
     */
    public final static String ACTION_GATT_CONNECTED = "com.example.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_CONNECTING = "com.example.bluetooth.le.ACTION_GATT_CONNECTING";
    public final static String ACTION_GATT_DISCONNECTED = "com.example.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_DISCONNECTING = "com.example.bluetooth.le.ACTION_GATT_DISCONNECTING";
    public final static String ACTION_GATT_SERVICES_DISCOVERED = "com.example.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";

    /**
     * 当收到数据时的Action
     */
    public final static String ACTION_DATA_AVAILABLE = "com.example.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA = "com.example.bluetooth.le.EXTRA_DATA";
    public final static String ACTION_WRITE_SUCCESSFUL = "com.example.bluetooth.le.WRITE_SUCCESSFUL";
    public final static String ACTION_GATT_SERVICES_NO_DISCOVERED = "com.example.bluetooth.le.GATT_SERVICES_NO_DISCOVERED";

    /**
     * 服务、读、写、通知的UUID
     */
    public final static UUID UUID_BLE_SPP_SERVICE = UUID.fromString(BleGattAttributes.BLE_SPP_Service);
    public final static UUID UUID_BLE_SPP_READ = UUID.fromString(BleGattAttributes.BLE_SPP_Read_Characteristic);
    public final static UUID UUID_BLE_SPP_WRITE = UUID.fromString(BleGattAttributes.BLE_SPP_Write_Characteristic);
    public final static UUID UUID_BLE_SPP_NOTIFY = UUID.fromString(BleGattAttributes.BLE_SPP_Notify_Characteristic);

    /**
     * GATT事件的监听回调
     */
    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        /**
         * 当连接状态改变的时候回调
         * @param gatt
         * @param status
         * @param newState
         */
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.i(TAG, "onConnectionStateChange():gatt===" + gatt.hashCode() + ",status===" + status + ",newState===" + newState);
            switch (newState) {
                case BluetoothProfile.STATE_CONNECTING:
                    Log.e(TAG, "Connecting to GATT server.");
                    broadcastUpdate(ACTION_GATT_CONNECTING);
                    break;
                case BluetoothProfile.STATE_CONNECTED:
                    Log.e(TAG, "Connected to GATT server.");
                    broadcastUpdate(ACTION_GATT_CONNECTED);
                    // to discover gatt service
                    gatt.discoverServices();
                    break;
                case BluetoothProfile.STATE_DISCONNECTING:
                    Log.e(TAG, "Disconnecting from GATT server.");
                    broadcastUpdate(ACTION_GATT_DISCONNECTING);
                    break;
                case BluetoothProfile.STATE_DISCONNECTED:
                    Log.e(TAG, "Disconnected from GATT server.");
                    broadcastUpdate(ACTION_GATT_DISCONNECTED);
                    gatt.disconnect();
                    gatt.close();
                    break;
            }
        }

        /**
         * 当服务被发现的时候回调
         * @param gatt
         * @param status
         */
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            Log.i(TAG, "onServicesDiscovered():gatt===" + gatt.hashCode() + ",status===" + status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                BluetoothGattService service = gatt.getService(UUID_BLE_SPP_SERVICE);
                if (service != null) {
                    Log.e(TAG, "Discovered to GATT services.");
                    mReadCharacteristic = service.getCharacteristic(UUID_BLE_SPP_READ);
                    mWriteCharacteristic = service.getCharacteristic(UUID_BLE_SPP_WRITE);
                    mNotifyCharacteristic = service.getCharacteristic(UUID_BLE_SPP_NOTIFY);

                    if (mNotifyCharacteristic != null) {
                        mBluetoothGattServer = gatt;
                        // enable notify
                        mBluetoothGattServer.setCharacteristicNotification(mNotifyCharacteristic, true);

                        List<BluetoothGattDescriptor> descriptors = mNotifyCharacteristic.getDescriptors();
                        if (descriptors != null && descriptors.size() > 0) {
                            for (BluetoothGattDescriptor descriptor : descriptors) {
                                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                                mBluetoothGattServer.writeDescriptor(descriptor);
                            }
                        }
                        //mBluetoothGattServer.writeCharacteristic(mWriteCharacteristic);
                        //mBluetoothGattServer.readCharacteristic(mReadCharacteristic);
                        broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
                    }
                } else {
                    Log.e(TAG, "onServicesDiscovered but not found that we wanted!");
                    gatt.disconnect();
                    gatt.close();
                }
            }
        }

        /**
         * 当读到数据的时候回调
         * @param gatt
         * @param characteristic
         * @param status
         */
        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            Log.e(TAG, "onCharacteristicRead():gatt=" + gatt.hashCode() + ",characteristic=" + characteristic.getUuid() + ",status=" + status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.e(TAG, "BLE数据读取成功~");
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            }
        }

        /**
         * 当特征值变化的时候回调
         * @param gatt
         * @param characteristic
         */
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            Log.e(TAG, "onCharacteristicChanged():gatt===" + gatt.hashCode() + ",characteristic===" + characteristic.getUuid());
            //setMTU(202);
            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
        }

        /**
         * 当数据写入成功的时候回调
         * @param gatt
         * @param characteristic
         * @param status
         */
        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            Log.e(TAG, "onCharacteristicWrite():gatt===" + gatt.hashCode() + ",characteristic===" + characteristic.getUuid() + ",status===" + status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.e(TAG, "BLE数据写入成功~");
                broadcastUpdate(ACTION_WRITE_SUCCESSFUL);
            }
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorRead(gatt, descriptor, status);
            Log.e(TAG, "onDescriptorRead():gatt===" + gatt.hashCode() + ",descriptor===" + descriptor.getUuid() + ",status===" + status);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
            Log.e(TAG, "onDescriptorWrite():gatt===" + gatt.hashCode() + ",descriptor===" + descriptor.getUuid() + ",status===" + status);
        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);
            Log.e(TAG, "onMtuChanged():gatt===" + gatt.hashCode() + ",mtu===" + mtu + ",status===" + status);
        }

        @Override
        public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
            super.onReliableWriteCompleted(gatt, status);
            Log.e(TAG, "onReliableWriteCompleted():gatt===" + gatt.hashCode() + ",status===" + status);
        }
    };

    /**
     * 更新Action并发送出去
     *
     * @param action
     */
    private void broadcastUpdate(String action) {
        sendBroadcast(new Intent(action));
    }

    /**
     * 更新带数据的Action并发送出去
     *
     * @param action
     * @param characteristic
     */
    private void broadcastUpdate(String action, final BluetoothGattCharacteristic characteristic) {
        if (UUID_BLE_SPP_NOTIFY.equals(characteristic.getUuid())) {
            if (mReadCharacteristic == characteristic) {
                final byte[] data = characteristic.getValue();
                if (data != null && data.length > 0) {
                    Intent intent = new Intent(action);
                    intent.putExtra(EXTRA_DATA, data);
                    sendBroadcast(intent);
                }
            }
        }
    }

    public class LocalBinder extends Binder {
        public BleService getService() {
            return BleService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    /**
     * After using a given device, you should make sure that BluetoothGatt.close() is called
     * such that resources are cleaned up properly.  In this particular example, close() is
     * invoked when the UI is disconnected from the Service close();
     *
     * @param intent
     * @return
     */
    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    /**
     * 初始化本地蓝牙适配器的参数
     * For API level 18 and above, get a reference to BluetoothAdapter through BluetoothManager.
     *
     * @return true:initialize success ,false:initialize failed.
     */
    public boolean initialize() {
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }
        return true;
    }

    /**
     * Connects to the GATT server hosted on the Bluetooth LE device.
     * The device address of the destination device.
     *
     * @return Return true if the connection is initiated successfully. The connection result
     * is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public boolean isConnected(BluetoothDevice device) {
        if (mBluetoothManager != null) {
            int status = mBluetoothManager.getConnectionState(device, BluetoothProfile.GATT_SERVER);
            if (BluetoothProfile.STATE_CONNECTED == status) {
                return true;
            }
        }
        return false;
    }

    /**
     * 连接设备
     * We want to directly connect to the device, so we are setting the autoConnect parameter to false.
     *
     * @param device
     * @return
     */
    public void connect(BluetoothDevice device) {
        if (device == null) return;
        if (mSearchedDevice != null) {
            if (!device.getAddress().equals(mSearchedDevice.getAddress())) {
                resetService();
                mSearchedDevice = device;
            } else {
                mSearchedDevice = null;
            }
        } else {
            mSearchedDevice = device;
        }

        if (mSearchedDevice != null) {
            mSearchedDevice.connectGatt(this, false, mGattCallback);
            Log.e(TAG, "Trying to create a new Gatt connection.");
        }
    }

    /**
     * 改变BLE默认的单次发包、收包的最大长度,用于android 5.0及以上版本
     *
     * @param mtu
     * @return
     */
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static boolean requestMtu(BluetoothGatt bluetoothGatt, int mtu) {
        if (bluetoothGatt != null) {
            return bluetoothGatt.requestMtu(mtu);
        }
        return false;
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public boolean setMTU(int mtu) {
        Log.i(TAG, "setMTU " + mtu);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (mtu > 20) {
                if (mBluetoothGattServer != null) {
                    boolean ret = mBluetoothGattServer.requestMtu(mtu);
                    Log.d(TAG, "requestMTU " + mtu + " ret=" + ret);
                    return ret;
                }
            }
        }
        return false;
    }

    /**
     * write data without mac.
     *
     * @param data
     * @return
     */
    public synchronized boolean writeData(byte[] data) {
        if (delayCount == 0) {
            Log.e(TAG, "delayCount===" + delayCount);
            SystemClock.sleep(100);
            delayCount++;
        }

        if (mWriteCharacteristic != null && mBluetoothGattServer != null) {
            if (!mWriteCharacteristic.setValue(data)) {
                return false;
            }
            mBluetoothGattServer.writeCharacteristic(mWriteCharacteristic);
            return true;
        } else {
            if (mSearchedDevice != null) {
                Log.e(TAG, "连接超时,结束!");
                resetService();
                return false;
            }
            return true;
        }
    }

    /**
     * write data with mac.
     *
     * @param bt_mac
     * @param data
     * @return
     */
    public synchronized boolean writeData(String bt_mac, byte[] data) {
        if (delayCount == 0) {
            Log.e(TAG, "writeData");
            SystemClock.sleep(100);
            delayCount++;
        }

        if (mWriteCharacteristic != null && mBluetoothGattServer != null) {
            if (!mWriteCharacteristic.setValue(data)) {
                return false;
            }
            mBluetoothGattServer.writeCharacteristic(mWriteCharacteristic);
            return true;
        } else {
            if (mSearchedDevice != null) {
                if (mWriteCharacteristic == null || mBluetoothGattServer == null) {
                    Log.e(TAG, "连接超时,结束!");
                    ToastUtil.show("连接门禁设备失败,请重试!");
                    return false;
                }
                // 开始写数据
                Log.e(TAG, "start mWriteCharacteristic!");
                if (!mWriteCharacteristic.setValue(data)) {
                    return false;
                }
                if (!mBluetoothGattServer.writeCharacteristic(mWriteCharacteristic)) {
                    Log.e(TAG, "start mWriteCharacteristic fail!");
                    ToastUtil.show("通讯失效,请重试!");
                }
                Toast.makeText(BleService.this, "正在开门，请勿重复操作...", Toast.LENGTH_LONG).show();
            }
            return true;
        }
    }

    /**
     * is or not find device.
     *
     * @return
     */
    public boolean isFoundDevice() {
        return (mSearchedDevice != null);
    }

    /**
     * reset ble gatt service.
     */
    public synchronized void resetService() {
        Log.e(TAG, "resetService()释放蓝牙！！！");
        if (mBluetoothGattServer != null) {
            mBluetoothGattServer.disconnect();
            mBluetoothGattServer.close();
            // 必须置为null,否则会存在后续连接不上的情况
            mBluetoothGattServer = null;
        }
        mSearchedDevice = null;
        delayCount = 0;
    }

}
