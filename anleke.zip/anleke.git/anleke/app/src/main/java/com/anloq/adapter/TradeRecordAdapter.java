package com.anloq.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.model.AccountTradeBean;

import java.util.List;

/**
 * Created by xpf on 2017/11/7 :)
 * Function:广告收益交易记录数据的适配器
 */

public class TradeRecordAdapter extends RecyclerView.Adapter<TradeRecordAdapter.ViewHolder> {
    private Context context;
    private List<AccountTradeBean.ObjectBean.RecordsBean> datas;

    public TradeRecordAdapter(Context context, List<AccountTradeBean.ObjectBean.RecordsBean> datas) {
        this.context = context;
        this.datas = datas;
    }

    @Override
    public TradeRecordAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_available, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        AccountTradeBean.ObjectBean.RecordsBean item = datas.get(position);
        holder.tvDate.setText(item.getTime());
        holder.tvSum.setText(item.getAmount());
        switch (item.getType()) {
            case 1:
                holder.tvType.setText("充值");
                break;
            case 2:
                holder.tvType.setText("提现");
                break;
            case 3:
                holder.tvType.setText("投资合作");
                break;
            case 4:
                holder.tvType.setText("收益");
                break;
        }
    }

    @Override
    public int getItemCount() {
        return datas == null ? 0 : datas.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvType;
        private TextView tvDate;
        private TextView tvSum;

        public ViewHolder(View itemView) {
            super(itemView);
            tvType = (TextView) itemView.findViewById(R.id.tvType);
            tvDate = (TextView) itemView.findViewById(R.id.tvDate);
            tvSum = (TextView) itemView.findViewById(R.id.tvSum);
        }
    }
}
