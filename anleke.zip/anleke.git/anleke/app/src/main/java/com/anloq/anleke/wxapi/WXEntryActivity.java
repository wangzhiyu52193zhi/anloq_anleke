package com.anloq.anleke.wxapi;


import com.umeng.weixin.callback.WXCallbackActivity;

public class WXEntryActivity extends WXCallbackActivity {



}
