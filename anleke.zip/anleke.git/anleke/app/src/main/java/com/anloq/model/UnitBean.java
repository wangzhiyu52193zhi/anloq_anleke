package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/3/28 :)
 * Function:单元Bean类
 */
public class UnitBean {

    /**
     * name : units
     * object : [{"unit_id":2,"unit_name":"1单元"},{"unit_id":3,"unit_name":"2单元"},{"unit_id":4,"unit_name":"3单元"},{"unit_id":5,"unit_name":"4单元"},{"unit_id":6,"unit_name":"5单元"}]
     * code : 200
     */

    private String name;
    private int code;
    private List<ObjectBean> object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<ObjectBean> getObject() {
        return object;
    }

    public void setObject(List<ObjectBean> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * unit_id : 2
         * unit_name : 1单元
         */

        private int unit_id;
        private String unit_name;

        public int getUnit_id() {
            return unit_id;
        }

        public void setUnit_id(int unit_id) {
            this.unit_id = unit_id;
        }

        public String getUnit_name() {
            return unit_name;
        }

        public void setUnit_name(String unit_name) {
            this.unit_name = unit_name;
        }
    }
}
