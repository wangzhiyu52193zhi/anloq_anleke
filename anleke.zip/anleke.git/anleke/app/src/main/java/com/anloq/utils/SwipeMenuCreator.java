package com.anloq.utils;

import com.baoyz.swipemenulistview.SwipeMenu;

/**
 *
 * @author baoyz
 * @date 2014-8-24
 *
 */
public interface SwipeMenuCreator {

    void create(SwipeMenu menu,int postion);
}
