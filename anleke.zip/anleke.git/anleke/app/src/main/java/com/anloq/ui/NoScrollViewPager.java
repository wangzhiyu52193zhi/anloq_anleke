package com.anloq.ui;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

/**
 * Created by xpf on 2017/04/03 :)
 * Function:自定义屏蔽ViewPager的滑动事件
 */

public class NoScrollViewPager extends ViewPager {

    private static final String TAG = NoScrollViewPager.class.getSimpleName();
    private boolean noScroll = false;
    private boolean isShow = false; // false表示不显示,true表示显示
    private float startX, startY;

    // 对外提供set方法,在某些情况下动态的设置ViewPager的滑动与否
    public void setNoScroll(boolean noScroll) {
        this.noScroll = noScroll;
    }

    /**
     * 是否需要显示视图
     */
    public boolean isShow() {
        return isShow;
    }

    public NoScrollViewPager(Context context) {
        super(context);
    }

    public NoScrollViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void scrollTo(int x, int y) {
        super.scrollTo(x, y);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        return super.onTouchEvent(ev);
    }

    // 是否拦截子view的事件
    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        //Log.e(TAG, "onTouchEvent--" + ev.toString());

        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                //Log.e(TAG, "onTouchEvent--ACTION_DOWN");
                startX = ev.getX(); // 1.记录按下x坐标
                startY = ev.getY(); // 1.记录按下y坐标
                break;
            case MotionEvent.ACTION_MOVE:
                //Log.e(TAG, "onTouchEvent--ACTION_MOVE");
                break;
            case MotionEvent.ACTION_UP:
                //Log.e(TAG, "onTouchEvent--ACTION_UP");
                float endX = ev.getX(); // 2.记录抬起x坐标
                float endY = ev.getY(); // 2.记录抬起y坐标
                // 3.判断滑动方向
                // 3.计算在X轴和Y轴滑动的距离
                int distancX = (int) Math.abs(endX - startX);
                int distancY = (int) Math.abs(endY - startY);
                if (distancY > 10 && startY > endY) {
                    //Log.e(TAG, "向上滑动---isShow====" + isShow);
                    isShow = true;
                    // 重新记录起始值
                    startX = ev.getX();
                    startX = ev.getY();
                    if (onShowListener != null) {
                        onShowListener.isShow(isShow);
                    }
                    return true;
                    // @当y轴滑动距离大于10且卡片显示的时候去处理向下滑动
                } else if (distancY > 10 && startY < endY && isShow) {
                    //Log.e(TAG, "向下滑动---isShow====" + isShow);
                    isShow = false;
                    // 重新记录起始值
                    startX = ev.getX();
                    startX = ev.getY();
                    if (onShowListener != null) {
                        onShowListener.isShow(isShow);
                    }
                    return true;
                }
                break;
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public void setCurrentItem(int item) {
        super.setCurrentItem(item);
    }

    @Override
    public void setCurrentItem(int item, boolean smoothScroll) {
        super.setCurrentItem(item, smoothScroll);
    }

    onShowListener onShowListener;

    public void setOnShowListener(NoScrollViewPager.onShowListener onShowListener) {
        this.onShowListener = onShowListener;
    }

    public interface onShowListener {
        void isShow(boolean isShow);
    }

}
