package com.anloq.utils;

import android.text.TextUtils;
import android.util.Log;

import com.anloq.model.AnloqContactBean;
import com.anloq.model.CallRecordBean;
import com.anloq.model.MessageBean;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xpf on 2015/04/26 :)
 * Function:消息储器类，存取消息的内容
 * 取内容json数据-->List; 存List-->json数据
 */

public class MessageProvider {

    private static final String TAG = MessageProvider.class.getSimpleName();
    private static final String JSON_MESSAGE = "json_message";
    private static final String JSON_CALL_RECORD = "json_call_record";
    private static final String JSON_UNLOCK_RECORD = "json_unlock_record";
    private static final String JSON_ANLOQ_CONTACTS = "json_anloq_contacts";
    private static final String JSON_ANLOQ_MESSAGE_TYPE_NUMBER = "json_anloq_message_type_number";

    private List<MessageBean> mMsgList;
    private List<CallRecordBean> mCallRecList;
    private List<AnloqContactBean> mContactsList;

    private MessageProvider() {
        mMsgList = new ArrayList<>();
        mCallRecList = new ArrayList<>();
        mContactsList = new ArrayList<>();
    }

    private static MessageProvider instance = new MessageProvider();

    public static MessageProvider getInstance() {
        return instance;
    }

    /**
     * 保存消息类型数量
     */
    public void saveMessageTypeNumber(final List<String> msgNumber) {
        new Thread() {
            public void run() {
                if (msgNumber != null && msgNumber.size() > 0) {
                    String mMsgListJson = new Gson().toJson(msgNumber);
                    CacheUtils.putString(JSON_ANLOQ_MESSAGE_TYPE_NUMBER, mMsgListJson);
                }
            }
        }.start();
    }

    /**
     * 获取消息类型数量
     */
    public List<String> getMessageTypeNumber() {
        List<String> allMsgType = new ArrayList<>();
        // 从本地保存中获取数据
        String saveJson = CacheUtils.getString(JSON_ANLOQ_MESSAGE_TYPE_NUMBER);
        if (!TextUtils.isEmpty(saveJson)) {
            // 直接把json数据解析成集合
            allMsgType = new Gson().fromJson(saveJson, new TypeToken<List<String>>() {
            }.getType());
        }
        return allMsgType;
    }

    /**
     * 得到本地已经缓存数据
     */
    public List<MessageBean> getLocalData() {
        List<MessageBean> allLocalMsg = new ArrayList<>();
        // 从本地保存中获取数据
        String saveJson = CacheUtils.getString(JSON_MESSAGE);
        if (!TextUtils.isEmpty(saveJson)) {
            // 直接把json数据解析成集合
            allLocalMsg = new Gson().fromJson(saveJson, new TypeToken<List<MessageBean>>() {
            }.getType());
        }
        return allLocalMsg;
    }

    public void saveReverseMsgList(final List<MessageBean> reverseList) {
        new Thread() {
            public void run() {
                if (reverseList != null && reverseList.size() > 0) {
                    String mMsgListJson = new Gson().toJson(reverseList);
                    CacheUtils.putString(JSON_MESSAGE, mMsgListJson);
                }
            }
        }.start();
    }

    /**
     * 得到本地已经缓存的通话记录
     */
    public List<CallRecordBean> getCallRecordData() {
        List<CallRecordBean> allRecord = new ArrayList<>();
        // 从本地保存中获取数据
        String saveJson = CacheUtils.getString(JSON_CALL_RECORD); // json字符串
        if (!TextUtils.isEmpty(saveJson)) {
            // 直接把json数据解析成集合
            allRecord = new Gson().fromJson(saveJson, new TypeToken<List<CallRecordBean>>() {
            }.getType());
        }
        return allRecord;
    }

    /**
     * 得到本地所有安络联系人
     */
    public List<AnloqContactBean> getAllAnloqContacts() {
        List<AnloqContactBean> allContacts = new ArrayList<>();
        // 从本地保存中获取数据
        String anloqContactJson = CacheUtils.getString(JSON_ANLOQ_CONTACTS); // json字符串
        if (!TextUtils.isEmpty(anloqContactJson)) {
            allContacts = new Gson().fromJson(anloqContactJson, new TypeToken<List<AnloqContactBean>>() {
            }.getType());
        }
        return allContacts;
    }

    /**
     * 增加数据
     * 把List列表数据-->json文本数据-->保存到本地
     */
    public void addMsgData(final MessageBean bean) {
        new Thread() {
            public void run() {
                mMsgList = getLocalData();
                if (mMsgList == null) {
                    mMsgList = new ArrayList<>();
                }
                mMsgList.add(0, bean);
                String mMsgListJson = new Gson().toJson(mMsgList);
                CacheUtils.putString(JSON_MESSAGE, mMsgListJson);
            }
        }.start();
    }

    /**
     * 增加通话记录数据
     * 把List列表数据-->json文本数据-->保存到本地
     */
    public void saveCallRecord(final CallRecordBean bean) {
        new Thread() {
            public void run() {
                mCallRecList = getCallRecordData();
                if (mCallRecList == null) {
                    mCallRecList = new ArrayList<>();
                }
                mCallRecList.add(0, bean);
                String mMsgListJson = new Gson().toJson(mCallRecList);
                CacheUtils.putString(JSON_CALL_RECORD, mMsgListJson);
            }
        }.start();
    }

    /**
     * 增加安络联系人数据
     * 把List列表数据-->json文本数据-->保存到本地
     */
    public void addToAnloqContact(String name, final String phone) {
        final AnloqContactBean bean = new AnloqContactBean();
        if ("".equals(name)) {
            name = "未知";
        }
        bean.setName(name);
        bean.setPhone(phone);
        new Thread() {
            public void run() {
                mContactsList = getAllAnloqContacts();
                if (mContactsList == null) {
                    mContactsList = new ArrayList<>();
                }
                if (!isExistSameNumber(phone)) { // 如果号码不存在
                    mContactsList.add(bean);
                    String allContactsJson = new Gson().toJson(mContactsList);
                    CacheUtils.putString(JSON_ANLOQ_CONTACTS, allContactsJson);
                }
            }
        }.start();
    }

    /**
     * 是否存在相同的手机号
     *
     * @param phone
     * @return
     */
    private boolean isExistSameNumber(String phone) {
        if (mContactsList.size() > 0) {
            for (int i = 0; i < mContactsList.size(); i++) {
                String phoneNum = mContactsList.get(i).getPhone();
                if (phoneNum.equals(phone)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 删除指定id的Message数据
     */
    public void deleteMessageById(final int id) {
        new Thread() {
            public void run() {
                mMsgList = getLocalData();
                if (mMsgList != null && mMsgList.size() > 0) {
                    if (id < mMsgList.size()) {
                        mMsgList.remove(id);
                        String mMsgListJson = new Gson().toJson(mMsgList);
                        CacheUtils.putString(JSON_MESSAGE, mMsgListJson);
                    }
                }
            }
        }.start();
    }

    /**
     * 删除指定id的通话记录的数据
     */
    public void deleteCallRecordById(final int id) {
        new Thread() {
            public void run() {
                mCallRecList = getCallRecordData();
                if (mCallRecList != null && mCallRecList.size() > 0) {
                    if (id < mCallRecList.size()) {
                        mCallRecList.remove(id);
                        String mMsgListJson = new Gson().toJson(mCallRecList);
                        CacheUtils.putString(JSON_CALL_RECORD, mMsgListJson);
                    }
                }
            }
        }.start();
    }

    /**
     * 设置为已读状态
     */
    public void setReadState(final int id) {
        new Thread() {
            public void run() {
                mMsgList = getLocalData();
                // 1.修改数据
                if (mMsgList != null && mMsgList.size() > 0) {
                    if (id < mMsgList.size()) {
                        MessageBean message = mMsgList.get(id);
                        message.setRead(true);
                        // 2.保存到本地
                        String mMsgListJson = new Gson().toJson(mMsgList);
                        CacheUtils.putString(JSON_MESSAGE, mMsgListJson);
                    }
                }
            }
        }.start();
    }

    /**
     * 保存开锁记录
     *
     * @param record
     */
    public void saveUnlockRecord(final String record) {
        new Thread() {
            public void run() {
                String unlockRecord = getUnlockRecord();
                if (!TextUtils.isEmpty(unlockRecord)) {
                    // 删除旧数据
                    boolean isDelete = CacheUtils.deleteString(JSON_UNLOCK_RECORD);
                }
                if (record != null && !TextUtils.isEmpty(record)) {
                    CacheUtils.putString(JSON_UNLOCK_RECORD, record);
                }
            }
        }.start();
    }

    /**
     * 获取开锁记录
     */
    public String getUnlockRecord() {
        return CacheUtils.getString(JSON_UNLOCK_RECORD);
    }
}
