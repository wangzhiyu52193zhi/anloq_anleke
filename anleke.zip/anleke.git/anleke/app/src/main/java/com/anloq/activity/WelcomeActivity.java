package com.anloq.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.DeviceInfoManager;
import com.anloq.utils.MD5Utils;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.huawei.hms.api.ConnectionResult;
import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.support.api.client.PendingResult;
import com.huawei.hms.support.api.client.ResultCallback;
import com.huawei.hms.support.api.push.HuaweiPush;
import com.huawei.hms.support.api.push.TokenResult;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;

import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.MediaType;

// 欢迎页
public class WelcomeActivity extends Activity implements HuaweiApiClient.ConnectionCallbacks, HuaweiApiClient.OnConnectionFailedListener {
    private HuaweiApiClient client = null;
    private static final String TAG = WelcomeActivity.class.getSimpleName();
    private String account;
    private String password;
    private boolean lastsuccess = false; // 记录上次是否登录成功
    private Context mContext;
    protected String devicetoken = "";
    protected int device_type = 0;
    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    SpUtil.getInstance().save("helpguide", false);
                    startActivity(new Intent(WelcomeActivity.this, GuideActivity.class));
                    finish();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    startActivity(new Intent(WelcomeActivity.this, MainActivity.class));
                    overridePendingTransition(R.anim.tran_next_enter, R.anim.tran_next_exit);
                    finish();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        ButterKnife.bind(this);
        mContext = this;
        account = SpUtil.getInstance().getString("account", "");
        password = SpUtil.getInstance().getString("password", "");
        if (!TextUtils.isEmpty(account) && !TextUtils.isEmpty(password)) {
            handler.sendEmptyMessage(2);
        } else {
            handler.sendEmptyMessageDelayed(1, 1000);
        }
        if (client == null) {
            client = new HuaweiApiClient.Builder(this)
                    .addApi(HuaweiPush.PUSH_API)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .build();
        }
        //建议在oncreate的时候连接华为移动服务
        //业务可以根据自己业务的形态来确定client的连接和断开的时机，但是确保connect和disconnect必须成对出现
        client.connect();
        //startService(new Intent(WelcomeActivity.this, HuaweiService.class));
        //startService(new Intent(WelcomeActivity.this, GuardService.class));
    }

    @Override
    public void onConnected() {
        // 华为移动服务client连接成功，在这边处理业务自己的事件
        Log.e(TAG, "HuaweiApiClient 连接成功");
        getTokenAsyn();//申请token值
        setReceiveNormalMsg(true);//透传
    }

    @Override
    public void onConnectionSuspended(int arg0) {
        //HuaweiApiClient异常断开连接, if 括号里的条件可以根据需要修改
        client.connect();
        Log.e(TAG, "HuaweiApiClient 连接断开");
    }

    private void setReceiveNormalMsg(boolean flag) {
        if (!client.isConnected()) {
            Log.i(TAG, "设置是否接收push消息失败，原因：HuaweiApiClient未连接");
            client.connect();
            return;
        }
        if (flag) {
            Log.i(TAG, "允许应用接收push透传消息");
        } else {
            Log.i(TAG, "禁止应用接收push透传消息");
        }
        HuaweiPush.HuaweiPushApi.enableReceiveNormalMsg(client, flag);
    }

    @Override
    public void onConnectionFailed(ConnectionResult arg0) {
        Log.i(TAG, "HuaweiApiClient连接失败，错误码：" + arg0.getErrorCode());
    }

    private void getTokenAsyn() {
        if (!client.isConnected()) {
            Log.e(TAG, "获取token失败，原因：HuaweiApiClient未连接");
            client.connect();
            return;
        }

        Log.i(TAG, "异步接口获取push token");
        PendingResult<TokenResult> tokenResult = HuaweiPush.HuaweiPushApi.getToken(client);
        tokenResult.setResultCallback(new ResultCallback<TokenResult>() {
            @Override
            public void onResult(TokenResult result) {
                Log.e(TAG, "onResult: " + result);
            }
        });
    }

    /**
     * 自动登录
     */
    private void login() {
        //需要进行判断是什么机型
        device_type = DeviceInfoManager.getDeviceType();
        switch (device_type) {
            case 2:
                //华为手机
                devicetoken = SpUtil.getInstance().getString("devicetoken", "");
                break;
            case 3:
                //小米手机
                devicetoken = SpUtil.getInstance().getString("regId", "");
                break;
            default: // 其他手机
                devicetoken = "";
                break;
        }
        String md5Pwd = MD5Utils.MD5(password);
        HashMap<String, Object> map = new HashMap<>();
        map.put("phone", account);
        map.put("password", md5Pwd);
        map.put("devicetoken", devicetoken);
        map.put("device_type", device_type);// 2代表华为 3代表小米 0代表其他
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String content = gson.toJson(map);
        Logger.t(TAG).json(content);
        String url = Constants.LOGIN;

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e("登录联网失败===" + e.toString());
                        lastsuccess = SpUtil.getInstance().getBoolean("lastsuccess", false);
                        SpUtil.getInstance().save("netstate", false);
                        Logger.t(TAG).e("lastsuccess===" + lastsuccess);
                        if (lastsuccess) {
                            handler.sendEmptyMessageDelayed(3, 500);
                        }
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        SpUtil.getInstance().save("netstate", true);
                        parseResult(response);
                    }
                });
    }

    private void parseResult(String json) {
        String code = RequestUtil.getCode(mContext, json);
        // 注意此处登录成功后才可以获取uid和token
        if ("200".equals(code)) {
            RequestUtil.saveLoginSuccessInfo(json);
            //View decorView = getWindow().getDecorView();
            //StatusToast.show(mContext, 2, "登陆成功", decorView);
            handler.sendEmptyMessage(3);
        } else {
            handler.sendEmptyMessageDelayed(1, 1000);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
