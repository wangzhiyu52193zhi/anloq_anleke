package com.anloq.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.model.CallRecordBean;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/4/19 :)
 * Function:通话记录数据的适配器
 */

public class CallRecordAdapter extends BaseAdapter {

    private Context mContext;
    private List<CallRecordBean> allRecord;

    public CallRecordAdapter(Context mContext, List<CallRecordBean> allRecord) {
        this.mContext = mContext;
        this.allRecord = allRecord;
    }

    @Override
    public int getCount() {
        return allRecord.size();
    }

    @Override
    public Object getItem(int position) {
        return allRecord.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_call_record, null);
            ButterKnife.bind(convertView);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        CallRecordBean callRecordBean = allRecord.get(position);
        String callTime = "";
        if (callRecordBean != null) {
            holder.tvEqtName.setText(callRecordBean.getEqtName());
            holder.tvTime.setText(callRecordBean.getCurrentTime());
            callTime = callRecordBean.getCallTime();
        }
        if ("".equals(callTime)) {
            holder.tvCallTime.setText("(未接听)");
            holder.tvCallTime.setTextColor(mContext.getResources().getColor(R.color.sup_color_red_deep));
            holder.ivInCall.setVisibility(View.GONE);
            holder.ivNoCall.setVisibility(View.VISIBLE);
        } else {
            holder.tvCallTime.setText("(" + callTime + ")");
            holder.tvCallTime.setTextColor(mContext.getResources().getColor(R.color.gray_a));
            holder.ivInCall.setVisibility(View.VISIBLE);
            holder.ivNoCall.setVisibility(View.GONE);
        }
        return convertView;
    }

    static class ViewHolder {
        @BindView(R.id.ivIcon)
        ImageView ivIcon;
        @BindView(R.id.tvType)
        TextView tvType;
        @BindView(R.id.tvTime)
        TextView tvTime;
        @BindView(R.id.ivInCall)
        ImageView ivInCall;
        @BindView(R.id.ivNoCall)
        ImageView ivNoCall;
        @BindView(R.id.tvEqtName)
        TextView tvEqtName;
        @BindView(R.id.tvCallTime)
        TextView tvCallTime;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
