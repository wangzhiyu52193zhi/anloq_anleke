package com.anloq;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

import com.anloq.api.OkHttpDns;
import com.anloq.utils.LocaleUtils;
import com.anloq.utils.SoundPoolUtils;
import com.anloq.utils.SpUtil;
import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;
import com.umeng.analytics.MobclickAgent;
import com.umeng.socialize.PlatformConfig;
import com.umeng.socialize.UMShareAPI;
import com.xiaomi.mipush.sdk.MiPushClient;
import com.zhy.http.okhttp.OkHttpUtils;

import org.litepal.LitePal;
import org.litepal.tablemanager.Connector;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;

/**
 * Created by xpf on 2017/2/20:)
 * Function:初始化相关操作
 */

public class MyApplication extends Application {

    public static Context mContext;
    public static Handler mHandler;
    public static Thread mainThread; // 获取主线程
    public static int mainThreadId;  // 获取主线程的id

    //小米推送初始化需要用到的三个参数
    public static final String APP_ID = "2882303761517592356";
    public static final String APP_KEY = "5571759290356";
    public static final String TAG = "com.anloq.anleke";
    //推送消息队列
    protected static HashSet<Integer> messageQueueList = null;

    static {
        //初始化三个平台的wx3b499d678a3bd905
        PlatformConfig.setWeixin("wx3b499d678a3bd905", "a0024ae556ab4335e8238a7339ba2afb");
        PlatformConfig.setQQZone("1106156333", "kkZxpgat8tL8Um9w");
        //暂时没有新浪的
        PlatformConfig.setSinaWeibo("3408725612", "c96c0658e15e93098c22f970675798bb", "http://sns.whalecloud.com/sina2/callback");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        UMShareAPI.get(this);
        mContext = this;
        mHandler = new Handler();
        mainThread = Thread.currentThread();       // 当前用于初始化Application的线程，即为主线程
        mainThreadId = android.os.Process.myTid(); // 获取当前主线程的id
        messageQueueList = new HashSet<>();//初始化消息队列

        createDB();
        initOkhttpClient();

        SoundPoolUtils.init(this);
        changeAppLanguage();

        Logger.addLogAdapter(new AndroidLogAdapter());
        // 上线后清除所有Logger显示
        //Logger.clearLogAdapters();

        // 设置出现未捕获异常时的处理类
        //CrashHandler.getInstance().init();

        // 小米推送
        if (shouldInit()) {
            MiPushClient.registerPush(this, APP_ID, APP_KEY);
        }
        // umeng
        MobclickAgent.setScenarioType(mContext, MobclickAgent.EScenarioType.E_UM_NORMAL);
    }

    private void createDB() {
        // 初始化LitePal数据库
        LitePal.initialize(this);
        Connector.getDatabase();
    }

    /**
     * 初始化OKhttpClient配置
     */
    private void initOkhttpClient() {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(10000L, TimeUnit.MILLISECONDS)
                .readTimeout(10000L, TimeUnit.MILLISECONDS)
                .dns(OkHttpDns.getInstance(getApplicationContext()))
                .hostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String hostname, SSLSession session) {
                        if (hostname.contains("anloq.com")) {
                            return true;
                        }
                        return false;
                    }
                })
                .sslSocketFactory(getSSLSocketFactory())
                .build(); //其他配置

        OkHttpUtils.initClient(okHttpClient);
    }

    private boolean shouldInit() {
        ActivityManager am = ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE));
        List<ActivityManager.RunningAppProcessInfo> processInfos = am.getRunningAppProcesses();
        String mainProcessName = getPackageName();
        int myPid = mainThreadId;
        for (ActivityManager.RunningAppProcessInfo info : processInfos) {
            if (info.pid == myPid && mainProcessName.equals(info.processName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 获取消息队列
     *
     * @return
     */
    public static HashSet<Integer> getMessageQuene() {
        return messageQueueList;
    }

    /**
     * 获取全局上下文
     *
     * @return
     */
    public static Context getContext() {
        return mContext;
    }

    /**
     * https SSL证书设置
     *
     * @return
     */
    private static SSLSocketFactory getSSLSocketFactory() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            return sslSocketFactory;
        } catch (KeyManagementException | NoSuchAlgorithmException e) {
            return null;
        }
    }

    /**
     * 设置语言：如果之前有设置就遵循设置如果没设置过就跟随系统语言
     */
    private void changeAppLanguage() {
        int currentLanguage = SpUtil.getInstance().getInt("currentlanguage", -1);
        Locale myLocale;
        // 0 简体中文 1 繁体中文 2 English
        switch (currentLanguage) {
            case 0:
                myLocale = Locale.SIMPLIFIED_CHINESE;
                break;
            case 1:
                myLocale = Locale.TRADITIONAL_CHINESE;
                break;
            case 2:
                myLocale = Locale.ENGLISH;
                break;
            default:
                myLocale = getResources().getConfiguration().locale;
        }
        // 本地语言设置
        if (LocaleUtils.needUpdateLocale(this, myLocale)) {
            LocaleUtils.updateLocale(this, myLocale);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.e("TAG", "onConfigurationChanged");
        setLanguage(newConfig);
    }

    /**
     * 当系统语言发生改变的时候还是继续遵循用户设置的语言
     *
     * @param newConfig
     */
    private void setLanguage(Configuration newConfig) {
        int currentLanguage = SpUtil.getInstance().getInt("currentlanguage", -1);
        Locale _UserLocale;
        // 0 简体中文 1 繁体中文 2 English
        switch (currentLanguage) {
            case 0:
                _UserLocale = Locale.SIMPLIFIED_CHINESE;
                break;
            case 1:
                _UserLocale = Locale.TRADITIONAL_CHINESE;
                break;
            case 2:
                _UserLocale = Locale.ENGLISH;
                break;
            default:
                _UserLocale = getResources().getConfiguration().locale;
        }
        // 系统语言改变了应用保持之前设置的语言
        if (_UserLocale != null) {
            Locale.setDefault(_UserLocale);
            Configuration _Configuration = new Configuration(newConfig);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                _Configuration.setLocale(_UserLocale);
            } else {
                _Configuration.locale = _UserLocale;
            }
            getResources().updateConfiguration(_Configuration, getResources().getDisplayMetrics());
        }
    }

}
