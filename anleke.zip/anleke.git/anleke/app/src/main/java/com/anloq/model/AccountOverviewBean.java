package com.anloq.model;

/**
 * Created by xpf on 2017/11/1 :)
 * Function:我的页面收益预览的Bean
 */

public class AccountOverviewBean {

    /**
     * name : account overview
     * object : {"recharge":0,"balance":99.63,"last_profit":0}
     * code : 200
     */

    private String name;
    private ObjectBean object;
    private int code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public static class ObjectBean {
        /**
         * recharge : 0
         * balance : 99.63
         * last_profit : 0
         */

        private String recharge;
        private String balance;
        private String last_profit;

        public String getRecharge() {
            return recharge;
        }

        public void setRecharge(String recharge) {
            this.recharge = recharge;
        }

        public String getBalance() {
            return balance;
        }

        public void setBalance(String balance) {
            this.balance = balance;
        }

        public String getLast_profit() {
            return last_profit;
        }

        public void setLast_profit(String last_profit) {
            this.last_profit = last_profit;
        }
    }
}
