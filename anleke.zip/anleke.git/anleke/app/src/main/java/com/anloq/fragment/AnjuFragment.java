package com.anloq.fragment;

import android.util.Log;
import android.view.View;

import com.anloq.adapter.MyFragmentPagerAdapter;
import com.anloq.anleke.R;
import com.anloq.base.BaseFragment;
import com.anloq.ui.MyViewPager;
import com.anloq.ui.NotifcationView;
import com.flyco.tablayout.SlidingTabLayout;
import com.flyco.tablayout.listener.OnTabSelectListener;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/3/22:)
 * Function:安居页面的Fragment
 */

public class AnjuFragment extends BaseFragment {

    private static final String TAG = AnjuFragment.class.getSimpleName();
    @BindView(R.id.slidingTabLayout)
    SlidingTabLayout slidingTabLayout;
    @BindView(R.id.viewPager)
    MyViewPager viewPager;
    private List<BaseFragment> fragments;
    private String[] topTitles = new String[2];

    @Override
    public View initView() {
        View view = View.inflate(mContext, R.layout.fragment_anju, null);
        ButterKnife.bind(this, view);
        Log.e(TAG, "安居页面的视图初始化了");
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        Log.e(TAG, "安居页面的数据初始化了");
        topTitles[0] = getResources().getString(R.string.anju_message);
        topTitles[1] = getResources().getString(R.string.anju_opendoor_record);
        viewPager.setNoScroll(true);
        NotifcationView.cancelNotice();
        initFragment();
        initListener();
    }

    private void initFragment() {
        fragments = new ArrayList<>();
        fragments.add(new MessageFragment());
        fragments.add(new UnlockRecFragment());
        if (fragments != null && fragments.size() > 0) {
            // 设置ViewPager的适配器
            viewPager.setAdapter(new MyFragmentPagerAdapter(getFragmentManager(), fragments, topTitles));
            slidingTabLayout.setViewPager(viewPager); // 将slidingTabLayout和ViewPager绑定！
        }
        viewPager.setCurrentItem(0); // 默认在第一页
    }

    private void initListener() {
        // 设置Tab指示器选择的监听
        slidingTabLayout.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                viewPager.setCurrentItem(position);
            }

            @Override
            public void onTabReselect(int position) {

            }
        });
    }

}
