package com.anloq.fragment;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.anloq.activity.AboutOurActivity;
import com.anloq.activity.AvailableDetail;
import com.anloq.activity.BindingActivity;
import com.anloq.activity.CallSetting;
import com.anloq.activity.GuideActivity;
import com.anloq.activity.HelpActivity;
import com.anloq.activity.KeyPkgActivity;
import com.anloq.activity.MainActivity;
import com.anloq.activity.MultiLanguage;
import com.anloq.activity.MySignActivity;
import com.anloq.activity.NoDisturbActivity;
import com.anloq.activity.OpinionActivity;
import com.anloq.activity.ProfitDetailActivity;
import com.anloq.activity.SettingActivity;
import com.anloq.activity.WithdrawActivity;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.base.BaseFragment;
import com.anloq.manager.BrightnessManager;
import com.anloq.manager.ProfileManager;
import com.anloq.model.AccountOverviewBean;
import com.anloq.model.EventBusMsg;
import com.anloq.model.ProfileBean;
import com.anloq.model.VkeyBean;
import com.anloq.nfcservice.EmqttService;
import com.anloq.nfcservice.NFCEmuService;
import com.anloq.ui.GlideCircleTransform;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;
import org.litepal.crud.DataSupport;

import java.io.File;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

/**
 * Created by xpf on 2017/3/22 :)
 * Function:我的页面的Fragment
 */
public class MeFragment extends BaseFragment {
    private static final String TAG = MeFragment.class.getSimpleName();
    @BindView(R.id.llMyInfo)
    LinearLayout llMyInfo;
    @BindView(R.id.llMySign)
    LinearLayout llMySign;
    @BindView(R.id.rlKeyBag)
    RelativeLayout rlKeyBag;
    @BindView(R.id.rlBinding)
    RelativeLayout rlBinding;
    @BindView(R.id.rlCallSetting)
    RelativeLayout rlCallSetting;
    @BindView(R.id.rlNoDisturb)
    RelativeLayout rlNoDisturb;
    @BindView(R.id.rlHelp)
    RelativeLayout rlHelp;
    @BindView(R.id.rlOpinion)
    RelativeLayout rlOpinion;
    @BindView(R.id.rlAboutOur)
    RelativeLayout rlAboutOur;
    @BindView(R.id.tvLogout)
    TextView tvLogout;
    @BindView(R.id.rlInvite_friends)
    RelativeLayout rlInvite_friends;
    @BindView(R.id.rlMultiLanguage)
    RelativeLayout rlMultiLanguage;
    @BindView(R.id.toggleIn)
    ToggleButton toggleIn;
    @BindView(R.id.ivIcon)
    ImageView ivIcon;
    @BindView(R.id.tvNickName)
    TextView tvNickName;
    @BindView(R.id.tvPhone)
    TextView tvPhone;
    @BindView(R.id.tvAnluoId)
    TextView tvAnluoId;
    @BindView(R.id.llInvest)
    LinearLayout llInvest;
    @BindView(R.id.llLastProfit)
    LinearLayout llLastProfit;
    @BindView(R.id.tvAvailable)
    TextView tvAvailable;
    @BindView(R.id.tvWithdraw)
    TextView tvWithdraw;
    @BindView(R.id.tvRecharge)
    TextView tvRecharge;
    @BindView(R.id.tvLastProfit)
    TextView tvLastProfit;
    @BindView(R.id.llMyProfit)
    LinearLayout llMyProfit;
    private int uid;
    private PopupWindow popupWindow, popupInvestWindow;
    private View popupView, InvestView;
    private TranslateAnimation animation;
    private String recharge;

    @Override
    public View initView() {
        View view = View.inflate(mContext, R.layout.fragment_me, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        //initProfitView();
        initListener();
    }

    private void initProfitView() {
        boolean accountVisible = SpUtil.getInstance().getBoolean("accountVisible", false);
        llMyProfit.setVisibility(accountVisible ? View.VISIBLE : View.GONE);
        if (accountVisible) {
            getMyProfitInfo();
        }
    }

    private void getMyProfitInfo() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.ACCOUNTOVERVIEW + uid + Constants.TOKEN + token;
        Logger.t(TAG).i("AccountOverview_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseProfit(response);
                    }
                });
    }

    private void parseProfit(String json) {
        AccountOverviewBean overviewBean = new Gson().fromJson(json, AccountOverviewBean.class);
        AccountOverviewBean.ObjectBean object = overviewBean.getObject();
        if (object != null) {
            String balance = object.getBalance();
            String last_profit = object.getLast_profit();
            recharge = object.getRecharge();
            tvRecharge.setText(String.valueOf(recharge));
            tvAvailable.setText(getString(R.string.available_profit_text) + String.valueOf(balance));
            tvLastProfit.setText(String.valueOf(last_profit));
        }
    }

    private void initListener() {
        // 是否接听
        toggleIn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {
                Logger.t(TAG).i("是否接听===" + isChecked);
                SpUtil.getInstance().save("isaccept", isChecked);
                HashMap<String, Object> map = new HashMap<>();
                map.put("call_answer", isChecked);
                ProfileManager.update(map, new ProfileManager.OnProfileUpdateListener() {
                    @Override
                    public void onUpdate(String result) {
                        String code = RequestUtil.getCode(mContext, result);
                        if ("200".equals(code)) {
                            Logger.t(TAG).i("是否接听设置成功isChecked===" + isChecked);
                        }
                    }
                });
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        getData();// 更新信息
    }

    private void getData() {
        uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.GETPROFILE + uid + Constants.TOKEN + token;
        Log.e(TAG, "GETPROFILE_url===" + url);

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e(e.toString());
                        showUserInfo();
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseJson(response);
                    }
                });
    }

    /**
     * 断网时显示用户的信息
     */
    private void showUserInfo() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String account = SpUtil.getInstance().getString("account", "");
        String nickname = SpUtil.getInstance().getString("nickname", "");
        boolean isaccept = SpUtil.getInstance().getBoolean("isaccept", true);
        toggleIn.setChecked(isaccept);
        SpUtil.getInstance().save("isaccept", isaccept);
        tvNickName.setText(nickname);
        tvPhone.setText(account);
        tvAnluoId.setText("" + uid);
    }

    private void parseJson(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            ProfileBean profileBean = new Gson().fromJson(json, ProfileBean.class);
            ProfileBean.ObjectBean object = profileBean.getObject();
            if (object != null) {
                String headpic = object.getHeadpic();
                String nickname = object.getNickname();
                SpUtil.getInstance().save("nickname", nickname);
                tvNickName.setText(nickname);
                boolean call_answer = object.isCall_answer();
                toggleIn.setChecked(call_answer);
                if (mContext != null && headpic != null && !"".equals(headpic)) {
                    Glide.with(mContext)
                            .load(headpic)
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .transform(new GlideCircleTransform(mContext))
                            .skipMemoryCache(true)
                            .into(ivIcon);
                }
            }
            String account = SpUtil.getInstance().getString("account", "");
            tvPhone.setText(account);
            tvAnluoId.setText("" + uid);
        }
    }

    @OnClick({R.id.llMyInfo, R.id.llMySign, R.id.rlKeyBag, R.id.rlBinding, R.id.rlCallSetting,
            R.id.rlNoDisturb, R.id.rlHelp, R.id.rlOpinion, R.id.rlAboutOur, R.id.tvLogout,
            R.id.rlInvite_friends, R.id.rlMultiLanguage, R.id.llInvest, R.id.llLastProfit,
            R.id.tvAvailable, R.id.tvWithdraw})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llMyInfo:
                mContext.startActivity(new Intent(mContext, SettingActivity.class));
                break;
            case R.id.llMySign:
                mContext.startActivity(new Intent(mContext, MySignActivity.class));
                break;
            case R.id.rlKeyBag:
                mContext.startActivity(new Intent(mContext, KeyPkgActivity.class));
                break;
            case R.id.rlBinding:
                mContext.startActivity(new Intent(mContext, BindingActivity.class));
                break;
            case R.id.rlCallSetting:
                mContext.startActivity(new Intent(mContext, CallSetting.class));
                break;
            case R.id.rlNoDisturb:
                mContext.startActivity(new Intent(mContext, NoDisturbActivity.class));
                break;
            case R.id.rlHelp:
                mContext.startActivity(new Intent(mContext, HelpActivity.class));
                break;
            case R.id.rlOpinion:
                mContext.startActivity(new Intent(mContext, OpinionActivity.class));
                break;
            case R.id.rlAboutOur:
                mContext.startActivity(new Intent(mContext, AboutOurActivity.class));
                break;
            case R.id.rlInvite_friends:
                //分享app给好友
                //表示的是带链接的 消息通知 url
                UMImage thumb = new UMImage(getActivity(), R.drawable.icon_anloq);
                UMWeb web = new UMWeb("http://www.anloq.com/app_mobile");
                web.setTitle("安络客下载");//标题
                web.setDescription("点击打开链接");
                web.setThumb(thumb);  //缩略图
                new ShareAction(getActivity())
                        .withMedia(web)
                        .setDisplayList(SHARE_MEDIA.SINA, SHARE_MEDIA.QQ, SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE)
                        .setCallback(umShareListener).open();
                break;
            case R.id.tvLogout:
                showConfirm();
                BrightnessManager.lightoff(mContext);
                break;
            case R.id.rlMultiLanguage:
                startActivity(new Intent(mContext, MultiLanguage.class));
                break;
            case R.id.llInvest:
                showInvestDialog();
                BrightnessManager.lightoff(mContext);
                break;
            case R.id.llLastProfit:
                startActivity(new Intent(mContext, ProfitDetailActivity.class));
                break;
            case R.id.tvAvailable:
                startActivity(new Intent(mContext, AvailableDetail.class));
                break;
            case R.id.tvWithdraw:
                startActivity(new Intent(mContext, WithdrawActivity.class));
                break;
        }
    }

    private void showInvestDialog() {
        if (popupInvestWindow == null) {
            InvestView = View.inflate(mContext, R.layout.popupwindow_invest, null);
            popupInvestWindow = new PopupWindow(InvestView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT);
            popupInvestWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(mContext);
                }
            });
            popupInvestWindow.setBackgroundDrawable(new BitmapDrawable());
            popupInvestWindow.setFocusable(true);
            popupInvestWindow.setOutsideTouchable(false);

            TextView tvRecharge = (TextView) InvestView.findViewById(R.id.tvRecharge);
            tvRecharge.setText("您有" + recharge + "元的投资份额");
            InvestView.findViewById(R.id.tvIKnow).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupInvestWindow.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
        }

        if (popupInvestWindow.isShowing()) {
            popupInvestWindow.dismiss();
            BrightnessManager.lighton(mContext);
        }
        popupInvestWindow.showAtLocation(getActivity().findViewById(R.id.me_fragment),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
    }

    private UMShareListener umShareListener = new UMShareListener() {
        @Override
        public void onStart(SHARE_MEDIA platform) {
            //分享开始的回调
        }

        @Override
        public void onResult(SHARE_MEDIA platform) {
            platformName = platform.toString();
            Log.d("plat", "platform" + platform);
            getPlatformName(platformName);
            Toast.makeText(getActivity(), platformToastName + getString(R.string.share_success), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable t) {
            platformName = platform.toString();
            getPlatformName(platformName);
            //Toast.makeText(getActivity(), platformToastName + getString(R.string.share_fail), Toast.LENGTH_SHORT).show();
            if (t != null) {
                Log.d("throw", "throw:" + t.getMessage());
                if (t.getMessage().contains("2008")) {
                    if (platformToastName.equals(getString(R.string.WEIXIN_CIRCLE))) {
                        platformToastName = getString(R.string.WEIXIN);
                    }
                    ToastUtil.show(getString(R.string.not_install_text) + platformToastName);
                }
            }
        }

        @Override
        public void onCancel(SHARE_MEDIA platform) {
            platformName = platform.toString();
            if (platformName.equals("QQ"))
                return;
            getPlatformName(platformName);
            Toast.makeText(getActivity(), platformToastName + getString(R.string.share_cancel), Toast.LENGTH_SHORT).show();
        }
    };
    private String platformToastName = "";
    private String platformName = "";

    private void getPlatformName(String str) {
        switch (str) {
            case "SINA":
                platformToastName = getString(R.string.SINA);
                break;
            case "QQ":
                platformToastName = getString(R.string.QQ);
                break;
            case "WEIXIN":
                platformToastName = getString(R.string.WEIXIN);
                break;
            case "WEIXIN_CIRCLE":
                platformToastName = getString(R.string.WEIXIN_CIRCLE);
                break;

        }
    }

    /**
     * 显示确认退出框
     */
    private void showConfirm() {
        if (popupWindow == null) {
            popupView = View.inflate(mContext, R.layout.item_logout, null);
            popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);

            popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(mContext);
                }
            });

            popupWindow.setBackgroundDrawable(new BitmapDrawable());
            popupWindow.setFocusable(true);
            popupWindow.setOutsideTouchable(true);
            animation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0, Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 1, Animation.RELATIVE_TO_PARENT, 0);
            animation.setInterpolator(new AccelerateInterpolator());
            animation.setDuration(200);

            popupView.findViewById(R.id.tvLogout).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    logout();
                    popupWindow.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            popupView.findViewById(R.id.tvCancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
        }

        if (popupWindow.isShowing()) {
            popupWindow.dismiss();
            BrightnessManager.lighton(mContext);
        }

        // 设置popupWindow的显示位置，此处是在手机屏幕底部且水平居中的位置
        popupWindow.showAtLocation(getActivity().findViewById(R.id.me_fragment),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        popupView.startAnimation(animation);
    }

    /**
     * 退出登录
     * TODO : 退出登录是否需要联网？考虑到退订topic
     */
    private void logout() {
        quit();//退出登录
        String account = SpUtil.getInstance().getString("account", "");
        String huawei_token = SpUtil.getInstance().getString("devicetoken", "");
        String xiaomi_regId = SpUtil.getInstance().getString("regId", "");
        SpUtil.getInstance().clearAll();
        // 1.清除sp存储中保存的用户信息
        SpUtil.getInstance().save("isfirst", false);
        SpUtil.getInstance().save("account", account);
        SpUtil.getInstance().save("devicetoken", huawei_token);//华为token
        SpUtil.getInstance().save("regId", xiaomi_regId);//小米注册regId
        DataSupport.deleteAll(VkeyBean.class);
        // 2.删除本地用户头像文件
        String filePath = mContext.getCacheDir() + "/tx.png";
        File file = new File(filePath);
        if (file.exists()) {
            file.delete();
        }
        // 3.发送取消订阅的消息 -> EmqttService
        EventBus.getDefault().post(new EventBusMsg("unsubscribe", ""));
        // Kill Service
        mContext.stopService(new Intent(mContext, NFCEmuService.class));
        mContext.stopService(new Intent(mContext, EmqttService.class));
        //mContext.stopService(new Intent(mContext, HuaweiService.class));
        //mContext.stopService(new Intent(mContext, GuardService.class));
        // 4.结束当前Activity的显示,跳转到登录页面
        mContext.startActivity(new Intent(mContext, GuideActivity.class));
        MainActivity mainActivity = (MainActivity) mContext;
        mainActivity.finish();
    }

    // 退出登录
    private void quit() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.LOGOUT + uid + Constants.TOKEN + token;// + Constants.STARTTIME + lasttime;
        Log.e(TAG, "LOGOUT_url===" + url);
        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Log.e(TAG, "网络访问错误！");
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Log.e(TAG, "退出登录===" + response);
                    }
                });
    }

}
