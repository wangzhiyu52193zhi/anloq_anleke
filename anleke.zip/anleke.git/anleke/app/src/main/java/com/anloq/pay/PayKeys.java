package com.anloq.pay;

/**
 * Created by xpf on 2017/11/01.
 * 提示：如何获取安全校验码和合作身份者id
 * 1.用您的签约支付宝账号登录支付宝网站(www.alipay.com)
 * 2.点击“商家服务”(https://b.alipay.com/order/myorder.htm)
 * 3.点击“查询合作者身份(pid)”、“查询安全校验码(key)”
 */
public class PayKeys {
    // 请参考 Android平台安全支付服务(msp)应用开发接口(4.2 RSA算法签名)部分，
    // 并使用压缩包中的openssl RSA密钥生成工具，生成一套RSA公私钥。
    // 这里签名时，只需要使用生成的RSA私钥。
    // Note: 为安全起见，使用RSA私钥进行签名的操作过程，应该尽量放到商家服务器端去进行。

    /**
     * 支付宝支付业务：入参app_id
     */
    public static final String APPID = "2017031306200835";

    /**
     * 支付宝账户登录授权业务：入参pid值，以2088开头的16位纯数字
     */
    public static final String PID = "2088102174754775";

    // 收款支付宝账号
    public static final String DEFAULT_SELLER = "917356107@qq.com";
    // 商户私钥，自助生成，在压缩包中有openssl，用此软件生成商户的公钥和私钥，写到此处要不然服务器返回错误。公钥要传到淘宝合作账户里详情请看淘宝的sdk文档
    public static final String PRIVATE = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAL51jaxQhxW9PnWpW+nz6yJ76tp9eGFXmfGnuxMK+Pmx/qavdsewXOLBfI2OSCR39TzxwMYvCmUrnrt0fVSa7mblbNos2FnMM9ijnx8bsAAhm+i7BKhuaHMunJKH69L+D753zH3P1YIh0ly5DnAr3WPqHydp384qBvb8NS9Tay0HAgMBAAECgYB82PIVknP6fCMFXg8yPQJViIVa1ASlSpdPIXQv93FdvKABA+QI4kMBIXRUFoCT506KtK55OzzFNOLIXoQJgcXj69z0l6pmjJJgXMaBW/9rOzelot13CiGatrIrGngEZO+bCBTud/jQA598zjZ1g182tT+FLDL7GIftW2hC8GqtAQJBAN+XrYsyfL+uSmLdAVEz1vzziU1naGr10Msm1jMnnO/JYdB+84j7FSHxsQ4YOgsmeN5YVsJcVfc/CReOxknns38CQQDaEHnVPDt+Z7sqT7bN0UKh0/CrqkDTiIjhz1lJyIIoqVRoeJjJn1wlEKBV5R9gkTJutQTVU19XFtblMEnOy6p5AkEAw170rEmMSa0QoHw+d2bVtydR1QnDapqqO6kOx5oYfkm4J4eWYx4J5CQdMpSmuzF9scL85E3sa+NvnV8LEm7cHwJALtXzFPWG4bNt47yTSslzQka/Hl/G5Kginj1mtA44xnr4AihEyKlNpThY95nqj1cgOd7vVtI9W/sv1LH2aFAeIQJBAIqXbMc6xGVfuiFAJKtg+AFNMBP0UOEgMEoKo4RPFp21nBhFgL9/WYM4ZjyHUdr45rCySAqQovw4DCHLfQZC23I=";
    // 公钥
    public static final String PUBLIC = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC+dY2sUIcVvT51qVvp8+sie+rafXhhV5nxp7sTCvj5sf6mr3bHsFziwXyNjkgkd/U88cDGLwplK567dH1Umu5m5WzaLNhZzDPYo58fG7AAIZvouwSobmhzLpySh+vS/g++d8x9z9WCIdJcuQ5wK91j6h8nad/OKgb2/DUvU2stBwIDAQAB";
    /**
     * 支付宝账户登录授权业务：入参target_id值
     */
    public static final String TARGET_ID = "bnoiyg8132@sandbox.com";

    /** 商户私钥，pkcs8格式 */
    /** 如下私钥，RSA2_PRIVATE 或者 RSA_PRIVATE 只需要填入一个 */
    /** 如果商户两个都设置了，优先使用 RSA2_PRIVATE */
    /** RSA2_PRIVATE 可以保证商户交易在更加安全的环境下进行，建议使用 RSA2_PRIVATE */
    /** 获取 RSA2_PRIVATE，建议使用支付宝提供的公私钥生成工具生成， */
    /**
     * 工具地址：https://doc.open.alipay.com/docs/doc.htm?treeId=291&articleId=106097&docType=1
     */
    public static final String RSA2_PRIVATE = "MIIEpAIBAAKCAQEAohmNOHZfn2hLgZgmeoEWBJIcE5400M3sqQkYxN7UJ6O0UfH0\n" +
            "f+UG3wU1+d15GlMFtPhtQ2TRuKJklpr9ecc4b3suDrSVGftk17KYUE6ARXK/asvT\n" +
            "ev12t0DNZPxCp/+afXMlUIc7sCrlAlcxEfVLGT39wKX+6gOFNjE0ioVGtDYXxiPx\n" +
            "2a2aQX5Aiqkjx0Q5NOO6qVBcNDetLx/jz5wKhGB3A7/gxpwIM0B4lbOPWj9c3amR\n" +
            "cmPHZKT2n3Y25vf7vthfGRNnN47cNimT6Gn/Ps5qefjKR9V1nWcMwWWlFF8OR4tT\n" +
            "W2YYbKMvTc3b0+ScoaQjmaIzHM/CombDpyxQUQIDAQABAoIBAFrKmvmL+6UKQnhU\n" +
            "owCseouW1pj6XLSzEiHfUXs7H3MQUvgu3/YebknN3lyT+reO1rx1BKXhu0GB23sr\n" +
            "Vlu2BNsUEEj2RijmUKYrhvo77cZ4LdSAU3QosSyU5DXywNbd6EbpjnXbOMhETj6Q\n" +
            "XZCkZiq+OPmFQBEMZbljt/z6Bw759PxnZCW+xRuXz9RFZzVY1NaQh1Ji9b6mGHP/\n" +
            "s4xQyfTxP4SInQlrpiTQdbAd3Y4l62VDRNhP/EF0QNnoPtSDypUO3hKJAZHPe0Kb\n" +
            "GuzBXBEaF4uWRd/FCydwtRk4F1v0EDxiJmpEqP04raBzHPkMUNGrksBm+pVFmT8M\n" +
            "g95gLa0CgYEAz4XAf39xMCVOpYq21DVMxmkBRF+/hw6ZcPFLZ967CKBS8xWMuqx0\n" +
            "BdXu/UiDXj71V0FWiDRA+P944vjx+3XzYTiUpxHpbfEPaUZNRbuejZQR60sY53MD\n" +
            "r2rrSI4lbOuRuM9+cjAoCm/rqNYSqvUEGw9dWyYo6TwuDqmT+KGnF4cCgYEAx/dv\n" +
            "rrZ4O5cLB7SKWdEjXQNuXwd4RMx9WDNBkecD4E/rpUvazafjGACHsCzsB1+KtA2/\n" +
            "S4cmRLcrrx+9j78jVocQPBvJNOtofVW1XXE+dLYfvcrRV3zR+hv/8ZMTBdrD8gHt\n" +
            "Lvg2SJzYeqqjJ7EG5Ixvt+M8gk20vuyAcytDn2cCgYEAr+YROoDNch/NP+gJ/GmJ\n" +
            "QAw1NL1r3JB1YxRD9DEIm9E5Pi4f8QLH/UJOpoXWRAZdcq5BKIYSJHx2/PxCMADU\n" +
            "YK3S4qH+GGBhzbv3N4pGZH8DiUtIOrZ0gzW/ZOqHsoEiLWJDLYrABcjEGYIKpLm1\n" +
            "1zH40Y/Q0ZFfALKgZ/itZvUCgYEAiqDVgi/p5pXuBad6Co5cj80jJSpOjJOfihfu\n" +
            "qzGWlFmTqgKOa+iqHSew6cga0XnA9NZa+gd11kmONVgx2IfP/dqgvKsesFtLEyjq\n" +
            "FR+/BraEBtWmj5pvD499voIRvAtPsGT5g4h8SZbC1Tea6JdnieZ6ROd6OXOZjIr0\n" +
            "+eLSfJ0CgYBdXmXG0H9QA6pq85RrmlakGWj9dWDxr4Ms+l52+vF0uzmr7I/1lxSO\n" +
            "JLsrPjX60ygguCCGbPgrHpWNucWx44AWeeJIBmGWBxXznGtJ27bySHUzVWL+4jw6\n" +
            "aDndbGqjJJuZuGaOhKRisa3rOu3AjaCqcgdCvjyafVWs1H8HDQjhVQ==";
    public static final String RSA_PRIVATE = "";
}

