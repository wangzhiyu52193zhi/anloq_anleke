package com.anloq.manager;

import android.app.KeyguardManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.os.PowerManager;
import android.util.Log;

import com.anloq.MyApplication;
import com.anloq.utils.ToastUtil;

import static android.content.Context.KEYGUARD_SERVICE;

/**
 * Created by xpf on 2017/6/3 :)
 * Function:手机特性的的管理者(如：NFC等)
 */

public class FeatureManager {

    private static final String TAG = FeatureManager.class.getSimpleName();

    /**
     * 是否有支持NFC，及是否打开
     *
     * @return 0:不支持  1：打开  2：关闭
     */
    public static int nfcState() {
        int state = -1;
        NfcManager manager = (NfcManager) MyApplication.getContext()
                .getSystemService(Context.NFC_SERVICE);
        NfcAdapter adapter = manager.getDefaultAdapter();
        if (adapter != null) { // adapter存在
            if (adapter.isEnabled()) { // 打开
                state = 1;
            } else { // 关闭
                state = 2;
            }
        } else {
            state = 0;
        }
        return state;
    }

    /**
     * 是否有支持BLE，及是否打开
     *
     * @return 0:不支持  1：打开  2：关闭
     */
    public static int bleState() {
        int state = -1;
        // 判断手机是否支持ble否则结束当前页面
        if (!MyApplication.getContext().getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            ToastUtil.show("BLE不支持");
            Log.e(TAG, "BLE不支持");
        }
        BluetoothAdapter mBluetoothAdapter = getBleAdapter(); // 蓝牙适配器
        // 检查手机是否支持蓝牙
        if (mBluetoothAdapter == null) {
            ToastUtil.show("Bluetooth not supported.");
            Log.e(TAG, "Bluetooth not supported.");
            state = 0;
        } else {
            if (mBluetoothAdapter.isEnabled()) {
                state = 1;
            } else {
                state = 2;
            }
        }
        return state;
    }

    /**
     * 初始化蓝牙适配器 For API level 18 and above
     * 通过蓝牙管理器获取蓝牙适配器对象
     */
    public static BluetoothAdapter getBleAdapter() {
        final BluetoothManager bluetoothManager = (BluetoothManager) MyApplication.getContext()
                .getSystemService(Context.BLUETOOTH_SERVICE);
        return bluetoothManager.getAdapter();
    }

    /**
     * 唤醒手机屏幕并解锁
     */
    public static void wakeUpAndUnlock() {
        // 获取电源管理器对象
        PowerManager pm = (PowerManager) MyApplication.getContext()
                .getSystemService(Context.POWER_SERVICE);
        boolean screenOn = pm.isScreenOn();
        if (!screenOn) {
            // 获取PowerManager.WakeLock对象,后面的参数|表示同时传入两个值,最后的是LogCat里用的Tag
            PowerManager.WakeLock wl = pm.newWakeLock(
                    PowerManager.ACQUIRE_CAUSES_WAKEUP |
                            PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "bright");
            wl.acquire(10000); // 点亮屏幕
            wl.release(); // 释放
        }
        // 屏幕解锁
        KeyguardManager keyguardManager = (KeyguardManager) MyApplication.getContext()
                .getSystemService(KEYGUARD_SERVICE);
        KeyguardManager.KeyguardLock keyguardLock = keyguardManager.newKeyguardLock("unLock");
        // 屏幕锁定
        keyguardLock.reenableKeyguard();
        keyguardLock.disableKeyguard(); // 解锁
    }
}
