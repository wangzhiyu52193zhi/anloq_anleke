package com.anloq.model;

/**
 * Created by xpf on 2017/6/6 :)
 * Function:开锁记录RecyclerView的悬浮日期
 */

public class TitleDate {

    private String date;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
