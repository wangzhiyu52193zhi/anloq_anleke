package com.anloq.api;

/**
 * Created by xpf on 2017/2/24:)
 * Function:联网请求常量类
 */
public class Constants {

    /**
     * HOST
     * 生产环境(HTTPS)：https://api.anloq.com:443
     * 研发环境：http://apidev.anloq.com:3001
     * 测试环境：http://apitest.anloq.com:3001
     */
    private static final String HOST = "http://api.anloq.com:3001";
    public static final String TOKEN = "&token=";
    public static final String PROVINCEID = "&province_id=";
    public static final String CITYID = "&city_id=";
    public static final String ZONEID = "&zone_id=";
    public static final String BUILDINGID = "&building_id=";
    public static final String UNITID = "&unit_id=";
    public static final String ROOMID = "&room_id=";
    public static final String PAGESIZE = "&pagesize=";
    public static final String PAGENUM = "&pagenum=";
    public static final String KEYID = "&key_id=";
    public static final String STARTTIME = "&starttime=";
    public static final String LASTRECORDID = "&last_record_id=";
    public static final String PHONE = "&phone=";
    public static final String IMAGEID = "&image_id=";

    /* 短信发送接口 */
    public static final String SMS = HOST + "/api/smsverify";

    /* 注册接口 */
    public static final String REGISTER = HOST + "/api/register";

    /* 登陆接口 */
    public static final String LOGIN = HOST + "/api/login";

    /* 修改密码接口 */
    public static final String CHANGEPWD = HOST + "/api/changepwd?uid=";

    /* 忘记密码接口 */
    public static final String RESETREGISTER = HOST + "/api/resetregister";

    /* 短信验证码登录（或忘记密码） */
    public static final String SMSLOGIN = HOST + "/api/smslogin";

    /* 安络目前支持的省市接口 */
    public static final String SELECTPROVINCE = HOST + "/api/provinceslist?uid=";

    /* 根据省市获取安络目前支持的城市，或者直辖市下的区域 */
    public static final String SELECTCITY = HOST + "/api/citeslist?uid=";

    /* 小区列表接口 */
    public static final String SELECTZONE = HOST + "/api/zonelist?uid=";

    /* 根据小区ID获取小区的楼洞信息 */
    public static final String SELECTBUILDING = HOST + "/api/buildinglist?uid=";

    /* 获取楼洞的单元信息 */
    public static final String SELECTUNIT = HOST + "/api/unitlist?uid=";

    /* 获取单元的房间信息 */
    public static final String SELECTROOM = HOST + "/api/roomlist?uid=";

    /* 钥匙申请接口 */
    public static final String APPLYKEY = HOST + "/api/vkeyrequest?uid=";

    /* 获取钥匙包接口 */
    public static final String KEYPACKAGE = HOST + "/api/vkeypack?uid=";

    /* 获取个人信息接口 */
    public static final String GETPROFILE = HOST + "/api/getprofile?uid=";

    /* 修改个人信息接口 */
    public static final String CHANGEPROFILE = HOST + "/api/changeprofile?uid=";

    /* 直接开锁接口 */
    public static final String UNLOCKINCALLING = HOST + "/api/calleqt?uid=";

    /* 获取服务联络电话接口 */
    public static final String SERVICETELS = HOST + "/api/servicetels?uid=";

    /* 钥匙授权接口 */
    public static final String AUTHKEY = HOST + "/api/authkey?uid=";

    /* 意见反馈接口 */
    public static final String ADDFEEDBACK = HOST + "/api/addfeedback?uid=";

    /* 获取开锁记录接口 */
    public static final String ROOMOPENRECORD = HOST + "/api/roomopenrecord?uid=";

    /* 授权管理：获取被我授权的钥匙列表接口 */
    public static final String KEYSBYME = HOST + "/api/keysbyme?uid=";

    /* (授权管理)暂停或者解冻或者删除某个已被授权的钥匙 */
    public static final String MODIFYVKEY = HOST + "/api/modifyvkey?uid=";

    /* 帮助（功能介绍） */
    public static final String GUIDEANSWER = HOST + "/api/gethelppage?uid=";

    /* 获取新手引导消息 */
    public static final String SENDGUIDEMSG = HOST + "/api/sendguidemsg?uid=";

    /* 退出登录接口 */
    public static final String LOGOUT = HOST + "/api/logout?uid=";

    /* 获取呼叫图片 */
    public static final String GETCALLIMG = HOST + "/api/getcallimg?uid=";

    /* 上报呼叫繁忙状态 */
    public static final String CALLBUSYMSG = HOST + "/api/callbusymsg?uid=";

    /* 安络客请求生成开锁二维码，此接口返回一个随机数，通知发给对应的安络保 */
    public static final String INIT_QRCODE_NUM = HOST + "/api/init_qrcode_num?uid=";

    /* 安络客调用该接口获取对应账户概览 */
    public static final String ACCOUNTOVERVIEW = HOST + "/api/accountOverview?uid=";

    /* 安络客调用该接口获取对应用户收益数据 */
    public static final String PROFITRECORDS = HOST + "/api/profitRecords?uid=";

    /* 安络客调用该接口获取对应用户账户金额变更记录 */
    public static final String TRADERECORDS = HOST + "/api/tradeRecords?uid=";

}
