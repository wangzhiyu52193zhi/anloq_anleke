package com.anloq.model;

/**
 * Created by xpf on 2017/4/21 :)
 * Function:Ble状态的Bean
 */

public class BleState {

    private boolean isEnable;
    private String key_id;

    public BleState() {
    }

    public BleState(boolean isEnable, String key_id) {
        this.isEnable = isEnable;
        this.key_id = key_id;
    }

    public boolean isEnable() {
        return isEnable;
    }

    public void setEnable(boolean enable) {
        isEnable = enable;
    }

    public String getKey_id() {
        return key_id;
    }

    public void setKey_id(String key_id) {
        this.key_id = key_id;
    }

    @Override
    public String toString() {
        return "BleState{" +
                "isEnable=" + isEnable +
                ", key_id='" + key_id + '\'' +
                '}';
    }
}
