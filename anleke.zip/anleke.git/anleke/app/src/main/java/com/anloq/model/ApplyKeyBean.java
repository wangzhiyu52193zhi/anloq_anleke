package com.anloq.model;

/**
 * Created by xpf on 2017/3/28 :)
 * Function:
 */

public class ApplyKeyBean {

    /**
     * name : admin_info
     * object : {"room_admin_name":"中关村物业","room_admin_tel":"12345678901","room_admin_type":0}
     * code : 200
     */

    private String name;
    private ObjectBean object;
    private int code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public static class ObjectBean {
        /**
         * room_admin_name : 中关村物业
         * room_admin_tel : 12345678901
         * room_admin_type : 0
         */

        private String room_admin_name;
        private String room_admin_tel;
        private int room_admin_type;

        public String getRoom_admin_name() {
            return room_admin_name;
        }

        public void setRoom_admin_name(String room_admin_name) {
            this.room_admin_name = room_admin_name;
        }

        public String getRoom_admin_tel() {
            return room_admin_tel;
        }

        public void setRoom_admin_tel(String room_admin_tel) {
            this.room_admin_tel = room_admin_tel;
        }

        public int getRoom_admin_type() {
            return room_admin_type;
        }

        public void setRoom_admin_type(int room_admin_type) {
            this.room_admin_type = room_admin_type;
        }
    }
}
