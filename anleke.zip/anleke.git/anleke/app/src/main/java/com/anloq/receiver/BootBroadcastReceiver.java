package com.anloq.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by xpf on 2017/3/8:)
 * Function:接收系统开机广播的接收器
 */

public class BootBroadcastReceiver extends BroadcastReceiver {

    static final String ACTION = "android.intent.action.BOOT_COMPLETED";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(ACTION)) {
            Log.e("TAG", "收到了开机完成的广播");
            // 自启动APP，参数为需要自动启动的应用包名
            //Intent bootIntent = context.getPackageManager().getLaunchIntentForPackage("com.anloq.anlebao");
            //Intent serviceIntent = new Intent(context, ObserverService.class);
            // 必须加上下面这句才能开机自动运行app
            //serviceIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            //context.startService(serviceIntent);
        }
    }
}
