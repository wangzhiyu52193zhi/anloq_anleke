package com.anloq.receiver;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.anloq.utils.ParseUtil;
import com.anloq.utils.SpUtil;
import com.huawei.hms.support.api.push.PushReceiver;

import java.io.UnsupportedEncodingException;

/**
 * Created by Steven on 2017/8/9.
 * 自定义华为接收器
 */

public class HuaweiPushRevicer extends PushReceiver {

    protected String TAG = "HuaweiPushRevicer";
    protected String content = "";
    protected String belongId = "";

    @Override
    public void onToken(Context context, String token, Bundle bundle) {
        super.onToken(context, token, bundle);
        belongId = bundle.getString("belongId");
        Log.e(TAG, "belongId: " + belongId + ",token" + token);
        SpUtil.getInstance().save("devicetoken", token);
    }

    @Override
    public boolean onPushMsg(Context context, byte[] msg, Bundle bundle) {
        try {
            String content = new String(msg, "UTF-8");
            ParseUtil.joinQueue(content);
            return true;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void onEvent(Context context, Event event, Bundle bundle) {
        super.onEvent(context, event, bundle);
    }

    @Override
    public void onPushState(Context context, boolean pushState) {
        super.onPushState(context, pushState);
        Log.e("TAG", "Push连接状态为:" + pushState);
    }
}
