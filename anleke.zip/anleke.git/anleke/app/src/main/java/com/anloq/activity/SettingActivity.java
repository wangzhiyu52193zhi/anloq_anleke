package com.anloq.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.BrightnessManager;
import com.anloq.manager.ProfileManager;
import com.anloq.model.ProfileBean;
import com.anloq.ui.GlideCircleTransform;
import com.anloq.utils.Base64Util;
import com.anloq.utils.BitmapUtils;
import com.anloq.utils.DensityUtil;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

// 基本设置页面
public class SettingActivity extends Activity {

    private static final String TAG = SettingActivity.class.getSimpleName();
    private final int START_ALBUM_REQUESTCODE = 1;
    private final int CAMERA_WITH_DATA = 2;
    private final int CROP_RESULT_CODE = 3;
    public static final String TMP_PATH = "clip_temp.jpg";

    @BindView(R.id.rlIcon)
    RelativeLayout rlIcon;
    @BindView(R.id.ivIcon)
    ImageView ivIcon;
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.llNickName)
    LinearLayout llNickName;
    @BindView(R.id.tvAnloqId)
    TextView tvAnloqId;
    @BindView(R.id.rlQrcode)
    RelativeLayout rlQrcode;
    @BindView(R.id.tvPhoneNum)
    TextView tvPhoneNum;
    @BindView(R.id.tvNickName)
    TextView tvNickName;
    @BindView(R.id.tvName)
    TextView tvName;
    @BindView(R.id.ivIn)
    ImageView ivIn;
    @BindView(R.id.ivRight)
    ImageView ivRight;
    @BindView(R.id.etUpdateNickName)
    EditText etUpdateNickName;
    @BindView(R.id.rlUpdatePwd)
    RelativeLayout rlUpdatePwd;
    @BindView(R.id.rlUpdatePayPwd)
    RelativeLayout rlUpdatePayPwd;
    @BindView(R.id.rlBinding)
    RelativeLayout rlBinding;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

    private PopupWindow popupWindow;
    private View popupView;
    private TranslateAnimation animation;
    private Context mContext;
    private int uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        ButterKnife.bind(this);
        mContext = this;
        tvTitle.setText(R.string.base_setting);
        getData();
    }

    private void getData() {
        uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        String url = Constants.GETPROFILE + uid + Constants.TOKEN + token;
        Logger.t(TAG).i("GETPROFILE_url===" + url);

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e(e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseJson(response);
                    }
                });
    }

    private void parseJson(String json) {
        ProfileBean profileBean = new Gson().fromJson(json, ProfileBean.class);
        if (profileBean != null) {
            ProfileBean.ObjectBean object = profileBean.getObject();
            if (object != null) {
                String headpic = object.getHeadpic();
                String nickname = object.getNickname();
                tvNickName.setText(nickname);
                if (!"".equals(headpic)) {
                    Glide.with(mContext)
                            .load(headpic)
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .transform(new GlideCircleTransform(mContext))
                            .crossFade()
                            .into(ivIcon);
                }
            }
        }
        tvAnloqId.setText("" + uid);
        String account = SpUtil.getInstance().getString("account", "");
        tvPhoneNum.setText(account);
    }

    @OnClick({R.id.rlIcon, R.id.llNickName, R.id.rlQrcode, R.id.rlUpdatePwd, R.id.rlUpdatePayPwd, R.id.rlBinding,
            R.id.ivBack, R.id.ivRight})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.rlIcon:
                changeIcon(); // 弹出popupwind
                BrightnessManager.lightoff(mContext);
                break;
            case R.id.llNickName:
                tvNickName.setVisibility(View.GONE);
                tvName.setVisibility(View.GONE);
                ivIn.setVisibility(View.GONE);
                etUpdateNickName.setVisibility(View.VISIBLE);
                etUpdateNickName.setText(tvNickName.getText());
                ivRight.setVisibility(View.VISIBLE);
                break;
            case R.id.rlQrcode:
                //startActivity(new Intent(SettingActivity.this, MyQrcodeActivity.class));
                ToastUtil.show(getString(R.string.look_forward_to));
                break;
            case R.id.rlUpdatePwd:
                startActivity(new Intent(SettingActivity.this, UpdatePwdActivity.class));
                break;
            case R.id.rlUpdatePayPwd:
                startActivity(new Intent(SettingActivity.this, UpdatePayPwd.class));
                break;
            case R.id.rlBinding:
                //startActivity(new Intent(SettingActivity.this, DataBaseActivity.class));
                ToastUtil.show(getString(R.string.look_forward_to));
                break;
            case R.id.ivBack:
                finish();
                break;
            case R.id.ivRight:
                String nickName = etUpdateNickName.getText().toString().trim();
                HashMap map = new HashMap();
                map.put("nickname", nickName);
                updateProfile(map);
                break;
        }
    }

    /**
     * 修改个人信息(头像、昵称)
     */
    private void updateProfile(HashMap map) {
        ProfileManager.update(map, new ProfileManager.OnProfileUpdateListener() {
            @Override
            public void onUpdate(String result) {
                Logger.t(TAG).json(result);
                parseResult(result);
            }
        });
    }

    private void parseResult(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            ProfileBean profileBean = new Gson().fromJson(json, ProfileBean.class);
            if (profileBean != null) {
                etUpdateNickName.setVisibility(View.GONE);
                ivRight.setVisibility(View.GONE);
                tvName.setVisibility(View.VISIBLE);
                ivIn.setVisibility(View.VISIBLE);
                tvNickName.setVisibility(View.VISIBLE);
                String nickname = profileBean.getObject().getNickname();
                String headpic = profileBean.getObject().getHeadpic();
                tvNickName.setText(nickname);
                if (!"".equals(headpic)) {
                    Glide.with(mContext)
                            .load(headpic)
                            .skipMemoryCache(true)
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .transform(new GlideCircleTransform(mContext))
                            .into(ivIcon);
                }
                ToastUtil.show(getString(R.string.upload_success));
            }
        }
    }

    /**
     * 弹出popupWindow更改头像
     */
    private void changeIcon() {
        if (popupWindow == null) {
            popupView = View.inflate(this, R.layout.item_change_icon, null);
            popupWindow = new PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
            popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    BrightnessManager.lighton(mContext);
                }
            });
            popupWindow.setBackgroundDrawable(new BitmapDrawable());
            popupWindow.setFocusable(true);
            popupWindow.setOutsideTouchable(true);
            animation = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0, Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 1, Animation.RELATIVE_TO_PARENT, 0);
            animation.setInterpolator(new AccelerateInterpolator());
            animation.setDuration(200);

            popupView.findViewById(R.id.tvTakePhoto).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startCapture(); // 打开系统拍照
                    popupWindow.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
            popupView.findViewById(R.id.tvSelectPhoto).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startAlbum(); // 打开系统图库选择图片
                    popupWindow.dismiss();
                    BrightnessManager.lighton(mContext);
                }
            });
        }

        if (popupWindow.isShowing()) {
            popupWindow.dismiss();
            BrightnessManager.lighton(mContext);
        }
        popupWindow.showAtLocation(SettingActivity.this.findViewById(R.id.setting),
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
        popupView.startAnimation(animation);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK) {
            return;
        }

        switch (requestCode) {
            case CROP_RESULT_CODE:
                String path = data.getStringExtra(ClipImageActivity.RESULT_PATH);
                Bitmap bitmap = BitmapFactory.decodeFile(path);
                // bitmap裁剪
                bitmap = BitmapUtils.zoom(bitmap, DensityUtil.dp2px(this, 20), DensityUtil.dp2px(this, 20));
                Logger.t(TAG).i("bitmap.size()===" + bitmap.getByteCount());
                // 将图片上传到服务器
                uploadHeadpic(bitmap);
                break;
            case START_ALBUM_REQUESTCODE:
                startCropImageActivity(getFilePath(data.getData()));
                break;
            case CAMERA_WITH_DATA:
                // 照相机程序返回的,再次调用图片剪辑程序去修剪图片
                startCropImageActivity(Environment.getExternalStorageDirectory()
                        + "/" + TMP_PATH);
                break;
        }
    }

    // 裁剪图片的Activity
    private void startCropImageActivity(String path) {
        ClipImageActivity.startActivity(this, path, CROP_RESULT_CODE);
    }

    private void startAlbum() {
        try {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT, null);
            intent.setType("image/*");
            startActivityForResult(intent, START_ALBUM_REQUESTCODE);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
            try {
                Intent intent = new Intent(Intent.ACTION_PICK, null);
                intent.setDataAndType(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                startActivityForResult(intent, START_ALBUM_REQUESTCODE);
            } catch (Exception e2) {
                e.printStackTrace();
            }
        }
    }

    private void startCapture() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(
                Environment.getExternalStorageDirectory(), TMP_PATH)));
        startActivityForResult(intent, CAMERA_WITH_DATA);
    }

    /**
     * 通过uri获取文件路径
     */
    public String getFilePath(Uri mUri) {
        try {
            if (mUri.getScheme().equals("file")) {
                return mUri.getPath();
            } else {
                return getFilePathByUri(mUri);
            }
        } catch (FileNotFoundException ex) {
            return null;
        }
    }

    // 获取文件路径通过url
    private String getFilePathByUri(Uri mUri) throws FileNotFoundException {
        Cursor cursor = getContentResolver().query(mUri, null, null, null, null);
        cursor.moveToFirst();
        return cursor.getString(1);
    }

    /**
     * 上传头像
     */
    private void uploadHeadpic(Bitmap bitmap) {
        String bitmapBase64 = Base64Util.bitmapToBase64(bitmap);
        Logger.t(TAG).i("bitmapBase64===" + bitmapBase64.getBytes().length);
        if (bitmapBase64.getBytes().length > 15000) {
            ToastUtil.show(getString(R.string.upload_fail));
            return;
        }
        HashMap map = new HashMap();
        map.put("imgbase64", bitmapBase64);
        updateProfile(map);
    }

}
