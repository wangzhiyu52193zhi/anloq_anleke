package com.anloq.model;

/**
 * Created by xpf on 2017/5/22 :)
 * Function:MQTT消息的Bean类(消息专用，勿用于其他)
 */

public class MessageBean {

    private String type; // 消息类型
    private String content; // 消息内容
    private boolean read; // 是否已读

    public MessageBean() {
    }

    public MessageBean(String type, String content, boolean read) {
        this.type = type;
        this.content = content;
        this.read = read;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    @Override
    public String toString() {
        return "MessageBean{" +
                "type='" + type + '\'' +
                ", content='" + content + '\'' +
                ", read=" + read +
                '}';
    }
}
