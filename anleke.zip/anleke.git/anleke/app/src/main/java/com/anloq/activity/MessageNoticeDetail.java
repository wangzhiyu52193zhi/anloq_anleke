package com.anloq.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.anloq.anleke.R;
import com.anloq.model.EventBusMsg;
import com.anloq.model.KeyPassMsgBean;
import com.anloq.model.MessageBean;
import com.anloq.model.NoticeMsgBean;
import com.anloq.model.RequestKeyBean;
import com.anloq.model.ServiceMsgBean;
import com.anloq.ui.NotifcationView;
import com.anloq.utils.MessageProvider;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

// 消息通知详情页面(公告)
public class MessageNoticeDetail extends Activity {

    private static final String TAG = MessageNoticeDetail.class.getSimpleName();
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.tvTitle)
    TextView tvTitle;
    @BindView(R.id.ivShare)
    ImageView ivShare;
    @BindView(R.id.webView)
    WebView webView;
    @BindView(R.id.tvContent)
    TextView tvContent;
    @BindView(R.id.tvLast)
    TextView tvLast;
    @BindView(R.id.tvNext)
    TextView tvNext;
    @BindView(R.id.tvMsgTitle)
    TextView tvMsgTitle;
    @BindView(R.id.llMsg)
    LinearLayout llMsg;
    @BindView(R.id.llBigWhiteBg)
    LinearLayout llBigWhiteBg;
    @BindView(R.id.tvLastTitle)
    TextView tvLastTitle;
    @BindView(R.id.tvNextTitle)
    TextView tvNextTitle;
    @BindView(R.id.tvTime)
    TextView tvTime;
    private int position = -1;
    private List<MessageBean> localData;
    private String mUrl = "";
    private String mType = "";
    private String mTitle = "";
    private String mTime = "";
    private String mContent = "";
    private String platformName = "";
    private String platformToastName = "";
    private boolean isPlainText = false;//暂时qq不支持纯文本分享

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_notice);
        ButterKnife.bind(this);

        Intent intent = getIntent();
        mType = intent.getStringExtra("type");
        position = intent.getIntExtra("position", -1);

        NotifcationView.cancelNotice();//取消状态栏信息

        if ("text".equals(mType)) {
            mTitle = intent.getStringExtra("title");
            mContent = intent.getStringExtra("content");
            mTime = intent.getStringExtra("time");
        } else if ("url".equals(mType)) {
            tvTitle.setText(getResources().getString(R.string.property_notice));
            mUrl = intent.getStringExtra("url");
        }
        initView();
        localData = MessageProvider.getInstance().getLocalData();
        if (position == 0) {
            tvLast.setEnabled(false);
            tvLastTitle.setText("");
            if (localData.size() > 1) {
                tvNextTitle.setText(getAndSetMyTitle(position + 1));
                tvNext.setEnabled(true);
            } else {
                tvNextTitle.setText("");
                tvNext.setEnabled(false);
            }
        } else {
            tvLast.setEnabled(true);
            tvLastTitle.setText(getAndSetMyTitle(position - 1));
            if (position == localData.size() - 1) {
                tvNext.setEnabled(false);
                tvNextTitle.setText("");
            } else {
                tvNextTitle.setText(getAndSetMyTitle(position + 1));
                tvNext.setEnabled(true);
            }
        }
    }

    /**
     * 取title值
     */
    private String getAndSetMyTitle(int position) {
        if (position < 0 || (position > localData.size() - 1)) {

        } else {
            //取数据title 类型 json
            String mTitle = "";
            String type = localData.get(position).getType();
            String json = localData.get(position).getContent();

            switch (type) {
                case "servicemsg":
                    ServiceMsgBean serviceMsgBean = new Gson().fromJson(json, ServiceMsgBean.class);
                    mTitle = serviceMsgBean.getObject().getTitle();
                    mTime = serviceMsgBean.getTime();
                    break;
                case "rqkeymsg":
                    RequestKeyBean requestKeyBean = new Gson().fromJson(json, RequestKeyBean.class);
                    mTitle = requestKeyBean.getObject().getTitle();
                    mTime = requestKeyBean.getTime();
                    break;
                case "noticemsg":
                    NoticeMsgBean noticeMsgBean = new Gson().fromJson(json, NoticeMsgBean.class);
                    mTitle = noticeMsgBean.getObject().getTitle();
                    mTime = noticeMsgBean.getTime();
                    break;
                case "keypassmsg":
                    KeyPassMsgBean keyPassMsgBean = new Gson().fromJson(json, KeyPassMsgBean.class);
                    mTitle = keyPassMsgBean.getObject().getTitle();
                    mTime = keyPassMsgBean.getTime();
                    break;
            }
            Logger.t(TAG).i("mTitle===" + mTitle + ",mTime===" + mTime);
        }
        return mTitle;
    }

    private void initView() {
        if ("text".equals(mType)) {
            webView.setVisibility(View.GONE);
            llMsg.setVisibility(View.VISIBLE);
            tvMsgTitle.setText(mTitle);
            tvContent.setText(mContent);
            tvTime.setText(mTime);

        } else if ("url".equals(mType)) {
            Logger.t(TAG).i("MessageNoticeDetail url===" + mUrl);
            llMsg.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl(mUrl);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true); // 设置使用javaScript
            settings.setUseWideViewPort(true);   // 设置支持双击页面变大
            settings.setPluginState(WebSettings.PluginState.ON);
            // 设置优先使用网络缓存
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
            // 关键的部分就是在这里设置Client
            webView.setWebChromeClient(new WebChromeClient());
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    WebView.HitTestResult hit = view.getHitTestResult();
                    if (hit != null) {
                        int hitType = hit.getType();
                        if (hitType == WebView.HitTestResult.SRC_ANCHOR_TYPE
                                || hitType == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {// 点击超链接
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setData(Uri.parse(url));
                            startActivity(i);
                        } else {
                            view.loadUrl(url);
                        }
                    } else {
                        view.loadUrl(url);
                    }
                    return true;
                }
            });
        }
    }

    @OnClick({R.id.ivBack, R.id.ivShare, R.id.tvLast, R.id.tvNext})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.ivShare:
                shareContent();
                break;
            case R.id.tvLast:
                if (position > 0) {
                    position--;
                    if (position == 0) {
                        tvLast.setEnabled(false);
                        tvLastTitle.setText("");
                        if (position < localData.size() - 1) {
                            tvNext.setEnabled(true);
                            tvNextTitle.setText(getAndSetMyTitle(position + 1));
                        } else {
                            tvNext.setEnabled(false);
                            tvNextTitle.setText("");
                        }
                    } else {
                        tvLast.setEnabled(true);
                        tvLastTitle.setText(getAndSetMyTitle(position - 1));
                        if (position < localData.size() - 1) {
                            tvNext.setEnabled(true);
                            tvNextTitle.setText(getAndSetMyTitle(position + 1));
                        } else {
                            tvNext.setEnabled(false);
                            tvNextTitle.setText("");
                        }
                    }
                    updateData();
                }
                break;
            case R.id.tvNext:
                position++;
                if (position == localData.size() - 1) {
                    tvNextTitle.setText("");
                    tvNext.setEnabled(false);
                    tvLast.setEnabled(true);
                    tvLastTitle.setText(getAndSetMyTitle(position - 1));
                } else {
                    tvNextTitle.setText(getAndSetMyTitle(position + 1));
                    tvNext.setEnabled(true);
                    tvLast.setEnabled(true);
                    tvLastTitle.setText(getAndSetMyTitle(position - 1));
                }
                updateData();
                break;
        }
    }

    private void updateData() {
        if (localData != null && localData.size() > 0) {
            MessageBean msgBean = localData.get(position);
            String content = msgBean.getContent();
            // 解析并判断类型
            switch (msgBean.getType()) {
                case "servicemsg":
                    ServiceMsgBean serviceMsgBean = new Gson().fromJson(content, ServiceMsgBean.class);
                    ServiceMsgBean.ObjectBean object = serviceMsgBean.getObject();
                    mTime = serviceMsgBean.getTime();
                    if (object != null) {
                        mType = "text";
                        mTitle = object.getTitle();
                        mContent = object.getContent();
                    }
                    break;
                case "rqkeymsg":
                    RequestKeyBean requestKeyBean = new Gson().fromJson(content, RequestKeyBean.class);
                    RequestKeyBean.ObjectBean rqtObject = requestKeyBean.getObject();
                    mTime = requestKeyBean.getTime();
                    if (rqtObject != null) {
                        mType = "text";
                        mTitle = rqtObject.getTitle();
                        mContent = rqtObject.getContent();
                    }
                    break;
                case "noticemsg":
                    NoticeMsgBean noticeMsgBean = new Gson().fromJson(content, NoticeMsgBean.class);
                    NoticeMsgBean.ObjectBean noticeObject = noticeMsgBean.getObject();
                    mTime = noticeMsgBean.getTime();
                    if (noticeObject != null) {
                        mType = "url";
                        mUrl = noticeObject.getContent();
                    }
                    break;
                case "keypassmsg":
                    KeyPassMsgBean keyPassMsgBean = new Gson().fromJson(content, KeyPassMsgBean.class);
                    KeyPassMsgBean.ObjectBean keyPassObject = keyPassMsgBean.getObject();
                    mTime = keyPassMsgBean.getTime();
                    if (keyPassObject != null) {
                        mType = "text";
                        mTitle = keyPassObject.getTitle();
                        mContent = keyPassObject.getContent();
                    }
                    break;
            }

            initView();
            // 1.本地position标记为已读状态
            MessageProvider.getInstance().setReadState(position);
            // 2.内存
            EventBus.getDefault().post(new EventBusMsg("setreadstate", "" + position));
        }
    }

    private void shareContent() {
        int a = llMsg.getVisibility();// 0 Visible ,4 invisible ,8  gone
        if (a == 8 || a == 4) {
            isPlainText = false;
            //表示的是带链接的 消息通知 url
            UMImage thumb = new UMImage(this, R.drawable.icon_anloq);
            UMWeb web = new UMWeb(webView.getUrl());
            web.setTitle("物业通知");//标题
            web.setDescription("点击打开链接");
            web.setThumb(thumb);  //缩略图
            new ShareAction(MessageNoticeDetail.this)
                    .withMedia(web)
                    .setDisplayList(SHARE_MEDIA.SINA, SHARE_MEDIA.QQ, SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE)
                    .setCallback(umShareListener).open();
        } else {
            //授权消息
            isPlainText = true;
            new ShareAction(MessageNoticeDetail.this)
                    .withText(tvContent.getText().toString())
                    .setDisplayList(SHARE_MEDIA.SINA, SHARE_MEDIA.QQ, SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE)
                    .setCallback(umShareListener).open();
        }
        /*UMImage image = new UMImage(MessageNoticeDetail.this, R.drawable.icon_anloq);//资源文件
        new ShareAction(MessageNoticeDetail.this).withText("hello")
                .setDisplayList(SHARE_MEDIA.SINA,SHARE_MEDIA.QQ,SHARE_MEDIA.WEIXIN)
                .setCallback(umShareListener).open();*/
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }

    private UMShareListener umShareListener = new UMShareListener() {
        @Override
        public void onStart(SHARE_MEDIA platform) {
            //分享开始的回调
            if (platform.equals(SHARE_MEDIA.QQ) && isPlainText) {
                ToastUtil.show(getString(R.string.android_qq_riminder));
            }
        }

        @Override
        public void onResult(SHARE_MEDIA platform) {
            platformName = platform.toString();
            Log.d("plat", "platform" + platform);
            getPlatformName(platformName);
            Toast.makeText(MessageNoticeDetail.this, platformToastName + getString(R.string.share_success), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable t) {
            platformName = platform.toString();
            getPlatformName(platformName);
            if (platform.equals(SHARE_MEDIA.QQ)) {
                Log.d("throw", "throw:" + t.getMessage());
                    Log.d("throw", "throw:" + t.getMessage());
                    if (t.getMessage().contains("2008")) {
                        ToastUtil.show(getString(R.string.not_install_text) + platformToastName);
                }else {
                        if (isPlainText)return;
                        Toast.makeText(MessageNoticeDetail.this, platformToastName + getString(R.string.share_fail), Toast.LENGTH_SHORT).show();
                    }
            }else{
                if (t.getMessage().contains("2008")) {
                    if (platformToastName.equals(getString(R.string.WEIXIN_CIRCLE))) {
                        platformToastName = getString(R.string.WEIXIN);
                    }
                    ToastUtil.show(getString(R.string.not_install_text) + platformToastName);
                }else{
                    Toast.makeText(MessageNoticeDetail.this, platformToastName + getString(R.string.share_fail), Toast.LENGTH_SHORT).show();
                }
            }
        }

        @Override
        public void onCancel(SHARE_MEDIA platform) {
            platformName = platform.toString();
            if (platformName.equals("QQ"))
                return;
            getPlatformName(platformName);
            Toast.makeText(MessageNoticeDetail.this, platformToastName + getString(R.string.share_cancel), Toast.LENGTH_SHORT).show();
        }
    };

    private void getPlatformName(String str) {
        switch (str) {
            case "SINA":
                platformToastName = getString(R.string.SINA);
                break;
            case "QQ":
                platformToastName = getString(R.string.QQ);
                break;
            case "WEIXIN":
                platformToastName = getString(R.string.WEIXIN);
                break;
            case "WEIXIN_CIRCLE":
                platformToastName = getString(R.string.WEIXIN_CIRCLE);
                break;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        webView.destroyDrawingCache();
        webView.destroy();
    }
}
