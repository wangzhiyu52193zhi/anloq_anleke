package com.anloq.ui;

import android.content.Context;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.anloq.MyApplication;
import com.anloq.anleke.R;
import com.anloq.model.VkeyBean;
import com.bumptech.glide.Glide;

import org.litepal.crud.DataSupport;

import java.util.List;

/**
 * Created by xpf on 2017/5/20 :)
 * Function:卡片信息的视图设置
 */

public class CardView {

    private static final String TAG = CardView.class.getSimpleName();

    /**
     * 设置卡片颜色和背景图片
     */
    public static void setColor(Context mContext, int zoneid, TextView tvCover, ImageView ivCard) {
        String cardColor = "";
        String image_url = "";
        // 查询对应小区卡片的颜色
        List<VkeyBean> keyList = DataSupport.where("zone_id = ?", String.valueOf(zoneid)).find(VkeyBean.class);
        for (int i = 0; i < keyList.size(); i++) {
            cardColor = keyList.get(0).getZone_key_color();
            image_url = keyList.get(0).getImage_url();
            Log.e(TAG, "cardColor===" + cardColor);
        }
        // 根据小区ID来设置不同的cardSrc颜色
        if ("1".equals(cardColor)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_pale_blue_shape));
        } else if ("2".equals(cardColor)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_sea_blue_shape));
        } else if ("3".equals(cardColor)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_yellow_purple_shape));
        } else if ("4".equals(cardColor)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_orange_shape));
        } else if ("5".equals(cardColor)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_grass_green_shape));
        }
        if (!"".equals(image_url)) {
            Glide.with(mContext).load(image_url).transform(new GlideRoundTransform(mContext)).into(ivCard);
        }
    }

    /**
     * 根据小区ID来设置不同的卡片颜色
     */
    public static void setBgColor(TextView tvCover, String zone_key_color) {
        if ("1".equals(zone_key_color)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_pale_blue_shape));
        } else if ("2".equals(zone_key_color)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_sea_blue_shape));
        } else if ("3".equals(zone_key_color)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_yellow_purple_shape));
        } else if ("4".equals(zone_key_color)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_orange_shape));
        } else if ("5".equals(zone_key_color)) {
            tvCover.setBackground(MyApplication.getContext().getResources().getDrawable(R.drawable.card_grass_green_shape));
        }
    }
}
