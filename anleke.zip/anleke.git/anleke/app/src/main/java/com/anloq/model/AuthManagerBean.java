package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/4/27 :)
 * Function:已经授权列表数据的Bean
 */

public class AuthManagerBean {

    /**
     * name : authkeys
     * object : [{"user_type":2,"user_phone":"15711459775","user_name":"Alan","resident_id":100003,"master_resident_id":100000,"auth_type":1,"approve_status":1,"auth_start_date":"2017-04-25T14:36:12.000Z","auth_end_date":"2017-05-02T14:36:12.000Z","is_freeze":false,"auth_key_id":100003,"headpic":"","user_id":100003},{"user_type":2,"user_phone":"15001182880","user_name":"Zhangxing","resident_id":100004,"master_resident_id":100000,"auth_type":1,"approve_status":2,"auth_start_date":"2017-04-21T00:00:00.000Z","auth_end_date":"2017-04-25T00:00:00.000Z","is_freeze":false,"auth_key_id":100004,"headpic":"","user_id":100004},{"user_type":2,"user_phone":"13693157159","user_name":"薛婷","resident_id":100005,"master_resident_id":100000,"auth_type":1,"approve_status":2,"auth_start_date":"2017-04-26T15:05:53.000Z","auth_end_date":"2017-05-03T15:05:53.000Z","is_freeze":false,"auth_key_id":100005,"headpic":"","user_id":100009},{"user_type":2,"user_phone":"18600879863","user_name":"黄文辉","resident_id":100006,"master_resident_id":100000,"auth_type":1,"approve_status":2,"auth_start_date":"2017-04-06T00:00:00.000Z","auth_end_date":"2017-04-26T00:00:00.000Z","is_freeze":false,"auth_key_id":100006,"headpic":"","user_id":100010},{"user_type":2,"user_phone":"18501344613","user_name":"嫌小","resident_id":100007,"master_resident_id":100000,"auth_type":1,"approve_status":2,"auth_start_date":"2017-04-10T00:00:00.000Z","auth_end_date":"2017-04-26T00:00:00.000Z","is_freeze":false,"auth_key_id":100007,"headpic":"","user_id":100012}]
     * code : 200
     */

    private String name;
    private int code;
    private List<ObjectBean> object;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<ObjectBean> getObject() {
        return object;
    }

    public void setObject(List<ObjectBean> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * user_type : 2
         * user_phone : 15711459775
         * user_name : Alan
         * resident_id : 100003
         * master_resident_id : 100000
         * auth_type : 1
         * approve_status : 1
         * auth_start_date : 2017-04-25T14:36:12.000Z
         * auth_end_date : 2017-05-02T14:36:12.000Z
         * is_freeze : false
         * auth_key_id : 100003
         * headpic :
         * user_id : 100003
         */

        private int user_type;
        private String user_phone;
        private String user_name;
        private int resident_id;
        private int master_resident_id;
        private int auth_type;
        private int approve_status;
        private String auth_start_date;
        private String auth_end_date;
        private boolean is_freeze;
        private int auth_key_id;
        private String headpic;
        private int user_id;

        public int getUser_type() {
            return user_type;
        }

        public void setUser_type(int user_type) {
            this.user_type = user_type;
        }

        public String getUser_phone() {
            return user_phone;
        }

        public void setUser_phone(String user_phone) {
            this.user_phone = user_phone;
        }

        public String getUser_name() {
            return user_name;
        }

        public void setUser_name(String user_name) {
            this.user_name = user_name;
        }

        public int getResident_id() {
            return resident_id;
        }

        public void setResident_id(int resident_id) {
            this.resident_id = resident_id;
        }

        public int getMaster_resident_id() {
            return master_resident_id;
        }

        public void setMaster_resident_id(int master_resident_id) {
            this.master_resident_id = master_resident_id;
        }

        public int getAuth_type() {
            return auth_type;
        }

        public void setAuth_type(int auth_type) {
            this.auth_type = auth_type;
        }

        public int getApprove_status() {
            return approve_status;
        }

        public void setApprove_status(int approve_status) {
            this.approve_status = approve_status;
        }

        public String getAuth_start_date() {
            return auth_start_date;
        }

        public void setAuth_start_date(String auth_start_date) {
            this.auth_start_date = auth_start_date;
        }

        public String getAuth_end_date() {
            return auth_end_date;
        }

        public void setAuth_end_date(String auth_end_date) {
            this.auth_end_date = auth_end_date;
        }

        public boolean isIs_freeze() {
            return is_freeze;
        }

        public void setIs_freeze(boolean is_freeze) {
            this.is_freeze = is_freeze;
        }

        public int getAuth_key_id() {
            return auth_key_id;
        }

        public void setAuth_key_id(int auth_key_id) {
            this.auth_key_id = auth_key_id;
        }

        public String getHeadpic() {
            return headpic;
        }

        public void setHeadpic(String headpic) {
            this.headpic = headpic;
        }

        public int getUser_id() {
            return user_id;
        }

        public void setUser_id(int user_id) {
            this.user_id = user_id;
        }
    }
}
