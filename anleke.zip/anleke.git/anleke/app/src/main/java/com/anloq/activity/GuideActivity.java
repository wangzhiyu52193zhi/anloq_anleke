package com.anloq.activity;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.anloq.adapter.GuideViewPagerAdapter;
import com.anloq.anleke.R;
import com.anloq.base.BaseFragment;
import com.anloq.fragment.GuideFragment1;
import com.anloq.fragment.GuideFragment2;
import com.anloq.fragment.GuideFragment3;
import com.anloq.fragment.GuideFragment4;
import com.anloq.fragment.LoginFragment;
import com.anloq.ui.MyViewPager;
import com.anloq.utils.CacheUtils;
import com.anloq.utils.DensityUtil;
import com.anloq.utils.SpUtil;
import com.umeng.socialize.UMShareAPI;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

// 引导页
public class GuideActivity extends FragmentActivity {

    @BindView(R.id.viewPager)
    MyViewPager viewPager;
    @BindView(R.id.llPointGroup)
    LinearLayout llPointGroup;
    @BindView(R.id.ivRedPoint)
    ImageView ivRedPoint;
    @BindView(R.id.rlPoints)
    RelativeLayout rlPoints;
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.rlTitle)
    RelativeLayout rlTitle;

    // 两点间的间距
    private int leftMarg;
    private int widthDpi;
    private ArrayList<BaseFragment> mFragments;
    private boolean helpguide; // 是否是帮助里的引导页

    /**
     * 需要进行检测的权限数组
     */
    protected String[] needPermissions = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);
        ButterKnife.bind(this);
        helpguide = SpUtil.getInstance().getBoolean("helpguide", false);
        if (helpguide) {
            rlTitle.setVisibility(View.VISIBLE);
        }
        initFragment();
        initData();
        // 设置ViewPager的适配器
        viewPager.setAdapter(new GuideViewPagerAdapter(getSupportFragmentManager(), mFragments));
        boolean isfirst = SpUtil.getInstance().getBoolean("isfirst", true);
        if (isfirst) {
            viewPager.setCurrentItem(0); // 默认在第一页
            requestCodePermissions();
        } else {
            if (!helpguide) {
                viewPager.setCurrentItem(4);
            }
        }
    }

    /**
     * 请求权限
     */
    private void requestCodePermissions() {
        if (!EasyPermissions.hasPermissions(this, needPermissions)) {
            EasyPermissions.requestPermissions(this, "应用需要这些权限，否则无法运行！", 520, needPermissions);
        } else {
            CacheUtils.delete(null); // 删除缓存的文件
        }
    }

    // 在请求权限回调中
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @AfterPermissionGranted(520)//请求码
    private void after() {
        if (EasyPermissions.hasPermissions(this, needPermissions)) {
            CacheUtils.delete(null); // 删除缓存的文件
        } else {
            EasyPermissions.requestPermissions(this, "应用需要这些权限，否则无法运行！", 520, needPermissions);
        }
    }

    /**
     * 初始化引导页的数据
     */
    private void initData() {
        widthDpi = DensityUtil.dp2px(this, 8);
        for (int i = 0; i < mFragments.size(); i++) {
            // 添加灰色的点
            ImageView point = new ImageView(this);
            // 给Point设置shape为oval,即圆
            point.setImageResource(R.drawable.point_gray);
            // 设置点的大小
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(widthDpi, widthDpi);
            if (i != 0) {
                params.leftMargin = widthDpi; //设置间距
            }
            point.setLayoutParams(params);
            llPointGroup.addView(point);
        }

        /**
         * 求间距 构造方法--> 测量(measure--onMeasure)--> layout-->onLayout-->draw-->onDraw
         */
        ivRedPoint.getViewTreeObserver().addOnGlobalLayoutListener(new MyOnGlobalLayoutListener());
        // 监听viewPager页面滑动的百分比
        viewPager.addOnPageChangeListener(new MyOnPageChangeListener());
    }

    private void initFragment() {
        mFragments = new ArrayList<>();
        mFragments.add(new GuideFragment1());
        mFragments.add(new GuideFragment2());
        mFragments.add(new GuideFragment3());
        mFragments.add(new GuideFragment4());
        if (!helpguide) {
            mFragments.add(new LoginFragment());
        }
    }

    @OnClick(R.id.ivBack)
    public void onClick() {
        finish();
    }

    class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {

        /**
         * @param position             当前滑动页面的下标位置
         * @param positionOffset       滑动了页面的百分比
         * @param positionOffsetPixels 滑动了页面多少像数
         */
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            // 坐标 = 起始位置 + 红点移动的距离
            float leftMargin = (position + positionOffset) * leftMarg;
            RelativeLayout.LayoutParams paramgs = (RelativeLayout.LayoutParams) ivRedPoint.getLayoutParams();
            // 距离左边的距离
            paramgs.leftMargin = (int) leftMargin;
            ivRedPoint.setLayoutParams(paramgs);
        }

        @Override
        public void onPageSelected(int position) {
            if (position == 4) {
                rlPoints.setVisibility(View.GONE);
                viewPager.setNoScroll(true);
            }
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    }

    class MyOnGlobalLayoutListener implements ViewTreeObserver.OnGlobalLayoutListener {

        @Override
        public void onGlobalLayout() {
            ivRedPoint.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            // 间距 = 第一个点距离左边距离 - 第0个点距离左边距离
            leftMarg = llPointGroup.getChildAt(1).getLeft() - llPointGroup.getChildAt(0).getLeft();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        SpUtil.getInstance().save("isfirst", false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }
}
