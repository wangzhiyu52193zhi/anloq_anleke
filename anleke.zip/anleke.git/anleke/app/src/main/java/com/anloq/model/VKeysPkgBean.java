package com.anloq.model;

import java.util.List;

/**
 * Created by xpf on 2017/3/29 :)
 * Function:虚拟钥匙包的Bean
 */
public class VKeysPkgBean {

    /**
     * code : 200
     * name : vkeys
     * object : [[{"admin_info":{"room_admin_name":"中关村物业","room_admin_tel":"13569784723","room_admin_type":0},"key_info":{"auth_count":0,"auth_end_date":"2087-07-28T17:51:50.000Z","auth_start_date":"2017-07-28T17:51:50.000Z","bt_device_mac":["5c:f8:21:de:55:7c"],"device_key_sr":"PQRaAXwc0S0dj9wi9uAKyy2nN1i9VZcQhk/lZDbx1Gtu2mGES88hbho9esy+DPtTYdSo1knoMOTwHO0YA1YjuNy8gDpBpspWic5cCKG+M0z6qVNjd4ERygUbey7o6r8T1huvhLmRIb/gd+SDm6EHQGfrddmGoQyb3z5pH1Y1sRFpQWG/Uqe8POkHeOaYkLx5N4gT2eZz6VX/iEfrth7H05sz1ixWqC2agYCUbrJr+IqBbUIU46Ac9C10p/kvRawc49rqdFVFZg6aFJmw587wBKmRi5YOF2zxg6th9aavnbUSIDVIyaDdYPbWvhHZv88CAnUME4FSddUqCjrf1/JgMWgHy+dhZNk1Czbt26HC6FAHooZRq4XgcCROZ3sNDVzNBa4fleytcPGVfZMYdQvMF9FT6Lq0rWAUgvbaIlu4R6v9Zp/4G8eaW6Zb2j08bFGmFa/ToCTsUU6opVfOVEvlj0iUFtSfr5p+QA1bR/L+1AO6+pC0vS8ghvboNBW+MVoS34YlOOku2/jEqAp228Fp4R4BGhS4/YhdYNu9QLKY7s7YfJie/SFiJFI8isZt1MAaLXVztP8zDTqNFFX1yYviJR5M5V733yp6p6467PVQBd0hs3jIlJtQCiBbCLtLcpJOAtbqP2J7nKc/tCG2xQj46sir097Rx2/UuprLD8y5IRvjqu1J3oZTl75f7SByLzUUPJd7jHznkYZSAYslEJ8IRr6czTvw6XIrr+uSb4RHqtPq09CGvNq+2ianmUVDNHHpN5Rc8ohvVHtXSHJoms6sbhW8xixeUcSM+YHQ0umiMFeNi5mUt2JVK0aIkesQVxDPEp+SKeba67bZnv4CRdOloSB+z5iunkC4FuHC2n64FPT9pTsS4zfu7qvlMpQo0Mirw9qCq464IkiheEGX8rIN5/aqHoCatq49el35YtVEuIDvJgNIQ067R5nM7jXfBk5e","expire_type":1,"first_key":"ZTU1NzE1YzUtN2JlMy00M2M0LThiOWMtZTI0NmRhNGQzYmQ4MjEwMDEyMTItMTI6MTI6MTIx","is_deleted":false,"is_freeze":false,"key_id":100000,"key_status":2,"user_phone":"17600733534"},"room_info":{"building_id":100000,"building_name":"100号楼","city_id":392,"city_name":"海淀区","province_id":1,"province_name":"北京市","relation":1,"room_id":100000,"room_name":"101","unit_id":100000,"unit_name":"1单元","zone_id":100000,"zone_key_color":"1","zone_name":"中关村小区"}},{"admin_info":{"room_admin_name":"中关村物业","room_admin_tel":"13569784723","room_admin_type":0},"key_info":{"auth_count":0,"auth_end_date":"2087-07-28T19:18:03.000Z","auth_start_date":"2017-07-28T19:18:03.000Z","bt_device_mac":["5c:f8:21:de:55:7c"],"device_key_sr":"IaxF4Mcv+BTotdNS9iwAiCzsG7MyQqaSwLvmNoroS/OjMTHuRdrLHqLzbWIka9DLT43EnRqAiUq6aBT1j/lkrMd5/oaUJP8UfjKUhk0yBiUIdADkz5NEdKUIbc+WQZZ+7+NqjLqqj5Jn9GDetNbTtKRcHcrQAynYDRbFsmMpRu+2YSpkqHeFwOffwVBjppv0BxtbyXJqNn1BV8iEdLq/jqfoimx+C12wE46FU/C/3LxPQaKS7lhRDepHQGG6sDhlYmvs4u9847Fzax9eZXL2zNTbZBTi/bWdQAdgrgphSNrsscqEPWV5qvcLCUfqgwkUcOtecPsNGOkBwWNZpmVOJ32aOmgkSA3jUUV1XL6ZMqG2p2F56WC4SUJKtY3VurBSHk5tmBJnmyciz2Sh4o9Wa+pnApT/qeVIMYECT1qWQRMhInZ9J0VtODivS6pBJaJdKsL6EeeNNHZ3XiIHqh1uKJmG1lKnTTY2giWyQgRP2xSU6ifGUE7js6sdUkte+q5Y8SleAGaZWVBrZb3TFBAT5qqNo3rhlS1jM80zU9o2NGEk1f9L2KLILVYnDt6rwq1vdscsIC2+ebCS08MPn3hC8l+L5PBCYdyECGSpF4BHMQwFfb9ohZz9vzUx324Im3df35D1rYLl9o7KiUYo/roC3KmXiAjAUoTrmNgEHZj4pap7s1B6BOsK2G4FvHDX83s9ZPfld3k6RyPcDUWeRD2iaW1B6oLeN/Mr7iYj8p2Q1Z5KSDeYfeGPnARcDWxYHoWI9lM90dIvHbHkrIzY7QnQirBepooQWiYWJbkktkpXaW1ienGUY+q41eK0tsSFjJz1d5yfg2CFgTQiMIM1hNJGNFGY+FjOAS8+tXuIS2k2OVGDoWy/ACEHNoGA0hvvhDAKuWyaqdN0YGSl5FCC7A+FMiIFPm+w0SGwqGowpJqekinojW34nZGd/3GoINv2oVTX","expire_type":1,"first_key":"ODkwOTA4MzktZTYxMC00ODVhLThlMDYtMzJkOTIyMWMxYzFmMjEwMDEyMTItMTI6MTI6MTIx","is_deleted":false,"is_freeze":false,"key_id":100011,"key_status":2,"user_phone":"17600733534"},"room_info":{"building_id":100000,"building_name":"100号楼","city_id":392,"city_name":"海淀区","province_id":1,"province_name":"北京市","relation":1,"room_id":100023,"room_name":"110","unit_id":100000,"unit_name":"1单元","zone_id":100000,"zone_key_color":"1","zone_name":"中关村小区"}},{"admin_info":{"room_admin_name":"中关村物业","room_admin_tel":"13569784723","room_admin_type":0},"key_info":{"auth_count":0,"auth_end_date":"2087-07-29T21:04:59.000Z","auth_start_date":"2017-07-29T21:04:59.000Z","bt_device_mac":["5c:f8:21:de:58:42"],"device_key_sr":"Q0lzDk+5SovqOtHZCgMJ23hkNaXKvs0tVTik9FIHSgtNOgUUcFcT71cx3aTdu60+FYqYxWSD1AA0xZTn9wEDjeo7VHK5sSUR+Wj+Qpgd8u4mVEfoshstEdu+xtPIT4Z6Bq8ewgqO2k16pla58Ut5dwRjr+LKmjWBhW0n/8L56QKjQKkO7ygSqAS1BrkkzNoBufy0Hr7gCugmwcUzxP5OSik6J/mh06/s8u735cAI9obL6TKZ5W4kAc3WTU+qfz+DmwsXPAqHxpufNa4eUyqTdqFoyb9d0JqTHEeBJMxvfxVVhomdO3C+DLM9Q2Iw7RAxcIyUSsygBI7wEbBWBuHGpZuAPYj5m+3u1aZjSBNNFvAomKykcezKPLReiechbYfO8CB9SqMKxt3v8g5NUXWCtJpUdVCRZoGmgzFxxJxI+Yjzjc/7dy1eLbAPb/kqKAyLhgAk65YKconEi2nf1eYrAD703cbrdxPaAHLhLDJr2eWid/scT7EU28uWk0G4NmZiKDIOelw1GzJIFfY4vnJEG+zuDEzHtpD/oXeaaFAxXf4mx+vhEkwE0u09tMo7zq8Hw/J/J66RCP3CzDHuIInJYZS7X0KUDXdWV2lAzZT5YuXv7gOlifEzE6gVi/8xwNwQA92OmrDvNyqFEbaaLlJTP5hFLa8jDILb1qvSLOC1kcWyPdfz9/W77cQOr63Yj+loTBfb6jxWg7ieAFldyemub/VhWomHazyUs6NFF/OKHxCeMvHpJAbWUwPTHgWMTNrcJGMgJ2fErWkWkdfMmcmqGVG2Xl7Xn3EN75GffF8OlMXGpQxhnFtOz2zXIg7Uf3iSi8S+H7XgZQKwbAhr3oAFJitgVyHtmt+/03W3PJgFoOnwEbXOifIbeYjJ0hn3Vo5HygHpdD+5lQ/xQfVCmLQAJ3lnzW/NMEnySkTfRjJAAPjhlpoGsDDQVo+szVaUlbwG","expire_type":1,"first_key":"YTA1ODk5OGItNGU2Ny00OTUyLWI0N2MtZTdhZWVhN2RkNWZlMjEwMDEyMTItMTI6MTI6MTIx","is_deleted":false,"is_freeze":false,"key_id":100018,"key_status":2,"user_phone":"17600733534"},"room_info":{"building_id":100000,"building_name":"100号楼","city_id":392,"city_name":"海淀区","province_id":1,"province_name":"北京市","relation":1,"room_id":100042,"room_name":"111","unit_id":100001,"unit_name":"2单元","zone_id":100000,"zone_key_color":"1","zone_name":"中关村小区"}}]]
     * time : 2017-08-03T11:29:19.772Z
     */

    private int code;
    private String name;
    private String time;
    private List<List<ObjectBean>> object;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public List<List<ObjectBean>> getObject() {
        return object;
    }

    public void setObject(List<List<ObjectBean>> object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * admin_info : {"room_admin_name":"中关村物业","room_admin_tel":"13569784723","room_admin_type":0}
         * key_info : {"auth_count":0,"auth_end_date":"2087-07-28T17:51:50.000Z","auth_start_date":"2017-07-28T17:51:50.000Z","bt_device_mac":["5c:f8:21:de:55:7c"],"device_key_sr":"PQRaAXwc0S0dj9wi9uAKyy2nN1i9VZcQhk/lZDbx1Gtu2mGES88hbho9esy+DPtTYdSo1knoMOTwHO0YA1YjuNy8gDpBpspWic5cCKG+M0z6qVNjd4ERygUbey7o6r8T1huvhLmRIb/gd+SDm6EHQGfrddmGoQyb3z5pH1Y1sRFpQWG/Uqe8POkHeOaYkLx5N4gT2eZz6VX/iEfrth7H05sz1ixWqC2agYCUbrJr+IqBbUIU46Ac9C10p/kvRawc49rqdFVFZg6aFJmw587wBKmRi5YOF2zxg6th9aavnbUSIDVIyaDdYPbWvhHZv88CAnUME4FSddUqCjrf1/JgMWgHy+dhZNk1Czbt26HC6FAHooZRq4XgcCROZ3sNDVzNBa4fleytcPGVfZMYdQvMF9FT6Lq0rWAUgvbaIlu4R6v9Zp/4G8eaW6Zb2j08bFGmFa/ToCTsUU6opVfOVEvlj0iUFtSfr5p+QA1bR/L+1AO6+pC0vS8ghvboNBW+MVoS34YlOOku2/jEqAp228Fp4R4BGhS4/YhdYNu9QLKY7s7YfJie/SFiJFI8isZt1MAaLXVztP8zDTqNFFX1yYviJR5M5V733yp6p6467PVQBd0hs3jIlJtQCiBbCLtLcpJOAtbqP2J7nKc/tCG2xQj46sir097Rx2/UuprLD8y5IRvjqu1J3oZTl75f7SByLzUUPJd7jHznkYZSAYslEJ8IRr6czTvw6XIrr+uSb4RHqtPq09CGvNq+2ianmUVDNHHpN5Rc8ohvVHtXSHJoms6sbhW8xixeUcSM+YHQ0umiMFeNi5mUt2JVK0aIkesQVxDPEp+SKeba67bZnv4CRdOloSB+z5iunkC4FuHC2n64FPT9pTsS4zfu7qvlMpQo0Mirw9qCq464IkiheEGX8rIN5/aqHoCatq49el35YtVEuIDvJgNIQ067R5nM7jXfBk5e","expire_type":1,"first_key":"ZTU1NzE1YzUtN2JlMy00M2M0LThiOWMtZTI0NmRhNGQzYmQ4MjEwMDEyMTItMTI6MTI6MTIx","is_deleted":false,"is_freeze":false,"key_id":100000,"key_status":2,"user_phone":"17600733534"}
         * room_info : {"building_id":100000,"building_name":"100号楼","city_id":392,"city_name":"海淀区","province_id":1,"province_name":"北京市","relation":1,"room_id":100000,"room_name":"101","unit_id":100000,"unit_name":"1单元","zone_id":100000,"zone_key_color":"1","zone_name":"中关村小区"}
         */

        private AdminInfoBean admin_info;
        private KeyInfoBean key_info;
        private RoomInfoBean room_info;

        public AdminInfoBean getAdmin_info() {
            return admin_info;
        }

        public void setAdmin_info(AdminInfoBean admin_info) {
            this.admin_info = admin_info;
        }

        public KeyInfoBean getKey_info() {
            return key_info;
        }

        public void setKey_info(KeyInfoBean key_info) {
            this.key_info = key_info;
        }

        public RoomInfoBean getRoom_info() {
            return room_info;
        }

        public void setRoom_info(RoomInfoBean room_info) {
            this.room_info = room_info;
        }

        public static class AdminInfoBean {
            /**
             * room_admin_name : 中关村物业
             * room_admin_tel : 13569784723
             * room_admin_type : 0
             */

            private String room_admin_name;
            private String room_admin_headpic;
            private String room_admin_tel;
            private int room_admin_type;

            public String getRoom_admin_headpic() {
                return room_admin_headpic;
            }

            public void setRoom_admin_headpic(String room_admin_headpic) {
                this.room_admin_headpic = room_admin_headpic;
            }

            public String getRoom_admin_name() {
                return room_admin_name;
            }

            public void setRoom_admin_name(String room_admin_name) {
                this.room_admin_name = room_admin_name;
            }

            public String getRoom_admin_tel() {
                return room_admin_tel;
            }

            public void setRoom_admin_tel(String room_admin_tel) {
                this.room_admin_tel = room_admin_tel;
            }

            public int getRoom_admin_type() {
                return room_admin_type;
            }

            public void setRoom_admin_type(int room_admin_type) {
                this.room_admin_type = room_admin_type;
            }
        }

        public static class KeyInfoBean {
            /**
             * auth_count : 0
             * auth_end_date : 2087-07-28T17:51:50.000Z
             * auth_start_date : 2017-07-28T17:51:50.000Z
             * bt_device_mac : ["5c:f8:21:de:55:7c"]
             * device_key_sr : PQRaAXwc0S0dj9wi9uAKyy2nN1i9VZcQhk/lZDbx1Gtu2mGES88hbho9esy+DPtTYdSo1knoMOTwHO0YA1YjuNy8gDpBpspWic5cCKG+M0z6qVNjd4ERygUbey7o6r8T1huvhLmRIb/gd+SDm6EHQGfrddmGoQyb3z5pH1Y1sRFpQWG/Uqe8POkHeOaYkLx5N4gT2eZz6VX/iEfrth7H05sz1ixWqC2agYCUbrJr+IqBbUIU46Ac9C10p/kvRawc49rqdFVFZg6aFJmw587wBKmRi5YOF2zxg6th9aavnbUSIDVIyaDdYPbWvhHZv88CAnUME4FSddUqCjrf1/JgMWgHy+dhZNk1Czbt26HC6FAHooZRq4XgcCROZ3sNDVzNBa4fleytcPGVfZMYdQvMF9FT6Lq0rWAUgvbaIlu4R6v9Zp/4G8eaW6Zb2j08bFGmFa/ToCTsUU6opVfOVEvlj0iUFtSfr5p+QA1bR/L+1AO6+pC0vS8ghvboNBW+MVoS34YlOOku2/jEqAp228Fp4R4BGhS4/YhdYNu9QLKY7s7YfJie/SFiJFI8isZt1MAaLXVztP8zDTqNFFX1yYviJR5M5V733yp6p6467PVQBd0hs3jIlJtQCiBbCLtLcpJOAtbqP2J7nKc/tCG2xQj46sir097Rx2/UuprLD8y5IRvjqu1J3oZTl75f7SByLzUUPJd7jHznkYZSAYslEJ8IRr6czTvw6XIrr+uSb4RHqtPq09CGvNq+2ianmUVDNHHpN5Rc8ohvVHtXSHJoms6sbhW8xixeUcSM+YHQ0umiMFeNi5mUt2JVK0aIkesQVxDPEp+SKeba67bZnv4CRdOloSB+z5iunkC4FuHC2n64FPT9pTsS4zfu7qvlMpQo0Mirw9qCq464IkiheEGX8rIN5/aqHoCatq49el35YtVEuIDvJgNIQ067R5nM7jXfBk5e
             * expire_type : 1
             * first_key : ZTU1NzE1YzUtN2JlMy00M2M0LThiOWMtZTI0NmRhNGQzYmQ4MjEwMDEyMTItMTI6MTI6MTIx
             * is_deleted : false
             * is_freeze : false
             * key_id : 100000
             * key_status : 2
             * user_phone : 17600733534
             */

            private int auth_count;
            private String auth_end_date;
            private String auth_start_date;
            private String device_key_sr;
            private int expire_type;
            private String first_key;
            private boolean is_deleted;
            private boolean is_freeze;
            private int key_id;
            private int key_status;
            private String user_phone;
            private List<String> bt_device_mac;
            private List<BtDeviceBean> bt_device;

            public List<BtDeviceBean> getBt_device() {
                return bt_device;
            }

            public void setBt_device(List<BtDeviceBean> bt_device) {
                this.bt_device = bt_device;
            }

            public int getAuth_count() {
                return auth_count;
            }

            public void setAuth_count(int auth_count) {
                this.auth_count = auth_count;
            }

            public String getAuth_end_date() {
                return auth_end_date;
            }

            public void setAuth_end_date(String auth_end_date) {
                this.auth_end_date = auth_end_date;
            }

            public String getAuth_start_date() {
                return auth_start_date;
            }

            public void setAuth_start_date(String auth_start_date) {
                this.auth_start_date = auth_start_date;
            }

            public String getDevice_key_sr() {
                return device_key_sr;
            }

            public void setDevice_key_sr(String device_key_sr) {
                this.device_key_sr = device_key_sr;
            }

            public int getExpire_type() {
                return expire_type;
            }

            public void setExpire_type(int expire_type) {
                this.expire_type = expire_type;
            }

            public String getFirst_key() {
                return first_key;
            }

            public void setFirst_key(String first_key) {
                this.first_key = first_key;
            }

            public boolean isIs_deleted() {
                return is_deleted;
            }

            public void setIs_deleted(boolean is_deleted) {
                this.is_deleted = is_deleted;
            }

            public boolean isIs_freeze() {
                return is_freeze;
            }

            public void setIs_freeze(boolean is_freeze) {
                this.is_freeze = is_freeze;
            }

            public int getKey_id() {
                return key_id;
            }

            public void setKey_id(int key_id) {
                this.key_id = key_id;
            }

            public int getKey_status() {
                return key_status;
            }

            public void setKey_status(int key_status) {
                this.key_status = key_status;
            }

            public String getUser_phone() {
                return user_phone;
            }

            public void setUser_phone(String user_phone) {
                this.user_phone = user_phone;
            }

            public List<String> getBt_device_mac() {
                return bt_device_mac;
            }

            public void setBt_device_mac(List<String> bt_device_mac) {
                this.bt_device_mac = bt_device_mac;
            }

            public static class BtDeviceBean {
                private String mac_attr;
                private int deviceid;
                private int unit_id;

                public String getMac_attr() {
                    return mac_attr;
                }

                public void setMac_attr(String mac_attr) {
                    this.mac_attr = mac_attr;
                }

                public int getDeviceid() {
                    return deviceid;
                }

                public void setDeviceid(int deviceid) {
                    this.deviceid = deviceid;
                }

                public int getUnit_id() {
                    return unit_id;
                }

                public void setUnit_id(int unit_id) {
                    this.unit_id = unit_id;
                }
            }
        }

        public static class RoomInfoBean {
            /**
             * building_id : 100000
             * building_name : 100号楼
             * city_id : 392
             * city_name : 海淀区
             * province_id : 1
             * province_name : 北京市
             * relation : 1
             * room_id : 100000
             * room_name : 101
             * unit_id : 100000
             * unit_name : 1单元
             * zone_id : 100000
             * zone_key_color : 1
             * zone_name : 中关村小区
             */

            private int building_id;
            private String building_name;
            private int city_id;
            private String city_name;
            private int province_id;
            private String province_name;
            private int relation;
            private int room_id;
            private String room_name;
            private int unit_id;
            private String unit_name;
            private int zone_id;
            private String zone_key_color;
            private String zone_name;
            private String image;

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }

            public int getBuilding_id() {
                return building_id;
            }

            public void setBuilding_id(int building_id) {
                this.building_id = building_id;
            }

            public String getBuilding_name() {
                return building_name;
            }

            public void setBuilding_name(String building_name) {
                this.building_name = building_name;
            }

            public int getCity_id() {
                return city_id;
            }

            public void setCity_id(int city_id) {
                this.city_id = city_id;
            }

            public String getCity_name() {
                return city_name;
            }

            public void setCity_name(String city_name) {
                this.city_name = city_name;
            }

            public int getProvince_id() {
                return province_id;
            }

            public void setProvince_id(int province_id) {
                this.province_id = province_id;
            }

            public String getProvince_name() {
                return province_name;
            }

            public void setProvince_name(String province_name) {
                this.province_name = province_name;
            }

            public int getRelation() {
                return relation;
            }

            public void setRelation(int relation) {
                this.relation = relation;
            }

            public int getRoom_id() {
                return room_id;
            }

            public void setRoom_id(int room_id) {
                this.room_id = room_id;
            }

            public String getRoom_name() {
                return room_name;
            }

            public void setRoom_name(String room_name) {
                this.room_name = room_name;
            }

            public int getUnit_id() {
                return unit_id;
            }

            public void setUnit_id(int unit_id) {
                this.unit_id = unit_id;
            }

            public String getUnit_name() {
                return unit_name;
            }

            public void setUnit_name(String unit_name) {
                this.unit_name = unit_name;
            }

            public int getZone_id() {
                return zone_id;
            }

            public void setZone_id(int zone_id) {
                this.zone_id = zone_id;
            }

            public String getZone_key_color() {
                return zone_key_color;
            }

            public void setZone_key_color(String zone_key_color) {
                this.zone_key_color = zone_key_color;
            }

            public String getZone_name() {
                return zone_name;
            }

            public void setZone_name(String zone_name) {
                this.zone_name = zone_name;
            }
        }
    }
}
