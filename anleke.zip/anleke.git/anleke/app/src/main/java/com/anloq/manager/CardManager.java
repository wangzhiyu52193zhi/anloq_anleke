package com.anloq.manager;

/**
 * Created by xpf on 2017/5/9 :)
 * Function:全局卡片的管理类，即卡片切换时对应卡片内容切换的管理者
 */

public class CardManager {

}
