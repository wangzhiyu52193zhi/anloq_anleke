package com.anloq.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.anloq.anleke.R;
import com.anloq.model.AccountProfitBean;
import com.anloq.ui.ProfitProgressBar;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by xpf on 2017/10/30 :)
 * Function:
 */

public class ProfitAdapter extends BaseAdapter {

    private Context mContext;
    private double maxProfit;
    private List<AccountProfitBean.ObjectBean.RecordsBean> records;

    public ProfitAdapter(Context mContext, List<AccountProfitBean.ObjectBean.RecordsBean> records,
                         double maxProfit) {
        this.mContext = mContext;
        this.records = records;
        this.maxProfit = maxProfit;
    }

    @Override
    public int getCount() {
        return records.size();
    }

    @Override
    public Object getItem(int position) {
        return records.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_profit, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        AccountProfitBean.ObjectBean.RecordsBean recordsBean = records.get(position);
        int progress = (int) (recordsBean.getAmount() * 100 / maxProfit);
        // 处理文字叠加的问题
        if (progress < 40) {
            progress = 40;
        } else if (progress >= 95) {
            progress = 90;
        }
        if (position == 0) {
            holder.profitBar.init(recordsBean.getTime(), String.valueOf(recordsBean.getAmount()),
                    progress, R.color.color_7ed321);
        } else {
            holder.profitBar.init(recordsBean.getTime(), String.valueOf(recordsBean.getAmount()),
                    progress, R.color.gray_c);
        }
        return convertView;
    }

    static class ViewHolder {
        @BindView(R.id.profitBar)
        ProfitProgressBar profitBar;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
