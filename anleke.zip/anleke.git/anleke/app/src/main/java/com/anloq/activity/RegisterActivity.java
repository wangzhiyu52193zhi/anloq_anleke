package com.anloq.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.manager.DeviceInfoManager;
import com.anloq.utils.MD5Utils;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.anloq.utils.Validator;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.iwgang.countdownview.CountdownView;
import okhttp3.Call;
import okhttp3.MediaType;

// 注册页面
public class RegisterActivity extends Activity implements View.OnClickListener {

    private static final String TAG = RegisterActivity.class.getSimpleName();
    @BindView(R.id.ivLogo)
    ImageView ivLogo;
    @BindView(R.id.tvRegister)
    TextView tvRegister;
    @BindView(R.id.tvLogin)
    TextView tvLogin;
    @BindView(R.id.etPhone)
    EditText etPhone;
    @BindView(R.id.llPhone)
    LinearLayout llPhone;
    @BindView(R.id.etCheckCode)
    EditText etCheckCode;
    @BindView(R.id.tvSend)
    TextView tvSend;
    @BindView(R.id.countDown)
    CountdownView countDown;
    @BindView(R.id.llPwd)
    LinearLayout llPwd;
    @BindView(R.id.etPwd)
    EditText etPwd;
    @BindView(R.id.etPwd2)
    EditText etPwd2;
    @BindView(R.id.tvToast)
    TextView tvToast;
    @BindView(R.id.tvRule)
    TextView tvRule;
    @BindView(R.id.llRule)
    LinearLayout llRule;
    @BindView(R.id.btnRegister)
    Button btnRegister;
    private String phone;
    private String md5Pwd;
    private String pwd;
    private Context mContext;
    protected String devicetoken = "";
    protected int device_type = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
        mContext = this;
        initListener();
    }

    private void initListener() {
        countDown.setOnCountdownEndListener(new CountdownView.OnCountdownEndListener() {
            @Override
            public void onEnd(CountdownView cv) {
                countDown.setVisibility(View.GONE);
                tvSend.setVisibility(View.VISIBLE);
                tvSend.setText(R.string.resend);
            }
        });

        etPwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() >= 6) {
                    btnRegister.setEnabled(true);
                } else {
                    btnRegister.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void sendPwdtoServer() {
        String pwd1 = etPwd.getText().toString().trim();
        if (pwd1.length() >= 6) {
            if (Validator.isPassword(pwd1)) {
                getDataFromNet();
            }
        } else {
            ToastUtil.show(getString(R.string.password_less_six));
        }
    }

    private void getDataFromNet() {
        pwd = etPwd.getText().toString().trim();
        md5Pwd = MD5Utils.MD5(pwd);
        String code = etCheckCode.getText().toString();
        String imei = DeviceInfoManager.getImei();
        String imsi = DeviceInfoManager.getImsi();

        HashMap map = new HashMap();
        map.put("cv", "0.1");
        map.put("phone", phone);
        map.put("password", md5Pwd);
        map.put("smscode", code);
        map.put("imei", imei);
        map.put("imsi", imsi);
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String content = gson.toJson(map);
        Logger.e(TAG, content);
        String url = Constants.REGISTER;

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.t(TAG).e("注册联网失败===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.t(TAG).json(response);
                        parseResult(response);
                    }
                });
    }

    private void parseResult(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            ToastUtil.show(getString(R.string.register_success));
            SpUtil.getInstance().save("isregister", true);
            //SpUtil.getInstance().save("nokey", true);
            //SpUtil.getInstance().save("isfirstup", true);
            login(); // 立即登录
        }
    }

    private void getCodeFromNet() {
        phone = etPhone.getText().toString().trim();
        String url = Constants.SMS;

        if (!TextUtils.isEmpty(phone) && (phone.length() == 11)) {
            tvSend.setVisibility(View.GONE);
            countDown.setVisibility(View.VISIBLE);
            countDown.start(60000);
            HashMap map = new HashMap();
            map.put("phone", phone);

            OkHttpUtils
                    .postString()
                    .url(url)
                    .content(new Gson().toJson(map))
                    .mediaType(MediaType.parse("application/json; charset=utf-8"))
                    .build()
                    .execute(new StringCallback() {
                        @Override
                        public void onError(Call call, Exception e, int id) {
                            Logger.e(TAG, "短信联网失败===" + e.toString());
                        }

                        @Override
                        public void onResponse(String response, int id) {
                            Logger.i(TAG, "短信联网成功===" + response);
                            parseJson(response);
                        }
                    });

        } else {
            ToastUtil.show(getString(R.string.phone_number_invalid));
        }
    }

    private void parseJson(String json) {
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            ToastUtil.show(getString(R.string.send_success));
        }
    }

    private void login() {
        //需要进行判断是什么机型
        device_type = DeviceInfoManager.getDeviceType();
        switch (device_type) {
            case 0:
                //其他手机
                devicetoken = null;
                break;
            case 2:
                //华为手机
                devicetoken = SpUtil.getInstance().getString("devicetoken", "");
                break;
            case 3:
                //小米手机
                devicetoken = SpUtil.getInstance().getString("regId", "");
                break;
        }
        HashMap map = new HashMap();
        map.put("phone", phone);
        map.put("password", md5Pwd);
        map.put("devicetoken", devicetoken);
        map.put("device_type", device_type);// 2代表华为 3代表小米 0代表其他
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String content = gson.toJson(map);
        Logger.e(TAG, content);
        String url = Constants.LOGIN;

        OkHttpUtils
                .postString()
                .url(url)
                .content(content)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        Logger.e(TAG, "登录联网失败===" + e.toString());
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        Logger.i(TAG, "登录联网成功===" + response);
                        SpUtil.getInstance().save("netstate", true);
                        parseLogin(response);
                    }
                });
    }


    private void parseLogin(String json) {
        String code = RequestUtil.getCode(mContext, json);
        // 注意此处登录成功后才可以获取uid和token
        if ("200".equals(code)) {
            RequestUtil.saveLoginSuccessInfo(json);
            SpUtil.getInstance().save("account", phone);
            SpUtil.getInstance().save("password", pwd); // 如果登录成功就将密码保存起来
            ToastUtil.show(getString(R.string.login_success));
            startActivity(new Intent(RegisterActivity.this, MainActivity.class));
            finish();
        }
    }

    @OnClick({R.id.tvLogin, R.id.tvSend, R.id.tvRule, R.id.btnRegister})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvLogin:
                startActivity(new Intent(RegisterActivity.this, GuideActivity.class));
                finish();
                break;
            case R.id.tvSend:
                phone = etPhone.getText().toString().trim();
                if (Validator.isChinaPhoneLegal(phone)) {
                    getCodeFromNet();
                } else {
                    ToastUtil.show(getString(R.string.phone_invalid));
                }
                break;
            case R.id.tvRule:
                startActivity(new Intent(RegisterActivity.this, AnloqRuleDetail.class));
                break;
            case R.id.btnRegister:
                phone = etPhone.getText().toString().trim();
                String code = etCheckCode.getText().toString().trim();
                if ("".equals(phone) || "".equals(code)) {
                    ToastUtil.show(getString(R.string.phone_or_code_empty));
                } else {
                    if (etCheckCode.length() == 6) {
                        //判断密码长度
                        if (etPwd.getText().length() > 18) {
                            ToastUtil.show(getString(R.string.password_more_eighteen));
                        } else {
                            sendPwdtoServer();
                        }

                    } else {
                        ToastUtil.show(getString(R.string.code_is_recorrect));
                    }
                }
                break;
        }
    }

}
