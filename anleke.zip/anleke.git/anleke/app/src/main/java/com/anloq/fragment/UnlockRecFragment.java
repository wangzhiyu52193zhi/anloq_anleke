package com.anloq.fragment;

import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;
import android.widget.TextView;

import com.anloq.adapter.OpenDoorAdapter;
import com.anloq.anleke.R;
import com.anloq.api.Constants;
import com.anloq.base.BaseFragment;
import com.anloq.model.EventBusMsg;
import com.anloq.model.UnlockRecordBean;
import com.anloq.utils.MessageProvider;
import com.anloq.utils.RequestUtil;
import com.anloq.utils.SpUtil;
import com.anloq.utils.ToastUtil;
import com.google.gson.Gson;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.orhanobut.logger.Logger;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;

/**
 * Created by xpf on 2017/3/22 :)
 * Function:开锁记录页面的Fragment
 */

public class UnlockRecFragment extends BaseFragment {

    private static final String TAG = UnlockRecFragment.class.getSimpleName();
    @BindView(R.id.tvNoData)
    TextView tvNoData;
    @BindView(R.id.recyclerView)
    XRecyclerView recyclerView;
    private OpenDoorAdapter openDoorAdapter;
    private List<UnlockRecordBean.ObjectBean.DataBean> allData;
    private int totalPage;
    private int mLastRecordId;
    private int pageNum = 1; // 页码
    private boolean isLoadMore = false; // 是否加载更多
    private String currentKeyId = "";

    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    getData();
                    break;
                case 2:
                    stopRefreshAndLoading();
                    break;
            }
        }
    };

    @Override
    public View initView() {
        Logger.t(TAG).i("开锁记录页面的视图初始化了");
        View view = View.inflate(mContext, R.layout.fragment_unlock_record, null);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void initData() {
        super.initData();
        Logger.t(TAG).i("开锁记录页面的数据初始化了");
        EventBus.getDefault().register(this);
        initListener();
        handler.sendEmptyMessageDelayed(1, 3000);
    }

    private void initListener() {
        recyclerView.setLoadingListener(new XRecyclerView.LoadingListener() {
            @Override
            public void onRefresh() {
                isLoadMore = false;
                pageNum = 1;
                getData();
            }

            @Override
            public void onLoadMore() {
                isLoadMore = true;
                if (pageNum < totalPage) {
                    pageNum++;
                    getData();
                } else {
                    handler.sendEmptyMessageDelayed(2, 2000);
                }
            }
        });
    }

    private void getData() {
        int uid = SpUtil.getInstance().getInt("uid", -1);
        String token = SpUtil.getInstance().getString("token", "");
        currentKeyId = SpUtil.getInstance().getString("currentkeyid", "");
        if ("".equals(currentKeyId)) {
            Logger.t(TAG).e("keyId为空请求失败!");
            return;
        }
        String url = Constants.ROOMOPENRECORD + uid + Constants.TOKEN + token + Constants.KEYID +
                currentKeyId + Constants.PAGESIZE + 20 + Constants.PAGENUM + pageNum;
        Logger.t(TAG).i("ROOMOPENRECORD_url===" + url);

        if (isLoadMore) {
            url = url + Constants.LASTRECORDID + mLastRecordId;
        }

        OkHttpUtils
                .get()
                .url(url)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {
                        String unlockRecord = MessageProvider.getInstance().getUnlockRecord();
                        if (unlockRecord != null && !"".equals(unlockRecord)) {
                            parseJson(unlockRecord);
                        }
                    }

                    @Override
                    public void onResponse(String response, int id) {
                        // Logger.t(TAG).json(response);
                        if (isLoadMore) {
                            addLoadMore(response);
                        } else {
                            parseJson(response);
                        }
                    }
                });
    }

    private void addLoadMore(String response) {
        handler.sendEmptyMessageDelayed(2, 2000);
        String code = RequestUtil.getCode(mContext, response);
        if ("200".equals(code)) {
            UnlockRecordBean unlockRecordBean = new Gson().fromJson(response, UnlockRecordBean.class);
            if (unlockRecordBean != null) {
                UnlockRecordBean.ObjectBean object = unlockRecordBean.getObject();
                if (object != null) {
                    List<UnlockRecordBean.ObjectBean.DataBean> secondData = object.getData();
                    if (secondData != null && secondData.size() > 0) {
                        ToastUtil.show("加载更多成功");
                        allData.addAll(secondData);
                        if (openDoorAdapter != null) {
                            openDoorAdapter.notifyDataSetChanged();
                        } else {
                            setAdapter();
                        }
                    } else {
                        ToastUtil.show("已没有更多数据了");
                    }
                }
            } else {
                ToastUtil.show("已没有更多数据");
            }
        }
    }

    private void parseJson(String json) {
        handler.sendEmptyMessageDelayed(2, 2000);
        String code = RequestUtil.getCode(mContext, json);
        if ("200".equals(code)) {
            UnlockRecordBean unlockRecordBean = new Gson().fromJson(json, UnlockRecordBean.class);
            if (unlockRecordBean != null) {
                UnlockRecordBean.ObjectBean object = unlockRecordBean.getObject();
                if (object != null) {
                    // 清除旧数据
                    if (allData != null && allData.size() > 0) {
                        allData.clear();
                    }
                    allData = object.getData();
                    totalPage = object.getPage().getTotalpage();
                    if (allData != null && allData.size() > 0) {
                        mLastRecordId = object.getData().get(allData.size() - 1).getRecord_id();
                        MessageProvider.getInstance().saveUnlockRecord(json); // 缓存到本地
                    }
                    setAdapter();
                }
            }
        }
    }

    /**
     * 设置适配器
     */
    private void setAdapter() {
        if (allData != null) {
            tvNoData.setVisibility(allData.size() > 0 ? View.GONE : View.VISIBLE);
            recyclerView.setVisibility(allData.size() > 0 ? View.VISIBLE : View.GONE);
        }
        openDoorAdapter = new OpenDoorAdapter(mContext, allData);
        recyclerView.setAdapter(openDoorAdapter);
        LinearLayoutManager manager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(manager);
    }

    /**
     * 停止刷新或加载视图
     */
    private void stopRefreshAndLoading() {
        if (isLoadMore) {
            recyclerView.loadMoreComplete();
        } else {
            recyclerView.refreshComplete();
        }
    }

    @OnClick(R.id.tvNoData)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvNoData:
                isLoadMore = false;
                pageNum = 1;
                getData();
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBusMsg msg) {
        String type = msg.getType();
        if ("updateopendoor".equals(type)) {
            currentKeyId = msg.getContent();
            Logger.t(TAG).i("收到了切换卡片时更新开锁记录的通知currentKeyId===" + currentKeyId);
            isLoadMore = false;
            pageNum = 1;
            getData();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
        handler.removeCallbacksAndMessages(null);
    }

}
