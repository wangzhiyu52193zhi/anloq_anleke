package com.anloq.model;

import com.anloq.utils.TimeUtil;
import com.google.gson.annotations.SerializedName;

/**
 * Created by xpf on 2017/4/18 :)
 * Function:消息公告通知的Bean类
 */

public class NoticeMsgBean {

    /**
     * name : noticemsg
     * object : {"title":"hello","content":"http://101.201.68.248:3001/upload/html/854338660139667456.html","status":"1","abstract":"sdjfklsdjffkl sdd ","release_date":"04/18 06:19","command":0}
     */

    private String name;
    private ObjectBean object;
    private String time;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return TimeUtil.getTime(time);
    }

    public void setTime(String time) {
        this.time = time;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * title : hello
         * content : http://101.201.68.248:3001/upload/html/854338660139667456.html
         * status : 1
         * abstract : sdjfklsdjffkl sdd
         * release_date : 04/18 06:19
         * command : 0
         */

        private String title;
        private String content;
        private String status;
        @SerializedName("abstract")
        private String abstractX;
        private String release_date;
        private int command;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getAbstractX() {
            return abstractX;
        }

        public void setAbstractX(String abstractX) {
            this.abstractX = abstractX;
        }

        public String getRelease_date() {
            return release_date;
        }

        public void setRelease_date(String release_date) {
            this.release_date = release_date;
        }

        public int getCommand() {
            return command;
        }

        public void setCommand(int command) {
            this.command = command;
        }
    }
}
