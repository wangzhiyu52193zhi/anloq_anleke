package com.anloq.model;

/**
 * Created by xpf on 2017/9/11 :)
 * Function:生成二维码的Bean
 */

public class QrCodeBean {

    /**
     * code : 200
     * object : {"num":"230498290385"}
     */

    private int code;
    private ObjectBean object;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public ObjectBean getObject() {
        return object;
    }

    public void setObject(ObjectBean object) {
        this.object = object;
    }

    public static class ObjectBean {
        /**
         * num : 230498290385
         */

        private String num;

        public String getNum() {
            return num;
        }

        public void setNum(String num) {
            this.num = num;
        }
    }
}
