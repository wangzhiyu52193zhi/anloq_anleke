package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class CHECK_IN_REC {
    private String cmd;
    private String session;
    private DEVICE device;
    private SDK sdk;
    private String seq;
    private int status;
    private String errorcode;

    public CHECK_IN_REC(String cmd, String session, DEVICE device, SDK sdk, String seq, int status, String errorCode) {
        this.cmd = cmd;
        this.session = session;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
        this.status = status;
        this.errorcode = errorCode;
    }

    public CHECK_IN_REC() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public String getSession() {
        return session;
    }

    public void setSession(String session) {
        this.session = session;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getErrorCode() {
        return errorcode;
    }

    public void setErrorCode(String errorCode) {
        this.errorcode = errorCode;
    }

    @Override
    public String toString() {
        return "CHECK_IN_REC{" +
                "cmd='" + cmd + '\'' +
                ", session='" + session + '\'' +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                ", status=" + status +
                ", errorCode='" + errorcode + '\'' +
                '}';
    }
}
