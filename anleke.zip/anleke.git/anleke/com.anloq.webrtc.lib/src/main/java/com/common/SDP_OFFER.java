package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class SDP_OFFER {
    private String cmd;
    private ID callerid;
    private ID calleeid;
    private String callersdp;
    private ID sdid;
    private DEVICE device;
    private SDK sdk;
    private String seq;

    public SDP_OFFER(String cmd, ID callerId, ID calleeId, String callerSDP, ID sdId, DEVICE device, SDK sdk, String seq) {
        this.cmd = cmd;
        this.callerid = callerId;
        this.calleeid = calleeId;
        this.callersdp = callerSDP;
        this.sdid = sdId;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
    }

    public SDP_OFFER() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public ID getCallerId() {
        return callerid;
    }

    public void setCallerId(ID callerId) {
        this.callerid = callerId;
    }

    public ID getCalleeId() {
        return calleeid;
    }

    public void setCalleeId(ID calleeId) {
        this.calleeid = calleeId;
    }

    public String getCallerSDP() {
        return callersdp;
    }

    public void setCallerSDP(String callerSDP) {
        this.callersdp = callerSDP;
    }

    public ID getSdId() {
        return sdid;
    }

    public void setSdId(ID sdId) {
        this.sdid = sdId;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Override
    public String toString() {
        return "SDP_OFFER{" +
                "cmd='" + cmd + '\'' +
                ", callerId=" + callerid +
                ", calleeId=" + calleeid +
                ", callerSDP='" + callersdp + '\'' +
                ", sdId=" + sdid +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                '}';
    }
}
