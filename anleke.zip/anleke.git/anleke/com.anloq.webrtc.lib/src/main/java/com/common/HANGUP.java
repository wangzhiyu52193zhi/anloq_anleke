package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class HANGUP {
    private String cmd;
    private ID callerid;
    private ID calleeid;
    private int status;
    private String errorcode;
    private ID sdid;
    private DEVICE device;
    private SDK sdk;
    private String seq;

    public HANGUP(String cmd, ID callerId, ID calleeId, int status, String errorCode, ID sdId, DEVICE device, SDK sdk, String seq) {
        this.cmd = cmd;
        this.callerid = callerId;
        this.calleeid = calleeId;
        this.status = status;
        this.errorcode = errorCode;
        this.sdid = sdId;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
    }

    public HANGUP() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public ID getCallerId() {
        return callerid;
    }

    public void setCallerId(ID callerId) {
        this.callerid = callerId;
    }

    public ID getCalleeId() {
        return calleeid;
    }

    public void setCalleeId(ID calleeId) {
        this.calleeid = calleeId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getErrorCode() {
        return errorcode;
    }

    public void setErrorCode(String errorCode) {
        this.errorcode = errorCode;
    }

    public ID getSdId() {
        return sdid;
    }

    public void setSdId(ID sdId) {
        this.sdid = sdId;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Override
    public String toString() {
        return "HANGUP{" +
                "cmd='" + cmd + '\'' +
                ", callerId=" + callerid +
                ", calleeId=" + calleeid +
                ", status=" + status +
                ", errorCode='" + errorcode + '\'' +
                ", sdId=" + sdid +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                '}';
    }
}
