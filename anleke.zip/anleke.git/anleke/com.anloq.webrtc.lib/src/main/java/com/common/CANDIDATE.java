package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class CANDIDATE {
    private String cmd;
    private ID callerid;
    private ID calleeid;
    private String candidatesdp;
    private ID sdid;
    private DEVICE device;
    private SDK sdk;
    private String seq;

    public CANDIDATE(String cmd, ID callerId, ID calleeId, String candidateSDP, ID sdId, DEVICE device, SDK sdk, String seq) {
        this.cmd = cmd;
        this.callerid = callerId;
        this.calleeid = calleeId;
        this.candidatesdp = candidateSDP;
        this.sdid = sdId;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
    }

    public CANDIDATE() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public ID getCallerId() {
        return callerid;
    }

    public void setCallerId(ID callerId) {
        this.callerid = callerId;
    }

    public ID getCalleeId() {
        return calleeid;
    }

    public void setCalleeId(ID calleeId) {
        this.calleeid = calleeId;
    }

    public String getCandidateSDP() {
        return candidatesdp;
    }

    public void setCandidateSDP(String candidateSDP) {
        this.candidatesdp = candidateSDP;
    }

    public ID getSdId() {
        return sdid;
    }

    public void setSdId(ID sdId) {
        this.sdid = sdId;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Override
    public String toString() {
        return "CANDIDATE{" +
                "cmd='" + cmd + '\'' +
                ", callerId=" + callerid +
                ", calleeId=" + calleeid +
                ", candidateSDP='" + candidatesdp + '\'' +
                ", sdId=" + sdid +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                '}';
    }
}
