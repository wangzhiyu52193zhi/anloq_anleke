package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class STREAM_START {
    private String cmd;
    private ID callerid;
    private ID calleeid;
    private String streamid;
    private String streamtype;
    private ID sdid;
    private DEVICE device;
    private SDK sdk;
    private String seq;

    public STREAM_START(String cmd, ID callerId, ID calleeId, String streamId, String streamType, ID sdId, DEVICE device, SDK sdk, String seq) {
        this.cmd = cmd;
        this.callerid = callerId;
        this.calleeid = calleeId;
        this.streamid = streamId;
        this.streamtype = streamType;
        this.sdid = sdId;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
    }

    public STREAM_START() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public ID getCallerId() {
        return callerid;
    }

    public void setCallerId(ID callerId) {
        this.callerid = callerId;
    }

    public ID getCalleeId() {
        return calleeid;
    }

    public void setCalleeId(ID calleeId) {
        this.calleeid = calleeId;
    }

    public String getStreamId() {
        return streamid;
    }

    public void setStreamId(String streamid) {
        this.streamid = streamid;
    }

    public String getStreamType() {
        return streamtype;
    }

    public void setStreamType(String streamtype) {
        this.streamtype = streamtype;
    }

    public ID getSdId() {
        return sdid;
    }

    public void setSdId(ID sdId) {
        this.sdid = sdId;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Override
    public String toString() {
        return "STREAM_START{" +
                "cmd='" + cmd + '\'' +
                ", callerid=" + callerid +
                ", calleeid=" + calleeid +
                ", streamid='" + streamid + '\'' +
                ", streamtype='" + streamtype + '\'' +
                ", sdid=" + sdid +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                '}';
    }
}
