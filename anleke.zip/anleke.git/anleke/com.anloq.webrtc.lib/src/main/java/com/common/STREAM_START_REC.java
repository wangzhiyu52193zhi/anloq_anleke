package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class STREAM_START_REC {
    private String cmd;
    private DEVICE device;
    private SDK sdk;
    private int status;
    private String seq;
    private String errorcode;

    public STREAM_START_REC(String cmd, DEVICE device, SDK sdk, String seq, int status, String seq1, String errorCode) {
        this.cmd = cmd;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
        this.status = status;
        this.seq = seq1;
        this.errorcode = errorCode;
    }

    public STREAM_START_REC() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public String getErrorCode() {
        return errorcode;
    }

    public void setErrorCode(String errorCode) {
        this.errorcode = errorCode;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "STREAM_START_REC{" +
                "cmd='" + cmd + '\'' +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                ", status=" + status +
                ", seq='" + seq + '\'' +
                ", errorCode='" + errorcode + '\'' +
                '}';
    }
}
