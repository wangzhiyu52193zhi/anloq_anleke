package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */
public class ID{
    private String type;
    private String id;
    private String token;

    public ID(String type, String id, String token) {
        this.type = type;
        this.id = id;
        this.token = token;
    }

    public ID() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "ID{" +
                "type='" + type + '\'' +
                ", id='" + id + '\'' +
                ", token='" + token + '\'' +
                '}';
    }
}

