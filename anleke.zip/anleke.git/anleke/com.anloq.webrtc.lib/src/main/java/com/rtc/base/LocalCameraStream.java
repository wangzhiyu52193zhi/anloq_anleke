package com.rtc.base;

import android.hardware.Camera;
import android.util.Log;

import org.webrtc.VideoTrack;

public class LocalCameraStream extends LocalStream {
    private static String TAG = "Anloq-LocalCameraStream";
    private int resolutionWidth = 0;
    private int resolutionHeight = 0;

    public LocalCameraStream(LocalCameraStreamParameters localStreamParameters)
            throws WoogeenStreamException {

        if (localStreamParameters == null)
            localStreamParameters = new LocalCameraStreamParameters(true, true);
        this.mediaStream = PCFactory.createMediaStream(localStreamParameters);
        this.streamId = "";
        this.resolutionWidth = PCFactory.getCapturerWidth();
        this.resolutionHeight = PCFactory.getCapturerHeight();
    }

    public int getResolutionWidth() {
        return this.resolutionWidth;
    }

    public int getResolutionHeight() {
        return this.resolutionHeight;
    }

    public boolean disableVideo() {
        if (mediaStream == null) {
            return false;
        }
        if (mediaStream.videoTracks.size() == 0) {
            return false;
        }
        if ((hasVideo()) && (((VideoTrack) this.mediaStream.videoTracks.get(0)).enabled()))
            PCFactory.stopVideoSource();
        return super.disableVideo();
    }

    public boolean enableVideo() {
        if ((hasVideo()) && (!((VideoTrack) this.mediaStream.videoTracks.get(0)).enabled()))
            PCFactory.restartVideoSource();
        return super.enableVideo();
    }

    public void switchCamera(ActionCallback<Boolean> callback) {
        PCFactory.switchVideoCapturer(callback);
    }

    public synchronized void close() {
        if (this.mediaStream == null) {
            Log.d(TAG, "Stream is already closed");
            return;
        }
        Log.d(TAG, "Dispose media stream");
        detach();
        try {
            disableVideo();
            disableAudio();
            PCFactory.onLocalCameraStreamClosed(this);
            this.mediaStream = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setCameraParameters(Camera.Parameters parameters) {
        PCFactory.setCameraParameters(parameters);
    }

    public Camera.Parameters getCameraParameters() {
        return PCFactory.getCameraParameters();
    }
}