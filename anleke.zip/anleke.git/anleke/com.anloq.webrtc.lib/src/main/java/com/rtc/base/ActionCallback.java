//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.rtc.base;

public interface ActionCallback<T> {
    void onSuccess(T var1);

    void onFailure(WoogeenException var1);
}
