package com.rtc.base;

import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.StatsReport;
import org.webrtc.StatsReport.Value;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class ConnectionStats {
    public Date timeStamp;
    public ConnectionStats.VideoBandwidthStats videoBandwidthStats;
    public List<ConnectionStats.MediaTrackStats> mediaTracksStatsList;

    public ConnectionStats(Vector<StatsReport> reports) {
        this.timeStamp = new Date((long) ((StatsReport) reports.get(0)).timestamp);
        this.mediaTracksStatsList = new ArrayList();

        try {
            Iterator e = reports.iterator();

            while (true) {
                while (e.hasNext()) {
                    StatsReport report = (StatsReport) e.next();
                    if (report.type.equals("VideoBwe")) {
                        this.videoBandwidthStats = new ConnectionStats.VideoBandwidthStats(report);
                    } else if (report.type.equals("ssrc")) {
                        JSONObject report_jobj = new JSONObject();
                        report_jobj.put("id", report.id);
                        Value[] arr$ = report.values;
                        int len$ = arr$.length;

                        for (int i$ = 0; i$ < len$; ++i$) {
                            Value value = arr$[i$];
                            report_jobj.put(value.name, value.value);
                        }

                        Object mts;
                        if (report_jobj.has("bytesSent")) {
                            if (report_jobj.has("googFrameHeightSent")) {
                                mts = new ConnectionStats.VideoSenderMediaTrackStats(report_jobj);
                            } else {
                                mts = new ConnectionStats.AudioSenderMediaTrackStats(report_jobj);
                            }
                        } else if (report_jobj.has("googFrameHeightReceived")) {
                            mts = new ConnectionStats.VideoReceiverMediaTrackStats(report_jobj);
                        } else {
                            mts = new ConnectionStats.AudioReceiverMediaTrackStats(report_jobj);
                        }

                        this.mediaTracksStatsList.add((MediaTrackStats) mts);
                    }
                }

                return;
            }
        } catch (JSONException var10) {
            var10.printStackTrace();
        }
    }

    public static class AudioLevels {
        private ArrayList<ConnectionStats.AudioLevels.AudioLevel> inputLevelList = new ArrayList();
        private ArrayList<ConnectionStats.AudioLevels.AudioLevel> outputLevelList = new ArrayList();

        public AudioLevels(ConnectionStats cs) {
            if (cs != null) {
                Iterator i$ = cs.mediaTracksStatsList.iterator();

                while (i$.hasNext()) {
                    ConnectionStats.MediaTrackStats mts = (ConnectionStats.MediaTrackStats) i$.next();
                    ConnectionStats.AudioLevels.AudioLevel al;
                    if (mts instanceof ConnectionStats.AudioSenderMediaTrackStats) {
                        al = new ConnectionStats.AudioLevels.AudioLevel(mts.id, ((ConnectionStats.AudioSenderMediaTrackStats) mts).audioInputLevel);
                        this.inputLevelList.add(al);
                    } else if (mts instanceof ConnectionStats.AudioReceiverMediaTrackStats) {
                        al = new ConnectionStats.AudioLevels.AudioLevel(mts.id, ((ConnectionStats.AudioReceiverMediaTrackStats) mts).audioOutputLevel);
                        this.outputLevelList.add(al);
                    }
                }
            }

        }

        public ArrayList<ConnectionStats.AudioLevels.AudioLevel> getInputLevelList() {
            return this.inputLevelList;
        }

        public ArrayList<ConnectionStats.AudioLevels.AudioLevel> getOutputLevelList() {
            return this.outputLevelList;
        }

        public static class AudioLevel {
            public final String ssrcId;
            public final int level;

            AudioLevel(String ssrcId, int level) {
                this.ssrcId = ssrcId;
                this.level = level;
            }
        }
    }

    public class AudioReceiverMediaTrackStats extends ConnectionStats.MediaTrackStats {
        public long bytesReceived = 0L;
        public long packetsReceived = 0L;
        public long packetsLost = 0L;
        public long delayEstimatedMs = 0L;
        public int audioOutputLevel = 0;

        public AudioReceiverMediaTrackStats(JSONObject report) {
            super();
            this.bytesReceived = Long.parseLong(this.getString(report, "bytesReceived"));
            this.packetsReceived = Long.parseLong(this.getString(report, "packetsReceived"));
            this.packetsLost = Long.parseLong(this.getString(report, "packetsLost"));
            this.delayEstimatedMs = Long.parseLong(this.getString(report, "googCurrentDelayMs"));
            this.audioOutputLevel = Integer.parseInt(this.getString(report, "audioOutputLevel"));
        }
    }

    public class AudioSenderMediaTrackStats extends ConnectionStats.MediaTrackStats {
        public long bytesSent = 0L;
        public long packetsSent = 0L;
        public long packetsLost = 0L;
        public long rtt = 0L;
        public int audioInputLevel = 0;

        public AudioSenderMediaTrackStats(JSONObject report) {
            super();
            this.bytesSent = Long.parseLong(this.getString(report, "bytesSent"));
            this.packetsSent = Long.parseLong(this.getString(report, "packetsSent"));
            this.packetsLost = Long.parseLong(this.getString(report, "packetsLost"));
            this.rtt = Long.parseLong(this.getString(report, "googRtt"));
            this.audioInputLevel = Integer.parseInt(this.getString(report, "audioInputLevel"));
        }
    }

    public class VideoReceiverMediaTrackStats extends ConnectionStats.MediaTrackStats {
        public long bytesReceived = 0L;
        public long packetsReceived = 0L;
        public long packetsLost = 0L;
        public long firsSent = 0L;
        public long naksSent = 0L;
        public long plisSent = 0L;
        public int frameWidthReceived = 0;
        public int frameHeightReceived = 0;
        public int frameRateReceived = 0;
        public int frameRateOutput = 0;
        public long currentDelayMs = 0L;

        public VideoReceiverMediaTrackStats(JSONObject report) {
            super();
            this.bytesReceived = Long.parseLong(this.getString(report, "bytesReceived"));
            this.packetsReceived = Long.parseLong(this.getString(report, "packetsReceived"));
            this.packetsLost = Long.parseLong(this.getString(report, "packetsLost"));
            this.firsSent = Long.parseLong(this.getString(report, "googFirsSent"));
            this.plisSent = Long.parseLong(this.getString(report, "googPlisSent"));
            this.naksSent = Long.parseLong(this.getString(report, "googNacksSent"));
            this.frameWidthReceived = Integer.parseInt(this.getString(report, "googFrameWidthReceived"));
            this.frameHeightReceived = Integer.parseInt(this.getString(report, "googFrameHeightReceived"));
            this.frameRateReceived = Integer.parseInt(this.getString(report, "googFrameRateReceived"));
            this.frameRateOutput = Integer.parseInt(this.getString(report, "googFrameRateDecoded"));
            this.currentDelayMs = Long.parseLong(this.getString(report, "googCurrentDelayMs"));
        }
    }

    public class VideoSenderMediaTrackStats extends ConnectionStats.MediaTrackStats {
        public ConnectionStats.AdaptReason adaptReason;
        public int adaptChanges = 0;
        public long bytesSent = 0L;
        public long packetsSent = 0L;
        public long packetsLost = 0L;
        public long firsReceived = 0L;
        public long plisReceived = 0L;
        public long naksReceived = 0L;
        public int frameWidthSent = 0;
        public int frameHeightSent = 0;
        public int frameRateSent = 0;
        public long rtt = 0L;

        public VideoSenderMediaTrackStats(JSONObject report) {
            super();
            if (this.getString(report, "googCpuLimitedResolution").equals("true")) {
                this.adaptReason = ConnectionStats.AdaptReason.ADAPT_CPU_LIMITATION;
            } else if (this.getString(report, "googBandwidthLimitedResolution").equals("true")) {
                this.adaptReason = ConnectionStats.AdaptReason.ADAPT_BANDWIDTH_LIMITATION;
            } else if (this.getString(report, "googViewLimitedResolution").equals("true")) {
                this.adaptReason = ConnectionStats.AdaptReason.ADAPT_VIEW_LIMITATION;
            } else {
                this.adaptReason = ConnectionStats.AdaptReason.ADAPT_UNKNOWN;
            }

            this.bytesSent = Long.parseLong(this.getString(report, "bytesSent"));
            this.packetsSent = Long.parseLong(this.getString(report, "packetsSent"));
            this.packetsLost = Long.parseLong(this.getString(report, "packetsLost"));
            this.firsReceived = Long.parseLong(this.getString(report, "googFirsReceived"));
            this.plisReceived = Long.parseLong(this.getString(report, "googPlisReceived"));
            this.naksReceived = Long.parseLong(this.getString(report, "googNacksReceived"));
            this.frameWidthSent = Integer.parseInt(this.getString(report, "googFrameWidthSent"));
            this.frameHeightSent = Integer.parseInt(this.getString(report, "googFrameHeightSent"));
            this.frameRateSent = Integer.parseInt(this.getString(report, "googFrameRateSent"));
            this.adaptChanges = Integer.parseInt(this.getString(report, "googAdaptationChanges"));
            this.rtt = Long.parseLong(this.getString(report, "googRtt"));
        }
    }

    public abstract class MediaTrackStats {
        public String id;
        public String codecName;
        public String trackId;

        MediaTrackStats(JSONObject report) {
            try {
                this.id = report.has("id") ? report.getString("id") : "";
                this.codecName = report.has("googCodecName") ? report.getString("googCodecName") : "";
                this.trackId = report.has("googTrackId") ? report.getString("googTrackId") : "";
            } catch (JSONException var4) {
                var4.printStackTrace();
            }

        }

        public MediaTrackStats() {

        }

        protected String getString(JSONObject jobj, String key) {
            if (jobj.has(key)) {
                try {
                    return jobj.getString(key);
                } catch (JSONException var4) {
                    return "0";
                }
            } else {
                return "0";
            }
        }
    }

    public class VideoBandwidthStats {
        public long availableReceiveBandwidth = 0L;
        public long availableSendBandwidth = 0L;
        public long transmitBitrate = 0L;
        public long reTransmitBitrate = 0L;

        public VideoBandwidthStats(StatsReport report) {
            Value[] arr$ = report.values;
            int len$ = arr$.length;

            for (int i$ = 0; i$ < len$; ++i$) {
                Value value = arr$[i$];
                if (value.name.equals("googAvailableReceiveBandwidth")) {
                    this.availableReceiveBandwidth = Long.parseLong(value.value);
                } else if (value.name.equals("googAvailableSendBandwidth")) {
                    this.availableSendBandwidth = Long.parseLong(value.value);
                } else if (value.name.equals("googTransmitBitrate")) {
                    this.transmitBitrate = Long.parseLong(value.value);
                } else if (value.name.equals("googRetransmitBitrate")) {
                    this.reTransmitBitrate = Long.parseLong(value.value);
                }
            }

        }
    }

    static enum AdaptReason {
        ADAPT_CPU_LIMITATION,
        ADAPT_BANDWIDTH_LIMITATION,
        ADAPT_VIEW_LIMITATION,
        ADAPT_UNKNOWN;

        private AdaptReason() {
        }
    }
}
