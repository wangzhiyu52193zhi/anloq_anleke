package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class DEVICE {
    private String type;
    private String os;
    private String version;
    private String deiceid;

    public DEVICE(String type, String os, String version, String deiceId) {
        this.type = type;
        this.os = os;
        this.version = version;
        this.deiceid = deiceId;
    }

    public DEVICE() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDeiceId() {
        return deiceid;
    }

    public void setDeiceId(String deiceId) {
        this.deiceid = deiceId;
    }

    @Override
    public String toString() {
        return "DEVICE{" +
                "type='" + type + '\'' +
                ", os='" + os + '\'' +
                ", version='" + version + '\'' +
                ", deiceId='" + deiceid + '\'' +
                '}';
    }
}
