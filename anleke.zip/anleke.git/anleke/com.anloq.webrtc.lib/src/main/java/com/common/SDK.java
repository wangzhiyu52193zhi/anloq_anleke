package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class SDK {
    private String type;
    private String version;

    public SDK(String type, String version) {
        this.type = type;
        this.version = version;
    }

    public SDK() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return "SDK{" +
                "type='" + type + '\'' +
                ", version='" + version + '\'' +
                '}';
    }
}
