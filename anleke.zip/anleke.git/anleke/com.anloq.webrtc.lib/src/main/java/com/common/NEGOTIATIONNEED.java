package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class NEGOTIATIONNEED {
    private String cmd;
    private ID callerid;
    private ID calleeid;
    private ID sdid;
    private DEVICE device;
    private SDK sdk;
    private String seq;

    public NEGOTIATIONNEED(String cmd, ID callerId, ID calleeId, ID sdId, DEVICE device, SDK sdk, String seq) {
        this.cmd = cmd;
        this.callerid = callerId;
        this.calleeid = calleeId;
        this.sdid = sdId;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
    }

    public NEGOTIATIONNEED() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public ID getCallerId() {
        return callerid;
    }

    public void setCallerId(ID callerId) {
        this.callerid = callerId;
    }

    public ID getCalleeId() {
        return calleeid;
    }

    public void setCalleeId(ID calleeId) {
        this.calleeid = calleeId;
    }

    public ID getSdId() {
        return sdid;
    }

    public void setSdId(ID sdId) {
        this.sdid = sdId;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Override
    public String toString() {
        return "NEGOTIATIONNEED{" +
                "cmd='" + cmd + '\'' +
                ", callerId=" + callerid +
                ", calleeId=" + calleeid +
                ", sdId=" + sdid +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                '}';
    }
}
