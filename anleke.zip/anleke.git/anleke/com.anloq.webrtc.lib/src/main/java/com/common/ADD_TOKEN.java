package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class ADD_TOKEN {
    private String cmd;
    private String tokenid;
    private DEVICE device;
    private SDK sdk;
    private String seq;

    public ADD_TOKEN(String cmd, String tokenId, DEVICE device, SDK sdk, String seq) {
        this.cmd = cmd;
        this.tokenid = tokenId;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
    }

    public ADD_TOKEN() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public String getTokenId() {
        return tokenid;
    }

    public void setTokenId(String tokenId) {
        this.tokenid = tokenId;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Override
    public String toString() {
        return "ADD_TOKEN{" +
                "cmd='" + cmd + '\'' +
                ", tokenId='" + tokenid + '\'' +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                '}';
    }
}
