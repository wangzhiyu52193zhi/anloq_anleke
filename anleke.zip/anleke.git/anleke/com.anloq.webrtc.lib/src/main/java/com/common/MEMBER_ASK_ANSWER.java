package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class MEMBER_ASK_ANSWER {
    private String sessionid;
    private String cmd;
    private ID calleeid;
    private int agree;
    private ID callerid;
    private ID sdid;
    private DEVICE device;
    private SDK sdk;
    private String seq;

    public MEMBER_ASK_ANSWER(String sessionId, String cmd, ID calleeId, int agree, ID callerId, ID sdId, DEVICE device, SDK sdk, String seq) {
        this.sessionid = sessionId;
        this.cmd = cmd;
        this.calleeid = calleeId;
        this.agree = agree;
        this.callerid = callerId;
        this.sdid = sdId;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
    }

    public MEMBER_ASK_ANSWER() {
    }

    public String getSessionId() {
        return sessionid;
    }

    public void setSessionId(String sessionId) {
        this.sessionid = sessionId;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public ID getCalleeId() {
        return calleeid;
    }

    public void setCalleeId(ID calleeId) {
        this.calleeid = calleeId;
    }

    public int getAgree() {
        return agree;
    }

    public void setAgree(int agree) {
        this.agree = agree;
    }

    public ID getCallerId() {
        return callerid;
    }

    public void setCallerId(ID callerId) {
        this.callerid = callerId;
    }

    public ID getSdId() {
        return sdid;
    }

    public void setSdId(ID sdId) {
        this.sdid = sdId;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Override
    public String toString() {
        return "MEMBER_ASK_ANSWER{" +
                "sessionId='" + sessionid + '\'' +
                ", cmd='" + cmd + '\'' +
                ", calleeId=" + calleeid +
                ", agree=" + agree +
                ", callerId=" + callerid +
                ", sdId=" + sdid +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                '}';
    }
}
