package com.rtc.base;

public class ExternalStream implements Publishable {
    private static String TAG = "Anloq-ExternalStream";
    private String url = "";
    private String id = "";
    private String transport = "";
    private int bufferSize = 0;

    public ExternalStream(String url) {
        this.url = url;
    }

    public String getUrl() {
        return this.url;
    }


    public String getTransport() {
        return this.transport;
    }

    public void setTransport(String transport) {
        if (transport != null) {
            this.transport = transport;
        }
    }

    public int getBufferSize() {
        return this.bufferSize;
    }

    public void setBufferSize(int size) {
        this.bufferSize = size;
    }

    public void setId(String id) {
        if (id != null) {
            this.id = id;
        }
    }

    public String getId() {
        return this.id;
    }
}