package com.common;

import com.google.gson.Gson;

/**
 * Created by arhuang75 on 17/2/24.
 */

public class AnloqUtil {
    public static String random(){
        java.util.Date date=new java.util.Date();
        java.text.SimpleDateFormat format=new java.text.SimpleDateFormat("yyyyMMddHHmmss");
        return format.format(date)+(long) (Math.random()*Math.random()*Math.random()*1000000000);
    }

    public static <T> T parseJsonWithGson(String jsonData, Class<T> type) {
        Gson gson = new Gson();
        T result = gson.fromJson(jsonData, type);
        return result;
    }
}
