package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class CHECK_IN {
    private String cmd;
    private ID id;
    private ID sdid;
    private DEVICE device;
    private SDK sdk;
    private String seq;

    public CHECK_IN(String cmd, ID id, ID sdid, DEVICE device, SDK sdk, String seq) {
        this.cmd = cmd;
        this.id = id;
        this.sdid = sdid;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
    }

    public CHECK_IN() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public ID getId() {
        return id;
    }

    public void setId(ID id) {
        this.id = id;
    }

    public ID getSdid() {
        return sdid;
    }

    public void setSdid(ID sdid) {
        this.sdid = sdid;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Override
    public String toString() {
        return "CHECK_IN{" +
                "cmd='" + cmd + '\'' +
                ", id=" + id +
                ", sdid=" + sdid +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                '}';
    }
}
