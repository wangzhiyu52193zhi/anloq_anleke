package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class NEGOTIATIONNEED_REC {
    private String cmd;
    private DEVICE device;
    private SDK sdk;
    private String seq;
    private int status;
    private String errorcode;

    public NEGOTIATIONNEED_REC(String cmd, DEVICE device, SDK sdk, String seq, int status, String errorCode) {
        this.cmd = cmd;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
        this.status = status;
        this.errorcode = errorCode;
    }

    public NEGOTIATIONNEED_REC() {
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getErrorCode() {
        return errorcode;
    }

    public void setErrorCode(String errorCode) {
        this.errorcode = errorCode;
    }

    @Override
    public String toString() {
        return "NEGOTIATIONNEED_REC{" +
                "cmd='" + cmd + '\'' +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                ", status=" + status +
                ", errorCode='" + errorcode + '\'' +
                '}';
    }
}
