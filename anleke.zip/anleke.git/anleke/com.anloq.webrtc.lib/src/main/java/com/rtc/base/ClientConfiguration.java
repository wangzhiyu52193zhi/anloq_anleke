package com.rtc.base;

import org.webrtc.PeerConnection;

import java.util.ArrayList;
import java.util.List;

public abstract class ClientConfiguration {
    private List<PeerConnection.IceServer> iceServers = new ArrayList();

    public void setIceServers(List<PeerConnection.IceServer> iceServers)
            throws WoogeenIllegalArgumentException {
        if (iceServers == null)
            throw new WoogeenIllegalArgumentException("Ice servers cannot be null.");
        this.iceServers = iceServers;
    }

    public List<PeerConnection.IceServer> getIceServers() {
        return this.iceServers;
    }
}