package com.common;

/**
 * Created by arhuang75 on 17/2/7.
 */

public class MEMBER_ASK {
    private String cmd;
    private ID callerid;
    private String chattype;
    private String sessionid;
    private ID sdid;
    private DEVICE device;
    private SDK sdk;
    private String seq;

    public MEMBER_ASK(String cmd, ID callerId, String chatType, String sessionId, ID sdid, DEVICE device, SDK sdk, String seq) {
        this.cmd = cmd;
        this.callerid = callerId;
        this.chattype = chatType;
        this.sessionid = sessionId;
        this.sdid = sdid;
        this.device = device;
        this.sdk = sdk;
        this.seq = seq;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public ID getCallerId() {
        return callerid;
    }

    public void setCallerId(ID callerId) {
        this.callerid = callerId;
    }

    public String getChatType() {
        return chattype;
    }

    public void setChatType(String chatType) {
        this.chattype = chatType;
    }

    public String getSessionId() {
        return sessionid;
    }

    public void setSessionId(String sessionId) {
        this.sessionid = sessionId;
    }

    public ID getSdid() {
        return sdid;
    }

    public void setSdid(ID sdid) {
        this.sdid = sdid;
    }

    public DEVICE getDevice() {
        return device;
    }

    public void setDevice(DEVICE device) {
        this.device = device;
    }

    public SDK getSdk() {
        return sdk;
    }

    public void setSdk(SDK sdk) {
        this.sdk = sdk;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    @Override
    public String toString() {
        return "MEMBER_ASK{" +
                "cmd='" + cmd + '\'' +
                ", callerId=" + callerid +
                ", chatType='" + chattype + '\'' +
                ", sessionId='" + sessionid + '\'' +
                ", sdid=" + sdid +
                ", device=" + device +
                ", sdk=" + sdk +
                ", seq='" + seq + '\'' +
                '}';
    }
}
