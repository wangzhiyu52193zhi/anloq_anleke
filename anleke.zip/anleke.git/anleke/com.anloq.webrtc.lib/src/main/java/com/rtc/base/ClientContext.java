package com.rtc.base;


//public class ClientContext {
//
//    public static void setApplicationContext(Context ctx) {
//        PeerConnectionChannel.init(ctx);
//    }
//
//    public static void setCodecHardwareAccelerationEnabled(MediaCodec.VideoCodec codec, boolean enabled) {
//        PCFactory.setCodecHardwareAccelerationEnabled(codec, enabled);
//    }
//
//    public static void setVideoHardwareAccelerationOptions(EglBase.Context eglctx) {
//        PCFactory.setVideohwAccopt(eglctx);
//    }
//}
import android.content.Context;
import com.rtc.base.MediaCodec.VideoCodec;

public class ClientContext {
    private static boolean eglContextSet = false;
    private static final Object contextLock = new Object();
    private static boolean customizedVideoEncoderEnabled = false;
    private static final Object encoderLock = new Object();

    public ClientContext() {
    }

    public static void setApplicationContext(Context ctx) {
        PeerConnectionChannel.init(ctx);
    }

    public static void setCodecHardwareAccelerationEnabled(VideoCodec codec, boolean enabled) {
        PCFactory.setCodecHardwareAccelerationEnabled(codec, enabled);
    }

    /** @deprecated */
    @Deprecated
    public static void setVideoHardwareAccelerationOptions(org.webrtc.EglBase.Context eglctx) {
        setVideoHardwareAccelerationOptions(eglctx, eglctx);
    }

    public static void setVideoHardwareAccelerationOptions(org.webrtc.EglBase.Context localEglCtx, org.webrtc.EglBase.Context remoteEglCtx) {
        PCFactory.setVideoHardwareAccelerationOptions(localEglCtx, remoteEglCtx);
        Object var2 = contextLock;
        synchronized(contextLock) {
            eglContextSet = true;
        }
    }

    public static void enableCustomizedVideoEncoder() {
        PCFactory.enableCustomizedVideoEncoder();
        Object var0 = encoderLock;
        synchronized(encoderLock) {
            customizedVideoEncoderEnabled = true;
        }
    }

    static boolean isCustomizedVideoEncoderEnabled() {
        Object var0 = encoderLock;
        synchronized(encoderLock) {
            return customizedVideoEncoderEnabled;
        }
    }

    public static void addIgnoreNetworkType(ClientContext.NetworkType ignoreNetworkType) {
        PCFactory.networkIgnoreMask |= ignoreNetworkType.value;
    }

    static boolean getEglContextSet() {
        Object var0 = contextLock;
        synchronized(contextLock) {
            return eglContextSet;
        }
    }

    public static enum NetworkType {
        ETHERNET(1),
        WIFI(2),
        CELLULAR(4),
        VPN(8),
        LOOPBACK(16);

        private int value;

        private NetworkType(int v) {
            this.value = v;
        }
    }
}
